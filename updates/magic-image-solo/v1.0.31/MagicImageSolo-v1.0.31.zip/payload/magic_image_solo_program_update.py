#!/usr/bin/env python3
"""Verified, unattended program updater for Magic Image.

The updater deliberately has a much smaller scope than a media rebuild: it
only replaces a fixed allow-list of program modules.  Models, Config folders,
Wi-Fi profiles, Clonezilla images and all user settings are never part of a
program package.  A public HTTPS URL works without credentials.  A private
GitHub source can optionally use a dedicated, read-only token from a local
source descriptor; tokens are never included in update packages or logs.
"""

from __future__ import annotations

from dataclasses import dataclass
import datetime as dt
import hashlib
import io
import json
import os
import pathlib
import re
import shutil
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from typing import Callable


DEFAULT_PROGRAM_MANIFEST_URL = (
    "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/main/"
    "updates/magic-image-solo/stable/update_manifest.json"
)
STATE_FILENAME = "magic-image-solo-program-update-state.json"
SOURCE_FILENAME = "magic-image-solo-program-source.json"
STAGING_DIRECTORY = pathlib.Path("updates") / "magic-image-solo" / "staging"
BACKUP_DIRECTORY = pathlib.Path("updates") / "magic-image-solo" / "backups"
SUCCESS_CHECK_INTERVAL = dt.timedelta(hours=24)
FAILURE_RETRY_INTERVAL = dt.timedelta(minutes=10)

# Program releases are intentionally unable to write any other file on an SSD.
ALLOWED_PROGRAM_FILES = frozenset(
    {
        "magic_image_solo_gui.py",
        "magic_image_manager.py",
        "model_database_update.py",
        "config_server_sync.py",
        "magic_image_solo_program_update.py",
        "hardwarecheck_v5_gui.py",
        "hardwarecheck_fast_gui.py",
    }
)


@dataclass(frozen=True)
class ProgramUpdateResult:
    checked: bool
    available: bool
    staged: bool
    message: str
    version: str = ""
    staging_dir: pathlib.Path | None = None


def _text(value: object) -> str:
    return str(value or "").strip()


def _read_json(path: pathlib.Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _flush_directory(directory: pathlib.Path) -> None:
    """Persist the renamed entry as well as its file data.

    The program lives on the writable FAT32 boot partition.  ``fsync`` on the
    temporary file alone is insufficient there: a power-off or reboot may
    otherwise leave the directory/FAT entry of ``os.replace`` only in cache.
    Directory syncing is not available on every platform, hence the guarded
    implementation; Linux live systems support it and additionally expose
    ``os.sync`` for the final device-wide flush.
    """

    try:
        descriptor = os.open(str(directory), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(descriptor)
    except OSError:
        pass
    finally:
        os.close(descriptor)


def _flush_filesystem(directory: pathlib.Path) -> None:
    _flush_directory(directory)
    sync = getattr(os, "sync", None)
    if callable(sync):
        sync()


def _write_bytes_atomic(path: pathlib.Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.new")
    try:
        with temporary.open("wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        _flush_filesystem(path.parent)
        # A successful rename alone is not enough on FAT32.  Read the exact
        # bytes back after the storage flush, so an interrupted/corrupt write
        # never gets reported as an installed program update.
        if _sha256_file(path) != _sha256_bytes(payload):
            raise OSError(f"Geschriebene Datei konnte nicht verifiziert werden: {path.name}")
    finally:
        try:
            temporary.unlink()
        except OSError:
            pass


def _write_json_atomic(path: pathlib.Path, value: dict[str, object]) -> None:
    _write_bytes_atomic(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _sha256_file(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(128 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _https_url(value: object) -> str:
    text = _text(value)
    try:
        parsed = urllib.parse.urlparse(text)
    except ValueError:
        return ""
    return text if parsed.scheme == "https" and bool(parsed.netloc) else ""


def _is_sha256(value: object) -> bool:
    return bool(re.fullmatch(r"[A-Fa-f0-9]{64}", _text(value)))


def _version_is_newer(remote: str, local: str) -> bool:
    remote_parts = [int(value) for value in re.findall(r"\d+", remote)]
    local_parts = [int(value) for value in re.findall(r"\d+", local)]
    width = max(len(remote_parts), len(local_parts), 1)
    remote_parts.extend([0] * (width - len(remote_parts)))
    local_parts.extend([0] * (width - len(local_parts)))
    return remote_parts > local_parts


def _parse_time(value: object) -> dt.datetime | None:
    try:
        parsed = dt.datetime.fromisoformat(_text(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)


def _now_iso(now: dt.datetime) -> str:
    return now.astimezone(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _safe_version(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._") or "unknown"


def program_manifest_url(root: pathlib.Path) -> str:
    """Use the shared public update endpoint; allow a future HTTPS server."""

    configured = _read_json(pathlib.Path(root) / SOURCE_FILENAME)
    return _https_url(configured.get("manifest_url")) or DEFAULT_PROGRAM_MANIFEST_URL


def program_access_token(root: pathlib.Path) -> str:
    """Read an optional *local* GitHub token without persisting or logging it."""

    configured = _read_json(pathlib.Path(root) / SOURCE_FILENAME)
    return _text(configured.get("github_token")) or _text(configured.get("access_token"))


def download_bytes(url: str, timeout: int = 20, *, access_token: str = "") -> bytes:
    headers = {"User-Agent": "MagicImageSolo-Updater/1.0"}
    if access_token:
        # GitHub accepts this header both for the contents API and raw files.
        # Never add the token to an URL, error message, state file or log.
        headers["Authorization"] = f"Bearer {access_token}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _defer(
    state: dict[str, object],
    url: str,
    now: dt.datetime,
    *,
    retry_failed_check: bool = False,
) -> bool:
    if _text(state.get("manifest_url")) != url:
        return False
    last_success = _parse_time(state.get("last_success_utc"))
    # Portable media moves between machines with different RTC settings.
    # A timestamp in the future must never suppress updates for months.
    if last_success and dt.timedelta(0) <= now - last_success < SUCCESS_CHECK_INTERVAL:
        return True
    last_attempt = _parse_time(state.get("last_attempt_utc"))
    return bool(
        not retry_failed_check
        and last_attempt
        and dt.timedelta(0) <= now - last_attempt < FAILURE_RETRY_INTERVAL
    )


def _save_state(root: pathlib.Path, url: str, now: dt.datetime, *, ok: bool, version: str = "") -> None:
    state = _read_json(root / STATE_FILENAME)
    state.update({"manifest_url": url, "last_attempt_utc": _now_iso(now), "last_result": "ok" if ok else "failed"})
    if ok:
        state.update({"last_success_utc": _now_iso(now), "version": version})
    try:
        _write_json_atomic(root / STATE_FILENAME, state)
    except OSError:
        pass


def _validate_package(directory: pathlib.Path, expected_version: str) -> tuple[bool, str, list[tuple[str, bytes]]]:
    manifest = _read_json(directory / "update_manifest.json")
    if _text(manifest.get("app")).lower() != "magic-image-solo":
        return False, "Paket gehört nicht zu Magic Image.", []
    if _text(manifest.get("version")) != expected_version:
        return False, "Paketversion stimmt nicht mit dem Manifest überein.", []
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        return False, "Paket enthält keine Dateiliste.", []
    checked: list[tuple[str, bytes]] = []
    seen: set[str] = set()
    for item in files:
        if not isinstance(item, dict):
            return False, "Ungültiger Dateieintrag im Paket.", []
        relative = _text(item.get("path"))
        if relative not in ALLOWED_PROGRAM_FILES or relative in seen:
            return False, f"Nicht erlaubte Paketdatei: {relative or '?' }", []
        expected_hash = _text(item.get("sha256"))
        if not _is_sha256(expected_hash):
            return False, f"Ungültige Prüfsumme für {relative}.", []
        payload_path = directory / "payload" / relative
        try:
            payload = payload_path.read_bytes()
        except OSError:
            return False, f"Paketdatei fehlt: {relative}.", []
        if _sha256_bytes(payload).lower() != expected_hash.lower():
            return False, f"Prüfsumme der Paketdatei stimmt nicht: {relative}.", []
        seen.add(relative)
        checked.append((relative, payload))
    return True, f"{len(checked)} Programmdatei(en) geprüft.", checked


def _safe_extract(payload: bytes, destination: pathlib.Path) -> None:
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        for item in archive.infolist():
            path = pathlib.PurePosixPath(item.filename)
            if path.is_absolute() or ".." in path.parts:
                raise ValueError("ZIP enthält einen unsicheren Pfad")
        archive.extractall(destination)


def find_staged_program_update(root: pathlib.Path, current_version: str) -> ProgramUpdateResult | None:
    """Return a previously verified newer package, without using the network.

    This closes the small but important gap between staging an update while an
    operator is working and the following start: the next launch must activate
    that already verified package even though the daily network check is still
    throttled.
    """

    staged_root = pathlib.Path(root) / STAGING_DIRECTORY
    try:
        candidates = [entry for entry in staged_root.iterdir() if entry.is_dir()]
    except OSError:
        return None

    best_version = ""
    best_path: pathlib.Path | None = None
    for candidate in candidates:
        version = candidate.name
        if not _version_is_newer(version, current_version):
            continue
        valid, _message, _files = _validate_package(candidate, version)
        if not valid:
            continue
        if not best_path or _version_is_newer(version, best_version):
            best_version, best_path = version, candidate
    if not best_path:
        return None
    return ProgramUpdateResult(
        False,
        True,
        True,
        f"Vorbereitetes Programm-Update gefunden: {best_version}.",
        best_version,
        best_path,
    )


def stage_program_update(
    root: pathlib.Path,
    current_version: str,
    *,
    force: bool = False,
    retry_failed_check: bool = False,
    now: dt.datetime | None = None,
    fetch: Callable[[str], bytes] | None = None,
) -> ProgramUpdateResult:
    """Check, verify and stage a release without altering program files."""

    root = pathlib.Path(root)
    current_time = now or dt.datetime.now(dt.timezone.utc)
    if current_time.tzinfo is None:
        current_time = current_time.replace(tzinfo=dt.timezone.utc)
    url = program_manifest_url(root)
    state = _read_json(root / STATE_FILENAME)
    staged = find_staged_program_update(root, current_version)
    if not force and _defer(state, url, current_time, retry_failed_check=retry_failed_check):
        # A package which was already verified remains installable while the
        # normal daily check is deferred. A manual check deliberately skips
        # this branch so a same-day hotfix can replace an older staged build.
        return staged or ProgramUpdateResult(False, False, False, "Programmprüfung bereits aktuell.")
    access_token = program_access_token(root)
    fetch_bytes = fetch or (lambda remote_url: download_bytes(remote_url, access_token=access_token))
    try:
        remote_raw = fetch_bytes(url)
        manifest = json.loads(remote_raw.decode("utf-8-sig"))
        if not isinstance(manifest, dict) or _text(manifest.get("app")).lower() != "magic-image-solo":
            raise ValueError("Programm-Manifest ist ungültig")
        version = _text(manifest.get("version"))
        package_url = _https_url(manifest.get("download_url"))
        package_hash = _text(manifest.get("sha256"))
        if not version or not package_url or not _is_sha256(package_hash):
            raise ValueError("Programm-Manifest ist unvollständig")
        if not _version_is_newer(version, current_version):
            _save_state(root, url, current_time, ok=True, version=current_version)
            # Do not discard a previously verified newer package merely
            # because a server temporarily reports an older manifest.
            return staged or ProgramUpdateResult(True, False, False, "Programm ist aktuell.", current_version)
        if staged and staged.version == version:
            _save_state(root, url, current_time, ok=True, version=version)
            return ProgramUpdateResult(
                True,
                True,
                True,
                f"Programm-Update bereit: {version}.",
                version,
                staged.staging_dir,
            )
        package = fetch_bytes(package_url)
        if _sha256_bytes(package).lower() != package_hash.lower():
            raise ValueError("Prüfsumme des Programm-Pakets stimmt nicht")
        stage = root / STAGING_DIRECTORY / _safe_version(version)
        if stage.exists():
            shutil.rmtree(stage, ignore_errors=True)
        stage.mkdir(parents=True, exist_ok=True)
        _safe_extract(package, stage)
        valid, message, _files = _validate_package(stage, version)
        if not valid:
            raise ValueError(message)
        _save_state(root, url, current_time, ok=True, version=version)
        return ProgramUpdateResult(True, True, True, f"Programm-Update bereit: {version}. {message}", version, stage)
    except (OSError, TimeoutError, urllib.error.URLError, UnicodeDecodeError, json.JSONDecodeError, ValueError, zipfile.BadZipFile) as exc:
        _save_state(root, url, current_time, ok=False)
        return ProgramUpdateResult(True, False, False, f"Programmupdate übersprungen: {exc}")


def apply_staged_program_update(root: pathlib.Path, staging_dir: pathlib.Path, version: str) -> ProgramUpdateResult:
    """Atomically replace only verified allowed files and retain a rollback copy."""

    root, staging_dir = pathlib.Path(root), pathlib.Path(staging_dir)
    valid, message, files = _validate_package(staging_dir, version)
    if not valid:
        return ProgramUpdateResult(True, True, False, message, version, staging_dir)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = root / BACKUP_DIRECTORY / f"{stamp}_{_safe_version(version)}"
    changed: list[tuple[pathlib.Path, pathlib.Path]] = []
    try:
        backup.mkdir(parents=True, exist_ok=True)
        for relative, payload in files:
            target = root / relative
            saved = backup / relative
            if target.is_file():
                shutil.copy2(target, saved)
            _write_bytes_atomic(target, payload)
            changed.append((target, saved))
        return ProgramUpdateResult(True, True, True, f"Programm aktualisiert: {version}.", version, staging_dir)
    except OSError as exc:
        for target, saved in reversed(changed):
            try:
                if saved.is_file():
                    _write_bytes_atomic(target, saved.read_bytes())
            except OSError:
                pass
        return ProgramUpdateResult(True, True, False, f"Programmupdate zurückgesetzt: {exc}", version, staging_dir)
