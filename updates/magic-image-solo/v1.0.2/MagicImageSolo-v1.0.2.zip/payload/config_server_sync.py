#!/usr/bin/env python3
"""Small, integrity-checked on-demand synchronisation for ``#configs``.

This module deliberately uses only the Python standard library.  A bootable
installer must never carry an administrator password.  The optional endpoint
is therefore HTTPS-only and read-only from the client point of view.  A server
can publish a compact manifest and one ZIP bundle per four-digit config.

The normal Magic Image validation remains local and immediate.  This helper is
called in a background thread after a four-digit config was entered; it only
downloads a package if that precise config is missing or newer than the local
copy.  All downloaded files are SHA-256 checked and staged before replacing an
existing config folder.
"""

from __future__ import annotations

from dataclasses import dataclass
from contextlib import contextmanager
import hashlib
import http.client
import io
import json
import os
import pathlib
import re
import shutil
import ssl
import subprocess
import tempfile
import time
from typing import Any, Iterable
from urllib.parse import urljoin, urlparse
import zipfile


SETTINGS_FILENAME = "config-server-settings.json"
STATE_FILENAME = "config-server-state.json"
OVERRIDES_FILENAME = "config-server-model-overrides.json"
MARKER_FILENAME = ".hardwarecheck-config-server.json"
MAX_MANIFEST_BYTES = 2 * 1024 * 1024
MAX_BUNDLE_BYTES = 64 * 1024 * 1024
MAX_ZIP_UNPACKED_BYTES = 128 * 1024 * 1024
CONFIG_RE = re.compile(r"\d{4}\Z")
SHA256_RE = re.compile(r"[0-9a-f]{64}\Z", re.IGNORECASE)


@dataclass(frozen=True)
class ConfigServerSettings:
    enabled: bool = False
    endpoint: str = ""
    certificate_sha256: str = ""
    check_interval_hours: int = 12


@dataclass(frozen=True)
class ConfigSyncResult:
    config: str
    attempted: bool
    changed: bool
    available: bool
    message: str
    version: str = ""
    error: str = ""


def _safe_text(value: object) -> str:
    return str(value or "").strip()


def settings_path(client_root: pathlib.Path) -> pathlib.Path:
    return client_root / SETTINGS_FILENAME


def state_path(client_root: pathlib.Path) -> pathlib.Path:
    return client_root / STATE_FILENAME


def overrides_path(client_root: pathlib.Path) -> pathlib.Path:
    return client_root / OVERRIDES_FILENAME


def _atomic_json_write(path: pathlib.Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    staged = path.with_name(f".{path.name}.new-{os.getpid()}-{time.time_ns()}")
    try:
        staged.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        # Windows does not allow fsync on a read-only descriptor.
        with staged.open("r+b") as handle:
            os.fsync(handle.fileno())
        os.replace(staged, path)
    finally:
        if staged.exists():
            try:
                staged.unlink()
            except OSError:
                pass


def load_settings(client_root: pathlib.Path) -> ConfigServerSettings:
    defaults = ConfigServerSettings()
    try:
        raw = json.loads(settings_path(client_root).read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return defaults
    if not isinstance(raw, dict):
        return defaults
    endpoint = _safe_text(raw.get("endpoint"))
    pin = re.sub(r"[^0-9A-Fa-f]", "", _safe_text(raw.get("certificate_sha256"))).lower()
    try:
        interval = int(raw.get("check_interval_hours") or defaults.check_interval_hours)
    except (TypeError, ValueError):
        interval = defaults.check_interval_hours
    return ConfigServerSettings(
        enabled=bool(raw.get("enabled")),
        endpoint=endpoint,
        certificate_sha256=pin if SHA256_RE.fullmatch(pin) else "",
        check_interval_hours=max(1, min(168, interval)),
    )


def save_settings(client_root: pathlib.Path, settings: ConfigServerSettings) -> None:
    endpoint = _normalise_endpoint(settings.endpoint) if settings.endpoint else ""
    pin = re.sub(r"[^0-9A-Fa-f]", "", settings.certificate_sha256).lower()
    if pin and not SHA256_RE.fullmatch(pin):
        raise ValueError("Der Zertifikat-Fingerprint muss aus 64 Hex-Zeichen bestehen.")
    _atomic_json_write(
        settings_path(client_root),
        {
            "enabled": bool(settings.enabled),
            "endpoint": endpoint,
            "certificate_sha256": pin,
            "check_interval_hours": max(1, min(168, int(settings.check_interval_hours))),
        },
    )


def _normalise_endpoint(value: object) -> str:
    endpoint = _safe_text(value).rstrip("/")
    parsed = urlparse(endpoint)
    if parsed.scheme.lower() != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Config-Server muss eine vollständige HTTPS-Adresse ohne Zugangsdaten sein.")
    if parsed.query or parsed.fragment:
        raise ValueError("Config-Server-Adresse darf keine Parameter oder Fragmente enthalten.")
    return endpoint


def _read_json(path: pathlib.Path) -> dict[str, Any]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return {}
    return raw if isinstance(raw, dict) else {}


def load_model_overrides(client_root: pathlib.Path, device_type: str = "") -> list[dict[str, object]]:
    raw = _read_json(overrides_path(client_root))
    items = raw.get("models") if isinstance(raw.get("models"), list) else []
    wanted = _safe_text(device_type).lower()
    result: list[dict[str, object]] = []
    for item in items:
        if not isinstance(item, dict) or not CONFIG_RE.fullmatch(_safe_text(item.get("model_id"))):
            continue
        item_type = _safe_text(item.get("device_type")).lower()
        if wanted and item_type and item_type != wanted:
            continue
        result.append(dict(item))
    return result


def merge_model_overrides(models: Iterable[dict[str, object]], client_root: pathlib.Path, device_type: str = "") -> list[dict[str, object]]:
    merged: dict[str, dict[str, object]] = {}
    for model in models:
        if isinstance(model, dict):
            key = _safe_text(model.get("model_id"))
            if key:
                merged[key] = dict(model)
    for model in load_model_overrides(client_root, device_type):
        merged[_safe_text(model.get("model_id"))] = model
    return list(merged.values())


def _request(settings: ConfigServerSettings, relative_url: str, headers: dict[str, str] | None, limit: int) -> tuple[int, bytes, dict[str, str]]:
    endpoint = _normalise_endpoint(settings.endpoint)
    relative = _safe_text(relative_url).lstrip("/")
    if not relative or ".." in pathlib.PurePosixPath(relative).parts:
        raise ValueError("Ungültiger Server-Pfad im Manifest.")
    target = urljoin(endpoint + "/", relative)
    parsed = urlparse(target)
    base = urlparse(endpoint)
    if parsed.scheme != "https" or parsed.hostname != base.hostname or parsed.port != base.port:
        raise ValueError("Manifest verweist außerhalb des konfigurierten Config-Servers.")
    connection = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, context=ssl.create_default_context(), timeout=10)
    try:
        request_headers = {"User-Agent": "HardwareCheck-ConfigSync/1", "Accept": "application/json, application/zip"}
        if headers:
            request_headers.update(headers)
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        connection.request("GET", path, headers=request_headers)
        response = connection.getresponse()
        if settings.certificate_sha256:
            certificate = connection.sock.getpeercert(binary_form=True) if connection.sock else b""
            digest = hashlib.sha256(certificate).hexdigest()
            if digest.lower() != settings.certificate_sha256.lower():
                raise ssl.SSLError("Zertifikat-Fingerprint des Config-Servers stimmt nicht überein.")
        body = response.read(limit + 1)
        if len(body) > limit:
            raise ValueError("Antwort des Config-Servers ist größer als zulässig.")
        return response.status, body, {key.lower(): value for key, value in response.getheaders()}
    finally:
        connection.close()


def _load_manifest(settings: ConfigServerSettings, client_root: pathlib.Path, force: bool) -> tuple[dict[str, Any], str, bool]:
    state = _read_json(state_path(client_root))
    cached = state.get("manifest") if isinstance(state.get("manifest"), dict) else {}
    last_checked = float(state.get("last_checked") or 0)
    interval = max(1, settings.check_interval_hours) * 3600
    if cached and not force and time.time() - last_checked < interval:
        return cached, _safe_text(state.get("etag")), False
    headers = {"If-None-Match": _safe_text(state.get("etag"))} if _safe_text(state.get("etag")) else {}
    status, body, response_headers = _request(settings, "manifest.json", headers, MAX_MANIFEST_BYTES)
    if status == 304 and cached:
        state["last_checked"] = time.time()
        _atomic_json_write(state_path(client_root), state)
        return cached, _safe_text(state.get("etag")), True
    if status != 200:
        raise OSError(f"Config-Server antwortet beim Manifest mit HTTP {status}.")
    try:
        manifest = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("Config-Server liefert kein gültiges JSON-Manifest.") from exc
    if not isinstance(manifest, dict) or not isinstance(manifest.get("configs"), dict):
        raise ValueError("Config-Server-Manifest enthält keine Config-Liste.")
    state = {"etag": _safe_text(response_headers.get("etag")), "last_checked": time.time(), "manifest": manifest}
    _atomic_json_write(state_path(client_root), state)
    return manifest, _safe_text(state.get("etag")), True


def _entry_for(manifest: dict[str, Any], config: str) -> dict[str, Any] | None:
    configs = manifest.get("configs")
    entry = configs.get(config) if isinstance(configs, dict) else None
    if not isinstance(entry, dict):
        return None
    digest = _safe_text(entry.get("sha256")).lower()
    url = _safe_text(entry.get("url"))
    version = _safe_text(entry.get("version"))
    if not version or not SHA256_RE.fullmatch(digest) or not url:
        raise ValueError(f"Server-Manifest für Config {config} ist unvollständig.")
    if not url.endswith(".zip"):
        raise ValueError(f"Server-Paket für Config {config} ist kein ZIP-Archiv.")
    return entry


def _local_marker(repository: pathlib.Path, config: str) -> dict[str, Any]:
    return _read_json(repository / "#configs" / config / MARKER_FILENAME)


def _is_current(repository_roots: Iterable[pathlib.Path], config: str, entry: dict[str, Any]) -> bool:
    expected_version, expected_digest = _safe_text(entry.get("version")), _safe_text(entry.get("sha256")).lower()
    for root in repository_roots:
        target = root / "#configs" / config
        if target.is_dir():
            marker = _local_marker(root, config)
            if _safe_text(marker.get("version")) == expected_version and _safe_text(marker.get("sha256")).lower() == expected_digest:
                return True
    return False


def _safe_extract_bundle(payload: bytes, config: str, target_root: pathlib.Path) -> pathlib.Path:
    staging_parent = pathlib.Path(tempfile.mkdtemp(prefix=f".server-config-{config}-", dir=str(target_root / "#configs")))
    try:
        total = 0
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            members = archive.infolist()
            expected_prefix = f"#configs/{config}/"
            if not members:
                raise ValueError("Config-Paket ist leer.")
            for member in members:
                name = member.filename.replace("\\", "/")
                parts = pathlib.PurePosixPath(name).parts
                if not name.startswith(expected_prefix) or name.startswith("/") or ".." in parts:
                    raise ValueError("Config-Paket enthält einen unzulässigen Pfad.")
                if (member.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError("Config-Paket darf keine symbolischen Links enthalten.")
                total += max(0, int(member.file_size))
                if total > MAX_ZIP_UNPACKED_BYTES:
                    raise ValueError("Config-Paket ist nach dem Entpacken zu groß.")
            for member in members:
                name = member.filename.replace("\\", "/")
                if name.endswith("/"):
                    continue
                destination = staging_parent / pathlib.PurePosixPath(name)
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member, "r") as source, destination.open("wb") as destination_handle:
                    shutil.copyfileobj(source, destination_handle, length=1024 * 1024)
        staged = staging_parent / "#configs" / config
        if not staged.is_dir():
            raise ValueError("Config-Paket enthält keinen erwarteten Config-Ordner.")
        return staged
    except Exception:
        shutil.rmtree(staging_parent, ignore_errors=True)
        raise


def _replace_config(repository: pathlib.Path, config: str, staged_config: pathlib.Path, entry: dict[str, Any]) -> None:
    configs = repository / "#configs"
    target = configs / config
    marker = staged_config / MARKER_FILENAME
    _atomic_json_write(marker, {"version": _safe_text(entry.get("version")), "sha256": _safe_text(entry.get("sha256")).lower(), "source": "config-server"})
    backup = configs / f".{config}.previous-{os.getpid()}-{time.time_ns()}"
    try:
        if target.exists():
            os.replace(target, backup)
        os.replace(staged_config, target)
    except Exception:
        if backup.exists() and not target.exists():
            os.replace(backup, target)
        raise
    finally:
        if backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        # ``staged_config`` is ``<temporary>/#configs/<id>``.  Remove only
        # that temporary root, never the repository's real ``#configs``.
        stage_root = staged_config.parents[1] if len(staged_config.parents) >= 2 else None
        if stage_root and stage_root.exists():
            shutil.rmtree(stage_root, ignore_errors=True)


def _save_model_override(client_root: pathlib.Path, model: object, config: str, device_type: str) -> None:
    if not isinstance(model, dict):
        return
    record = dict(model)
    if _safe_text(record.get("model_id")) != config:
        raise ValueError("Server-Modell gehört nicht zur angeforderten Config.")
    if device_type:
        record["device_type"] = device_type
    raw = _read_json(overrides_path(client_root))
    current = raw.get("models") if isinstance(raw.get("models"), list) else []
    result = [item for item in current if isinstance(item, dict) and _safe_text(item.get("model_id")) != config]
    result.append(record)
    _atomic_json_write(overrides_path(client_root), {"models": result})


@contextmanager
def _temporarily_writable_repository(repository: pathlib.Path):
    """Temporarily remount a verified Linux repository root read/write.

    The image partition is intentionally mounted read-only while the live
    system is running.  Updating a config is the one narrow exception.  This
    helper changes only the mount containing the already-detected repository,
    restores read-only mode afterwards, and never formats or touches images.
    """

    remounted = False
    if os.name == "posix":
        probe = subprocess.run(
            ["findmnt", "--noheadings", "--output", "OPTIONS", "--target", str(repository)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if probe.returncode == 0 and "ro" in {item.strip() for item in probe.stdout.strip().split(",")}:
            remount = subprocess.run(
                ["mount", "-o", "remount,rw", str(repository)],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
            if remount.returncode != 0:
                detail = _safe_text(remount.stderr) or "Mount konnte nicht beschreibbar eingehängt werden."
                raise OSError(f"Config-Repository ist schreibgeschützt: {detail}")
            remounted = True
    try:
        yield
    finally:
        if remounted:
            subprocess.run(
                ["mount", "-o", "remount,ro", str(repository)],
                text=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )


def sync_requested_config(
    config: str,
    repository_roots: Iterable[str],
    client_root: pathlib.Path,
    device_type: str = "",
) -> ConfigSyncResult:
    """Check exactly one config and replace it only after full verification.

    A disabled or not-yet-configured server never changes local behaviour.  A
    failed server request also preserves every local config folder.
    """

    config = _safe_text(config)
    roots = [pathlib.Path(item) for item in repository_roots if _safe_text(item)]
    local_exists = any((root / "#configs" / config).is_dir() for root in roots)
    if not CONFIG_RE.fullmatch(config):
        return ConfigSyncResult(config, False, False, local_exists, "Config ist nicht vierstellig.")
    settings = load_settings(client_root)
    if not settings.enabled or not settings.endpoint:
        return ConfigSyncResult(config, False, False, local_exists, "Config-Server ist nicht eingerichtet; lokale Config wird verwendet.")
    if not roots:
        return ConfigSyncResult(config, False, False, False, "Kein beschreibbares Image-Repository erkannt.")
    try:
        manifest, _etag, _fetched = _load_manifest(settings, client_root, force=not local_exists)
        entry = _entry_for(manifest, config)
        if entry is None:
            return ConfigSyncResult(config, True, False, local_exists, "Config ist auf dem Server nicht veröffentlicht.")
        version = _safe_text(entry.get("version"))
        if _is_current(roots, config, entry):
            return ConfigSyncResult(config, True, False, True, f"Config {config} ist aktuell ({version}).", version)
        status, bundle, _headers = _request(settings, _safe_text(entry.get("url")), None, MAX_BUNDLE_BYTES)
        if status != 200:
            raise OSError(f"Config-Paket antwortet mit HTTP {status}.")
        digest = hashlib.sha256(bundle).hexdigest().lower()
        if digest != _safe_text(entry.get("sha256")).lower():
            raise ValueError("SHA-256-Prüfsumme des Config-Pakets stimmt nicht überein.")
        selected_root = next((root for root in roots if (root / "#configs").is_dir()), roots[0])
        with _temporarily_writable_repository(selected_root):
            staged = _safe_extract_bundle(bundle, config, selected_root)
            _replace_config(selected_root, config, staged, entry)
        _save_model_override(client_root, entry.get("model"), config, _safe_text(entry.get("device_type")) or device_type)
        return ConfigSyncResult(config, True, True, True, f"Config {config} wurde vom Server aktualisiert ({version}).", version)
    except Exception as exc:
        return ConfigSyncResult(config, True, False, local_exists, "Config-Server konnte nicht aktualisieren; lokale Config bleibt unverändert.", error=_safe_text(exc))
