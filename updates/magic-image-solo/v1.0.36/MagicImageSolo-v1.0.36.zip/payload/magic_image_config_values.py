"""Pure value parsing for legacy Magic Image config text files."""

from __future__ import annotations

import re

from magic_image_text import text


_LEGACY_CONFIG_ID = re.compile(r"(?<!\d)(\d{4})(?!\d)")


def legacy_image_config_id(folder_name: object) -> str:
    """Return the first four-digit legacy-image config id, if one is present."""

    match = _LEGACY_CONFIG_ID.search(text(folder_name))
    return match.group(1) if match else ""


def number(value: object) -> float | None:
    match = re.search(r"[-+]?\d+(?:[.,]\d+)?", text(value))
    if not match:
        return None
    try:
        return float(match.group(0).replace(",", "."))
    except ValueError:
        return None


def ssd_capacity_gb(value: object) -> int | None:
    raw = number(value)
    if raw is None or raw <= 0:
        return None
    capacities = (128, 256, 512, 1000, 2000, 4000)
    capacity = min(capacities, key=lambda item: min(abs(raw - item), abs(raw - (item * 0.931))))
    tolerance = max(16.0, capacity * 0.10)
    return capacity if min(abs(raw - capacity), abs(raw - (capacity * 0.931))) <= tolerance else int(round(raw))


def ram_capacity_gb(value: object) -> int | None:
    raw = number(value)
    if raw is None or raw <= 0:
        return None
    common_sizes = (4, 8, 12, 16, 20, 24, 32, 40, 48, 64)
    reserved_capacity = next((capacity for capacity in common_sizes if capacity * 0.75 <= raw <= capacity), None)
    if reserved_capacity is not None:
        return reserved_capacity
    capacity = min(common_sizes, key=lambda item: abs(raw - item))
    return capacity if abs(raw - capacity) <= 1.0 else int(round(raw))


def profile_from_values(model_id: object, values: dict[str, object]) -> dict[str, object]:
    """Build a config profile from already-read legacy text values.

    The caller owns filesystem access.  Empty or untrustworthy values are not
    invented here, so the safety layer can require a manual confirmation.
    """

    identifier = text(model_id)
    profile: dict[str, object] = {"model_id": identifier, "_source": "config-folder"}
    cpu = text(values.get("CPU.txt"))
    if cpu:
        profile["cpu"] = cpu
    ram_total = ram_capacity_gb(values.get("RAM.txt"))
    if ram_total is not None:
        profile["ram_total"] = ram_total
    ssd = ssd_capacity_gb(values.get("driveCsize.txt"))
    if ssd is not None:
        profile["ssd"] = ssd
    resolution = text(values.get("resolution.txt"))
    if resolution:
        profile["display_type"] = resolution
    inches = number(values.get("physical-display-size.txt"))
    if inches is not None and inches > 0:
        profile["inch"] = inches
    modules = number(values.get("ram-modules-amount.txt"))
    if modules is not None and modules > 0 and modules.is_integer():
        profile["ram_module_count"] = int(modules)
    return profile if len(profile) > 2 else {}


def storage_capacities_equivalent(actual: object, expected: object) -> bool:
    """Return whether common manufacturer/usable SSD sizes mean the same disk."""

    actual_value = number(actual)
    expected_value = number(expected)
    if actual_value is None or expected_value is None or actual_value <= 0 or expected_value <= 0:
        return False
    actual_size, expected_size = int(round(actual_value)), int(round(expected_value))
    if actual_size == expected_size:
        return True
    groups = (
        {120, 128},
        {240, 250, 256},
        {480, 500, 512},
        {960, 1000, 1024},
        {1920, 2000, 2048},
        {3840, 4000, 4096},
    )
    return any(actual_size in group and expected_size in group for group in groups)
