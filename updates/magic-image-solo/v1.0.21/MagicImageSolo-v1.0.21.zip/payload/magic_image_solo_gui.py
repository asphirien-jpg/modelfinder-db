#!/usr/bin/env python3
"""Focused, full-screen Magic Image installer for the standalone Solo medium.

The proven HardwareCheck core supplies hardware recognition, Wi-Fi and the
Clonezilla restore proof.  This module deliberately exposes only the short
Magic Image workflow: device type, config, image and target SSD.
"""

from __future__ import annotations

import datetime
import json
import os
import pathlib
import re
import subprocess
import sys
import threading
import traceback
from typing import Any

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GLib, GdkPixbuf, Gtk, Pango  # noqa: E402

import magic_image_manager as magic  # noqa: E402
import model_database_update as model_database_update  # noqa: E402
import magic_image_solo_program_update as program_update  # noqa: E402

# The deployed Solo medium carries this small helper beside this launcher.  The
# fallback also makes a checkout of the combined repository executable without
# duplicating the security-critical synchronisation implementation.
try:
    import config_server_sync as config_sync  # noqa: E402
except ModuleNotFoundError:  # pragma: no cover - only used from the source tree
    _core_source = pathlib.Path(__file__).resolve().parents[1] / "HardwareCheck_DEV"
    if str(_core_source) not in sys.path:
        sys.path.insert(0, str(_core_source))
    import config_server_sync as config_sync  # type: ignore[no-redef] # noqa: E402


APP_VERSION = "v1.0.21"
SCRIPT_DIR = pathlib.Path(__file__).resolve().parent
SETTINGS_FILE = SCRIPT_DIR / "magic-image-solo-settings.json"
LAPTOP_DATABASE_FILE = SCRIPT_DIR / "models-laptops.json"
PC_DATABASE_FILE = SCRIPT_DIR / "models-pcs.json"
MANIFEST_FILE = SCRIPT_DIR / "model_manifest_local.json"

LANGUAGES = ("DE", "CZ", "EN")
LAYOUTS = (
    "original", "service-light", "workshop-pro", "blue-control", "service-desk",
    "workshop-console", "studio-panels",
)

TEXT = {
    "DE": {
        "app": "Magic Image", "version": "Standalone-Installer", "device_type": "Gerätetyp",
        "notebook": "Notebook", "computer": "Computer", "clonezilla": "Clonezilla",
        "refresh": "Aktualisieren", "checking_media": "Clonezilla wird geprüft …",
        "clonezilla_ready": "Clonezilla bereit", "clonezilla_error": "Clonezilla nicht bereit",
        "config": "Config", "four_digits": "vierstellig", "enter_config": "Config eingeben",
        "four_digits_only": "Bitte vier Ziffern eingeben.", "hardware_wait": "Hardware wird noch gelesen …",
        "image_and_target": "Image und Ziel", "image": "Magic Image", "choose_image": "Magic Image auswählen",
        "target": "Ziel-SSD", "choose_target": "Interne Ziel-SSD auswählen", "status": "Sicherheitsstatus",
        "data_disk": "Daten-HDD (optional)", "choose_data_disk": "Keine Daten-HDD vorbereiten",
        "data_disk_hint": "Optional: zweite HDD vollständig leeren und als NTFS-Datenplatte vorbereiten.",
        "data_disk_unselected": "nicht ausgewählt (bleibt unverändert)",
        "data_disk_confirm": "Zusätzliche Daten-HDD: {disk}\nSie wird vollständig gelöscht und als leere NTFS-Datenplatte „{label}“ vorbereitet.",
        "install": "Jetzt installieren …", "config_unchecked": "noch nicht geprüft",
        "image_unselected": "noch nicht gewählt", "target_unselected": "noch nicht gewählt",
        "ready": "Bereit zur Installation", "not_ready": "Installation noch nicht bereit",
        "config_matches": "Config passt zum Gerät.", "config_attention": "Config bitte prüfen.",
        "config_unavailable": "Keine passende Config vorhanden.",
        "complete_image": "Clonezilla-Komplettimage",
        "complete_image_found": "Clonezilla-Image gefunden.",
        "complete_image_workflow": "Das vorhandene Windows-Skript im Image bleibt unverändert. Keine externe Config-Übergabe und keine Übernahme externer Treiber.",
        "complete_image_choose": "Clonezilla-Komplettimage auswählen",
        "complete_image_confirm": "Komplettimage für Modell {config}: Kein Hardwarevergleich vor der Installation. Prüfen Sie die Modellnummer bewusst. Der im Image vorhandene ModelCheck startet nach Windows. Es wird keine externe Config übergeben.",
        "legacy_config_without_model": "#configs\\{config} ist vorhanden, aber model.json hat keine Hardwaredaten. Kein automatischer Hardwarevergleich – nur nach bewusster Bestätigung.",
        "database_active": "{device}-Datenbank aktiv · {count} Configs",
        "database_empty": "{device}-Datenbank aktiv · noch keine Configs",
        "hardware_error": "Hardware konnte nicht gelesen werden.", "check_config": "Config bitte prüfen",
        "attention": "ACHTUNG: Config bitte prüfen", "detected_differences": "Erkannte Abweichungen:",
        "change_config": "Config ändern", "confirm_difference": "Abweichung bewusst bestätigen",
        "difference_confirmed": "Abweichung bestätigt.", "install_unavailable": "Installation nicht verfügbar",
        "no_config": "Keine passende Config auf dem Medium gefunden.", "close": "Schließen",
        "classic_acronis_found": "Keine moderne Magic-Config gefunden. Klassisches Acronis-Image vorhanden.",
        "no_config_or_acronis": "Keine moderne Magic-Config, kein Clonezilla-Komplettimage und kein klassisches Acronis-Image gefunden.",
        "start_acronis": "Acronis starten", "acronis_manual_title": "Acronis manuell öffnen",
        "acronis_manual_text": "Das Gerät startet einmalig in Acronis neu. Dort wählen Sie Image und Ziel wie gewohnt selbst aus. Es wird kein Image automatisch wiederhergestellt.",
        "restart_now": "Jetzt neu starten", "acronis_start_failed": "Acronis konnte nicht gestartet werden",
        "acronis_reboot_failed": "Acronis wurde vorbereitet, aber der Neustart konnte nicht ausgelöst werden.",
        "confirm_install": "Installation endgültig bestätigen",
        "confirmation_changed": "Die Installationsauswahl wurde aktualisiert. Bitte erneut prüfen und bestätigen.",
        "confirm_text": "Config: {config}\nImage: {image}\nZiel: {target}\n\nDie ausgewählte SSD wird vollständig gelöscht.",
        "cancel": "Abbrechen", "continue": "Installieren", "preparing": "Clonezilla wird vorbereitet …",
        "after_restore": "Nach erfolgreichem Restore:", "start_windows": "Windows automatisch starten",
        "shutdown_device": "Gerät ausschalten", "windows_starting": "Windows wird automatisch gestartet …",
        "device_shutting_down": "Gerät wird automatisch ausgeschaltet …",
        "options": "Optionen", "language": "Sprache", "layout": "Layout", "wifi": "WLAN",
        "workshop_mode": "Arbeitsmodus", "workshop_mode_hint": "Beim nächsten Programmstart wird die gewählte Oberfläche geöffnet.",
        "workshop_mode_magic": "Magic Image", "workshop_mode_hardwarecheck": "HardwareCheck",
        "workshop_mode_saved": "{mode} wird beim nächsten Start geöffnet.", "workshop_mode_save_failed": "Arbeitsmodus konnte nicht gespeichert werden.",
        "program_updates": "Programm-Updates", "program_update_hint": "Automatisch höchstens einmal in 24 Stunden. Die manuelle Prüfung startet sofort.",
        "program_update_check": "Jetzt nach Updates suchen", "program_update_checking": "Programm-Update wird geprüft …",
        "program_update_busy": "Programm-Update wird bereits geprüft.", "program_update_current": "Programm ist aktuell.",
        "program_update_ready": "Programm-Update {version} ist bereit.",
        "program_update_downloaded": "Programm-Update {version} wurde heruntergeladen und geprüft. Jetzt installieren.",
        "program_update_failed": "Update-Prüfung fehlgeschlagen: {reason}",
        "program_update_question": "Version {version} wurde vollständig geprüft. Jetzt installieren und Magic Image neu starten?",
        "program_update_install": "Jetzt installieren", "program_update_install_ready": "Update {version} installieren", "program_update_later": "Später",
        "program_update_prepared": "Programm-Update {version} ist vorbereitet und wird beim nächsten Start aktiviert.",
        "program_update_restarting": "Programm-Update {version} wird installiert. Magic Image startet neu …",
        "program_update_alert": "UPDATE VERFÜGBAR: {version}", "program_update_alert_tooltip": "Zu den Programm-Updates in den Optionen wechseln",
        "program_update_alert_test": "Update-Hinweis testen",
        "wifi_offline": "WLAN nicht verbunden", "wifi_connecting": "WLAN verbindet …",
        "wifi_choose": "WLAN auswählen", "wifi_refresh": "Netze suchen", "wifi_no_adapter": "Kein WLAN-Adapter gefunden.",
        "wifi_no_networks": "Keine WLAN-Netze gefunden.", "wifi_saved": "gespeichert", "wifi_connected": "verbunden",
        "wifi_password": "Passwort für {ssid}", "wifi_show_password": "Passwort anzeigen",
        "wifi_save_connect": "Speichern und verbinden", "layout_original": "Original",
        "layout_service_light": "Service Light", "layout_workshop_pro": "Werkstatt Pro",
        "layout_blue_control": "Blau Control", "layout_service_desk": "Service Desk",
        "layout_workshop_console": "Werkstatt-Konsole", "layout_studio_panels": "Studio Panels",
        "battery": "Akku", "battery_unknown": "–", "db": "DB",
        "device_overview": "Aktuelles Gerät", "device_system": "System", "device_cpu": "CPU",
        "device_memory": "Arbeitsspeicher", "device_storage": "Systemlaufwerk", "device_additional_storage": "Weitere Laufwerke", "device_optical": "Optisches Laufwerk", "device_display": "Display",
        "device_mainboard": "Mainboard", "device_graphics": "Grafikkarte", "device_reading": "Hardware wird erkannt …",
        "media_missing": "Images oder #configs fehlen auf dem Medium.",
        "config_server": "Config-Server", "config_server_disabled": "Nicht eingerichtet – nur lokale Configs.",
        "config_server_checking": "Config wird lokal geprüft · Server-Version wird geprüft …",
        "config_server_settings": "Config-Server einrichten", "config_server_enable": "Server-Abgleich aktivieren",
        "config_server_url": "HTTPS-Serveradresse", "config_server_pin": "Zertifikat-Fingerprint SHA-256 (optional)",
        "config_server_interval": "Prüfintervall in Stunden", "config_server_save": "Speichern",
        "config_server_security": "Keine Kennwörter auf der Installations-SSD speichern. HTTPS schützt die Übertragung; der Server muss Clients nur lesenden Zugriff geben.",
        "comparison_vendor": "Hersteller", "comparison_ram_total": "RAM gesamt", "comparison_ram_type": "RAM-Typ", "comparison_ram_layout": "RAM-Bestückung",
        "comparison_ssd_type": "SSD-Typ", "comparison_ssd_size": "SSD-Größe", "comparison_display_resolution": "Display-Auflösung", "comparison_display_size": "Display-Größe",
        "comparison_device": "Gerät {value}", "comparison_config": "Config {config}: {value}",
        "comparison_unknown": "Gerät unbekannt – Config {config}: {value} kann nicht sicher geprüft werden.",
        "options_open_failed": "Optionen konnten nicht geöffnet werden", "wifi_open_unsupported": "Offene WLAN-Netze werden nicht unterstützt.",
        "wifi_networks_refreshed": "WLAN-Netze wurden aktualisiert.", "wifi_scan_failed": "WLAN-Netze konnten nicht gesucht werden.",
        "wifi_connected_status": "WLAN verbunden.", "wifi_connection_failed": "WLAN-Verbindung fehlgeschlagen.",
        "program_update_error": "Update konnte nicht geprüft werden. Bitte Internetverbindung prüfen.",
        "program_update_install_failed": "Update konnte nicht installiert werden. Es wurden keine Programmdateien geändert.",
        "config_server_sync_failed": "Config-Server konnte nicht abgefragt werden. Die lokale Config bleibt aktiv.", "config_server_settings_failed": "Config-Server-Einstellungen konnten nicht gespeichert werden.",
        "acronis_scheduled": "Acronis ist für den nächsten Neustart vorbereitet.", "acronis_schedule_failed": "Acronis konnte nicht vorbereitet werden.",
        "data_disk_ready": "Daten-HDD wird nach der Windows-Installation vorbereitet.", "data_disk_unavailable": "Daten-HDD kann nicht vorbereitet werden.",
        "unknown_model": "unbekanntes Modell", "unknown_bus": "unbekannter Bus", "image_manifest": "Manifest", "image_without_manifest": "Image ohne Manifest",
        "ram_slots": "{count} Slots", "restore_complete": "Restore und Windows-Handoff wurden erfolgreich abgeschlossen.",
        "restore_complete_image": "Clonezilla-Komplettimage erfolgreich installiert. Die Modellprüfung startet mit dem vorhandenen Windows-Skript.",
        "restore_progress_complete_image": "Komplettimage wiederhergestellt; Windows-Modellprüfung bleibt unverändert.",
        "restore_failed": "Restore wurde aus Sicherheitsgründen abgebrochen. Details stehen im Protokoll.", "restore_handoff": "Windows-Handoff", "restore_log": "Protokoll",
        "restore_progress_generic": "Restore läuft …", "restore_progress_starting": "Clonezilla startet …", "restore_progress_writing": "Clonezilla schreibt das Image …",
        "restore_progress_environment": "Clonezilla-Umgebung wird vorbereitet …", "restore_progress_data_disk": "Daten-HDD wird vorbereitet …",
        "restore_progress_data_disk_done": "Daten-HDD wurde als NTFS vorbereitet …", "restore_progress_handoff": "Windows-Handoff wird geschrieben …",
    },
    "EN": {
        "app": "Magic Image", "version": "Standalone installer", "device_type": "Device type",
        "notebook": "Notebook", "computer": "Computer", "clonezilla": "Clonezilla",
        "refresh": "Refresh", "checking_media": "Checking Clonezilla …",
        "clonezilla_ready": "Clonezilla ready", "clonezilla_error": "Clonezilla not ready",
        "config": "Config", "four_digits": "four digits", "enter_config": "Enter config",
        "four_digits_only": "Please enter four digits.", "hardware_wait": "Reading hardware …",
        "image_and_target": "Image and target", "image": "Magic Image", "choose_image": "Select Magic Image",
        "target": "Target SSD", "choose_target": "Select internal target SSD", "status": "Safety status",
        "data_disk": "Data HDD (optional)", "choose_data_disk": "Do not prepare a data HDD",
        "data_disk_hint": "Optional: erase a second HDD completely and prepare it as an NTFS data drive.",
        "data_disk_unselected": "not selected (remains unchanged)",
        "data_disk_confirm": "Additional data HDD: {disk}\nIt will be erased completely and prepared as an empty NTFS data drive named “{label}”.",
        "install": "Install now …", "config_unchecked": "not checked yet", "image_unselected": "not selected yet",
        "target_unselected": "not selected yet", "ready": "Ready to install", "not_ready": "Installation not ready",
        "config_matches": "Config matches the device.", "config_attention": "Please check the config.",
        "config_unavailable": "No matching config available.",
        "complete_image": "Complete Clonezilla image",
        "complete_image_found": "Clonezilla image found.",
        "complete_image_workflow": "The existing Windows script in the image remains unchanged. No external config handoff or external driver copying.",
        "complete_image_choose": "Select complete Clonezilla image",
        "complete_image_confirm": "Complete image for model {config}: No hardware comparison before installation. Check the model number carefully. The embedded ModelCheck starts after Windows. No external config is passed to Windows.",
        "legacy_config_without_model": "#configs\\{config} exists, but model.json has no hardware data for it. No automatic hardware comparison is possible – confirm deliberately to continue.",
        "database_active": "{device} database active · {count} configs",
        "database_empty": "{device} database active · no configs yet", "hardware_error": "Hardware could not be read.",
        "check_config": "Check config", "attention": "ATTENTION: Please check the config",
        "detected_differences": "Detected differences:", "change_config": "Change config",
        "confirm_difference": "Confirm difference", "difference_confirmed": "Difference confirmed.",
        "install_unavailable": "Installation unavailable", "no_config": "No matching config was found on the medium.",
        "classic_acronis_found": "No modern Magic config found. A classical Acronis image is available.",
        "no_config_or_acronis": "No modern Magic config, complete Clonezilla image or classical Acronis image found.",
        "start_acronis": "Start Acronis", "acronis_manual_title": "Open Acronis manually",
        "acronis_manual_text": "The device restarts once into Acronis. There you select image and target manually as usual. No image is restored automatically.",
        "restart_now": "Restart now", "acronis_start_failed": "Acronis could not be started",
        "acronis_reboot_failed": "Acronis was prepared, but the restart could not be triggered.",
        "close": "Close", "confirm_install": "Confirm installation",
        "confirmation_changed": "The installation selection was updated. Please check and confirm it again.",
        "confirm_text": "Config: {config}\nImage: {image}\nTarget: {target}\n\nThe selected SSD will be erased completely.",
        "cancel": "Cancel", "continue": "Install", "preparing": "Preparing Clonezilla …",
        "after_restore": "After successful restore:", "start_windows": "Start Windows automatically",
        "shutdown_device": "Shut down device", "windows_starting": "Windows will start automatically …",
        "device_shutting_down": "Device will shut down automatically …",
        "options": "Options", "language": "Language", "layout": "Layout", "wifi": "Wi-Fi",
        "workshop_mode": "Work mode", "workshop_mode_hint": "The selected interface opens the next time the application starts.",
        "workshop_mode_magic": "Magic Image", "workshop_mode_hardwarecheck": "HardwareCheck",
        "workshop_mode_saved": "{mode} will open on the next start.", "workshop_mode_save_failed": "The work mode could not be saved.",
        "program_updates": "Application updates", "program_update_hint": "Automatic checks run at most once every 24 hours. The manual check starts immediately.",
        "program_update_check": "Check for updates now", "program_update_checking": "Checking application update …",
        "program_update_busy": "An application update is already being checked.", "program_update_current": "Application is up to date.",
        "program_update_ready": "Application update {version} is ready.",
        "program_update_downloaded": "Application update {version} was downloaded and verified. Install it now.",
        "program_update_failed": "Update check failed: {reason}",
        "program_update_question": "Version {version} has been fully verified. Install it now and restart Magic Image?",
        "program_update_install": "Install now", "program_update_install_ready": "Install update {version}", "program_update_later": "Later",
        "program_update_prepared": "Application update {version} is prepared and will be activated on the next start.",
        "program_update_restarting": "Application update {version} is being installed. Magic Image is restarting …",
        "program_update_alert": "UPDATE AVAILABLE: {version}", "program_update_alert_tooltip": "Open application updates in Options",
        "program_update_alert_test": "Test update alert",
        "wifi_offline": "Wi-Fi not connected", "wifi_connecting": "Connecting Wi-Fi …",
        "wifi_choose": "Choose Wi-Fi", "wifi_refresh": "Search networks", "wifi_no_adapter": "No Wi-Fi adapter found.",
        "wifi_no_networks": "No Wi-Fi networks found.", "wifi_saved": "saved", "wifi_connected": "connected",
        "wifi_password": "Password for {ssid}", "wifi_show_password": "Show password",
        "wifi_save_connect": "Save and connect", "layout_original": "Original",
        "layout_service_light": "Service Light", "layout_workshop_pro": "Workshop Pro",
        "layout_blue_control": "Blue Control", "layout_service_desk": "Service Desk",
        "layout_workshop_console": "Workshop Console", "layout_studio_panels": "Studio Panels",
        "battery": "Battery", "battery_unknown": "–", "db": "DB",
        "device_overview": "Current device", "device_system": "System", "device_cpu": "CPU",
        "device_memory": "Memory", "device_storage": "System drive", "device_additional_storage": "Additional drives", "device_optical": "Optical drive", "device_display": "Display",
        "device_mainboard": "Mainboard", "device_graphics": "Graphics card", "device_reading": "Detecting hardware …",
        "media_missing": "Images or #configs are missing from the medium.",
        "config_server": "Config server", "config_server_disabled": "Not configured – local configs only.",
        "config_server_checking": "Checking config locally · checking server version …",
        "config_server_settings": "Configure config server", "config_server_enable": "Enable server synchronisation",
        "config_server_url": "HTTPS server address", "config_server_pin": "Certificate SHA-256 fingerprint (optional)",
        "config_server_interval": "Check interval in hours", "config_server_save": "Save",
        "config_server_security": "Do not store passwords on the installation SSD. HTTPS protects transport; the server must grant clients read-only access only.",
        "comparison_vendor": "Manufacturer", "comparison_ram_total": "Total RAM", "comparison_ram_type": "RAM type", "comparison_ram_layout": "RAM configuration",
        "comparison_ssd_type": "SSD type", "comparison_ssd_size": "SSD size", "comparison_display_resolution": "Display resolution", "comparison_display_size": "Display size",
        "comparison_device": "Device {value}", "comparison_config": "Config {config}: {value}",
        "comparison_unknown": "Device unknown – config {config}: {value} cannot be verified safely.",
        "options_open_failed": "Options could not be opened", "wifi_open_unsupported": "Open Wi-Fi networks are not supported.",
        "wifi_networks_refreshed": "Wi-Fi networks were refreshed.", "wifi_scan_failed": "Wi-Fi networks could not be searched.",
        "wifi_connected_status": "Wi-Fi connected.", "wifi_connection_failed": "Wi-Fi connection failed.",
        "program_update_error": "The update could not be checked. Please check the Internet connection.",
        "program_update_install_failed": "The update could not be installed. No application files were changed.",
        "config_server_sync_failed": "The config server could not be reached. The local config remains active.", "config_server_settings_failed": "The config server settings could not be saved.",
        "acronis_scheduled": "Acronis is prepared for the next restart.", "acronis_schedule_failed": "Acronis could not be prepared.",
        "data_disk_ready": "The data HDD will be prepared after the Windows installation.", "data_disk_unavailable": "The data HDD cannot be prepared.",
        "unknown_model": "unknown model", "unknown_bus": "unknown bus", "image_manifest": "Manifest", "image_without_manifest": "Image without manifest",
        "ram_slots": "{count} slots", "restore_complete": "Restore and Windows handoff completed successfully.",
        "restore_complete_image": "Complete Clonezilla image installed successfully. The existing Windows script will check the model.",
        "restore_progress_complete_image": "Complete image restored; the Windows model check remains unchanged.",
        "restore_failed": "Restore was stopped for safety. Details are in the log.", "restore_handoff": "Windows handoff", "restore_log": "Log",
        "restore_progress_generic": "Restore is running …", "restore_progress_starting": "Starting Clonezilla …", "restore_progress_writing": "Clonezilla is writing the image …",
        "restore_progress_environment": "Preparing the Clonezilla environment …", "restore_progress_data_disk": "Preparing the data HDD …",
        "restore_progress_data_disk_done": "Data HDD was prepared as NTFS …", "restore_progress_handoff": "Writing Windows handoff …",
    },
    "CZ": {
        "app": "Magic Image", "version": "Samostatný instalátor", "device_type": "Typ zařízení",
        "notebook": "Notebook", "computer": "Počítač", "clonezilla": "Clonezilla",
        "refresh": "Obnovit", "checking_media": "Kontrola Clonezilly …",
        "clonezilla_ready": "Clonezilla připravena", "clonezilla_error": "Clonezilla není připravena",
        "config": "Konfigurace", "four_digits": "čtyři číslice", "enter_config": "Zadejte konfiguraci",
        "four_digits_only": "Zadejte prosím čtyři číslice.", "hardware_wait": "Načítání hardwaru …",
        "image_and_target": "Image a cíl", "image": "Magic Image", "choose_image": "Vybrat Magic Image",
        "target": "Cílové SSD", "choose_target": "Vybrat interní cílové SSD", "status": "Stav bezpečnosti",
        "data_disk": "Datový HDD (volitelné)", "choose_data_disk": "Datový HDD nepřipravovat",
        "data_disk_hint": "Volitelné: druhý HDD zcela vymazat a připravit jako datový disk NTFS.",
        "data_disk_unselected": "nevybráno (zůstane beze změny)",
        "data_disk_confirm": "Další datový HDD: {disk}\nBude zcela vymazán a připraven jako prázdný datový disk NTFS s názvem „{label}“.",
        "install": "Instalovat nyní …", "config_unchecked": "zatím neověřeno", "image_unselected": "zatím nevybráno",
        "target_unselected": "zatím nevybráno", "ready": "Připraveno k instalaci", "not_ready": "Instalace není připravena",
        "config_matches": "Konfigurace odpovídá zařízení.", "config_attention": "Zkontrolujte konfiguraci.",
        "config_unavailable": "Odpovídající konfigurace není k dispozici.",
        "complete_image": "Kompletní obraz Clonezilla",
        "complete_image_found": "Obraz Clonezilla byl nalezen.",
        "complete_image_workflow": "Stávající skript Windows v obrazu zůstane beze změny. Bez předání externí konfigurace a bez kopírování externích ovladačů.",
        "complete_image_choose": "Vybrat kompletní obraz Clonezilla",
        "complete_image_confirm": "Kompletní obraz pro model {config}: Před instalací se hardware neporovnává. Pečlivě ověřte číslo modelu. Vestavěný ModelCheck se spustí po startu Windows. Externí konfigurace se nepředává.",
        "legacy_config_without_model": "#configs\\{config} existuje, ale model.json pro ni neobsahuje údaje o hardwaru. Automatické porovnání hardwaru není možné – pokračujte pouze po vědomém potvrzení.",
        "database_active": "Databáze {device} aktivní · {count} konfigurací",
        "database_empty": "Databáze {device} aktivní · zatím bez konfigurací", "hardware_error": "Hardware nelze načíst.",
        "check_config": "Zkontrolovat konfiguraci", "attention": "POZOR: Zkontrolujte konfiguraci",
        "detected_differences": "Zjištěné rozdíly:", "change_config": "Změnit konfiguraci",
        "confirm_difference": "Potvrdit rozdíl", "difference_confirmed": "Rozdíl potvrzen.",
        "install_unavailable": "Instalace není k dispozici", "no_config": "Na médiu nebyla nalezena odpovídající konfigurace.",
        "classic_acronis_found": "Nebyla nalezena moderní konfigurace Magic. Je k dispozici klasický obraz Acronis.",
        "no_config_or_acronis": "Nebyla nalezena moderní konfigurace Magic, kompletní obraz Clonezilla ani klasický obraz Acronis.",
        "start_acronis": "Spustit Acronis", "acronis_manual_title": "Otevřít Acronis ručně",
        "acronis_manual_text": "Zařízení se jednou restartuje do Acronis. Obraz a cíl zde vyberete ručně jako obvykle. Žádný obraz se automaticky neobnoví.",
        "restart_now": "Restartovat", "acronis_start_failed": "Acronis nelze spustit",
        "acronis_reboot_failed": "Acronis byl připraven, ale restart nelze spustit.",
        "close": "Zavřít", "confirm_install": "Potvrdit instalaci",
        "confirmation_changed": "Výběr instalace byl aktualizován. Znovu jej prosím zkontrolujte a potvrďte.",
        "confirm_text": "Konfigurace: {config}\nImage: {image}\nCíl: {target}\n\nVybrané SSD bude zcela vymazáno.",
        "cancel": "Zrušit", "continue": "Instalovat", "preparing": "Příprava Clonezilly …",
        "after_restore": "Po úspěšném obnovení:", "start_windows": "Automaticky spustit Windows",
        "shutdown_device": "Vypnout zařízení", "windows_starting": "Windows se automaticky spustí …",
        "device_shutting_down": "Zařízení se automaticky vypne …",
        "options": "Nastavení", "language": "Jazyk", "layout": "Vzhled", "wifi": "Wi-Fi",
        "workshop_mode": "Pracovní režim", "workshop_mode_hint": "Při příštím spuštění programu se otevře vybrané rozhraní.",
        "workshop_mode_magic": "Magic Image", "workshop_mode_hardwarecheck": "HardwareCheck",
        "workshop_mode_saved": "Při příštím spuštění se otevře: {mode}.", "workshop_mode_save_failed": "Pracovní režim se nepodařilo uložit.",
        "program_updates": "Aktualizace programu", "program_update_hint": "Automatická kontrola probíhá nejvýše jednou za 24 hodin. Ruční kontrola se spustí ihned.",
        "program_update_check": "Vyhledat aktualizace nyní", "program_update_checking": "Kontrola aktualizace programu …",
        "program_update_busy": "Aktualizace programu se již kontroluje.", "program_update_current": "Program je aktuální.",
        "program_update_ready": "Aktualizace programu {version} je připravena.",
        "program_update_downloaded": "Aktualizace programu {version} byla stažena a ověřena. Nyní ji nainstalujte.",
        "program_update_failed": "Kontrola aktualizace selhala: {reason}",
        "program_update_question": "Verze {version} byla plně ověřena. Nainstalovat ji nyní a restartovat Magic Image?",
        "program_update_install": "Instalovat nyní", "program_update_install_ready": "Instalovat aktualizaci {version}", "program_update_later": "Později",
        "program_update_prepared": "Aktualizace programu {version} je připravena a aktivuje se při příštím spuštění.",
        "program_update_restarting": "Aktualizace programu {version} se instaluje. Magic Image se restartuje …",
        "program_update_alert": "AKTUALIZACE K DISPOZICI: {version}", "program_update_alert_tooltip": "Otevřít aktualizace programu v nastavení",
        "program_update_alert_test": "Vyzkoušet upozornění na aktualizaci",
        "wifi_offline": "Wi-Fi není připojena", "wifi_connecting": "Připojování Wi-Fi …",
        "wifi_choose": "Vybrat Wi-Fi", "wifi_refresh": "Vyhledat sítě", "wifi_no_adapter": "Adaptér Wi-Fi nebyl nalezen.",
        "wifi_no_networks": "Nenalezeny žádné sítě Wi-Fi.", "wifi_saved": "uloženo", "wifi_connected": "připojeno",
        "wifi_password": "Heslo pro {ssid}", "wifi_show_password": "Zobrazit heslo",
        "wifi_save_connect": "Uložit a připojit", "layout_original": "Originál",
        "layout_service_light": "Světlý servis", "layout_workshop_pro": "Dílna Pro",
        "layout_blue_control": "Modré řízení", "layout_service_desk": "Servisní pult",
        "layout_workshop_console": "Dílenská konzole", "layout_studio_panels": "Studiové panely",
        "battery": "Baterie", "battery_unknown": "–", "db": "DB",
        "device_overview": "Aktuální zařízení", "device_system": "Systém", "device_cpu": "CPU",
        "device_memory": "Operační paměť", "device_storage": "Systémový disk", "device_additional_storage": "Další disky", "device_optical": "Optická jednotka", "device_display": "Displej",
        "device_mainboard": "Základní deska", "device_graphics": "Grafická karta", "device_reading": "Načítání hardwaru …",
        "media_missing": "Na médiu chybí Images nebo #configs.",
        "config_server": "Server konfigurací", "config_server_disabled": "Není nastaven – pouze místní konfigurace.",
        "config_server_checking": "Konfigurace se ověřuje místně · kontroluje se verze na serveru …",
        "config_server_settings": "Nastavit server konfigurací", "config_server_enable": "Zapnout synchronizaci se serverem",
        "config_server_url": "Adresa serveru HTTPS", "config_server_pin": "Otisk certifikátu SHA-256 (volitelné)",
        "config_server_interval": "Interval kontroly v hodinách", "config_server_save": "Uložit",
        "config_server_security": "Na instalační SSD neukládejte hesla. HTTPS chrání přenos; server musí klientům poskytovat pouze přístup pro čtení.",
        "comparison_vendor": "Výrobce", "comparison_ram_total": "Celková RAM", "comparison_ram_type": "Typ RAM", "comparison_ram_layout": "Osazení RAM",
        "comparison_ssd_type": "Typ SSD", "comparison_ssd_size": "Velikost SSD", "comparison_display_resolution": "Rozlišení displeje", "comparison_display_size": "Velikost displeje",
        "comparison_device": "Zařízení {value}", "comparison_config": "Konfigurace {config}: {value}",
        "comparison_unknown": "Zařízení není rozpoznáno – konfiguraci {config}: {value} nelze spolehlivě ověřit.",
        "options_open_failed": "Nastavení nelze otevřít", "wifi_open_unsupported": "Otevřené sítě Wi-Fi nejsou podporovány.",
        "wifi_networks_refreshed": "Sítě Wi-Fi byly aktualizovány.", "wifi_scan_failed": "Sítě Wi-Fi nelze vyhledat.",
        "wifi_connected_status": "Wi-Fi je připojena.", "wifi_connection_failed": "Připojení k Wi-Fi se nezdařilo.",
        "program_update_error": "Aktualizaci nelze zkontrolovat. Zkontrolujte připojení k internetu.",
        "program_update_install_failed": "Aktualizaci nelze nainstalovat. Žádné soubory programu nebyly změněny.",
        "config_server_sync_failed": "Server konfigurací nelze kontaktovat. Místní konfigurace zůstává aktivní.", "config_server_settings_failed": "Nastavení serveru konfigurací nelze uložit.",
        "acronis_scheduled": "Acronis je připraven pro příští restart.", "acronis_schedule_failed": "Acronis nelze připravit.",
        "data_disk_ready": "Datový HDD bude připraven po instalaci systému Windows.", "data_disk_unavailable": "Datový HDD nelze připravit.",
        "unknown_model": "neznámý model", "unknown_bus": "neznámá sběrnice", "image_manifest": "Manifest", "image_without_manifest": "Image bez manifestu",
        "ram_slots": "{count} sloty", "restore_complete": "Obnovení a předání systému Windows bylo úspěšně dokončeno.",
        "restore_complete_image": "Kompletní obraz Clonezilla byl úspěšně nainstalován. Model ověří stávající skript Windows.",
        "restore_progress_complete_image": "Kompletní obraz byl obnoven; kontrola modelu ve Windows zůstává beze změny.",
        "restore_failed": "Obnovení bylo z bezpečnostních důvodů zastaveno. Podrobnosti jsou v protokolu.", "restore_handoff": "Předání systému Windows", "restore_log": "Protokol",
        "restore_progress_generic": "Probíhá obnovení …", "restore_progress_starting": "Spouští se Clonezilla …", "restore_progress_writing": "Clonezilla zapisuje image …",
        "restore_progress_environment": "Připravuje se prostředí Clonezilly …", "restore_progress_data_disk": "Připravuje se datový HDD …",
        "restore_progress_data_disk_done": "Datový HDD byl připraven jako NTFS …", "restore_progress_handoff": "Zapisuje se předání systému Windows …",
    },
}


# The core safety checks deliberately remain language-neutral.  It returns
# stable comparison text which is also useful in support logs; this UI map
# converts its visible labels and sentences for the selected operator language.
COMPARISON_METRIC_KEYS = {
    "Hersteller": "comparison_vendor",
    "CPU": "device_cpu",
    "RAM gesamt": "comparison_ram_total",
    "RAM-Typ": "comparison_ram_type",
    "RAM-Bestückung": "comparison_ram_layout",
    "SSD-Typ": "comparison_ssd_type",
    "SSD-Größe": "comparison_ssd_size",
    "Display-Auflösung": "comparison_display_resolution",
    "Display-Größe": "comparison_display_size",
}

RESTORE_PROGRESS_TEXT_KEYS = {
    "Clonezilla startet …": "restore_progress_starting",
    "Clonezilla schreibt das Image …": "restore_progress_writing",
    "Clonezilla-Umgebung wird vorbereitet …": "restore_progress_environment",
    "Daten-HDD wird vorbereitet …": "restore_progress_data_disk",
    "Daten-HDD als NTFS vorbereitet …": "restore_progress_data_disk_done",
    "Windows-Handoff wird geschrieben …": "restore_progress_handoff",
    "Komplettimage wiederhergestellt; Windows-Modellprüfung bleibt unverändert.": "restore_progress_complete_image",
}


CSS = b"""
* { font-family: Inter, "Segoe UI", sans-serif; }
window, .background, .root, dialog, messagedialog { background-color: #0b1018; color: #edf3fb; }
.root { background-color: #0b1018; }
.top { background: #111824; border-bottom: 1px solid #2d3d57; padding: 11px 18px; }
.title { color: #ffffff; font-size: 23px; font-weight: 800; }
.subtitle, .muted { color: #aabbd0; font-size: 12px; }
.section { color: #f7f9fc; font-size: 17px; font-weight: 800; }
.card { background: #141d2b; border: 1px solid #30405a; border-radius: 14px; }
.status-chip { background: #192438; border: 1px solid #3b4e6c; border-radius: 17px; color: #e8f1fc; padding: 7px 11px; font-size: 12px; font-weight: 800; }
.status-chip.good { color: #76e5b8; border-color: #2a755b; }
.status-chip.warn { color: #ffd27d; border-color: #805d26; }
.status-chip.bad { color: #ff9da5; border-color: #7d3b44; }
.network-dot { color: transparent; font-size: 17px; font-weight: 900; margin-right: 1px; }
.network-dot.online { color: #58eea2; }
.status-good { color: #70e0ad; font-weight: 800; }
.status-warn { color: #ffd177; font-weight: 800; }
.status-bad { color: #ff9ba3; font-weight: 800; }
entry, combobox button, combobox button box { background-color: #18263a; color: #f6f9ff; border: 1px solid #516789; border-radius: 8px; min-height: 39px; font-size: 16px; }
entry selection { background-color: #3c83d3; color: #ffffff; }
entry:focus, combobox button:focus { border-color: #7db6ff; box-shadow: 0 0 0 1px #7db6ff; }
combobox button label, combobox button arrow { color: #f6f9ff; }
combobox menu { background-color: #152236; color: #f4f8fd; border: 1px solid #4b617f; }
combobox menu menuitem { color: #f4f8fd; background-color: #152236; padding: 8px; }
combobox menu menuitem:hover { background-color: #294b73; color: #ffffff; }
.config-entry { font-size: 27px; font-weight: 800; min-height: 57px; }
button { background: #22354f; color: #f4f8fd; min-height: 40px; border: 1px solid #55729a; border-radius: 9px; padding: 7px 13px; font-weight: 800; }
button:hover { background: #2b4770; color: #ffffff; border-color: #91bfff; }
button.primary { background: #176fc1; color: #ffffff; border-color: #8ac5ff; }
button.primary:hover { background: #2786df; }
button.danger { background: #b42d3b; color: #ffffff; border-color: #f18d97; }
button.danger:hover { background: #d13f50; }
button.gear { min-width: 42px; min-height: 38px; padding: 4px 8px; font-size: 19px; }
button.update-alert { border: 2px solid #ffffff; border-radius: 10px; min-height: 38px; padding: 6px 11px; font-weight: 900; }
button.update-alert.update-phase-red { background: #b51f32; color: #ffffff; border-color: #ff8a98; }
button.update-alert.update-phase-gold { background: #e6a82e; color: #10151d; border-color: #fff2ad; }
button.update-alert.update-phase-blue { background: #176fc1; color: #ffffff; border-color: #92ccff; }
button.update-alert.update-phase-purple { background: #8138a6; color: #ffffff; border-color: #e4a8ff; }
button.language-active { background: #176fc1; color: #ffffff; border-color: #9bcfff; }
textview, textview text { background: #0d1521; color: #e8f0fa; font-family: monospace; font-size: 12px; }
progressbar trough { background: #172238; min-height: 23px; border-radius: 7px; }
progressbar progress { background: #2eb77b; border-radius: 7px; }
progressbar text { color: #ffffff; font-weight: 800; }
dialog, dialog .dialog-vbox, dialog .content-area, dialog .dialog-action-area, dialog box { background: #111a28; color: #edf3fb; }
dialog .dialog-action-area { border-top: 1px solid #31425d; padding: 10px; }
dialog label { color: #edf3fb; }
.dialog-title { color: #ffffff; font-size: 24px; font-weight: 900; }
.dialog-list row { background: #16253a; color: #f5f9ff; border: 1px solid #334b6d; border-radius: 8px; margin: 3px; }
.dialog-list row:hover { background: #24446b; }
.difference-row { background: #16253a; border: 1px solid #334b6d; border-radius: 9px; padding: 9px 12px; }
.difference-metric { color: #ffffff; font-size: 15px; font-weight: 900; }
.difference-actual { color: #f6f9ff; font-size: 14px; }
.difference-expected { color: #8fc6ff; font-size: 14px; font-weight: 700; }
.device-overview { background: #0d1521; border: 1px solid #334b6d; border-radius: 10px; padding: 5px 8px; }
.device-overview-title { color: #ffffff; font-size: 13px; font-weight: 900; }
.device-key { color: #aabbd0; font-size: 11px; font-weight: 800; }
.device-value { color: #f4f8fd; font-size: 12px; font-weight: 700; }
.layout-service-light .top, .layout-service-desk .top { background: #10221f; }
.layout-workshop-pro .top, .layout-workshop-console .top { background: #21190f; }
.layout-blue-control .top { background: #101b31; }
.layout-studio-panels .top { background: #21182a; }

/* Real HardwareCheck appearance presets.  The Solo screen deliberately uses
   the same visual families, even though it has no left navigation. */
.root.layout-original { background: #231838; }
.layout-original .top { background: #161126; border-bottom: 2px solid #f0c94e; }
.layout-original .card { background: #211b34; border-color: #6e5285; border-radius: 16px; }
.layout-original .section, .layout-original .title, .layout-original .dialog-title { color: #ffffff; }
.layout-original .subtitle, .layout-original .muted { color: #c5b9d9; }
.layout-original .status-chip { background: #302546; border-color: #8065a0; }
.layout-original entry, .layout-original combobox button, .layout-original button.combo { background: #171426; color: #faf7ff; border-color: #a178c2; }
.layout-original .primary { background: #efc84c; color: #161119; border-color: #ffe78c; }
.layout-original button.primary:hover { background: #ffdc68; color: #161119; }
.layout-original button.danger { background: #cf526a; border-color: #ff9ead; }
.layout-original progressbar progress { background: #efc84c; }

.root.layout-service-light { background: #f4f0e7; color: #193849; }
.layout-service-light .top { background: #fffdf8; border-bottom: 2px solid #2b8f82; }
.layout-service-light .card { background: #fffdf8; border-color: #bfd1cc; border-radius: 11px; }
.layout-service-light .title, .layout-service-light .section, .layout-service-light .dialog-title { color: #153a4b; }
.layout-service-light .subtitle, .layout-service-light .muted { color: #637d88; }
.layout-service-light .status-chip { background: #edf7f3; border-color: #a6c7bd; color: #17685f; }
.layout-service-light entry, .layout-service-light combobox button, .layout-service-light button.combo { background: #ffffff; color: #17384a; border-color: #98b9b2; }
.layout-service-light button { background: #edf5f2; color: #17384a; border-color: #8db4ab; }
.layout-service-light button.primary { background: #168b7e; color: #ffffff; border-color: #59b9aa; }
.layout-service-light button.danger { background: #b43c4d; border-color: #e38791; }
.layout-service-light textview, .layout-service-light textview text { background: #fffdf8; color: #193849; }
.layout-service-light progressbar trough { background: #dce9e4; }
.layout-service-light progressbar progress { background: #168b7e; }

.root.layout-workshop-pro { background: #1a1b1c; }
.layout-workshop-pro .top { background: #0d0e0f; border-bottom: 3px solid #e39b2e; }
.layout-workshop-pro .card { background: #202224; border-color: #54585a; border-radius: 0; }
.layout-workshop-pro .title, .layout-workshop-pro .section, .layout-workshop-pro .dialog-title { color: #f6f3ea; }
.layout-workshop-pro .subtitle, .layout-workshop-pro .muted { color: #a4a7a4; }
.layout-workshop-pro .status-chip { background: #292c2e; border-color: #606466; border-radius: 0; }
.layout-workshop-pro entry, .layout-workshop-pro combobox button, .layout-workshop-pro button.combo { background: #111315; color: #f8f6ef; border-color: #63676a; border-radius: 0; }
.layout-workshop-pro button { background: #2c2f31; color: #f4f1e9; border-color: #676b6d; border-radius: 0; }
.layout-workshop-pro button.primary { background: #e39b2e; color: #17120a; border-color: #ffd184; }
.layout-workshop-pro button.danger { background: #ae3840; border-color: #e4828a; }
.layout-workshop-pro textview, .layout-workshop-pro textview text { background: #151617; color: #eeeae0; }
.layout-workshop-pro progressbar trough { background: #383a3b; border-radius: 0; }
.layout-workshop-pro progressbar progress { background: #e39b2e; border-radius: 0; }

.root.layout-blue-control { background: #0b1a3b; }
.layout-blue-control .top { background: #08162f; border-bottom: 2px solid #3b94dc; }
.layout-blue-control .card { background: #10264c; border-color: #3c75ae; border-radius: 15px; }
.layout-blue-control .title, .layout-blue-control .section, .layout-blue-control .dialog-title { color: #f7fbff; }
.layout-blue-control .subtitle, .layout-blue-control .muted { color: #a9c6eb; }
.layout-blue-control .status-chip { background: #153666; border-color: #4f8bc9; }
.layout-blue-control entry, .layout-blue-control combobox button, .layout-blue-control button.combo { background: #091a37; color: #f2f8ff; border-color: #4a81b8; }
.layout-blue-control button { background: #174276; color: #f4f9ff; border-color: #609bd5; }
.layout-blue-control button.primary { background: #2389db; color: #ffffff; border-color: #8bc8ff; }
.layout-blue-control button.danger { background: #82394d; border-color: #cc7c91; }
.layout-blue-control progressbar trough { background: #1a4071; }
.layout-blue-control progressbar progress { background: #32b5e6; }

.root.layout-service-desk { background: #e9edf0; color: #1c3341; }
.layout-service-desk .top { background: #173d50; border-bottom: 3px solid #42bfa7; }
.layout-service-desk .card { background: #f9fbfa; border-color: #b9c8cb; border-radius: 2px; }
.layout-service-desk .title, .layout-service-desk .top .section { color: #ffffff; }
.layout-service-desk .section, .layout-service-desk .dialog-title { color: #173d50; }
.layout-service-desk .subtitle { color: #b9d2d7; }
.layout-service-desk .muted { color: #637a86; }
.layout-service-desk .status-chip { background: #214f63; border-color: #5e9fa4; color: #e9ffff; border-radius: 4px; }
.layout-service-desk entry, .layout-service-desk combobox button, .layout-service-desk button.combo { background: #ffffff; color: #173d50; border-color: #8eabb2; border-radius: 4px; }
.layout-service-desk button { background: #e6f1ee; color: #173d50; border-color: #8bafa8; border-radius: 4px; }
.layout-service-desk button.primary { background: #168f82; color: #ffffff; border-color: #6ccabb; }
.layout-service-desk button.danger { background: #b5414e; border-color: #e58a91; }
.layout-service-desk textview, .layout-service-desk textview text { background: #f9fbfa; color: #193743; }
.layout-service-desk progressbar trough { background: #dbe8e5; }
.layout-service-desk progressbar progress { background: #168f82; }

.root.layout-workshop-console { background: #111315; }
.layout-workshop-console .top { background: #050607; border-bottom: 3px solid #e17432; }
.layout-workshop-console .card { background: #1b1e20; border-color: #4e5356; border-radius: 0; }
.layout-workshop-console .title, .layout-workshop-console .section, .layout-workshop-console .dialog-title { color: #f4f0e9; }
.layout-workshop-console .subtitle, .layout-workshop-console .muted { color: #9fa4a4; }
.layout-workshop-console .status-chip { background: #202427; border-color: #5e6568; border-radius: 0; }
.layout-workshop-console entry, .layout-workshop-console combobox button, .layout-workshop-console button.combo { background: #0b0d0f; color: #f5efe3; border-color: #62696a; border-radius: 0; }
.layout-workshop-console button { background: #272b2e; color: #f5f1e8; border-color: #656b6d; border-radius: 0; }
.layout-workshop-console button.primary { background: #e17432; color: #191007; border-color: #ffc091; }
.layout-workshop-console button.danger { background: #9d3338; border-color: #db767b; }
.layout-workshop-console textview, .layout-workshop-console textview text { background: #0b0d0f; color: #f0ede5; }
.layout-workshop-console progressbar trough { background: #34393b; border-radius: 0; }
.layout-workshop-console progressbar progress { background: #e17432; border-radius: 0; }

.root.layout-studio-panels { background: #241531; }
.layout-studio-panels .top { background: #37174e; border-bottom: 3px solid #ec6ea5; }
.layout-studio-panels .card { background: #332147; border-color: #9466ad; border-radius: 22px; }
.layout-studio-panels .title, .layout-studio-panels .section, .layout-studio-panels .dialog-title { color: #fff7fc; }
.layout-studio-panels .subtitle, .layout-studio-panels .muted { color: #dec2e8; }
.layout-studio-panels .status-chip { background: #4e2c62; border-color: #c67ab3; border-radius: 18px; }
.layout-studio-panels entry, .layout-studio-panels combobox button, .layout-studio-panels button.combo { background: #23142e; color: #fff7fd; border-color: #ba79c5; border-radius: 12px; }
.layout-studio-panels button { background: #57356f; color: #fff8ff; border-color: #c983c4; border-radius: 13px; }
.layout-studio-panels button.primary { background: #df5e9f; color: #ffffff; border-color: #ffa9cf; }
.layout-studio-panels button.danger { background: #b74368; border-color: #f488ab; }
.layout-studio-panels progressbar trough { background: #593a6f; }
.layout-studio-panels progressbar progress { background: #ec6ea5; }

/* A few GTK themes otherwise paint ComboBoxText white. */
.root combobox button.combo, .root combobox button.toggle, .root combobox button,
.solo-dialog combobox button.combo, .solo-dialog combobox button.toggle, .solo-dialog combobox button { background-image: none; }
"""


# Every layout gets a complete surface palette.  This is intentionally loaded
# after the common CSS: some Gtk themes colour empty boxes, viewports and
# dialogs blue unless every one of those surfaces is set explicitly.
LAYOUT_PALETTES = {
    "original": {
        "background": "#25183b", "surface": "#34224b", "top": "#181028", "field": "#21142f",
        "border": "#a26bb4", "text": "#fff8ff", "muted": "#dfc6e8", "chip": "#4c2d60",
        "primary": "#efc84c", "primary_text": "#18120a", "danger": "#c94c68", "progress": "#efc84c",
    },
    "service-light": {
        "background": "#f4f0e8", "surface": "#fffdf8", "top": "#fffdf8", "field": "#ffffff",
        "border": "#99bdb4", "text": "#173d4c", "muted": "#637d88", "chip": "#edf7f3",
        "primary": "#168b7e", "primary_text": "#ffffff", "danger": "#b43d4c", "progress": "#168b7e",
    },
    "workshop-pro": {
        "background": "#191b1d", "surface": "#202224", "top": "#0d0f10", "field": "#111315",
        "border": "#626668", "text": "#f5f1e8", "muted": "#a3a6a3", "chip": "#292c2e",
        "primary": "#e19b30", "primary_text": "#191308", "danger": "#a93940", "progress": "#e19b30",
    },
    "blue-control": {
        "background": "#0b1b3d", "surface": "#112952", "top": "#08162f", "field": "#091a37",
        "border": "#4b83ba", "text": "#f5f9ff", "muted": "#aac6e8", "chip": "#153767",
        "primary": "#258cde", "primary_text": "#ffffff", "danger": "#833c51", "progress": "#35b7e7",
    },
    "service-desk": {
        "background": "#e9eeed", "surface": "#fbfdfb", "top": "#173e50", "field": "#ffffff",
        "border": "#94afb5", "text": "#193b49", "muted": "#657d86", "chip": "#214f63",
        "primary": "#178e81", "primary_text": "#ffffff", "danger": "#b4404c", "progress": "#178e81",
    },
    "workshop-console": {
        "background": "#101214", "surface": "#1b1e20", "top": "#050607", "field": "#0a0c0e",
        "border": "#5e6466", "text": "#f2eee7", "muted": "#a2a6a5", "chip": "#202427",
        "primary": "#e17432", "primary_text": "#1a1008", "danger": "#9f3338", "progress": "#e17432",
    },
    "studio-panels": {
        "background": "#2b173c", "surface": "#3b2450", "top": "#39184f", "field": "#271532",
        "border": "#bd78c5", "text": "#fff7fd", "muted": "#e2c7e9", "chip": "#513064",
        "primary": "#df5e9f", "primary_text": "#ffffff", "danger": "#b54268", "progress": "#ed72a7",
    },
}


def solo_layout_css(layout: str) -> bytes:
    """Create the complete colour layer for the selected Solo layout."""
    palette = dict(LAYOUT_PALETTES.get(layout, LAYOUT_PALETTES["original"]))
    palette["name"] = layout if layout in LAYOUT_PALETTES else "original"
    return """
window.layout-{name}, .root.layout-{name}, .root.layout-{name} > .solo-scroll,
.root.layout-{name} .solo-content, .root.layout-{name} .solo-work,
.root.layout-{name} viewport, .root.layout-{name} scrolledwindow {{
  background-color: {background}; background-image: none; color: {text};
}}
.root.layout-{name} .top {{
  background-color: {top}; background-image: none; border-bottom: 3px solid {primary};
}}
.root.layout-{name} .solo-controls, .root.layout-{name} .solo-footer {{
  background-color: {background}; background-image: none; color: {muted};
}}
.root.layout-{name} .card {{
  background-color: {surface}; background-image: none; border-color: {border}; color: {text};
}}
.root.layout-{name} .device-overview {{
  background-color: {field}; background-image: none; border-color: {border}; color: {text};
}}
.root.layout-{name} .device-overview-title, .root.layout-{name} .device-value {{ color: {text}; }}
.root.layout-{name} .device-key {{ color: {muted}; }}
.root.layout-{name} .title, .root.layout-{name} .section {{ color: {text}; }}
.root.layout-{name} .subtitle, .root.layout-{name} .muted {{ color: {muted}; }}
.root.layout-{name} .status-chip {{
  background-color: {chip}; background-image: none; border-color: {border}; color: {text};
}}
.root.layout-{name} entry, .root.layout-{name} combobox button,
.root.layout-{name} combobox button.combo, .root.layout-{name} button.combo {{
  background-color: {field}; background-image: none; color: {text}; border-color: {border};
}}
.root.layout-{name} combobox button label, .root.layout-{name} combobox button arrow {{ color: {text}; }}
.root.layout-{name} button {{ background-color: {chip}; background-image: none; color: {text}; border-color: {border}; }}
.root.layout-{name} button.primary {{ background-color: {primary}; color: {primary_text}; border-color: {primary}; }}
.root.layout-{name} button.danger {{ background-color: {danger}; color: #ffffff; border-color: {danger}; }}
.root.layout-{name} button.update-alert {{ border: 2px solid #ffffff; font-weight: 900; }}
.root.layout-{name} button.update-alert.update-phase-red {{ background-color: #b51f32; color: #ffffff; border-color: #ff8a98; }}
.root.layout-{name} button.update-alert.update-phase-gold {{ background-color: #e6a82e; color: #10151d; border-color: #fff2ad; }}
.root.layout-{name} button.update-alert.update-phase-blue {{ background-color: #176fc1; color: #ffffff; border-color: #92ccff; }}
.root.layout-{name} button.update-alert.update-phase-purple {{ background-color: #8138a6; color: #ffffff; border-color: #e4a8ff; }}
.root.layout-{name} textview, .root.layout-{name} textview text {{
  background-color: {field}; background-image: none; color: {text}; border-color: {border};
}}
.root.layout-{name} progressbar trough {{ background-color: {field}; background-image: none; }}
.root.layout-{name} progressbar progress {{ background-color: {progress}; background-image: none; }}
dialog.solo-dialog.layout-{name}, dialog.solo-dialog.layout-{name} .dialog-vbox,
dialog.solo-dialog.layout-{name} .content-area, dialog.solo-dialog.layout-{name} .dialog-action-area,
dialog.solo-dialog.layout-{name} box {{ background-color: {surface}; background-image: none; color: {text}; }}
dialog.solo-dialog.layout-{name} .dialog-action-area {{ border-top-color: {border}; }}
dialog.solo-dialog.layout-{name} .dialog-title, dialog.solo-dialog.layout-{name} .section {{ color: {text}; }}
dialog.solo-dialog.layout-{name} .muted {{ color: {muted}; }}
dialog.solo-dialog.layout-{name} .difference-row {{ background-color: {field}; background-image: none; border-color: {border}; }}
dialog.solo-dialog.layout-{name} .difference-metric {{ color: {text}; }}
dialog.solo-dialog.layout-{name} .difference-actual {{ color: {muted}; }}
dialog.solo-dialog.layout-{name} .difference-expected {{ color: {primary}; }}
dialog.solo-dialog.layout-{name} entry, dialog.solo-dialog.layout-{name} combobox button,
dialog.solo-dialog.layout-{name} combobox button.combo {{ background-color: {field}; background-image: none; color: {text}; border-color: {border}; }}
dialog.solo-dialog.layout-{name} button {{ background-color: {chip}; background-image: none; color: {text}; border-color: {border}; }}
dialog.solo-dialog.layout-{name} button.primary {{ background-color: {primary}; color: {primary_text}; border-color: {primary}; }}
dialog.solo-dialog.layout-{name} button.danger {{ background-color: {danger}; color: #ffffff; border-color: {danger}; }}
""".format(**palette).encode("utf-8")


def _safe_text(value: object) -> str:
    return str(value or "").strip()


def _read_sysfs_text(path: str) -> str:
    """Read an optional DMI value without making hardware discovery brittle."""

    try:
        return pathlib.Path(path).read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""


def _collect_optional_device_details() -> dict[str, str]:
    """Collect display-only PC details absent from the common core snapshot.

    The data is deliberately informational: neither the mainboard nor the
    graphics adapter participates in the Config safety comparison.
    """

    board_vendor = _read_sysfs_text("/sys/class/dmi/id/board_vendor")
    board_name = _read_sysfs_text("/sys/class/dmi/id/board_name")
    mainboard = " ".join(part for part in (board_vendor, board_name) if part).strip()
    graphics: list[str] = []
    try:
        completed = subprocess.run(
            ["lspci"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=2,
            check=False,
        )
        for line in completed.stdout.splitlines():
            marker = next(
                (item for item in ("VGA compatible controller:", "3D controller:", "Display controller:") if item in line),
                "",
            )
            if not marker:
                continue
            value = line.split(marker, 1)[1].strip()
            if value and value not in graphics:
                graphics.append(value)
    except (OSError, subprocess.SubprocessError):
        pass
    return {"mainboard": mainboard, "graphics": " · ".join(graphics[:2])}


class MagicImageSolo:
    # Match HardwareCheck's clearly visible update notification.  The update
    # itself remains fully verified and still requires an explicit click in
    # Options; the animated header button only makes a ready update impossible
    # to overlook.
    UPDATE_ALERT_PHASE_CLASSES = (
        "update-phase-red",
        "update-phase-gold",
        "update-phase-blue",
        "update-phase-purple",
    )

    def __init__(self, core: Any) -> None:
        self.core = core
        self.settings = self._load_settings()
        self.snapshot: dict[str, object] = {}
        self.models: list[dict[str, object]] = []
        self.inspection = magic.MediaInspection()
        self.images_by_id: dict[str, magic.MagicImage] = {}
        self.targets_by_path: dict[str, magic.BlockDevice] = {}
        self.data_disks_by_path: dict[str, magic.BlockDevice] = {}
        self.validation: magic.ConfigValidation | None = None
        self.plan: magic.RestoreProofPlan | None = None
        self.data_disk_plan: magic.DataDiskPreparePlan | None = None
        self._restore_running = False
        self._image_choices_refreshing = False
        self._post_restore_action = "reboot"
        self._validation_timer: int | None = None
        self._warning_acknowledged = ""
        self._last_warning = ""
        self._config_server_pending = ""
        self._config_server_checked: set[str] = set()
        self._wifi_busy = False
        self._internet_online = False
        self._internet_probe_running = False
        self._time_sync_running = False
        self._model_sync_running = False
        self._program_update_running = False
        # A verified package is intentionally only *staged* in the background.
        # Applying it remains a visible operator action in Options.
        self._pending_program_update: program_update.ProgramUpdateResult | None = None
        self._program_update_alert_timer_id: int | None = None
        self._program_update_alert_phase = 0
        self._program_update_alert_version = ""
        self._wifi_dialog_status: Gtk.Label | None = None
        self._wifi_dialog_rows: Gtk.ListBox | None = None

        self._base_css_provider = Gtk.CssProvider(); self._base_css_provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(self._screen(), self._base_css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self._layout_css_provider = Gtk.CssProvider(); self._layout_css_provider.load_from_data(solo_layout_css(self.settings["layout"]))
        Gtk.StyleContext.add_provider_for_screen(self._screen(), self._layout_css_provider, Gtk.STYLE_PROVIDER_PRIORITY_USER)
        self.window = Gtk.Window(title=self._t("app"))
        self.window.set_default_size(1280, 800); self.window.set_border_width(0)
        self.window.get_style_context().add_class(f"layout-{self.settings['layout']}")
        self.window.connect("destroy", Gtk.main_quit)
        self._build(); self._reload_models(); self._scan_hardware(); self._refresh_media(); self._start_wifi_autoconnect()
        # Keep the startup responsive.  A connected WLAN/LAN triggers the
        # small manifest request in the background; the full model database is
        # downloaded only when its verified checksum changed.
        GLib.timeout_add_seconds(4, self._start_background_model_sync)
        GLib.timeout_add_seconds(8, self._start_background_program_update)
        GLib.timeout_add_seconds(3, self._refresh_internet_state)
        GLib.timeout_add_seconds(30, self._refresh_internet_state)
        # NTP must not depend on the update schedule or on the header's
        # Internet indicator.  The first call is immediate; later calls are
        # a real repeating GLib timer, not a one-time 30-second callback.
        GLib.timeout_add_seconds(2, self._retry_time_sync)
        GLib.timeout_add_seconds(30, self._repeat_time_sync)
        GLib.timeout_add_seconds(1, self._refresh_header)

    @staticmethod
    def _screen():
        from gi.repository import Gdk
        return Gdk.Screen.get_default()

    def _language(self) -> str:
        language = _safe_text(self.settings.get("language")).upper()
        return language if language in LANGUAGES else "DE"

    def _t(self, key: str, **values: object) -> str:
        text = TEXT.get(self._language(), TEXT["DE"]).get(key, TEXT["DE"].get(key, key))
        return text.format(**values)

    def _localized_difference_detail(self, detail: str) -> str:
        """Translate the visible, structured hardware comparison from the core."""

        if detail.startswith("Hardware-Abgleich:"):
            config = self.validation.config if self.validation else ""
            return self._t("legacy_config_without_model", config=config)
        if self._language() == "DE":
            return detail
        metric, separator, comparison = detail.partition(":")
        metric_key = COMPARISON_METRIC_KEYS.get(metric.strip())
        if not separator or not metric_key:
            return detail
        localized_metric = self._t(metric_key)
        comparison = comparison.strip()
        unknown = re.fullmatch(
            r"Gerät unbekannt – Config ([^:]+): (.+) kann nicht sicher geprüft werden\.",
            comparison,
        )
        if unknown:
            return f"{localized_metric}: {self._t('comparison_unknown', config=unknown.group(1), value=unknown.group(2))}"
        mismatch = re.fullmatch(r"Gerät (.+?) ≠ Config ([^:]+): (.+)", comparison)
        if mismatch:
            actual, config, expected = mismatch.groups()
            return (
                f"{localized_metric}: {self._t('comparison_device', value=actual)} ≠ "
                f"{self._t('comparison_config', config=config, value=expected)}"
            )
        return f"{localized_metric}: {comparison}"

    def _localized_restore_progress(self, detail: str) -> str:
        key = RESTORE_PROGRESS_TEXT_KEYS.get(detail)
        if key:
            return self._t(key)
        return detail if self._language() == "DE" else self._t("restore_progress_generic")

    def _disk_display_text(self, disk: magic.BlockDevice) -> str:
        """Keep device data verbatim but localize the manager's fallback words."""

        return disk.description.replace("unbekanntes Modell", self._t("unknown_model")).replace(
            "unbekannter Bus", self._t("unknown_bus")
        )

    def _image_display_text(self, image: magic.MagicImage) -> str:
        # A short operator folder is intentionally presented without the
        # internal Clonezilla image directory or technical source suffix.
        if image.display_location:
            return image.operator_label
        version = f" · {image.version}" if image.version else ""
        source = self._t("image_manifest" if image.managed else "image_without_manifest")
        return f"{image.display_name}{version} ({source})"

    def _refresh_image_choices(self, *, preserve_selection: bool = True) -> None:
        """Expose only images allowed for the current config/install route."""

        selected_id = self.image_combo.get_active_id() if preserve_selection else ""
        images = magic.install_images_for_config(self.validation, self.inspection.images)
        complete = bool(self.validation and self.validation.deployment_mode == "complete")
        self.images_by_id = {image.image_id: image for image in images}
        self._image_choices_refreshing = True
        try:
            self.image_combo.remove_all()
            self.image_combo.append("", self._t("complete_image_choose" if complete else "choose_image"))
            for image in images:
                self.image_combo.append(image.image_id, self._image_display_text(image))
            if complete and self._config_server_pending == self.validation.config:
                self.image_combo.set_active(0)
            elif selected_id and selected_id in self.images_by_id:
                self.image_combo.set_active_id(selected_id)
            elif complete and len(images) == 1:
                self.image_combo.set_active_id(images[0].image_id)
            else:
                self.image_combo.set_active(0)
        finally:
            self._image_choices_refreshing = False

    def _load_settings(self) -> dict[str, str]:
        result = {"device_type": "laptop", "language": "DE", "layout": "original"}
        # Existing combined HardwareCheck media already store the operator's
        # language in hardwarecheck-settings.json.  Read that first so Solo
        # does not jump back to German merely because its own settings file has
        # not been created yet.  A dedicated Solo setting still wins.
        for settings_path in (SCRIPT_DIR / "hardwarecheck-settings.json", SETTINGS_FILE):
            try:
                value = json.loads(settings_path.read_text(encoding="utf-8-sig"))
                if isinstance(value, dict):
                    mode = _safe_text(value.get("device_type")).lower()
                    language = _safe_text(value.get("language")).upper()
                    layout = _safe_text(value.get("layout") or value.get("v5_layout")).lower()
                    if mode in {"laptop", "pc"}: result["device_type"] = mode
                    if language in LANGUAGES: result["language"] = language
                    if layout in LAYOUTS: result["layout"] = layout
            except (OSError, json.JSONDecodeError):
                pass
        return result

    def _save_settings(self) -> None:
        staging = SETTINGS_FILE.with_suffix(".new")
        try:
            staging.write_text(json.dumps(self.settings, indent=2) + "\n", encoding="utf-8"); os.replace(staging, SETTINGS_FILE)
        except OSError:
            try: staging.unlink()
            except OSError: pass

    def _mode(self) -> str: return _safe_text(self.settings.get("device_type")).lower() or "laptop"
    def _device_label(self) -> str: return self._t("computer") if self._mode() == "pc" else self._t("notebook")

    def _workshop_start_mode(self) -> str:
        try:
            mode = _safe_text(self.core.get_workshop_start_mode()).lower()
        except (AttributeError, OSError, ValueError):
            mode = "magic"
        return mode if mode in {"magic", "hardwarecheck"} else "magic"

    def _load_database(self) -> list[dict[str, object]]:
        path = PC_DATABASE_FILE if self._mode() == "pc" else LAPTOP_DATABASE_FILE
        try: payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError): return []
        models = [item for item in payload if isinstance(item, dict)] if isinstance(payload, list) else []
        return config_sync.merge_model_overrides(models, SCRIPT_DIR, self._mode())

    def _label(self, text: str, style: str = "", wrap: bool = False) -> Gtk.Label:
        label = Gtk.Label(label=text, xalign=0); label.set_line_wrap(wrap)
        if wrap: label.set_line_wrap_mode(2)
        if style: label.get_style_context().add_class(style)
        return label

    def _button(self, text: str, callback, style: str = "") -> Gtk.Button:
        button = Gtk.Button(label=text)
        if style: button.get_style_context().add_class(style)
        button.connect("clicked", callback); return button

    def _card(self) -> tuple[Gtk.Frame, Gtk.Box]:
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.NONE)
        frame.get_style_context().add_class("card")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        box.set_margin_start(18); box.set_margin_end(18); box.set_margin_top(16); box.set_margin_bottom(16)
        frame.add(box)
        return frame, box

    def _chip(self, text: str) -> Gtk.Label: return self._label(text, "status-chip")

    def _network_chip(self) -> Gtk.Box:
        """Create a Wi-Fi status chip with an explicit online indicator."""
        chip = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        chip.get_style_context().add_class("status-chip")
        self.wifi_dot = self._label("●", "network-dot")
        self.wifi_dot.set_no_show_all(True)
        self.wifi_dot.hide()
        self.wifi_label = self._label(self._t("wifi_offline"))
        chip.pack_start(self.wifi_dot, False, False, 0)
        chip.pack_start(self.wifi_label, False, False, 0)
        return chip

    def _build_program_update_alert(self) -> Gtk.Button:
        """Build the header alert that leads directly to Options > Updates."""

        button = Gtk.Button()
        button.get_style_context().add_class("update-alert")
        button.set_no_show_all(True)
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        icon = Gtk.Image.new_from_icon_name("software-update-available-symbolic", Gtk.IconSize.BUTTON)
        inner.pack_start(icon, False, False, 0)
        self.update_alert_label = self._label(self._t("program_update_alert", version=""))
        self.update_alert_label.set_max_width_chars(27)
        self.update_alert_label.set_ellipsize(Pango.EllipsizeMode.END)
        inner.pack_start(self.update_alert_label, False, False, 0)
        button.add(inner)
        button.connect("clicked", self._open_options_safe)
        button.set_tooltip_text(self._t("program_update_alert_tooltip"))
        self.update_alert_button = button
        return button

    def _set_network_chip(self, text: str, state: str = "", online: bool = False) -> None:
        self.wifi_label.set_text(text)
        self._set_chip_state(self.wifi_chip, state)
        context = self.wifi_dot.get_style_context()
        context.remove_class("online")
        if online:
            context.add_class("online")
            self.wifi_dot.show()
        else:
            self.wifi_dot.hide()

    @staticmethod
    def _flag_pixbuf(language: str, width: int = 30, height: int = 18) -> GdkPixbuf.Pixbuf:
        """Return a tiny drawn flag instead of relying on emoji fonts.

        The minimal Debian images deliberately do not install colour emoji
        fonts.  Drawing the three flags here keeps the language buttons clear
        on every supported display and Gtk theme.
        """
        width, height = max(12, int(width)), max(8, int(height))
        pixels = bytearray(width * height * 4)

        def set_pixel(x: int, y: int, rgb: tuple[int, int, int]) -> None:
            offset = (y * width + x) * 4
            pixels[offset:offset + 4] = bytes((*rgb, 255))

        def fill(rgb: tuple[int, int, int]) -> None:
            for y in range(height):
                for x in range(width):
                    set_pixel(x, y, rgb)

        language = language.upper()
        if language == "DE":
            bands = ((0, 0, 0), (205, 43, 47), (255, 206, 55))
            for y in range(height):
                colour = bands[min(2, (y * 3) // height)]
                for x in range(width):
                    set_pixel(x, y, colour)
        elif language == "CZ":
            for y in range(height):
                colour = (255, 255, 255) if y < height // 2 else (215, 38, 56)
                for x in range(width):
                    set_pixel(x, y, colour)
            middle = (height - 1) / 2
            for y in range(height):
                reach = int((height / 2 - abs(y - middle)) * (width / height))
                for x in range(max(0, reach)):
                    set_pixel(x, y, (23, 76, 153))
        else:  # United Kingdom / English
            fill((31, 73, 142))
            white = max(2, height // 4)
            red = max(1, height // 7)
            for y in range(height):
                for x in range(width):
                    if abs(x - width // 2) < white or abs(y - height // 2) < white:
                        set_pixel(x, y, (255, 255, 255))
            for y in range(height):
                for x in range(width):
                    if abs(x - width // 2) < red or abs(y - height // 2) < red:
                        set_pixel(x, y, (200, 34, 47))

        return GdkPixbuf.Pixbuf.new_from_bytes(
            GLib.Bytes.new(bytes(pixels)),
            GdkPixbuf.Colorspace.RGB,
            True,
            8,
            width,
            height,
            width * 4,
        )

    def _language_button(self, language: str, callback) -> Gtk.Button:
        button = Gtk.Button()
        if language == self._language():
            button.get_style_context().add_class("language-active")
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        inner.pack_start(Gtk.Image.new_from_pixbuf(self._flag_pixbuf(language)), False, False, 0)
        inner.pack_start(self._label(language), False, False, 0)
        button.add(inner)
        button.connect("clicked", callback)
        return button

    def _build(self) -> None:
        self.root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.root.get_style_context().add_class("root"); self.root.get_style_context().add_class(f"layout-{self.settings['layout']}")
        self.window.add(self.root)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8); top.get_style_context().add_class("top")
        brand = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        brand.pack_start(self._label(self._t("app"), "title"), False, False, 0)
        brand.pack_start(self._label(self._t("version") + f" · {APP_VERSION}", "subtitle"), False, False, 0)
        top.pack_start(brand, False, False, 0); top.pack_start(Gtk.Box(), True, True, 0)
        self.update_alert_button = self._build_program_update_alert()
        self.wifi_chip = self._network_chip(); self.db_chip = self._chip(f"{self._t('db')} –")
        self.battery_chip = self._chip(f"{self._t('battery')}: {self._t('battery_unknown')}"); self.clock_chip = self._chip("–")
        for widget in (self.update_alert_button, self.wifi_chip, self.db_chip, self.battery_chip, self.clock_chip): top.pack_start(widget, False, False, 0)
        # The symbol keeps the header compact.  The safe wrapper turns an
        # unexpected GTK error into a visible message instead of making the
        # click appear dead.
        gear = self._button("⚙", self._open_options_safe, "gear")
        gear.set_tooltip_text(self._t("options")); top.pack_start(gear, False, False, 0)
        self.root.pack_start(top, False, False, 0)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10); header.get_style_context().add_class("solo-controls")
        header.set_margin_start(24); header.set_margin_end(24); header.set_margin_top(13); header.set_margin_bottom(9)
        header.pack_start(self._label(self._t("device_type"), "section"), False, False, 0)
        self.mode_combo = Gtk.ComboBoxText(); self.mode_combo.append("laptop", self._t("notebook")); self.mode_combo.append("pc", self._t("computer"))
        self.mode_combo.set_active_id(self._mode()); self.mode_combo.connect("changed", self._mode_changed); header.pack_start(self.mode_combo, False, False, 0)
        self.root.pack_start(header, False, False, 0)
        scroll = Gtk.ScrolledWindow(); scroll.get_style_context().add_class("solo-scroll"); scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12); outer.get_style_context().add_class("solo-content")
        outer.set_margin_start(24); outer.set_margin_end(24); outer.set_margin_top(5); outer.set_margin_bottom(13); scroll.add(outer)
        self.root.pack_start(scroll, True, True, 0)
        work = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        work.get_style_context().add_class("solo-work")
        outer.pack_start(work, True, True, 0)
        left, left_box = self._card()
        right, right_box = self._card()
        # Keep the proven full-height right-side allocation, but make that
        # outer frame transparent.  The two visible cards inside it share the
        # height; neither is a competing top-level panel beside the workflow.
        right.get_style_context().remove_class("card")
        device_card, device_box = self._card()
        status_card, status_box = self._card()
        self.device_card = device_card
        self.status_card = status_card
        # Never let either visible card consume the spare height of the
        # workflow.  Their requested heights are set from the actual device
        # rows below, so the unused space remains plain page background.
        right_box.pack_start(device_card, False, False, 0)
        right_box.pack_start(status_card, False, False, 10)
        work.pack_start(left, True, True, 0)
        work.pack_start(right, True, True, 0)
        line = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8); line.pack_start(self._label(self._t("clonezilla"), "section"), True, True, 0)
        line.pack_end(self._button(self._t("refresh"), self._refresh_media), False, False, 0); left_box.pack_start(line, False, False, 0)
        self.media_status = self._label(self._t("checking_media"), "muted", True); left_box.pack_start(self.media_status, False, False, 0)
        left_box.pack_start(self._label(self._t("config"), "section"), False, False, 8)
        config_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9); self.config_entry = Gtk.Entry()
        self.config_entry.set_max_length(4); self.config_entry.set_width_chars(8); self.config_entry.set_size_request(190, 64); self.config_entry.set_input_purpose(Gtk.InputPurpose.DIGITS)
        self.config_entry.get_style_context().add_class("config-entry"); self.config_entry.connect("changed", self._config_changed); self.config_entry.connect("activate", self._validate_config)
        config_row.pack_start(self.config_entry, False, False, 0); config_row.pack_start(self._label(self._t("four_digits"), "muted"), False, False, 0); left_box.pack_start(config_row, False, False, 0)
        self.config_status = self._label(self._t("enter_config"), "muted", True); left_box.pack_start(self.config_status, False, False, 0)
        left_box.pack_start(self._label(self._t("image_and_target"), "section"), False, False, 8)
        image_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8); image_row.pack_start(self._label(self._t("image")), False, False, 0)
        self.image_combo = Gtk.ComboBoxText(); self.image_combo.set_hexpand(True); self.image_combo.connect("changed", self._selection_changed); image_row.pack_start(self.image_combo, True, True, 0); left_box.pack_start(image_row, False, False, 0)
        target_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8); target_row.pack_start(self._label(self._t("target")), False, False, 0)
        self.target_combo = Gtk.ComboBoxText(); self.target_combo.set_hexpand(True); self.target_combo.connect("changed", self._selection_changed); target_row.pack_start(self.target_combo, True, True, 0); left_box.pack_start(target_row, False, False, 0)
        data_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8); data_row.pack_start(self._label(self._t("data_disk")), False, False, 0)
        self.data_disk_combo = Gtk.ComboBoxText(); self.data_disk_combo.set_hexpand(True); self.data_disk_combo.connect("changed", self._selection_changed); data_row.pack_start(self.data_disk_combo, True, True, 0); left_box.pack_start(data_row, False, False, 7)
        left_box.pack_start(self._label(self._t("data_disk_hint"), "muted", True), False, False, 0)
        self.device_overview_box = device_box
        self.device_overview_box.set_vexpand(False); self.device_overview_box.set_valign(Gtk.Align.START)
        self._update_device_overview()
        status_header = self._label(self._t("status"), "section")
        status_box.pack_start(status_header, False, False, 0); self.summary = Gtk.TextView()
        self.summary.set_editable(False); self.summary.set_cursor_visible(False); self.summary.set_wrap_mode(Gtk.WrapMode.WORD_CHAR); self.summary.set_size_request(273, 92); status_box.pack_start(self.summary, True, True, 0)
        self.progress_label = self._label("", "muted", True); self.progress_label.set_no_show_all(True); self.progress = Gtk.ProgressBar(); self.progress.set_show_text(True); self.progress.set_no_show_all(True)
        status_box.pack_start(self.progress_label, False, False, 0); status_box.pack_start(self.progress, False, False, 0)
        self.install_button = self._button(self._t("install"), self._install_clicked, "danger"); self.install_button.set_sensitive(False); status_box.pack_start(self.install_button, False, False, 0)
        footer_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
        footer_row.set_margin_start(24); footer_row.set_margin_end(24); footer_row.set_margin_bottom(11)
        self.footer = self._label("", "muted", True); self.footer.get_style_context().add_class("solo-footer")
        self.footer_update_spinner = Gtk.Spinner(); self.footer_update_spinner.set_no_show_all(True); self.footer_update_spinner.hide()
        self.footer_update_button = self._button(self._t("program_update_install"), self._install_pending_program_update, "primary")
        self.footer_update_button.set_no_show_all(True); self.footer_update_button.hide()
        footer_row.pack_start(self.footer, True, True, 0)
        footer_row.pack_end(self.footer_update_button, False, False, 0)
        footer_row.pack_end(self.footer_update_spinner, False, False, 0)
        self.root.pack_start(footer_row, False, False, 0)

    # ---------- appearance, device type and small header ----------
    def _mode_changed(self, _widget=None) -> None:
        self.settings["device_type"] = self.mode_combo.get_active_id() or "laptop"; self._save_settings(); self._reload_models(); self._update_device_overview(); self._validate_config()

    def _reload_models(self) -> None:
        self.models = self._load_database()
        self.footer.set_text(self._t("database_active", device=self._device_label(), count=len(self.models)) if self.models else self._t("database_empty", device=self._device_label()))
        self._refresh_header()

    def _start_background_model_sync(self) -> bool:
        """Fetch the public GitHub database only after Internet is available.

        Config-server access remains deliberately separate and is still only
        activated for the exact requested config.
        """

        if self._model_sync_running:
            return False
        self._model_sync_running = True

        def worker() -> model_database_update.SyncResult:
            magic.synchronize_live_time()
            try:
                online = bool(self.core.internet_already_available(timeout=2.5))
            except Exception:
                online = False
            if not online:
                return model_database_update.SyncResult(False, False, "Keine Internetverbindung für Datenbankprüfung.")
            return model_database_update.sync_model_database(SCRIPT_DIR)

        def finished(result: model_database_update.SyncResult) -> bool:
            self._model_sync_running = False
            if result.updated:
                self._reload_models()
                self._validate_config()
            else:
                self._refresh_header()
            return False

        threading.Thread(
            target=lambda: GLib.idle_add(finished, worker()),
            name="magic-solo-model-sync",
            daemon=True,
        ).start()
        return False

    def _can_activate_program_update(self) -> bool:
        """Never restart while an operator has already started a workflow."""

        if self._restore_running:
            return False
        if self.config_entry.get_text().strip():
            return False
        return not any((self.image_combo.get_active_id(), self.target_combo.get_active_id(), self.data_disk_combo.get_active_id()))

    def _start_background_program_update(self, retry_failed_check: bool = False) -> bool:
        """Stage a verified update silently, but never apply it silently.

        This is intentionally independent from the model database update.  The
        manifest request is tiny and throttled to once per day by the updater;
        a changed program package is only installed after every contained file
        has passed its SHA-256 check.
        """

        if self._program_update_running:
            return False
        self._program_update_running = True

        def worker() -> program_update.ProgramUpdateResult:
            # Der Updater prüft eine bereits vollständig verifizierte Staging-
            # Version zuerst und verwendet danach selbst den kleinen Manifest-
            # Abruf als tatsächlichen Verbindungscheck.  So verhindert ein
            # träger WLAN-Status beim Systemstart kein Programm-Update.
            magic.synchronize_live_time()
            return program_update.stage_program_update(
                SCRIPT_DIR,
                APP_VERSION,
                retry_failed_check=retry_failed_check,
            )

        def finished(result: program_update.ProgramUpdateResult) -> bool:
            self._program_update_running = False
            self._pending_program_update = result if result.staged else None
            if result.staged:
                # The background check downloads and verifies the package,
                # but the visible footer button leaves the final restart in
                # the operator's control.
                self._show_pending_program_update(result)
            else:
                self._hide_program_update_alert()
            return False

        threading.Thread(
            target=lambda: GLib.idle_add(finished, worker()),
            name="magic-solo-program-update",
            daemon=True,
        ).start()
        return False

    def _show_pending_program_update(self, result: program_update.ProgramUpdateResult) -> None:
        """Expose a background-verified release without opening Options."""

        self._pending_program_update = result
        self.footer.set_text(self._t("program_update_ready", version=result.version))
        self.footer_update_spinner.stop(); self.footer_update_spinner.hide()
        self.footer_update_button.set_label(self._t("program_update_install_ready", version=result.version))
        self.footer_update_button.set_sensitive(True)
        self.footer_update_button.show()
        self._show_program_update_alert(result.version)

    def _clear_program_update_alert_phase_classes(self) -> None:
        context = self.update_alert_button.get_style_context()
        for css_class in self.UPDATE_ALERT_PHASE_CLASSES:
            context.remove_class(css_class)

    def _program_update_alert_tick(self) -> bool:
        if not self._program_update_alert_version:
            self._clear_program_update_alert_phase_classes()
            self._program_update_alert_timer_id = None
            return False
        self._clear_program_update_alert_phase_classes()
        css_class = self.UPDATE_ALERT_PHASE_CLASSES[
            self._program_update_alert_phase % len(self.UPDATE_ALERT_PHASE_CLASSES)
        ]
        self._program_update_alert_phase += 1
        self.update_alert_button.get_style_context().add_class(css_class)
        return True

    def _show_program_update_alert(self, version: str) -> None:
        """Show the colourful clickable header alert for a verified update."""

        self._program_update_alert_version = version
        self.update_alert_label.set_text(self._t("program_update_alert", version=version))
        child = self.update_alert_button.get_child()
        if child is not None:
            child.show_all()
        self.update_alert_button.show()
        if self._program_update_alert_timer_id is None:
            self._program_update_alert_phase = 0
            self._program_update_alert_tick()
            self._program_update_alert_timer_id = GLib.timeout_add(650, self._program_update_alert_tick)

    def _hide_program_update_alert(self) -> None:
        self._program_update_alert_version = ""
        if self._program_update_alert_timer_id is not None:
            try:
                GLib.source_remove(self._program_update_alert_timer_id)
            except Exception:
                pass
            self._program_update_alert_timer_id = None
        self._clear_program_update_alert_phase_classes()
        self.update_alert_button.hide()

    def _show_test_program_update_alert(self, _button=None) -> None:
        """Make the visual notification testable without publishing a release."""

        self._show_program_update_alert("TEST")

    def _set_program_update_failure(self, message: str) -> None:
        self.footer_update_spinner.stop(); self.footer_update_spinner.hide()
        self.footer_update_button.set_sensitive(True)
        self.footer.set_text(message)

    def _install_pending_program_update(self, _button=None) -> None:
        """Install the prepared update from the persistent main-screen button."""

        result = self._pending_program_update
        if result is None or not result.staged:
            return
        self._apply_pending_program_update(result)

    def _manual_program_update(
        self,
        owner: Gtk.Dialog,
        status: Gtk.Label,
        spinner: Gtk.Spinner,
        progress: Gtk.ProgressBar,
        check_button: Gtk.Button,
        install_button: Gtk.Button,
        pending: dict[str, program_update.ProgramUpdateResult | None],
    ) -> None:
        """Force one verified program check from the Options dialog.

        The automatic job deliberately observes the daily interval in the
        updater.  This operator action is the explicit, safe escape hatch for
        a same-day hotfix: it bypasses only the interval, never the HTTPS,
        package allow-list or SHA-256 checks.
        """

        progress.set_show_text(True)
        progress.set_fraction(0.0)
        progress.set_text(self._t("program_update_checking"))
        progress.show()

        # A normal start may already be staging the same package in the
        # background.  The Options dialog must not look inactive in that case:
        # it waits visibly for that worker and exposes its verified result.
        if self._program_update_running:
            status.set_text(self._t("program_update_busy"))
            spinner.show()
            spinner.start()

            def await_background() -> bool:
                if self._program_update_running:
                    progress.pulse()
                    return True
                spinner.stop()
                spinner.hide()
                check_button.set_sensitive(True)
                result = self._pending_program_update
                if result is not None and result.staged:
                    pending["result"] = result
                    status.set_text(self._t("program_update_downloaded", version=result.version))
                    progress.set_fraction(1.0)
                    progress.set_text(self._t("program_update_downloaded", version=result.version))
                    install_button.set_label(self._t("program_update_install_ready", version=result.version))
                    install_button.show()
                    return False
                # The automatic check found no usable update.  Continue with
                # the requested forced check so a same-day release is not
                # hidden behind the daily interval.
                self._manual_program_update(owner, status, spinner, progress, check_button, install_button, pending)
                return False

            GLib.timeout_add(120, await_background)
            return
        self._program_update_running = True
        check_button.set_sensitive(False)
        install_button.hide()
        pending["result"] = None
        status.set_text(self._t("program_update_checking"))
        spinner.show()
        spinner.start()

        def pulse_progress() -> bool:
            if not self._program_update_running:
                return False
            progress.pulse()
            return True

        GLib.timeout_add(120, pulse_progress)

        def worker() -> program_update.ProgramUpdateResult:
            try:
                magic.synchronize_live_time()
                return program_update.stage_program_update(SCRIPT_DIR, APP_VERSION, force=True)
            except Exception as exc:  # Keep a manual check visibly actionable.
                return program_update.ProgramUpdateResult(False, False, False, str(exc))

        def finished(result: program_update.ProgramUpdateResult) -> bool:
            self._program_update_running = False
            check_button.set_sensitive(True)
            spinner.stop()
            spinner.hide()
            if result.staged:
                pending["result"] = result
                status.set_text(self._t("program_update_downloaded", version=result.version))
                self._show_pending_program_update(result)
                progress.set_fraction(1.0)
                progress.set_text(self._t("program_update_downloaded", version=result.version))
                install_button.set_label(self._t("program_update_install_ready", version=result.version))
                install_button.show()
                return False
            if result.checked and not result.available:
                status.set_text(self._t("program_update_current"))
                progress.set_fraction(1.0)
                progress.set_text(self._t("program_update_current"))
                self._hide_program_update_alert()
            else:
                failure = self._t("program_update_error")
                status.set_text(self._t("program_update_failed", reason=failure))
                progress.set_fraction(0.0)
                progress.set_text(self._t("program_update_failed", reason=failure))
            return False

        threading.Thread(
            target=lambda: GLib.idle_add(finished, worker()),
            name="magic-solo-manual-program-update",
            daemon=True,
        ).start()

    def _install_manual_program_update(
        self,
        owner: Gtk.Dialog,
        status: Gtk.Label,
        check_button: Gtk.Button,
        install_button: Gtk.Button,
        pending: dict[str, program_update.ProgramUpdateResult | None],
    ) -> None:
        """Apply the explicitly staged release from the visible Options button."""

        result = pending.get("result")
        if result is None or not result.staged:
            return
        self._apply_pending_program_update(
            result,
            owner=owner,
            status=status,
            check_button=check_button,
            install_button=install_button,
        )

    def _apply_pending_program_update(
        self,
        result: program_update.ProgramUpdateResult,
        *,
        owner: Gtk.Dialog | None = None,
        status: Gtk.Label | None = None,
        check_button: Gtk.Button | None = None,
        install_button: Gtk.Button | None = None,
    ) -> None:
        """Apply a verified staged update and visibly restart Magic Image."""

        if not self._can_activate_program_update():
            if status is not None:
                status.set_text(self._t("program_update_prepared", version=result.version))
            self.footer.set_text(self._t("program_update_prepared", version=result.version))
            return
        if check_button is not None:
            check_button.set_sensitive(False)
        if install_button is not None:
            install_button.set_sensitive(False)
        self.footer_update_button.set_sensitive(False)
        self.footer_update_spinner.show(); self.footer_update_spinner.start()
        if status is not None:
            status.set_text(self._t("program_update_restarting", version=result.version))
        self.footer.set_text(self._t("program_update_restarting", version=result.version))
        applied = program_update.apply_staged_program_update(
            SCRIPT_DIR,
            result.staging_dir or SCRIPT_DIR,
            result.version,
        )
        if not applied.staged:
            if check_button is not None:
                check_button.set_sensitive(True)
            if install_button is not None:
                install_button.set_sensitive(True)
            failure = self._t("program_update_install_failed")
            if status is not None:
                status.set_text(failure)
            self._set_program_update_failure(failure)
            return
        # Closing Options first prevents a visible obsolete window while the
        # program restarts into the newly verified files.
        if owner is not None:
            owner.response(Gtk.ResponseType.CLOSE)
        GLib.timeout_add(550, self._restart_solo)

    def _refresh_internet_state(self) -> bool:
        """Probe Internet access outside the Gtk thread for the header dot."""
        if self._internet_probe_running:
            return False
        self._internet_probe_running = True

        def worker() -> bool:
            try:
                online = bool(self.core.internet_already_available(timeout=2.5))
                # The first boot-time update probe can happen before Wi-Fi is
                # ready.  Polling is already every 30 seconds; the shared
                # helper itself retries a failed NTP request only after one
                # minute and caches success for an hour.  Run it here, never
                # in the GTK thread, so connecting later needs no click.
                if online:
                    magic.synchronize_live_time()
                return online
            except Exception:
                return False

        def finished(online: bool) -> bool:
            became_online = online and not self._internet_online
            self._internet_online = online
            self._internet_probe_running = False
            self._refresh_header()
            if became_online:
                # A failed start-up attempt must not force a newly connected
                # SSD to wait ten minutes before it can see an update.
                self._start_background_model_sync()
                self._start_background_program_update(retry_failed_check=True)
            return False

        threading.Thread(
            target=lambda: GLib.idle_add(finished, worker()),
            name="magic-solo-internet-state",
            daemon=True,
        ).start()
        return False

    def _database_version(self) -> str:
        try:
            manifest = json.loads(MANIFEST_FILE.read_text(encoding="utf-8-sig")); return _safe_text(manifest.get("version")) or str(len(self.models) or "–")
        except (OSError, json.JSONDecodeError): return str(len(self.models) or "–")

    def _refresh_header(self) -> bool:
        self.clock_chip.set_text(datetime.datetime.now().strftime("%H:%M · %d.%m.%Y")); self.db_chip.set_text(f"{self._t('db')} {self._database_version()} · {len(self.models)}")
        try:
            battery = self.core.read_battery_details(); capacity = battery.get("capacity_percent")
            self.battery_chip.set_text(f"{self._t('battery')}: {capacity} %" if capacity is not None else f"{self._t('battery')}: {self._t('battery_unknown')}")
        except Exception: self.battery_chip.set_text(f"{self._t('battery')}: {self._t('battery_unknown')}")
        ssid = self._current_wifi_ssid()
        if ssid:
            self._set_network_chip(f"⌁ {ssid}", "good" if self._internet_online else "warn", self._internet_online)
        else:
            self._set_network_chip(self._t("wifi_offline"))
        return True

    @staticmethod
    def _set_chip_state(widget: Gtk.Widget, state: str) -> None:
        context = widget.get_style_context()
        for item in ("good", "warn", "bad"): context.remove_class(item)
        if state: context.add_class(state)

    def _current_wifi_ssid(self) -> str:
        try:
            for interface in self.core.list_network_interfaces(wifi=True):
                ssid = _safe_text(self.core.current_wifi_ssid(interface))
                if ssid: return ssid
        except Exception: pass
        return ""

    # ---------- hardware and media ----------
    def _scan_hardware(self, _button=None) -> None:
        def worker() -> None:
            try: snapshot, error = self.core.get_system_snapshot(), ""
            except Exception as exc: snapshot, error = {}, str(exc)
            GLib.idle_add(self._finish_hardware_scan, snapshot, error)
        threading.Thread(target=worker, name="magic-solo-hardware", daemon=True).start()

    def _finish_hardware_scan(self, snapshot: dict[str, object], error: str) -> bool:
        self.snapshot = snapshot
        self.snapshot.update(_collect_optional_device_details())
        self._update_device_overview()
        if error: self.config_status.set_text(self._t("hardware_error")); self._set_status_class("status-bad")
        self._validate_config(); return False

    def _resize_right_cards(self, row_count: int) -> None:
        """Keep the two right-hand cards compact and always on screen.

        The device card gets one additional line per detected detail (for
        example RAM slots, DVD drive, mainboard or graphics).  The status card
        stays immediately below it instead of being stretched to the bottom
        of the window.
        """

        # Five standard notebook rows need only a little over 125 px.  Extra
        # hardware (DVD, graphics, mainboard, more slots) gains one real row
        # at a time.  The fixed, unstyled shells leave the safety card directly
        # below it even when GTK allocates a tall right-hand viewport.
        # The cards include their own 16 px top/bottom content margins.  These
        # are real minimums, so the fixed slot never makes the two visible
        # cards overlap even with a notebook's five standard detail rows.
        device_height = max(154, 58 + max(1, row_count) * 19)
        status_height = 230
        card_width = 350
        total_height = device_height + 10 + status_height
        if hasattr(self, "device_card"):
            self.device_card.set_size_request(card_width, device_height)
        if hasattr(self, "device_shell"):
            self.device_shell.set_size_request(card_width, device_height)
        if hasattr(self, "status_card"):
            self.status_card.set_size_request(card_width, status_height)
        if hasattr(self, "status_shell"):
            self.status_shell.set_size_request(card_width, status_height)
        if hasattr(self, "right_cards"):
            self.right_cards.set_size_request(card_width, total_height)
            self.right_cards.move(self.device_shell, 0, 0)
            self.right_cards.move(self.status_shell, 0, device_height + 10)

    def _update_device_overview(self) -> None:
        """Show a compact device card that grows only for real extra details."""

        box = getattr(self, "device_overview_box", None)
        if box is None:
            return
        for child in box.get_children():
            box.remove(child)
        box.pack_start(self._label(self._t("device_overview"), "device-overview-title"), False, False, 0)
        if not self.snapshot:
            box.pack_start(self._label(self._t("device_reading"), "muted"), False, False, 0)
            self._resize_right_cards(1)
            box.show_all()
            return

        def value(name: str, fallback: str = "–") -> str:
            text = _safe_text(self.snapshot.get(name))
            return text or fallback

        vendor = value("vendor_short", value("vendor", ""))
        model = value("model_name", "")
        system = " ".join(part for part in (vendor, model) if part).strip() or "–"
        ram_parts = [f"{value('ram_total_gb')} GB", value("ram_type", "")]
        ram_layout = value("ram_layout", "")
        if ram_layout:
            ram_parts.append(ram_layout)
        slots = self.snapshot.get("ram_slots_total")
        if slots:
            ram_parts.append(self._t("ram_slots", count=slots))
        storage = " ".join(part for part in (value("primary_disk_gb", ""), value("primary_storage_type", "")) if part).strip()
        if not storage:
            lines = self.snapshot.get("storage_lines") or []
            storage = _safe_text(lines[0]) if isinstance(lines, list) and lines else "–"
        display = " · ".join(
            part for part in (
                f"{value('display_inches', '')}\"" if value("display_inches", "") else "",
                value("display_type", ""),
                value("resolution", ""),
            ) if part
        ) or "–"
        rows: list[tuple[str, str]] = [
            (self._t("device_system"), system),
            (self._t("device_cpu"), value("cpu_short", value("cpu"))),
            (self._t("device_memory"), " · ".join(part for part in ram_parts if part)),
            (self._t("device_storage"), storage),
        ]
        if self._mode() == "pc":
            rows.extend(
                [
                    (self._t("device_mainboard"), value("mainboard")),
                    (self._t("device_graphics"), value("graphics")),
                ]
            )
        else:
            rows.append((self._t("device_display"), display))

        # The shared scanner lists every internal disk and optical drive in
        # ``storage_lines``.  Keep the primary disk in the standard row above,
        # but add each real extra drive as its own row.  The card's requested
        # height follows the row count, so a desktop with HDDs/DVD expands only
        # by the information it actually has.
        raw_storage_lines = self.snapshot.get("storage_lines") or []
        storage_lines = [_safe_text(line) for line in raw_storage_lines] if isinstance(raw_storage_lines, list) else []
        disk_lines = [line for line in storage_lines if line.lower().startswith("disk ")]
        for disk in disk_lines[1:]:
            rows.append((self._t("device_additional_storage"), disk))
        optical_lines = [
            line for line in storage_lines
            if line.lower().startswith(("dvd ", "cd ", "blu-ray "))
        ]
        for optical in optical_lines:
            rows.append((self._t("device_optical"), optical))

        # Retain compatibility with older scan snapshots which provided this
        # value separately instead of in ``storage_lines``.
        legacy_optical = value("optical_drive", "")
        if not optical_lines and legacy_optical and legacy_optical not in {"–", "none", "None", "NEIN", "Nein", "No"}:
            rows.append((self._t("device_optical"), legacy_optical))

        self._resize_right_cards(len(rows))

        grid = Gtk.Grid(column_spacing=11, row_spacing=2)
        grid.set_column_homogeneous(False)
        for row_number, (label, detail) in enumerate(rows):
            key = self._label(label, "device-key")
            # These details must not make GTK calculate a multi-line natural
            # height before the card has its final width.  Additional hardware
            # gets additional rows; an exceptionally long individual value is
            # kept on one line and shown in full as a tooltip.
            value_label = self._label(detail, "device-value")
            value_label.set_ellipsize(Pango.EllipsizeMode.END)
            value_label.set_tooltip_text(detail)
            value_label.set_hexpand(True)
            grid.attach(key, 0, row_number, 1, 1)
            grid.attach(value_label, 1, row_number, 1, 1)
        box.pack_start(grid, False, False, 0)
        box.show_all()

    def _refresh_media(self, _button=None) -> None:
        self.media_status.set_text(self._t("checking_media"))
        threading.Thread(target=lambda: GLib.idle_add(self._finish_media_refresh, magic.inspect_media()), name="magic-solo-media", daemon=True).start()

    def _finish_media_refresh(self, inspection: magic.MediaInspection) -> bool:
        self.inspection = inspection; self.validation = None; self.plan = None; self.targets_by_path = {target.path: target for target in inspection.safe_targets}
        self.data_disks_by_path = {disk.path: disk for disk in magic.safe_data_disk_targets(inspection.devices, inspection.protected_disks)}
        self._refresh_image_choices(preserve_selection=False)
        self.target_combo.remove_all(); self.target_combo.append("", self._t("choose_target"))
        for target in inspection.safe_targets: self.target_combo.append(target.path, self._disk_display_text(target))
        self.target_combo.set_active(0); self.data_disk_combo.remove_all(); self.data_disk_combo.append("", self._t("choose_data_disk"))
        for disk in self.data_disks_by_path.values(): self.data_disk_combo.append(disk.path, self._disk_display_text(disk))
        self.data_disk_combo.set_active(0); ready = bool(inspection.clonezilla.source_path)
        self.media_status.set_text(self._t("clonezilla_ready") if ready else self._t("media_missing")); self._set_status_class_on(self.media_status, "status-good" if ready else "status-bad")
        self._validate_config(); self._update_summary(); self._diagnose_engine(); return False

    def _diagnose_engine(self) -> None:
        if not self.inspection.clonezilla.source_path: return
        def worker() -> None: GLib.idle_add(self._finish_engine_diagnosis, magic.diagnose_clonezilla_runtime(self.inspection))
        threading.Thread(target=worker, name="magic-solo-clonezilla", daemon=True).start()

    def _finish_engine_diagnosis(self, probe: magic.ClonezillaProbe) -> bool:
        self.inspection.clonezilla = probe; ready = bool(probe.usage_verified)
        self.media_status.set_text(self._t("clonezilla_ready") if ready else self._t("clonezilla_error")); self._set_status_class_on(self.media_status, "status-good" if ready else "status-bad"); self._update_summary(); return False

    # ---------- config, safety warning and restore ----------
    def _config_changed(self, _widget=None) -> None:
        value = self.config_entry.get_text().strip(); digits = "".join(char for char in value if char.isdigit())[:4]
        if digits != value: self.config_entry.set_text(digits); return
        if self._validation_timer is not None: GLib.source_remove(self._validation_timer); self._validation_timer = None
        self.validation = None; self.plan = None
        self._refresh_image_choices()
        if self._warning_acknowledged and value != self._warning_acknowledged: self._warning_acknowledged = ""
        if self._last_warning and value != self._last_warning: self._last_warning = ""
        if len(value) == 4: self._validation_timer = GLib.timeout_add(850, self._validate_after_pause)
        elif value: self.config_status.set_text(self._t("four_digits_only")); self._set_status_class("muted")
        else: self.config_status.set_text(self._t("enter_config")); self._set_status_class("muted")
        self._update_summary()

    def _validate_after_pause(self) -> bool: self._validation_timer = None; self._validate_config(); return False

    def _validate_config(self, _widget=None) -> None:
        value = self.config_entry.get_text().strip()
        if len(value) != 4: self.validation = None; self._refresh_image_choices(); self._update_summary(); return
        # Complete images use their embedded Windows ModelCheck, not model.json.
        # A missing snapshot must still block the ordinary config comparison.
        complete_available = value not in self.inspection.available_configs and any(
            image.deployment_mode == "complete" and value in image.model_configs
            for image in self.inspection.images
        )
        if not self.snapshot and not complete_available:
            self.validation = None; self._refresh_image_choices()
            self.config_status.set_text(self._t("hardware_wait")); self._set_status_class("muted"); self._update_summary(); return
        self.validation = magic.validate_config(
            value,
            self.models,
            self.snapshot,
            self.core.score_model_candidate,
            self.inspection.available_configs,
            self.inspection.classic_acronis_images,
            self.inspection.config_profiles,
            complete_images=self.inspection.images,
        )
        if self.validation.requires_confirmation and self.validation.config == self._warning_acknowledged: self.validation = magic.confirm_config_override(self.validation)
        # Complete images are only a fallback. Finish any configured server
        # lookup before selecting/installing one, since a normal config wins.
        self._start_config_server_check(value)
        checking_server = self._config_server_pending == value
        self._refresh_image_choices()
        if checking_server and (not self.validation.valid or self.validation.deployment_mode == "complete"):
            message, style = self._t("config_server_checking"), "muted"
        elif self.validation.deployment_mode == "complete": message, style = self._t("complete_image_found"), "status-good"
        elif self.validation.strict_match: message, style = self._t("config_matches"), "status-good"
        elif self.validation.legacy_config_without_model: message, style = self._t("legacy_config_without_model", config=value), "status-warn"
        elif self.validation.valid and self.validation.requires_confirmation: message, style = self._t("config_attention"), "status-warn"
        else: message, style = self._t("config_unavailable"), "status-bad"
        self.config_status.set_text(message); self._set_status_class(style); self._update_summary()
        # Local comparison stays responsive, but unavailable/fallback decisions
        # wait for the one background check of this exact config to finish.
        if checking_server and (not self.validation.valid or self.validation.deployment_mode == "complete"):
            return
        if self.validation.config != self._last_warning:
            if self.validation.valid and self.validation.requires_confirmation and not self.validation.override_confirmed:
                self._last_warning = self.validation.config; self._show_difference_warning(self.validation)
            elif not self.validation.valid:
                self._last_warning = self.validation.config; self._show_unavailable_warning(self.validation)

    def _config_server_is_active(self) -> bool:
        settings = config_sync.load_settings(SCRIPT_DIR)
        return bool(settings.enabled and settings.endpoint)

    def _start_config_server_check(self, config: str) -> bool:
        if not self._config_server_is_active() or self._config_server_pending == config or config in self._config_server_checked:
            return False
        self._config_server_pending = config
        repositories = tuple(self.inspection.config_repository_paths)
        device_type = self._mode()

        def worker() -> None:
            result = config_sync.sync_requested_config(config, repositories, SCRIPT_DIR, device_type)
            GLib.idle_add(self._config_server_finished, result)

        threading.Thread(target=worker, name=f"magic-solo-config-{config}", daemon=True).start()
        return True

    def _config_server_finished(self, result: config_sync.ConfigSyncResult) -> bool:
        if self._config_server_pending == result.config: self._config_server_pending = ""
        self._config_server_checked.add(result.config)
        if result.changed:
            self.inspection.available_configs = magic.discover_config_ids(self.inspection.config_repository_paths)
            self.inspection.config_profiles = magic.discover_config_profiles(self.inspection.config_repository_paths)
            self._reload_models()
            self._last_warning = ""
        if self.config_entry.get_text().strip() != result.config:
            return False
        self._validate_config()
        if result.error and self.validation and not self.validation.valid:
            self.config_status.set_text(self._t("config_server_sync_failed")); self._set_status_class("status-warn")
        return False

    def _set_status_class(self, css_class: str) -> None: self._set_status_class_on(self.config_status, css_class)

    @staticmethod
    def _set_status_class_on(widget: Gtk.Widget, css_class: str) -> None:
        context = widget.get_style_context()
        for name in ("status-good", "status-warn", "status-bad", "muted"): context.remove_class(name)
        if css_class: context.add_class(css_class)

    def _new_dialog(self, title: str, width: int = 650) -> Gtk.Dialog:
        dialog = Gtk.Dialog(title=title, transient_for=self.window, flags=Gtk.DialogFlags.MODAL)
        dialog.set_default_size(width, -1)
        dialog.set_modal(True)
        dialog.set_resizable(False)
        dialog.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
        dialog.get_style_context().add_class("solo-dialog")
        dialog.get_style_context().add_class(f"layout-{self.settings['layout']}")
        return dialog

    def _dialog_content(self, dialog: Gtk.Dialog) -> Gtk.Box:
        box = dialog.get_content_area(); box.set_spacing(12); box.set_margin_start(24); box.set_margin_end(24); box.set_margin_top(20); box.set_margin_bottom(18); return box

    def _show_difference_warning(self, validation: magic.ConfigValidation) -> None:
        dialog = self._new_dialog(self._t("check_config"), 760); dialog.add_button(self._t("change_config"), Gtk.ResponseType.CANCEL).get_style_context().add_class("primary"); dialog.add_button(self._t("confirm_difference"), Gtk.ResponseType.ACCEPT).get_style_context().add_class("secondary")
        box = self._dialog_content(dialog)
        box.pack_start(self._label(self._t("attention"), "dialog-title"), False, False, 0)
        box.pack_start(self._label(f"{self._t('config')}: {validation.config}", "section"), False, False, 0)
        box.pack_start(self._label(self._t("detected_differences"), "section"), False, False, 0)
        differences = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        for detail in validation.details:
            differences.pack_start(self._difference_row(self._localized_difference_detail(detail)), False, False, 0)
        box.pack_start(differences, False, False, 0)
        dialog.show_all(); response = dialog.run(); dialog.destroy()
        if response == Gtk.ResponseType.ACCEPT:
            self.validation = magic.confirm_config_override(validation); self._warning_acknowledged = validation.config; self.config_status.set_text(self._t("difference_confirmed")); self._set_status_class("status-warn"); self._update_summary()

    def _difference_row(self, detail: str) -> Gtk.Box:
        """Render one mismatch as a readable metric/device/config block."""
        metric, separator, comparison = detail.partition(":")
        row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        row.get_style_context().add_class("difference-row")
        if not separator:
            row.pack_start(self._label(detail, "difference-actual", True), False, False, 0)
            return row
        row.pack_start(self._label(metric.strip(), "difference-metric"), False, False, 0)
        actual, marker, expected = comparison.strip().partition(" ≠ ")
        row.pack_start(self._label(actual.strip(), "difference-actual", True), False, False, 0)
        if marker:
            row.pack_start(self._label(expected.strip(), "difference-expected", True), False, False, 0)
        return row

    def _show_unavailable_warning(self, validation: magic.ConfigValidation) -> None:
        dialog = self._new_dialog(self._t("install_unavailable"), 650)
        dialog.add_button(self._t("change_config"), Gtk.ResponseType.CLOSE).get_style_context().add_class("primary")
        if validation.classic_acronis_images:
            dialog.add_button(self._t("start_acronis"), Gtk.ResponseType.ACCEPT).get_style_context().add_class("secondary")
        box = self._dialog_content(dialog)
        box.pack_start(self._label(self._t("install_unavailable"), "dialog-title"), False, False, 0)
        box.pack_start(self._label(f"{self._t('config')}: {validation.config}", "section"), False, False, 0)
        message = self._t("classic_acronis_found") if validation.classic_acronis_images else self._t("no_config_or_acronis")
        box.pack_start(self._label(message, "muted", True), False, False, 0)
        dialog.show_all()
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.ACCEPT and validation.classic_acronis_images:
            self._start_acronis()

    def _start_acronis(self) -> None:
        """Offer the legacy/manual path only for an actually found Acronis image."""

        dialog = self._new_dialog(self._t("start_acronis"), 650)
        dialog.add_button(self._t("cancel"), Gtk.ResponseType.CANCEL).get_style_context().add_class("primary")
        dialog.add_button(self._t("restart_now"), Gtk.ResponseType.ACCEPT).get_style_context().add_class("secondary")
        box = self._dialog_content(dialog)
        box.pack_start(self._label(self._t("acronis_manual_title"), "dialog-title"), False, False, 0)
        box.pack_start(self._label(self._t("acronis_manual_text"), "muted", True), False, False, 0)
        dialog.show_all()
        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.ACCEPT:
            return

        result = magic.schedule_acronis_boot(self.inspection)
        if not result.ready:
            # Do not hide the safe-stop reason.  It tells the user whether
            # Acronis itself is missing or only the one-time GRUB hand-off
            # needs attention.
            message = f"{self._t('acronis_schedule_failed')}\n\n{result.message}"
            self.config_status.set_text(message)
            self._set_status_class("status-bad")
            error = Gtk.MessageDialog(
                transient_for=self.window,
                flags=Gtk.DialogFlags.MODAL,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.CLOSE,
                text=self._t("acronis_start_failed"),
            )
            error.format_secondary_text(message)
            error.run()
            error.destroy()
            return

        self.config_status.set_text(self._t("acronis_scheduled"))
        self._set_status_class("status-good")
        GLib.timeout_add(450, self._reboot_to_acronis)

    def _reboot_to_acronis(self) -> bool:
        try:
            os.sync()
            subprocess.Popen(["systemctl", "reboot"], start_new_session=True)
        except OSError as exc:
            self.config_status.set_text(self._t("acronis_reboot_failed"))
            self._set_status_class("status-bad")
        return False

    def _selected_image(self) -> magic.MagicImage | None:
        image = self.images_by_id.get(self.image_combo.get_active_id() or "")
        if self.validation and self.validation.config != self.config_entry.get_text().strip():
            return None
        if image not in magic.install_images_for_config(self.validation, self.inspection.images):
            return None
        return image
    def _selected_target(self) -> magic.BlockDevice | None: return self.targets_by_path.get(self.target_combo.get_active_id() or "")
    def _selected_data_disk(self) -> magic.BlockDevice | None: return self.data_disks_by_path.get(self.data_disk_combo.get_active_id() or "")
    def _selection_changed(self, _widget=None) -> None:
        if not self._image_choices_refreshing:
            self._update_summary()

    def _update_summary(self) -> None:
        config, image, target, data_disk = self.validation, self._selected_image(), self._selected_target(), self._selected_data_disk()
        checking_server = bool(config and self._config_server_pending == config.config)
        lines = [self._t("not_ready"), f"{self._t('config')}: {config.config if config else self._t('config_unchecked')}"]
        if checking_server:
            lines.append(self._t("config_server_checking"))
        if config:
            if config.deployment_mode == "complete":
                lines.extend((self._t("complete_image_found"), self._t("complete_image_workflow")))
            else:
                lines.append(self._t("config_matches") if config.strict_match else self._t("config_attention") if config.requires_confirmation else self._t("config_unavailable"))
        lines.append(f"{self._t('image')}: {self._image_display_text(image) if image else self._t('image_unselected')}"); lines.append(f"{self._t('target')}: {self._disk_display_text(target) if target else self._t('target_unselected')}")
        lines.append(f"{self._t('data_disk')}: {self._disk_display_text(data_disk) if data_disk else self._t('data_disk_unselected')}")
        lines.append(f"{self._t('clonezilla')}: {self._t('clonezilla_ready') if self.inspection.clonezilla.usage_verified else self._t('clonezilla_error')}")
        self.plan = None; self.data_disk_plan = None
        if config and image and target and not checking_server:
            self.plan = magic.build_restore_proof_plan(config, image, target, self.inspection)
            if data_disk is not None:
                label = "Daten" if self._language() == "DE" else "Data"
                self.data_disk_plan = magic.build_data_disk_prepare_plan(data_disk, target, self.inspection, label=label)
                lines.append(f"{self._t('data_disk')}: {self._t('data_disk_ready') if self.data_disk_plan.ready else self._t('data_disk_unavailable')}")
            if self.plan.ready and (self.data_disk_plan is None or self.data_disk_plan.ready): lines[0] = self._t("ready")
        self.summary.get_buffer().set_text("\n".join(lines)); self.install_button.set_sensitive(bool(self.plan and self.plan.ready and (self.data_disk_plan is None or self.data_disk_plan.ready) and not self._restore_running and not checking_server))

    def _install_clicked(self, _button=None) -> None:
        if self._restore_running: return
        self._update_summary()
        plan, data_disk_plan = self.plan, self.data_disk_plan
        if plan is None or not plan.ready or self._restore_running or self._config_server_pending == plan.config: return
        dialog = self._new_dialog(self._t("confirm_install"), 620); dialog.add_button(self._t("cancel"), Gtk.ResponseType.CANCEL); dialog.add_button(self._t("continue"), Gtk.ResponseType.OK).get_style_context().add_class("danger")
        image = self._selected_image()
        image_text = self._image_display_text(image) if image else plan.image_name
        confirmation_text = self._t("confirm_text", config=plan.config, image=image_text, target=plan.target_selector)
        if plan.deployment_mode == "complete":
            confirmation_text += "\n\n" + self._t("complete_image_confirm", config=plan.config)
        if data_disk_plan is not None:
            confirmation_text += "\n\n" + self._t("data_disk_confirm", disk=data_disk_plan.disk_selector, label=data_disk_plan.label)
        box = self._dialog_content(dialog); box.pack_start(self._label(self._t("confirm_install"), "dialog-title"), False, False, 0); box.pack_start(self._label(confirmation_text, "muted", True), False, False, 0)
        completion_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        completion_row.pack_start(self._label(self._t("after_restore"), "muted"), False, False, 0)
        completion_choice = Gtk.ComboBoxText()
        completion_choice.append("reboot", self._t("start_windows"))
        completion_choice.append("poweroff", self._t("shutdown_device"))
        completion_choice.set_active_id("reboot")
        completion_row.pack_start(completion_choice, True, True, 0)
        box.pack_start(completion_row, False, False, 0)
        dialog.show_all(); response = dialog.run(); post_restore_action = completion_choice.get_active_id() or "reboot"; dialog.destroy()
        if response != Gtk.ResponseType.OK: return
        self._update_summary()
        # GTK's modal loop still receives config-server and media callbacks.
        # Never restore a superseded route after a background config arrived.
        if self.plan != plan or self.data_disk_plan != data_disk_plan or self._config_server_pending == plan.config:
            self.config_status.set_text(self._t("confirmation_changed")); self._set_status_class("status-warn")
            return
        self._post_restore_action = post_restore_action
        self._restore_running = True; self.progress.show(); self.progress_label.show(); self.progress.set_fraction(0.0); self.progress.set_text("0 %"); self.progress_label.set_text(self._t("preparing")); self._update_summary()
        def worker() -> None:
            result = magic.execute_restore_proof(plan, self.inspection, progress_callback=lambda percent, text: GLib.idle_add(self._restore_progress, percent, text), data_disk_plan=data_disk_plan); GLib.idle_add(self._restore_finished, result)
        threading.Thread(target=worker, name="magic-solo-restore", daemon=True).start()

    def _restore_progress(self, percent: int, text: str) -> bool:
        bounded = max(0, min(100, int(percent))); self.progress.set_fraction(bounded / 100); self.progress.set_text(f"{bounded} %"); self.progress_label.set_text(self._localized_restore_progress(text)); return False

    def _restore_finished(self, result: magic.RestoreProofResult) -> bool:
        self._restore_running = False
        success_key = "restore_complete_image" if result.deployment_mode == "complete" else "restore_complete"
        message = self._t(success_key) if result.success else self._t("restore_failed")
        self._restore_progress(100 if result.success else 0, message)
        lines = [message]
        if result.handoff_path: lines.append(f"{self._t('restore_handoff')}: {result.handoff_path}")
        if result.log_path: lines.append(f"{self._t('restore_log')}: {result.log_path}")
        self.summary.get_buffer().set_text("\n".join(lines)); self.install_button.set_sensitive(False)
        if result.success:
            self.progress_label.set_text(self._t("windows_starting") if self._post_restore_action == "reboot" else self._t("device_shutting_down"))
            GLib.timeout_add(1300, self._apply_post_restore_action)
        return False

    def _retry_time_sync(self) -> bool:
        """Try NTP in a worker even when the update check is unavailable."""
        if self._time_sync_running:
            return False
        self._time_sync_running = True

        def worker() -> tuple[bool, str]:
            try:
                # The normal update path first replaces a stale DNS setup.
                # Do exactly the same here; otherwise NTP cannot resolve its
                # server until an operator presses "Updates suchen".
                self.core.write_public_dns()
                return magic.synchronize_live_time()
            except Exception as exc:
                return False, f'Zeitabgleich nicht verfügbar: {exc}'

        def finished(_result: tuple[bool, str]) -> bool:
            self._time_sync_running = False
            self._refresh_header()
            return False

        threading.Thread(
            target=lambda: GLib.idle_add(finished, worker()),
            name="magic-solo-time-sync",
            daemon=True,
        ).start()
        return False

    def _repeat_time_sync(self) -> bool:
        self._retry_time_sync()
        return True

    def _apply_post_restore_action(self) -> bool:
        try:
            os.sync()
            subprocess.Popen(["systemctl", self._post_restore_action], start_new_session=True)
        except OSError: pass
        return False

    # ---------- options and WLAN ----------
    def _open_options_safe(self, _button=None) -> None:
        """Always give feedback for the header options button.

        A modal dialog failing during construction used to leave the user with
        an apparently inactive gear.  This wrapper deliberately catches every
        exception, writes a local diagnostic and displays a real GTK message.
        """
        try:
            self._open_options(_button)
        except Exception as exc:  # pragma: no cover - defensive live fallback
            details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            try:
                (SCRIPT_DIR / "magic-image-solo-options-error.log").write_text(details, encoding="utf-8")
            except OSError:
                pass
            alert = Gtk.MessageDialog(
                transient_for=self.window,
                flags=Gtk.DialogFlags.MODAL,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.CLOSE,
                text=self._t("options_open_failed"),
            )
            alert.format_secondary_text(self._t("options_open_failed"))
            alert.set_position(Gtk.WindowPosition.CENTER_ON_PARENT)
            alert.run()
            alert.destroy()

    def _open_options(self, _button=None) -> None:
        dialog = self._new_dialog(self._t("options"), 610); dialog.add_button(self._t("close"), Gtk.ResponseType.CLOSE); box = self._dialog_content(dialog); box.pack_start(self._label(self._t("options"), "dialog-title"), False, False, 0)
        box.pack_start(self._label(self._t("language"), "section"), False, False, 6); languages = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        for language in ("CZ", "DE", "EN"):
            languages.pack_start(self._language_button(language, lambda _b, item=language, owner=dialog: self._select_language(item, owner)), False, False, 0)
        box.pack_start(languages, False, False, 0); box.pack_start(self._label(self._t("layout"), "section"), False, False, 9)
        layout_combo = Gtk.ComboBoxText()
        for layout in LAYOUTS: layout_combo.append(layout, self._t(f"layout_{layout.replace('-', '_')}"))
        layout_combo.set_active_id(self.settings["layout"]); layout_combo.connect("changed", lambda widget, owner=dialog: self._select_layout(widget.get_active_id() or "original", owner)); box.pack_start(layout_combo, False, False, 0)
        box.pack_start(self._label(self._t("workshop_mode"), "section"), False, False, 9)
        mode_combo = Gtk.ComboBoxText()
        mode_combo.append("magic", self._t("workshop_mode_magic"))
        mode_combo.append("hardwarecheck", self._t("workshop_mode_hardwarecheck"))
        mode_combo.set_active_id(self._workshop_start_mode())
        mode_status = self._label(self._t("workshop_mode_hint"), "muted", True)
        mode_combo.connect("changed", lambda widget, status=mode_status: self._select_workshop_start_mode(widget.get_active_id() or "magic", status))
        box.pack_start(mode_combo, False, False, 0)
        box.pack_start(mode_status, False, False, 3)
        box.pack_start(self._label(self._t("wifi"), "section"), False, False, 9); wifi_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        wifi_row.pack_start(self._label(self._current_wifi_ssid() or self._t("wifi_offline"), "muted"), True, True, 0); wifi_row.pack_end(self._button(self._t("wifi_choose"), lambda _b, owner=dialog: self._open_wifi_dialog(owner)), False, False, 0); box.pack_start(wifi_row, False, False, 0)
        box.pack_start(self._label(self._t("program_updates"), "section"), False, False, 9)
        program_update_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        program_update_status = self._label(self._t("program_update_hint"), "muted", True)
        program_update_row.pack_start(program_update_status, True, True, 0)
        program_update_spinner = Gtk.Spinner()
        program_update_spinner.set_no_show_all(True)
        program_update_spinner.hide()
        program_update_row.pack_start(program_update_spinner, False, False, 0)
        program_update_progress = Gtk.ProgressBar()
        program_update_progress.set_show_text(True)
        program_update_progress.set_no_show_all(True)
        program_update_progress.hide()
        program_update_button = Gtk.Button(label=self._t("program_update_check"))
        program_update_button.get_style_context().add_class("secondary")
        program_install_button = Gtk.Button(label=self._t("program_update_install"))
        program_install_button.get_style_context().add_class("primary")
        program_install_button.set_no_show_all(True)
        program_install_button.hide()
        pending_program_update: dict[str, program_update.ProgramUpdateResult | None] = {"result": None}
        program_update_button.connect(
            "clicked",
            lambda _button, owner=dialog, status=program_update_status, spinner=program_update_spinner, progress=program_update_progress, check=program_update_button, install=program_install_button, pending=pending_program_update:
            self._manual_program_update(owner, status, spinner, progress, check, install, pending),
        )
        program_install_button.connect(
            "clicked",
            lambda _button, owner=dialog, status=program_update_status, check=program_update_button, install=program_install_button, pending=pending_program_update:
            self._install_manual_program_update(owner, status, check, install, pending),
        )
        program_update_row.pack_end(program_update_button, False, False, 0)
        program_update_row.pack_end(program_install_button, False, False, 0)
        box.pack_start(program_update_row, False, False, 0)
        box.pack_start(program_update_progress, False, False, 2)
        if "-test" in APP_VERSION:
            alert_test_button = self._button(
                self._t("program_update_alert_test"),
                self._show_test_program_update_alert,
                "secondary",
            )
            alert_test_button.set_tooltip_text(self._t("program_update_alert_tooltip"))
            box.pack_start(alert_test_button, False, False, 2)
        # If the automatic check already staged a verified package, the manual
        # dialog exposes it immediately instead of requiring a blind restart.
        if self._pending_program_update is not None and self._pending_program_update.staged:
            staged = self._pending_program_update
            pending_program_update["result"] = staged
            ready_text = self._t("program_update_downloaded", version=staged.version)
            program_update_status.set_text(ready_text)
            program_update_progress.set_fraction(1.0)
            program_update_progress.set_text(ready_text)
            program_update_progress.show()
            program_install_button.set_label(self._t("program_update_install_ready", version=staged.version))
            program_install_button.show()
        box.pack_start(self._label(self._t("config_server"), "section"), False, False, 9)
        server = config_sync.load_settings(SCRIPT_DIR)
        server_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        server_row.pack_start(self._label(server.endpoint if server.enabled and server.endpoint else self._t("config_server_disabled"), "muted", True), True, True, 0)
        server_row.pack_end(self._button(self._t("config_server_settings"), lambda _b, owner=dialog: self._open_config_server_dialog(owner)), False, False, 0)
        box.pack_start(server_row, False, False, 0)
        dialog.show_all(); dialog.run(); dialog.destroy()

    def _open_config_server_dialog(self, owner: Gtk.Dialog) -> None:
        owner.hide()
        settings = config_sync.load_settings(SCRIPT_DIR)
        dialog = self._new_dialog(self._t("config_server"), 720)
        dialog.add_button(self._t("cancel"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self._t("config_server_save"), Gtk.ResponseType.OK).get_style_context().add_class("primary")
        box = self._dialog_content(dialog)
        box.pack_start(self._label(self._t("config_server"), "dialog-title"), False, False, 0)
        box.pack_start(self._label(self._t("config_server_security"), "muted", True), False, False, 0)
        enabled = Gtk.CheckButton(label=self._t("config_server_enable")); enabled.set_active(settings.enabled); box.pack_start(enabled, False, False, 0)
        box.pack_start(self._label(self._t("config_server_url"), "section"), False, False, 0)
        endpoint = Gtk.Entry(); endpoint.set_placeholder_text("https://configs.example.invalid/hardwarecheck/v1"); endpoint.set_text(settings.endpoint); box.pack_start(endpoint, False, False, 0)
        box.pack_start(self._label(self._t("config_server_pin"), "section"), False, False, 0)
        pin = Gtk.Entry(); pin.set_placeholder_text("64 Hex-Zeichen"); pin.set_text(settings.certificate_sha256); box.pack_start(pin, False, False, 0)
        box.pack_start(self._label(self._t("config_server_interval"), "section"), False, False, 0)
        interval = Gtk.SpinButton.new_with_range(1, 168, 1); interval.set_value(settings.check_interval_hours); box.pack_start(interval, False, False, 0)
        status = self._label("", "status-bad", True); box.pack_start(status, False, False, 0)
        dialog.show_all()
        while True:
            response = dialog.run()
            if response != Gtk.ResponseType.OK:
                break
            try:
                config_sync.save_settings(SCRIPT_DIR, config_sync.ConfigServerSettings(enabled.get_active(), endpoint.get_text(), pin.get_text(), int(interval.get_value())))
            except (OSError, ValueError):
                status.set_text(self._t("config_server_settings_failed")); status.show(); continue
            self._config_server_checked.clear()
            break
        dialog.destroy(); owner.show_all()

    def _select_language(self, language: str, dialog: Gtk.Dialog) -> None:
        if language not in LANGUAGES or language == self._language(): return
        self.settings["language"] = language; self._save_settings(); dialog.destroy(); GLib.timeout_add(120, self._restart_solo)

    def _select_layout(self, layout: str, dialog: Gtk.Dialog) -> None:
        if layout not in LAYOUTS or layout == self.settings["layout"]: return
        self.settings["layout"] = layout; self._save_settings(); dialog.destroy(); GLib.timeout_add(120, self._restart_solo)

    def _select_workshop_start_mode(self, mode: str, status: Gtk.Label) -> None:
        if mode not in {"magic", "hardwarecheck"}:
            return
        try:
            self.core.set_workshop_start_mode(mode)
        except (AttributeError, OSError, ValueError):
            status.set_text(self._t("workshop_mode_save_failed"))
            return
        label = self._t("workshop_mode_magic" if mode == "magic" else "workshop_mode_hardwarecheck")
        status.set_text(self._t("workshop_mode_saved", mode=label))

    def _restart_solo(self) -> bool:
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(self.core.__file__).resolve())], os.environ.copy()); return False

    def _open_wifi_dialog(self, owner: Gtk.Dialog) -> None:
        owner.hide(); dialog = self._new_dialog(self._t("wifi"), 650); dialog.add_button(self._t("close"), Gtk.ResponseType.CLOSE); box = self._dialog_content(dialog)
        heading = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8); heading.pack_start(self._label(self._t("wifi"), "dialog-title"), True, True, 0); heading.pack_end(self._button(self._t("wifi_refresh"), lambda _b: self._scan_wifi_into(dialog)), False, False, 0); box.pack_start(heading, False, False, 0)
        self._wifi_dialog_status = self._label(self._t("wifi_refresh"), "muted"); box.pack_start(self._wifi_dialog_status, False, False, 0); self._wifi_dialog_rows = Gtk.ListBox(); self._wifi_dialog_rows.set_selection_mode(Gtk.SelectionMode.NONE); self._wifi_dialog_rows.get_style_context().add_class("dialog-list")
        scroll = Gtk.ScrolledWindow(); scroll.set_min_content_height(310); scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC); scroll.add(self._wifi_dialog_rows); box.pack_start(scroll, True, True, 0); dialog.show_all(); self._scan_wifi_into(dialog); dialog.run(); dialog.destroy(); self._wifi_dialog_status = None; self._wifi_dialog_rows = None; owner.show_all()

    def _scan_wifi_into(self, dialog: Gtk.Dialog) -> None:
        status, rows = self._wifi_dialog_status, self._wifi_dialog_rows
        if status is None or rows is None: return
        status.set_text(self._t("wifi_refresh")); self._clear_listbox(rows); row = Gtk.ListBoxRow(); row.add(self._label(self._t("wifi_refresh"), "muted")); rows.add(row); rows.show_all()
        def worker() -> tuple[list[dict[str, str]], str, str]:
            try: networks, message = self.core.scan_wifi_networks(); return networks, message, ""
            except Exception as exc: return [], "", str(exc)
        def done(networks: list[dict[str, str]], message: str, error: str) -> bool:
            if not dialog.get_visible(): return False
            self._render_wifi_rows(dialog, networks)
            if self._wifi_dialog_status is not None:
                status_text = self._t("wifi_scan_failed") if error else self._t("wifi_networks_refreshed") if networks else self._t("wifi_no_networks")
                self._wifi_dialog_status.set_text(status_text)
            return False
        threading.Thread(target=lambda: GLib.idle_add(done, *worker()), name="magic-solo-wifi-scan", daemon=True).start()

    @staticmethod
    def _clear_listbox(listbox: Gtk.ListBox) -> None:
        for item in listbox.get_children(): listbox.remove(item)

    def _render_wifi_rows(self, dialog: Gtk.Dialog, scanned: list[dict[str, str]]) -> None:
        rows = self._wifi_dialog_rows
        if rows is None: return
        self._clear_listbox(rows); saved = {str(item.get("ssid") or ""): dict(item) for item in self.core.load_wifi_networks()}; merged: dict[str, dict[str, str]] = {ssid: dict(value) for ssid, value in saved.items()}
        for network in scanned:
            ssid = _safe_text(network.get("ssid"))
            if ssid: merged.setdefault(ssid, {}).update(network)
        current = self._current_wifi_ssid(); items = sorted(merged.values(), key=lambda item: str(item.get("ssid") or "").lower())
        if not items:
            row = Gtk.ListBoxRow(); row.add(self._label(self._t("wifi_no_networks"), "muted")); rows.add(row)
        for network in items:
            ssid = _safe_text(network.get("ssid"))
            if not ssid: continue
            row = Gtk.ListBoxRow(); inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8); row.add(inner); sub = []
            if ssid == current: sub.append(self._t("wifi_connected"))
            if ssid in saved: sub.append(self._t("wifi_saved"))
            signal = _safe_text(network.get("signal")); text = ssid + (f" · {signal}" if signal else "") + (f" · {', '.join(sub)}" if sub else "")
            inner.pack_start(self._label(text), True, True, 0); inner.pack_end(self._button(self._t("wifi_choose"), lambda _b, item=network, owner=dialog: self._connect_wifi(item, owner)), False, False, 0); rows.add(row)
        rows.show_all()

    def _password_dialog(self, ssid: str) -> str | None:
        dialog = self._new_dialog(self._t("wifi"), 480); dialog.add_button(self._t("cancel"), Gtk.ResponseType.CANCEL); dialog.add_button(self._t("wifi_save_connect"), Gtk.ResponseType.OK).get_style_context().add_class("primary")
        box = self._dialog_content(dialog); box.pack_start(self._label(self._t("wifi_password", ssid=ssid), "section"), False, False, 0); entry = Gtk.Entry(); entry.set_visibility(False); entry.set_activates_default(True); box.pack_start(entry, False, False, 0)
        reveal = Gtk.CheckButton(label=self._t("wifi_show_password")); reveal.connect("toggled", lambda widget: entry.set_visibility(widget.get_active())); box.pack_start(reveal, False, False, 0); dialog.set_default_response(Gtk.ResponseType.OK); dialog.show_all(); response = dialog.run(); value = entry.get_text() if response == Gtk.ResponseType.OK else None; dialog.destroy(); return value

    def _connect_wifi(self, network: dict[str, str], dialog: Gtk.Dialog) -> None:
        if self._wifi_busy: return
        ssid = _safe_text(network.get("ssid"))
        if not ssid: return
        saved = {str(item.get("ssid") or ""): dict(item) for item in self.core.load_wifi_networks()}; candidate = dict(saved.get(ssid) or network); candidate.update({key: value for key, value in network.items() if value}); security = self.core.normalize_wifi_security(candidate.get("security_mode") or candidate.get("security"))
        if security == "OPEN":
            if self._wifi_dialog_status is not None: self._wifi_dialog_status.set_text(self._t("wifi_open_unsupported"))
            return
        if not _safe_text(candidate.get("password")):
            password = self._password_dialog(ssid)
            if not password: return
            candidate["password"] = password; self.core.save_wifi_network(ssid, password, security)
        if self._wifi_dialog_status is not None: self._wifi_dialog_status.set_text(self._t("wifi_connecting"))
        self._wifi_busy = True; self._set_network_chip(self._t("wifi_connecting"), "warn")
        def worker() -> tuple[bool, str]:
            try:
                ok, message, cleanup = self.core.connect_temporary_network(None, [], [candidate], require_internet=True, allow_active=False, allow_lan=False, cleanup_success=False)
                if not ok: cleanup()
                return bool(ok), _safe_text(message)
            except Exception as exc: return False, str(exc)
        def done(_ok: bool, message: str) -> bool:
            self._wifi_busy = False
            if self._wifi_dialog_status is not None: self._wifi_dialog_status.set_text(self._t("wifi_connected_status") if _ok else self._t("wifi_connection_failed"))
            self._refresh_header()
            if _ok:
                self._refresh_internet_state()
                self._start_background_model_sync()
                self._start_background_program_update(retry_failed_check=True)
            return False
        threading.Thread(target=lambda: GLib.idle_add(done, *worker()), name="magic-solo-wifi-connect", daemon=True).start()

    def _start_wifi_autoconnect(self) -> None:
        try: saved = self.core.load_wifi_networks()
        except Exception: saved = []
        if not saved or self._current_wifi_ssid(): return
        self._wifi_busy = True; self._set_network_chip(self._t("wifi_connecting"), "warn")
        def worker() -> tuple[bool, str]:
            try:
                ok, message, cleanup = self.core.connect_temporary_network(None, [], saved, require_internet=True, allow_active=True, allow_lan=True, cleanup_success=False)
                if not ok: cleanup()
                return bool(ok), _safe_text(message)
            except Exception as exc: return False, str(exc)
        def done(_ok: bool, _message: str) -> bool:
            self._wifi_busy = False; self._refresh_header()
            if _ok:
                self._refresh_internet_state()
                self._start_background_model_sync()
                self._start_background_program_update(retry_failed_check=True)
            return False
        threading.Thread(target=lambda: GLib.idle_add(done, *worker()), name="magic-solo-wifi-auto", daemon=True).start()

    def show(self) -> None:
        self.window.show_all(); self.window.fullscreen()
        GLib.timeout_add(350, self._enable_numlock)

    @staticmethod
    def _enable_numlock() -> bool:
        """Enable Num Lock after the X session is visible (best effort)."""
        for command in (("numlockx", "on"), ("xset", "led", "named", "Num Lock")):
            try:
                result = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2, check=False)
                if result.returncode == 0:
                    break
            except (FileNotFoundError, subprocess.SubprocessError):
                continue
        return False


def run(core: Any) -> int:
    app = MagicImageSolo(core); app.show(); Gtk.main(); return 0


if __name__ == "__main__":  # pragma: no cover - live entrypoint only
    import hardwarecheck_fast_gui as hardwarecheck_core
    raise SystemExit(run(hardwarecheck_core))
