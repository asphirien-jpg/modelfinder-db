"""Pure text and presentation helpers shared by the Magic Image core.

This module intentionally has no filesystem, subprocess, GTK, network or
media dependencies.  Keeping it separate makes these deterministic helpers
easy to test without importing the restore workflow.
"""

from __future__ import annotations

import re


def text(value: object) -> str:
    """Return a trimmed string, treating missing values as empty."""
    return str(value or "").strip()


def mountpoints(value: object) -> tuple[str, ...]:
    """Normalize lsblk's scalar-or-list mountpoint representation."""
    candidates = value if isinstance(value, list) else [value]
    return tuple(item for item in (text(candidate) for candidate in candidates) if item)


def safe_name(value: object, fallback: str = "") -> str:
    """Accept only a portable filename token; never create a path."""
    candidate = text(value)
    return candidate if re.fullmatch(r"[A-Za-z0-9._+-]+", candidate) else fallback


def format_size(size_bytes: int) -> str:
    """Format a non-negative byte count for the read-only UI."""
    if size_bytes <= 0:
        return "unbekannt"
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    value = float(size_bytes)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return "unbekannt"
