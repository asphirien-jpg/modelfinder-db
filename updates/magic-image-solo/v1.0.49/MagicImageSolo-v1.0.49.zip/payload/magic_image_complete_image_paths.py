"""Read-only repository rules for Clonezilla images.

These helpers only recognise an already-present Clonezilla directory.  They
never open image data, mount media, execute Clonezilla, or write to a disk.
"""

from __future__ import annotations

import pathlib
import re

from magic_image_config_values import legacy_image_config_id
from magic_image_text import safe_name, text


def looks_like_clonezilla_image(path: pathlib.Path) -> bool:
    """Recognise Clonezilla's file structure, never merely a folder name."""

    try:
        if not path.is_dir():
            return False
        return (path / "parts").is_file() and (path / "disk").is_file()
    except OSError:
        return False


def model_folder_configs(name: str) -> tuple[str, ...]:
    """Return only the leading config IDs; CPU numbers are never identities."""

    match = re.match(r"^(\d{4}(?:\s*\+\s*\d{4})*)(?=$|[\s(_-])", name)
    return tuple(dict.fromkeys(re.findall(r"\d{4}", match.group(1)))) if match else ()


def plain_repository_path(root: pathlib.Path, path: pathlib.Path) -> bool:
    """Reject escaped paths and symlink aliases, including Clonezilla markers."""

    try:
        relative = path.absolute().relative_to(root.absolute())
        current = root
        for part in relative.parts:
            current = current / part
            if current.is_symlink():
                return False
        root_resolved = root.resolve()
        path.resolve().relative_to(root_resolved)
        return not any((path / marker).is_symlink() for marker in ("disk", "parts"))
    except (OSError, ValueError):
        return False


def complete_image_configs(root: pathlib.Path, path: pathlib.Path) -> tuple[str, ...]:
    """Recognise vendor/model[/image or /Clonezilla/image] with containment."""

    if not plain_repository_path(root, path):
        return ()
    try:
        parts = path.resolve().relative_to(root.resolve()).parts
    except (OSError, ValueError):
        return ()
    if len(parts) not in (2, 3, 4) or parts[0].startswith(("#", ".")):
        return ()
    if len(parts) == 4 and parts[2].casefold() != "clonezilla":
        return ()
    return model_folder_configs(parts[1])


def child_directories(path: pathlib.Path) -> list[pathlib.Path]:
    """List real direct child directories in a stable order."""

    try:
        return sorted(
            (item for item in path.iterdir() if item.is_dir() and not item.is_symlink()),
            key=lambda item: item.name.casefold(),
        )
    except OSError:
        return []


def manifest_image_records(root: pathlib.Path, manifest_file: str) -> list[dict[str, object]]:
    """Read valid manifest records without creating application image objects.

    The caller decides how these records become UI objects.  This helper only
    reads the manifest and confirms that every selected path remains inside
    its repository and has Clonezilla's existing marker files.
    """

    import json

    try:
        data = json.loads((root / manifest_file).read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return []
    entries = data.get("images") if isinstance(data, dict) else None
    if not isinstance(entries, list):
        return []
    records: list[dict[str, object]] = []
    for raw in entries:
        if not isinstance(raw, dict):
            continue
        image_id = safe_name(raw.get("id"))
        relative_path = text(raw.get("clonezilla_path") or raw.get("path"))
        candidate = root / relative_path
        try:
            minimum = int(raw.get("minimum_target_bytes") or raw.get("minimum_target_size_bytes") or 0)
        except (TypeError, ValueError):
            minimum = 0
        if not image_id or not relative_path or not _inside(root, candidate) or not looks_like_clonezilla_image(candidate):
            continue
        records.append({
            "image_id": image_id,
            "display_name": text(raw.get("display_name")) or image_id,
            "version": text(raw.get("version")),
            "image_path": str(candidate),
            "minimum_target_bytes": max(0, minimum),
            "description": text(raw.get("description")),
        })
    return records


def _inside(root: pathlib.Path, candidate: pathlib.Path) -> bool:
    try:
        candidate.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


_ACRONIS_SUFFIXES = {".tib", ".tibx"}


def acronis_file_paths(folder: pathlib.Path) -> tuple[tuple[str, ...], int]:
    """Return capped, read-only Acronis file evidence below one folder."""

    paths: list[str] = []
    total_bytes = 0
    try:
        for candidate in folder.rglob("*"):
            if not candidate.is_file() or candidate.suffix.casefold() not in _ACRONIS_SUFFIXES:
                continue
            try:
                total_bytes += candidate.stat().st_size
            except OSError:
                pass
            paths.append(str(candidate))
            if len(paths) >= 128:
                break
    except OSError:
        return (), 0
    return tuple(sorted(paths, key=str.casefold)), total_bytes


def classic_acronis_records(
    repository_roots: tuple[str, ...] | list[str] | object, config_filter: str = ""
) -> list[dict[str, object]]:
    """Discover legacy Acronis evidence without constructing UI image objects."""

    requested_config = config_filter.strip()
    if requested_config and not re.fullmatch(r"\d{4}", requested_config):
        return []
    records: list[dict[str, object]] = []
    seen_folders: set[str] = set()
    for root_text in repository_roots:
        root = pathlib.Path(root_text)
        try:
            vendor_folders = [child for child in root.iterdir() if child.is_dir() and not child.name.startswith("#")]
        except OSError:
            continue
        for vendor_folder in sorted(vendor_folders, key=lambda item: item.name.casefold()):
            try:
                model_folders = [vendor_folder, *[child for child in vendor_folder.iterdir() if child.is_dir()]]
            except OSError:
                model_folders = [vendor_folder]
            for model_folder in model_folders:
                config_id = legacy_image_config_id(model_folder.name)
                if not config_id or (requested_config and config_id != requested_config):
                    continue
                try:
                    folder_key = str(model_folder.resolve())
                except OSError:
                    folder_key = str(model_folder)
                if folder_key in seen_folders:
                    continue
                seen_folders.add(folder_key)
                file_paths, total_bytes = acronis_file_paths(model_folder)
                if not file_paths:
                    continue
                records.append({
                    "config": config_id,
                    "vendor": vendor_folder.name,
                    "source_folder": str(model_folder),
                    "file_paths": file_paths,
                    "total_bytes": total_bytes,
                })
    return sorted(records, key=lambda item: (str(item["config"]), str(item["vendor"]).casefold(), str(item["source_folder"]).casefold()))
