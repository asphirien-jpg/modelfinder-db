"""Pure value normalization helpers for Magic Image config comparisons."""

from __future__ import annotations

import re

from magic_image_text import text


def normalise_token(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", "", text(value).casefold())


def positive_number(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def format_number(value: object, unit: str = "") -> str:
    number = positive_number(value)
    if number is None:
        return "unbekannt"
    display = str(int(number)) if number.is_integer() else f"{number:.1f}"
    return f"{display} {unit}".strip()
