#!/usr/bin/env python3
"""Compatibility entrypoint used by the existing Debian live-session script."""

from magic_image_solo_gui import run

__all__ = ["run"]
