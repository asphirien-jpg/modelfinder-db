#!/usr/bin/env python3
"""Small, verified model-database updater for Magic Image Solo.

The public ModelFinder GitHub database remains Solo's source of truth for the
time being.  Config folders deliberately use their separate company-server
sync implementation.  Keeping the two paths apart means a future change from
GitHub to the company server needs only a source file change, not a rewrite of
the installer or of the Config-server logic.
"""

from __future__ import annotations

from dataclasses import dataclass
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable


DEFAULT_MODEL_MANIFEST_URL = (
    "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/model_manifest.json"
)
DEFAULT_MODEL_DATABASE_URL = (
    "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/model.json"
)
DATABASE_FILENAME = "models-laptops.json"
MANIFEST_FILENAME = "model_manifest_local.json"
STATE_FILENAME = "magic-image-solo-model-sync.json"
SOURCE_FILENAME = "magic-image-solo-model-source.json"
SUCCESS_CHECK_INTERVAL = dt.timedelta(hours=6)
FAILURE_RETRY_INTERVAL = dt.timedelta(minutes=5)


@dataclass(frozen=True)
class SyncResult:
    """Result of one low-traffic background database check."""

    checked: bool
    updated: bool
    message: str
    version: str = ""
    models_count: int = 0


@dataclass(frozen=True)
class DatabaseSource:
    """Current source, with an explicit future migration seam.

    By default this is the public GitHub source used by HardwareCheck.  A
    developer may later place ``magic-image-solo-model-source.json`` beside
    the program with HTTPS URLs for the company server.  There is intentionally
    no UI setting and no credential storage on the installation SSD.
    """

    manifest_url: str
    database_url: str


def _text(value: object) -> str:
    return str(value or "").strip()


def _https_url(value: object) -> str:
    text = _text(value)
    try:
        parsed = urllib.parse.urlparse(text)
    except ValueError:
        return ""
    return text if parsed.scheme == "https" and bool(parsed.netloc) else ""


def _read_json(path: pathlib.Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def _write_bytes_atomic(path: pathlib.Path, payload: bytes) -> None:
    """Install a complete downloaded file or keep the previous one intact."""

    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.new")
    try:
        with temporary.open("wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink()
        except OSError:
            pass


def _write_json_atomic(path: pathlib.Path, value: dict[str, object]) -> None:
    _write_bytes_atomic(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def _file_sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            while chunk := handle.read(128 * 1024):
                digest.update(chunk)
    except OSError:
        return ""
    return digest.hexdigest()


def _manifest_value(manifest: dict[str, object], *names: str) -> str:
    for name in names:
        text = _text(manifest.get(name))
        if text:
            return text
    return ""


def _is_valid_sha256(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Fa-f0-9]{64}", value))


def _parse_time(value: object) -> dt.datetime | None:
    text = _text(value)
    if not text:
        return None
    try:
        parsed = dt.datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)


def _now_iso(now: dt.datetime) -> str:
    return now.astimezone(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _version_is_newer(remote: str, local: str) -> bool:
    remote_parts = [int(item) for item in re.findall(r"\d+", remote)]
    local_parts = [int(item) for item in re.findall(r"\d+", local)]
    width = max(len(remote_parts), len(local_parts), 1)
    remote_parts.extend([0] * (width - len(remote_parts)))
    local_parts.extend([0] * (width - len(local_parts)))
    return remote_parts > local_parts


def load_database_source(root: pathlib.Path) -> DatabaseSource:
    """Return GitHub by default; accept only an explicit future HTTPS source."""

    fallback = DatabaseSource(DEFAULT_MODEL_MANIFEST_URL, DEFAULT_MODEL_DATABASE_URL)
    configured = _read_json(root / SOURCE_FILENAME)
    manifest_url = _https_url(configured.get("manifest_url"))
    database_url = _https_url(configured.get("database_url"))
    return DatabaseSource(manifest_url, database_url) if manifest_url and database_url else fallback


def download_bytes(url: str, timeout: int = 12) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "MagicImageSolo-ModelUpdater/1.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _should_defer(state: dict[str, object], source: DatabaseSource, now: dt.datetime) -> bool:
    if _text(state.get("manifest_url")) != source.manifest_url:
        return False
    last_success = _parse_time(state.get("last_success_utc"))
    if last_success and now - last_success < SUCCESS_CHECK_INTERVAL:
        return True
    last_attempt = _parse_time(state.get("last_attempt_utc"))
    return bool(last_attempt and now - last_attempt < FAILURE_RETRY_INTERVAL)


def _state_payload(
    source: DatabaseSource,
    now: dt.datetime,
    *,
    success: bool,
    version: str = "",
    models_count: int = 0,
    existing: dict[str, object] | None = None,
) -> dict[str, object]:
    state = dict(existing or {})
    state.update(
        {
            "manifest_url": source.manifest_url,
            "last_attempt_utc": _now_iso(now),
            "last_result": "ok" if success else "failed",
        }
    )
    if success:
        state.update({"last_success_utc": _now_iso(now), "version": version, "models_count": models_count})
    return state


def _write_state_safely(root: pathlib.Path, state: dict[str, object]) -> None:
    try:
        _write_json_atomic(root / STATE_FILENAME, state)
    except OSError:
        # A read-only medium must still remain fully usable with its existing
        # local database.  The caller reports the actual update error instead.
        pass


def sync_model_database(
    root: pathlib.Path,
    *,
    force: bool = False,
    now: dt.datetime | None = None,
    fetch: Callable[[str], bytes] | None = None,
) -> SyncResult:
    """Check GitHub's manifest and atomically install a verified model.json.

    This function never removes a valid local data file.  If GitHub is offline,
    the manifest is invalid, the checksum differs, or the target directory is
    read-only, Solo simply continues with the currently installed database.
    """

    root = pathlib.Path(root)
    current_time = now or dt.datetime.now(dt.timezone.utc)
    if current_time.tzinfo is None:
        current_time = current_time.replace(tzinfo=dt.timezone.utc)
    source = load_database_source(root)
    state = _read_json(root / STATE_FILENAME)
    if not force and _should_defer(state, source, current_time):
        return SyncResult(False, False, "Datenbankprüfung bereits aktuell.")

    fetch_bytes = fetch or download_bytes
    database_path = root / DATABASE_FILENAME
    manifest_path = root / MANIFEST_FILENAME
    try:
        manifest_raw = fetch_bytes(source.manifest_url)
        remote_raw = json.loads(manifest_raw.decode("utf-8-sig"))
        if not isinstance(remote_raw, dict):
            raise ValueError("Manifest ist keine JSON-Struktur")
        remote_manifest: dict[str, object] = remote_raw
        remote_sha = _manifest_value(remote_manifest, "sha256", "model_sha256", "database_sha256")
        if not _is_valid_sha256(remote_sha):
            raise ValueError("Manifest enthält keine gültige SHA-256-Prüfsumme")
        remote_version = _manifest_value(remote_manifest, "version", "db_version", "database_version")
        local_manifest = _read_json(manifest_path)
        local_version = _manifest_value(local_manifest, "version", "db_version", "database_version")
        local_sha = _file_sha256(database_path)
        expected_url = _https_url(_manifest_value(remote_manifest, "database_url", "model_url", "raw_database_url")) or source.database_url

        if local_sha.lower() == remote_sha.lower():
            _write_json_atomic(manifest_path, remote_manifest)
            count = int(remote_manifest.get("models_count") or remote_manifest.get("model_count") or 0)
            _write_state_safely(root, _state_payload(source, current_time, success=True, version=remote_version, models_count=count, existing=state))
            return SyncResult(True, False, "Datenbank ist aktuell.", remote_version, count)

        # A changed checksum always wins over a cosmetic version mismatch.
        # The version comparison is retained only for an understandable result.
        _ = _version_is_newer(remote_version, local_version)
        payload = fetch_bytes(expected_url)
        if hashlib.sha256(payload).hexdigest().lower() != remote_sha.lower():
            raise ValueError("SHA-256-Prüfsumme der model.json stimmt nicht")
        parsed = json.loads(payload.decode("utf-8-sig"))
        if not isinstance(parsed, list) or not parsed or not all(isinstance(item, dict) for item in parsed):
            raise ValueError("model.json enthält keine gültige Modell-Liste")
        _write_bytes_atomic(database_path, payload)
        _write_json_atomic(manifest_path, remote_manifest)
        count = len(parsed)
        _write_state_safely(root, _state_payload(source, current_time, success=True, version=remote_version, models_count=count, existing=state))
        return SyncResult(True, True, f"Datenbank aktualisiert: {count} Configs.", remote_version, count)
    except (OSError, TimeoutError, urllib.error.URLError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        _write_state_safely(root, _state_payload(source, current_time, success=False, existing=state))
        return SyncResult(True, False, f"Datenbankupdate übersprungen: {exc}")
