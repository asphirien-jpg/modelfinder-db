"""Pure hardware-profile normalization used by the shared Magic Image core.

This module deliberately accepts already collected values only.  It does not
read hardware, mount media, start Clonezilla, modify firmware or write files.
"""

from __future__ import annotations

import re
from typing import Callable

from magic_image_normalize import format_number, normalise_token, positive_number
from magic_image_config_values import storage_capacities_equivalent
from magic_image_text import text


def vendor_token(value: object) -> str:
    token = normalise_token(value)
    aliases = {
        "hewlettpackard": "hp",
        "hpinc": "hp",
        "asustekcomputerinc": "asus",
        "asustek": "asus",
    }
    return aliases.get(token, token)


def cpu_token(value: object) -> str:
    raw = re.sub(r"\((?:r|tm)\)", "", text(value).casefold())
    core_match = re.search(
        r"\b(?:intel\s+)?core\s+(?:ultra\s+)?[3579]\s*\d{3,5}[a-z0-9-]*\b",
        raw,
    )
    if core_match:
        return normalise_token(re.sub(r"^intel\s+", "", core_match.group(0)))
    patterns = (
        r"\bamd\s+ryzen\s+[3579](?:\s+pro)?\s+\d{4,5}[a-z0-9-]*\b",
        r"\bryzen\s+[3579](?:\s+pro)?\s+\d{4,5}[a-z0-9-]*\b",
        r"\bi[3579][\s-]*\d{4,5}[a-z0-9-]*\b",
        r"\b(?:n|u|h|p)\d{3,5}[a-z0-9-]*\b",
        r"\b(?:ryzen\s*)?\d{4,5}[a-z0-9-]*\b",
    )
    for pattern in patterns:
        match = re.search(pattern, raw)
        if match:
            return normalise_token(match.group(0))
    return normalise_token(raw)


def ram_type_token(value: object) -> str:
    token = normalise_token(value)
    for candidate in ("lpddr5", "lpddr4", "ddr5", "ddr4", "ddr3"):
        if candidate in token:
            return candidate
    return token


def ram_layout_token(value: object) -> str:
    pairs = [
        (int(count), int(size))
        for count, size in re.findall(r"\b(\d+)\s*x\s*(\d+)\b", text(value).casefold())
    ]
    if not pairs:
        return normalise_token(value)
    modules = [size for count, size in pairs for _index in range(count)]
    if len(set(modules)) == 1:
        return f"{len(modules)}x{modules[0]}"
    return "+".join(f"1x{size}" for size in sorted(modules))


def ram_module_count(value: object) -> int | None:
    pairs = re.findall(r"\b(\d+)\s*x\s*\d+\b", text(value).casefold())
    return sum(int(count) for count in pairs) if pairs else None


def storage_kind(value: object) -> str:
    token = normalise_token(value)
    if "nvme" in token:
        return "nvme"
    if "emmc" in token:
        return "emmc"
    if "hdd" in token or "harddisk" in token:
        return "hdd"
    if "sata" in token and "ssd" in token:
        return "sata-ssd"
    if "ssd" in token:
        return "sata-ssd"
    return token


def display_type_token(value: object) -> str:
    raw = text(value).casefold()
    token = normalise_token(raw)
    if "3840x2160" in token or "4k" in token or "uhd" in token:
        return "uhd"
    if "2560x1440" in token or "qhd" in token:
        return "qhd"
    if "1920x1080" in token or "fullhd" in token or token == "fhd":
        return "full-hd"
    # ``normalise_token`` deliberately removes punctuation, including the
    # plus sign.  Therefore detect the common panel labels from the original
    # text first: HD+, HD++ and 1600×900 identify the same HD+ class here.
    if "1600x900" in token or re.search(r"(?<![a-z0-9])hd\s*\+{1,2}(?![a-z0-9])", raw) or "hdplus" in token or "hdplusplus" in token:
        return "hd-plus"
    if "1366x768" in token or token == "hd":
        return "hd"
    return token


def graphics_token(value: object) -> str:
    """Normalize a GPU name without relying on a vendor/device-ID database."""

    raw = text(value).casefold()
    geforce = re.search(r"\bgeforce\s+(?:rtx|gtx|gt|gts|mx)?\s*[a-z0-9 -]+", raw)
    if geforce:
        return normalise_token("nvidia " + geforce.group(0))
    # lspci commonly adds a PCI identifier and bracketed marketing name.  Both
    # forms should compare against the existing ``vga.txt`` config value.
    raw = re.sub(r"\[[0-9a-f]{4}:[0-9a-f]{4}\]", " ", raw)
    # PCI revisions and legal vendor suffixes describe the driver/bus, not
    # the GPU model.  Preserve names and model numbers, but remove only these
    # harmless decorations so a config such as Intel(R) HD Graphics 530
    # matches lspci's Intel Corporation HD Graphics 530 (rev 06).
    raw = re.sub(r"\(\s*rev\s+[0-9a-f]+\s*\)", " ", raw)
    raw = raw.replace("(r)", "").replace("(tm)", "")
    raw = raw.replace("advanced micro devices", "amd")
    raw = raw.replace("corporation", " ")
    raw = raw.replace("inc.", " ").replace("inc", " ")
    raw = re.sub(r"\b(?:vga compatible controller|3d controller|display controller)\b", " ", raw)
    return normalise_token(raw)


def graphics_equivalent(actual_value: object, expected_value: object) -> bool:
    """Compare graphics safely while allowing an intentionally generic config.

    Some established PC configs contain only values such as ``Intel(R)
    Graphics``.  ``lspci`` on newer systems expands that to a chip family such
    as ``Raptor Lake-U Intel Graphics``.  A generic config is a vendor-level
    statement and must accept that detail, but a concrete config (for example
    ``HD Graphics 530`` or ``RTX 3060``) remains an exact check.
    """

    actual = graphics_token(actual_value)
    expected = graphics_token(expected_value)
    if not actual or not expected:
        return False
    if actual == expected:
        return True
    generic_by_vendor = {
        "intelgraphics": "intel",
        "amdgraphics": "amd",
        "nvidiagraphics": "nvidia",
    }
    vendor = generic_by_vendor.get(expected)
    if vendor is None:
        return False
    # A GPU snapshot is already collected from the graphics controller.  AMD
    # Radeon and NVIDIA GeForce marketing names often omit the literal word
    # "Graphics", so the matching vendor is sufficient for a deliberately
    # generic config value only.
    return vendor in actual


def _comparison_line(label: str, actual: str, expected: str, config: str, unknown: bool = False) -> str:
    if unknown:
        return f"{label}: Gerät unbekannt – Config {config}: {expected} kann nicht sicher geprüft werden."
    return f"{label}: Gerät {actual} ≠ Config {config}: {expected}"


def strict_config_differences(
    config: str, model: dict[str, object], snapshot: dict[str, object], device_type: str = "laptop"
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Return strict profile mismatches without reading or changing hardware."""

    mismatches: list[str] = []
    unknowns: list[str] = []

    def compare_text(label: str, actual_value: object, expected_value: object, normaliser: Callable[[object], str] = normalise_token) -> None:
        expected = normaliser(expected_value)
        if not expected:
            return
        actual = normaliser(actual_value)
        expected_text = text(expected_value)
        if not actual:
            unknowns.append(_comparison_line(label, "", expected_text, config, unknown=True))
        elif actual != expected:
            mismatches.append(_comparison_line(label, text(actual_value), expected_text, config))

    def compare_number(label: str, actual_value: object, expected_value: object, unit: str, tolerance: float = 0.0) -> None:
        expected = positive_number(expected_value)
        if expected is None:
            return
        actual = positive_number(actual_value)
        expected_text = format_number(expected_value, unit)
        if actual is None:
            unknowns.append(_comparison_line(label, "", expected_text, config, unknown=True))
        elif abs(actual - expected) > tolerance:
            mismatches.append(_comparison_line(label, format_number(actual_value, unit), expected_text, config))

    compare_text("Hersteller", snapshot.get("vendor_short") or snapshot.get("vendor"), model.get("vendor"), vendor_token)
    compare_text("CPU", snapshot.get("cpu") or snapshot.get("cpu_short"), model.get("cpu"), cpu_token)
    compare_number("RAM gesamt", snapshot.get("ram_total_gb"), model.get("ram_total"), "GB")
    compare_text("RAM-Typ", snapshot.get("ram_type"), model.get("ram_type"), ram_type_token)
    compare_text("RAM-Bestückung", snapshot.get("ram_layout"), model.get("ram_layout"), ram_layout_token)

    expected_modules = positive_number(model.get("ram_module_count"))
    if expected_modules is not None:
        actual_modules = ram_module_count(snapshot.get("ram_layout"))
        expected_text = format_number(expected_modules, "Module")
        if actual_modules is None:
            unknowns.append(_comparison_line("RAM-Module", "", expected_text, config, unknown=True))
        elif int(actual_modules) != int(expected_modules):
            mismatches.append(_comparison_line("RAM-Module", format_number(actual_modules, "Module"), expected_text, config))

    expected_storage = storage_kind(model.get("storage_type"))
    actual_storage = storage_kind(snapshot.get("primary_storage_type"))
    if expected_storage:
        expected_text = text(model.get("storage_type"))
        if not actual_storage:
            unknowns.append(_comparison_line("SSD-Typ", "", expected_text, config, unknown=True))
        elif actual_storage != expected_storage:
            mismatches.append(_comparison_line("SSD-Typ", text(snapshot.get("primary_storage_type")), expected_text, config))

    expected_disk = positive_number(model.get("ssd"))
    actual_disk = positive_number(snapshot.get("primary_disk_gb"))
    if expected_disk is not None:
        expected_text = format_number(model.get("ssd"), "GB")
        if actual_disk is None:
            unknowns.append(_comparison_line("SSD-Größe", "", expected_text, config, unknown=True))
        else:
            if not storage_capacities_equivalent(actual_disk, expected_disk):
                mismatches.append(_comparison_line("SSD-Größe", format_number(actual_disk, "GB"), expected_text, config))

    if str(device_type or "").lower() == "pc":
        # A desktop monitor is not a characteristic of the PC itself.  The
        # optional vga.txt value, however, is a useful machine characteristic.
        expected_graphics = model.get("graphics")
        actual_graphics = snapshot.get("graphics")
        expected_token = graphics_token(expected_graphics)
        actual_token = graphics_token(actual_graphics)
        if expected_token:
            expected_text = text(expected_graphics)
            if not actual_token:
                unknowns.append(_comparison_line("Grafikkarte", "", expected_text, config, unknown=True))
            elif not graphics_equivalent(actual_graphics, expected_graphics):
                mismatches.append(_comparison_line("Grafikkarte", text(actual_graphics), expected_text, config))
    else:
        compare_text("Display-Auflösung", snapshot.get("display_type"), model.get("display_type"), display_type_token)
        compare_number("Display-Größe", snapshot.get("display_inches"), model.get("inch"), '"', tolerance=0.35)
    return tuple(mismatches), tuple(unknowns)
