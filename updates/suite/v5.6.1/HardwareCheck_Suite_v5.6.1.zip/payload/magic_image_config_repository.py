"""Read-only access to existing Magic Image ``#configs`` folders.

The module only reads small legacy text files already present on the image
medium.  It never runs scripts, mounts media, starts a restore, or writes to a
config folder.
"""

from __future__ import annotations

import pathlib
import re
from typing import Iterable

from magic_image_config_values import profile_from_values


_PROFILE_FILENAMES = (
    "CPU.txt", "RAM.txt", "driveCsize.txt", "resolution.txt",
    "physical-display-size.txt", "ram-modules-amount.txt", "vga.txt",
)


def discover_config_ids(repository_roots: Iterable[str]) -> set[str]:
    """Return four-digit configuration folders from already-known repositories."""

    configs: set[str] = set()
    for root_text in repository_roots:
        try:
            for candidate in (pathlib.Path(root_text) / "#configs").iterdir():
                if candidate.is_dir() and re.fullmatch(r"\d{4}", candidate.name):
                    configs.add(candidate.name)
        except OSError:
            continue
    return configs


def config_profile_text(config_directory: pathlib.Path, filename: str) -> str:
    """Read one small legacy config value without executing any script."""

    try:
        children = tuple((config_directory / "skripte").iterdir())
    except OSError:
        return ""
    candidate = next(
        (child for child in children if child.is_file() and child.name.casefold() == filename.casefold()),
        None,
    )
    if candidate is None:
        return ""
    try:
        return candidate.read_text(encoding="utf-8-sig", errors="replace").strip()
    except OSError:
        return ""


def config_folder_profile(config_directory: pathlib.Path) -> dict[str, object]:
    """Build a profile from the config's existing hardware-value text files."""

    return profile_from_values(
        config_directory.name,
        {filename: config_profile_text(config_directory, filename) for filename in _PROFILE_FILENAMES},
    )


def discover_config_profiles(repository_roots: Iterable[str]) -> dict[str, dict[str, object]]:
    """Read the best available hardware profile for every config folder."""

    profiles: dict[str, dict[str, object]] = {}
    for root_text in repository_roots:
        try:
            candidates = tuple((pathlib.Path(root_text) / "#configs").iterdir())
        except OSError:
            continue
        for candidate in candidates:
            if not candidate.is_dir() or not re.fullmatch(r"\d{4}", candidate.name):
                continue
            profile = config_folder_profile(candidate)
            previous = profiles.get(candidate.name, {})
            if len(profile) > len(previous):
                profiles[candidate.name] = profile
    return profiles
