#!/usr/bin/env python3
"""Native GTK 3 interface for the HardwareCheck v5 development line.

The proven HardwareCheck module remains the functional core.  This file only
owns the new navigation, presentation and asynchronous UI orchestration so the
legacy Tk interface remains available as a safe fallback.
"""

from __future__ import annotations

import datetime
import json
import os
import pathlib
import re
import sys
import threading
import traceback
from typing import Callable

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango  # noqa: E402


APP_ID = "de.hardwarecheck.v5"
ACCENT = "#f7b733"
GOOD = "#2ec98f"
WARN = "#f0a83b"
BAD = "#ed5d68"
INFO = "#4aa7ff"


CSS = b"""
* {
  font-family: Inter, "Segoe UI", sans-serif;
}
window, .app-root {
  background: #0b1018;
  color: #ecf2f8;
}
.topbar {
  background: #111824;
  border-bottom: 1px solid #283347;
  padding: 10px 18px;
}
.brand {
  color: #ffffff;
  font-size: 22px;
  font-weight: 800;
}
.version {
  color: #8fa2b8;
  font-size: 11px;
  font-weight: 700;
}
.status-chip {
  background: #192334;
  border: 1px solid #30405a;
  border-radius: 18px;
  color: #cfe0ef;
  padding: 7px 12px;
  font-weight: 700;
}
.status-chip.good { color: #74e1b5; border-color: #286b54; }
.status-chip.warn { color: #ffd07b; border-color: #735824; }
.status-chip.bad { color: #ff969e; border-color: #71313a; }
.update-alert {
  border: 2px solid #ffffff;
  border-radius: 10px;
  padding: 8px 14px;
  font-weight: 900;
}
.update-phase-red { background: #b51f32; color: #ffffff; border-color: #ff8a98; }
.update-phase-gold { background: #e6a82e; color: #10151d; border-color: #fff2ad; }
.update-phase-blue { background: #176fc1; color: #ffffff; border-color: #92ccff; }
.update-phase-purple { background: #8138a6; color: #ffffff; border-color: #e4a8ff; }
popover, popover.background, .dark-popover, .dark-popover > contents {
  background: #111824;
  color: #ecf2f8;
  border-color: #34435b;
}
.dark-popover { border: 1px solid #34435b; border-radius: 12px; }
.sidebar {
  background: #0e1520;
  border-right: 1px solid #253146;
  padding: 14px 10px;
}
.nav-button {
  background: transparent;
  color: #aebdcd;
  border: 0;
  border-radius: 10px;
  padding: 12px 14px;
  margin: 2px 0;
  font-size: 14px;
  font-weight: 700;
}
.nav-button:hover { background: #182235; color: #ffffff; }
.nav-button.active {
  background: #253044;
  color: #ffd06a;
  border-left: 4px solid #f7b733;
}
.content { background: #0b1018; padding: 20px; }
.page-title { color: #ffffff; font-size: 26px; font-weight: 800; }
.page-subtitle { color: #8fa2b8; font-size: 13px; }
.hero {
  background: linear-gradient(135deg, #18253a, #172033);
  border: 1px solid #33435e;
  border-radius: 16px;
  padding: 22px;
}
.hero-title { color: #ffffff; font-size: 25px; font-weight: 800; }
.hero-subtitle { color: #aebed0; font-size: 14px; }
.section-title { color: #f5f8fb; font-size: 17px; font-weight: 800; }
.card {
  background: #141c29;
  border: 1px solid #2b374c;
  border-radius: 14px;
  padding: 16px;
}
.card:hover { border-color: #435674; }
.card-icon { color: #f7b733; }
.card-title { color: #92a5ba; font-size: 12px; font-weight: 700; }
.card-value { color: #ffffff; font-size: 19px; font-weight: 800; }
.card-subtitle { color: #7f91a7; font-size: 11px; }
.quick-button {
  background: #162234;
  border: 1px solid #344763;
  border-radius: 13px;
  color: #ffffff;
  padding: 16px;
  font-size: 14px;
  font-weight: 800;
}
.quick-button:hover { background: #21314a; border-color: #f7b733; }
.primary-button {
  background: #e6a82e;
  color: #11151d;
  border: 0;
  border-radius: 9px;
  padding: 9px 16px;
  font-weight: 800;
}
.primary-button:hover { background: #ffc957; }
.secondary-button {
  background: #1b2739;
  color: #e8eef5;
  border: 1px solid #354762;
  border-radius: 9px;
  padding: 9px 14px;
  font-weight: 700;
}
.secondary-button:hover { background: #25354d; }
.danger-button {
  background: #42212a;
  color: #ffabb2;
  border: 1px solid #78343f;
  border-radius: 9px;
  padding: 9px 14px;
  font-weight: 800;
}
entry, searchentry, spinbutton {
  background: #101825;
  color: #f7f9fc;
  border: 1px solid #3b4b64;
  border-radius: 9px;
  padding: 9px 12px;
}
treeview, list, textview, textview text {
  background: #101722;
  color: #eaf0f6;
}
treeview header button {
  background: #d9d6cf;
  color: #121820;
  border: 1px solid #b9b5ad;
  font-weight: 800;
  padding: 8px;
}
treeview:selected, row:selected { background: #a96b00; color: #ffffff; }
.list-row { background: #121b28; border-bottom: 1px solid #29364a; padding: 10px; }
.list-row:hover { background: #192538; }
.muted { color: #8da0b5; }
.good-text { color: #55dca8; font-weight: 800; }
.warn-text { color: #ffc86b; font-weight: 800; }
.bad-text { color: #ff858f; font-weight: 800; }
.match-cell { background: #176b61; color: #ffffff; padding: 8px; }
.mismatch-cell { background: #85242b; color: #ffffff; padding: 8px; }
.reference-cell { background: #18506b; color: #ffffff; padding: 8px; }
.neutral-cell { background: #151e2b; color: #dce6f0; padding: 8px; }
.unavailable-cell { background: #171d27; color: #748397; padding: 8px; }
.comparison-header { background: #d9d6cf; color: #111820; padding: 8px; font-weight: 800; }
.footer {
  background: #101722;
  border-top: 1px solid #263247;
  color: #91a3b8;
  padding: 7px 14px;
}
.footer.update-phase-red, .nav-button.update-phase-red { background: #b51f32; color: #ffffff; border-color: #ff8a98; }
.footer.update-phase-gold, .nav-button.update-phase-gold { background: #e6a82e; color: #10151d; border-color: #fff2ad; }
.footer.update-phase-blue, .nav-button.update-phase-blue { background: #176fc1; color: #ffffff; border-color: #92ccff; }
.footer.update-phase-purple, .nav-button.update-phase-purple { background: #8138a6; color: #ffffff; border-color: #e4a8ff; }
.footer.update-phase-red label, .footer.update-phase-blue label, .footer.update-phase-purple label,
.nav-button.update-phase-red label, .nav-button.update-phase-blue label, .nav-button.update-phase-purple label { color: #ffffff; }
.footer.update-phase-gold label, .nav-button.update-phase-gold label { color: #10151d; }
progressbar trough, levelbar trough {
  background: #253044;
  border: 0;
  border-radius: 6px;
  min-height: 12px;
}
progressbar progress, levelbar block.filled {
  background: #2ec98f;
  border: 0;
  border-radius: 6px;
}
separator { background: #2a374b; }
"""


def _clean(value: object, fallback: str = "–") -> str:
    text = str(value or "").strip()
    return text if text else fallback


def _short(value: object, maximum: int = 80) -> str:
    text = " ".join(str(value or "").split())
    return text if len(text) <= maximum else text[: maximum - 1].rstrip() + "…"


def _flag_rgb(language: str, width: int = 42, height: int = 26) -> bytes:
    language = str(language or "DE").upper()
    data = bytearray()
    for y in range(height):
        for x in range(width):
            nx = x / max(1, width - 1)
            ny = y / max(1, height - 1)
            if language == "CZ":
                color = (248, 248, 248) if ny < 0.5 else (215, 20, 26)
                if nx <= 0.5 * (1.0 - abs(2.0 * ny - 1.0)):
                    color = (17, 69, 126)
            elif language == "EN":
                color = (33, 70, 139)
                if abs(ny - nx) <= 0.13 or abs(ny - (1.0 - nx)) <= 0.13:
                    color = (247, 247, 247)
                if abs(ny - nx) <= 0.05 or abs(ny - (1.0 - nx)) <= 0.05:
                    color = (207, 20, 43)
                if abs(nx - 0.5) <= 0.13 or abs(ny - 0.5) <= 0.20:
                    color = (247, 247, 247)
                if abs(nx - 0.5) <= 0.06 or abs(ny - 0.5) <= 0.09:
                    color = (207, 20, 43)
            else:
                color = (20, 20, 20) if ny < 1 / 3 else (221, 30, 47) if ny < 2 / 3 else (245, 202, 40)
            data.extend(color)
    return bytes(data)


def flag_pixbuf(language: str, width: int = 42, height: int = 26) -> GdkPixbuf.Pixbuf:
    raw = GLib.Bytes.new(_flag_rgb(language, width, height))
    return GdkPixbuf.Pixbuf.new_from_bytes(raw, GdkPixbuf.Colorspace.RGB, False, 8, width, height, width * 3)


class HardwareCheckV5(Gtk.Application):
    """GTK shell using the proven v3 core functions without blocking startup."""

    UPDATE_PHASE_CLASSES = (
        "update-phase-red",
        "update-phase-gold",
        "update-phase-blue",
        "update-phase-purple",
    )

    NAV_ITEMS = (
        ("dashboard", "view-grid-symbolic", ("Übersicht", "Overview", "Přehled")),
        ("models", "system-search-symbolic", ("ModelFinder", "Model finder", "Vyhledávač modelů")),
        ("battery", "battery-symbolic", ("Akku-Test", "Battery test", "Test baterie")),
        ("print", "document-print-symbolic", ("Drucken", "Print", "Tisk")),
        ("reports", "folder-documents-symbolic", ("Reports", "Reports", "Reporty")),
        ("settings", "preferences-system-symbolic", ("Einstellungen", "Settings", "Nastavení")),
    )

    def __init__(self, core) -> None:
        super().__init__(application_id=APP_ID, flags=0)
        self.core = core
        try:
            self.language = core.LANGUAGES[core.load_language_index()]
        except Exception:
            self.language = "DE"
        self.window: Gtk.ApplicationWindow | None = None
        self.stack: Gtk.Stack | None = None
        self.nav_buttons: dict[str, Gtk.Button] = {}
        self.pages: dict[str, Gtk.Widget] = {}
        self.current_page = "dashboard"
        self.snapshot: dict[str, object] = {}
        self.models: list[dict[str, object]] = []
        self.match_results: list[dict[str, object]] = []
        self._model_relation_map: dict[str, tuple[list[str], list[str]]] = {}
        self._model_selected_ids: list[str] = []
        self._model_visible_results: list[tuple[int, dict[str, object]]] = []
        self._model_option_bindings: list[dict[str, object]] = []
        self._model_selection_syncing = False
        self._busy_count = 0
        self._refresh_tasks: set[str] = set()
        self._battery_samples: list[dict[str, object]] = []
        self._battery_mode = ""
        self._battery_csv_path: pathlib.Path | None = None
        self._battery_timer_id: int | None = None
        self._printer_results: list[dict[str, object]] = []
        self._report_paths: list[pathlib.Path] = []
        self._wifi_autoconnect_started = False
        self._wifi_connection_busy = False
        self._wifi_connected_ssid = ""
        self._wifi_quick_networks: list[dict[str, str]] = []
        self._auto_update_check_started = False
        self._update_operation = ""
        self._db_update_available = False
        self._program_update_available = False
        self._update_alert_demo = False
        self._update_alert_timer_id: int | None = None
        self._update_alert_phase = 0
        self._update_progress_determinate = False
        self._build_refs: dict[str, object] = {}

    def _t(self, de: str, en: str, cz: str) -> str:
        return {"DE": de, "EN": en, "CZ": cz}.get(self.language, de)

    def do_activate(self) -> None:
        if self.window is not None:
            self.window.present()
            return
        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.window = Gtk.ApplicationWindow(application=self)
        self.window.set_title(f"HardwareCheck {self.core.APP_VERSION}")
        self.window.set_default_size(1366, 820)
        self.window.set_size_request(900, 600)
        self.window.get_style_context().add_class("app-root")
        if os.environ.get("HC_V5_WINDOWED") == "1":
            self.window.set_position(Gtk.WindowPosition.CENTER)
        else:
            self.window.fullscreen()

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.window.add(root)
        root.pack_start(self._build_topbar(), False, False, 0)

        middle = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        root.pack_start(middle, True, True, 0)
        middle.pack_start(self._build_sidebar(), False, False, 0)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=180)
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        middle.pack_start(self.stack, True, True, 0)
        self._build_pages()
        root.pack_end(self._build_footer(), False, False, 0)

        self.window.show_all()
        self.show_page("dashboard")
        GLib.timeout_add_seconds(1, self._clock_tick)
        GLib.timeout_add_seconds(2, self._battery_refresh_tick)
        GLib.idle_add(self._start_initial_load)

    # ---------- shared widgets ----------

    def _icon(self, name: str, size: Gtk.IconSize = Gtk.IconSize.BUTTON) -> Gtk.Image:
        return Gtk.Image.new_from_icon_name(name, size)

    def _label(self, text: str = "", css: str = "", xalign: float = 0.0, wrap: bool = False) -> Gtk.Label:
        label = Gtk.Label(label=text, xalign=xalign)
        if css:
            label.get_style_context().add_class(css)
        label.set_line_wrap(wrap)
        label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        label.set_selectable(False)
        return label

    def _button(self, text: str, callback: Callable, css: str = "secondary-button", icon: str = "") -> Gtk.Button:
        button = Gtk.Button()
        button.get_style_context().add_class(css)
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        box.set_halign(Gtk.Align.CENTER)
        if icon:
            box.pack_start(self._icon(icon), False, False, 0)
        box.pack_start(self._label(text), False, False, 0)
        button.add(box)
        button.connect("clicked", callback)
        return button

    def _page_shell(self, title: str, subtitle: str) -> tuple[Gtk.ScrolledWindow, Gtk.Box]:
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.get_style_context().add_class("content")
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        outer.set_margin_start(22)
        outer.set_margin_end(22)
        outer.set_margin_top(18)
        outer.set_margin_bottom(22)
        outer.pack_start(self._label(title, "page-title"), False, False, 0)
        outer.pack_start(self._label(subtitle, "page-subtitle", wrap=True), False, False, 2)
        scroll.add(outer)
        return scroll, outer

    def _card(self, title: str, value: str = "–", subtitle: str = "", icon: str = "computer-symbolic") -> tuple[Gtk.Frame, Gtk.Label, Gtk.Label]:
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.NONE)
        frame.set_size_request(245, 128)
        frame.get_style_context().add_class("card")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        frame.add(box)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        image = self._icon(icon, Gtk.IconSize.LARGE_TOOLBAR)
        image.get_style_context().add_class("card-icon")
        top.pack_start(image, False, False, 0)
        top.pack_start(self._label(title, "card-title"), True, True, 0)
        box.pack_start(top, False, False, 0)
        value_label = self._label(value, "card-value", wrap=True)
        value_label.set_ellipsize(Pango.EllipsizeMode.END)
        box.pack_start(value_label, True, True, 0)
        subtitle_label = self._label(subtitle, "card-subtitle", wrap=True)
        box.pack_start(subtitle_label, False, False, 0)
        return frame, value_label, subtitle_label

    def _section(self, parent: Gtk.Box, title: str, margin_top: int = 16) -> Gtk.Box:
        title_label = self._label(title, "section-title")
        title_label.set_margin_top(margin_top)
        parent.pack_start(title_label, False, False, 4)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        parent.pack_start(box, False, False, 0)
        return box

    def _flow(self) -> Gtk.FlowBox:
        flow = Gtk.FlowBox()
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_row_spacing(12)
        flow.set_column_spacing(12)
        flow.set_homogeneous(True)
        flow.set_max_children_per_line(4)
        flow.set_min_children_per_line(1)
        return flow

    # ---------- application chrome ----------

    def _build_topbar(self) -> Gtk.Widget:
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        bar.get_style_context().add_class("topbar")
        brand_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        brand_box.pack_start(self._label("HardwareCheck", "brand"), False, False, 0)
        brand_box.pack_start(self._label(f"VERSION {self.core.APP_VERSION.upper()} · GTK DEVELOPMENT", "version"), False, False, 0)
        bar.pack_start(brand_box, False, False, 0)

        self._build_refs["top_spinner"] = Gtk.Spinner()
        bar.pack_start(self._build_refs["top_spinner"], False, False, 0)
        bar.pack_start(Gtk.Box(), True, True, 0)

        network_button = self._build_wifi_quick_menu()
        update_button = self._build_update_alert_button()
        self._build_refs["db_chip"] = self._label("DB: –", "status-chip")
        self._build_refs["battery_chip"] = self._label(self._t("Akku: –", "Battery: –", "Baterie: –"), "status-chip")
        self._build_refs["clock"] = self._label("", "status-chip")
        bar.pack_start(network_button, False, False, 0)
        bar.pack_start(update_button, False, False, 0)
        for key in ("db_chip", "battery_chip", "clock"):
            bar.pack_start(self._build_refs[key], False, False, 0)
        return bar

    def _build_update_alert_button(self) -> Gtk.Button:
        button = Gtk.Button()
        button.get_style_context().add_class("update-alert")
        button.set_no_show_all(True)
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        inner.pack_start(self._icon("software-update-available-symbolic"), False, False, 0)
        label = self._label(self._t("UPDATE VERFÜGBAR", "UPDATE AVAILABLE", "AKTUALIZACE K DISPOZICI"))
        inner.pack_start(label, False, False, 0)
        button.add(inner)
        button.connect("clicked", self._open_update_settings)
        self._build_refs["update_alert_button"] = button
        self._build_refs["update_alert_label"] = label
        return button

    def _build_wifi_quick_menu(self) -> Gtk.MenuButton:
        button = Gtk.MenuButton()
        button.get_style_context().add_class("status-chip")
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        inner.pack_start(self._icon("network-wireless-symbolic"), False, False, 0)
        label = self._label(self._t("WLAN wird geprüft", "Checking Wi-Fi", "Kontrola Wi-Fi"))
        inner.pack_start(label, False, False, 0)
        button.add(inner)

        popover = Gtk.Popover.new(button)
        popover.get_style_context().add_class("dark-popover")
        popover.set_size_request(440, 430)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        content.set_margin_start(12)
        content.set_margin_end(12)
        content.set_margin_top(12)
        content.set_margin_bottom(12)

        heading = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        heading.pack_start(self._label("WLAN", "section-title"), True, True, 0)
        heading.pack_end(
            self._button(
                self._t("Aktualisieren", "Refresh", "Obnovit"),
                lambda _b: self._refresh_wifi_quick_menu(force=True),
                "secondary-button",
                "view-refresh-symbolic",
            ),
            False,
            False,
            0,
        )
        content.pack_start(heading, False, False, 0)
        quick_status = self._label(self._t("Verbindung wird geprüft …", "Checking connection …", "Kontrola připojení …"), "muted", wrap=True)
        content.pack_start(quick_status, False, False, 0)

        quick_list = Gtk.ListBox()
        quick_list.set_selection_mode(Gtk.SelectionMode.NONE)
        quick_scroll = Gtk.ScrolledWindow()
        quick_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        quick_scroll.set_min_content_height(270)
        quick_scroll.add(quick_list)
        content.pack_start(quick_scroll, True, True, 0)
        content.pack_start(
            self._button(
                self._t("Gespeicherte WLANs verwalten", "Manage saved Wi-Fi", "Spravovat uložené Wi-Fi"),
                lambda _b: self._open_settings_tool("wifi", popover),
                "secondary-button",
                "preferences-system-symbolic",
            ),
            False,
            False,
            0,
        )
        popover.add(content)
        content.show_all()
        button.set_popover(popover)
        button.connect("toggled", self._wifi_quick_toggled)
        self._build_refs["network_chip_button"] = button
        self._build_refs["network_chip"] = label
        self._build_refs["wifi_quick_popover"] = popover
        self._build_refs["wifi_quick_status"] = quick_status
        self._build_refs["wifi_quick_list"] = quick_list
        return button

    def _build_sidebar(self) -> Gtk.Widget:
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        side.set_size_request(225, -1)
        side.get_style_context().add_class("sidebar")
        for name, icon, texts in self.NAV_ITEMS:
            button = Gtk.Button()
            button.get_style_context().add_class("nav-button")
            inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            inner.pack_start(self._icon(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            label = self._label(self._t(*texts))
            inner.pack_start(label, True, True, 0)
            button.add(inner)
            button.connect("clicked", lambda _button, page=name: self.show_page(page))
            side.pack_start(button, False, False, 0)
            self.nav_buttons[name] = button
            self._build_refs[f"nav_label_{name}"] = label
        side.pack_start(Gtk.Box(), True, True, 0)
        side.pack_start(self._label(self._t("Native GTK-Oberfläche", "Native GTK interface", "Nativní rozhraní GTK"), "version", wrap=True), False, False, 8)
        side.pack_start(self._build_power_menu(), False, False, 0)
        return side

    def _build_power_menu(self) -> Gtk.MenuButton:
        button = Gtk.MenuButton()
        button.get_style_context().add_class("danger-button")
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        inner.set_halign(Gtk.Align.CENTER)
        inner.pack_start(self._icon("system-shutdown-symbolic"), False, False, 0)
        inner.pack_start(self._label(self._t("Ein/Aus", "Power", "Napájení")), False, False, 0)
        button.add(inner)

        popover = Gtk.Popover.new(button)
        popover.get_style_context().add_class("dark-popover")
        actions = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        actions.set_margin_start(6)
        actions.set_margin_end(6)
        actions.set_margin_top(6)
        actions.set_margin_bottom(6)
        actions.pack_start(
            self._button(
                self._t("Herunterfahren", "Shut down", "Vypnout"),
                lambda _b: self._power_menu_action("poweroff", popover),
                "secondary-button",
                "system-shutdown-symbolic",
            ),
            False,
            False,
            0,
        )
        actions.pack_start(
            self._button(
                self._t("Neu starten", "Restart", "Restartovat"),
                lambda _b: self._power_menu_action("reboot", popover),
                "secondary-button",
                "view-refresh-symbolic",
            ),
            False,
            False,
            0,
        )
        popover.add(actions)
        actions.show_all()
        button.set_popover(popover)
        self._build_refs["power_menu"] = popover
        return button

    def _build_footer(self) -> Gtk.Widget:
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        footer.get_style_context().add_class("footer")
        self._build_refs["footer_box"] = footer
        self._build_refs["footer_icon"] = self._icon("emblem-system-symbolic")
        self._build_refs["footer_status"] = self._label(self._t("v5 wird gestartet …", "Starting v5 …", "Spouštění v5 …"), wrap=True)
        footer.pack_start(self._build_refs["footer_icon"], False, False, 0)
        footer.pack_start(self._build_refs["footer_status"], True, True, 0)
        self._build_refs["footer_progress"] = Gtk.ProgressBar()
        self._build_refs["footer_progress"].set_size_request(170, -1)
        self._build_refs["footer_progress"].set_no_show_all(True)
        footer.pack_end(self._build_refs["footer_progress"], False, False, 0)
        return footer

    def _build_pages(self) -> None:
        builders = {
            "dashboard": self._build_dashboard,
            "models": self._build_models_page,
            "battery": self._build_battery_page,
            "wifi": self._build_wifi_page,
            "printers": self._build_printers_page,
            "print": self._build_print_page,
            "reports": self._build_reports_page,
            "settings": self._build_settings_page,
        }
        for name, builder in builders.items():
            page = builder()
            self.pages[name] = page
            self.stack.add_named(page, name)

    def show_page(self, name: str) -> None:
        if self.stack is None or name not in self.pages:
            return
        self.current_page = name
        self.stack.set_visible_child_name(name)
        active_nav = "settings" if name in {"wifi", "printers"} else name
        for key, button in self.nav_buttons.items():
            context = button.get_style_context()
            if key == active_nav:
                context.add_class("active")
            else:
                context.remove_class("active")
        if name == "wifi":
            self._refresh_wifi_saved_rows()
        elif name == "printers":
            self._refresh_printer_profiles()
        elif name == "print":
            self._refresh_print_page()
        elif name == "reports":
            self._refresh_reports()
        elif name == "models":
            self._refresh_model_table()

    # ---------- dashboard ----------

    def _build_dashboard(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Werkstatt-Dashboard", "Workshop dashboard", "Dílenský přehled"),
            self._t("Hardware, Modellabgleich und Servicetools auf einen Blick.", "Hardware, model matching and service tools at a glance.", "Hardware, porovnání modelů a servisní nástroje na jednom místě."),
        )
        hero = Gtk.Frame()
        hero.set_shadow_type(Gtk.ShadowType.NONE)
        hero.get_style_context().add_class("hero")
        hero_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hero.add(hero_box)
        hero_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self._build_refs["hero_title"] = self._label(self._t("Gerät wird erkannt …", "Detecting device …", "Rozpoznávání zařízení …"), "hero-title", wrap=True)
        self._build_refs["hero_subtitle"] = self._label(self._t("Die Oberfläche ist bereits bereit; der Hardware-Scan läuft im Hintergrund.", "The interface is ready while hardware scanning continues in the background.", "Rozhraní je připraveno, sken hardwaru probíhá na pozadí."), "hero-subtitle", wrap=True)
        hero_text.pack_start(self._build_refs["hero_title"], False, False, 0)
        hero_text.pack_start(self._build_refs["hero_subtitle"], False, False, 0)
        hero_box.pack_start(hero_text, True, True, 0)
        hero_box.pack_end(self._button(self._t("Neu scannen", "Scan again", "Skenovat znovu"), self._rescan_clicked, "primary-button", "view-refresh-symbolic"), False, False, 0)
        outer.pack_start(hero, False, False, 12)

        metrics = self._section(outer, self._t("Systemübersicht", "System overview", "Přehled systému"))
        flow = self._flow()
        metrics.pack_start(flow, False, False, 0)
        card_specs = (
            ("system", self._t("Gerät", "Device", "Zařízení"), "computer-symbolic"),
            ("cpu", "CPU", "cpu-symbolic"),
            ("ram", "RAM", "drive-harddisk-symbolic"),
            ("storage", self._t("Speicher", "Storage", "Úložiště"), "drive-harddisk-symbolic"),
            ("display", self._t("Anzeige", "Display", "Displej"), "video-display-symbolic"),
            ("match", self._t("Bester Modelltreffer", "Best model match", "Nejlepší shoda modelu"), "system-search-symbolic"),
        )
        for key, title, icon in card_specs:
            card, value, subtitle = self._card(title, icon=icon)
            flow.add(card)
            self._build_refs[f"metric_{key}"] = value
            self._build_refs[f"metric_{key}_sub"] = subtitle

        suggestions = self._section(outer, self._t("Modellvorschläge", "Model suggestions", "Návrhy modelů"))
        self._build_refs["dashboard_model_count"] = self._label(
            self._t("Hardware wird ausgewertet …", "Evaluating hardware …", "Vyhodnocování hardwaru …"),
            "muted",
        )
        suggestions.pack_start(self._build_refs["dashboard_model_count"], False, False, 0)
        self._build_refs["dashboard_model_list"] = Gtk.ListBox()
        self._build_refs["dashboard_model_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        suggestion_scroll = Gtk.ScrolledWindow()
        suggestion_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        suggestion_scroll.set_min_content_height(190)
        suggestion_scroll.add(self._build_refs["dashboard_model_list"])
        suggestions.pack_start(suggestion_scroll, False, False, 0)
        return page

    def _render_dashboard_model_suggestions(self) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("dashboard_model_list")
        count_label: Gtk.Label | None = self._build_refs.get("dashboard_model_count")
        if listbox is None or count_label is None:
            return
        self._clear_listbox(listbox)
        shown = self.match_results[:6]
        count_label.set_text(
            self._t(
                f"{len(self.match_results)} passende Geräte · die besten {len(shown)} werden angezeigt",
                f"{len(self.match_results)} matching devices · showing the best {len(shown)}",
                f"Odpovídající zařízení: {len(self.match_results)} · zobrazeno nejlepších {len(shown)}",
            )
        )
        if not shown:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Kein passendes Modell gefunden.", "No matching model found.", "Nebyl nalezen odpovídající model."), "muted", wrap=True))
            listbox.add(row)
        for index, result in enumerate(shown):
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            model_id = _clean(item.get("model_id"))
            score = int(result.get("score") or 0)
            row = Gtk.ListBoxRow()
            row.get_style_context().add_class("list-row")
            content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            row.add(content)
            rank = self._label("★" if index == 0 else str(index + 1), "good-text" if index == 0 else "muted", xalign=0.5)
            rank.set_size_request(32, -1)
            content.pack_start(rank, False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            title = f"{model_id} · {score}%"
            if index == 0:
                title = f"{self._t('Bester Treffer', 'Best match', 'Nejlepší shoda')}: {title}"
            text.pack_start(self._label(title, "section-title"), False, False, 0)
            text.pack_start(self._label(_short(self.core.model_notebook_summary(item), 100), "muted", wrap=True), False, False, 0)
            content.pack_start(text, True, True, 0)
            content.pack_end(
                self._button(
                    self._t("Vergleichen", "Compare", "Porovnat"),
                    lambda _b, value=model_id: self._open_dashboard_model(value),
                    "secondary-button",
                    "system-search-symbolic",
                ),
                False,
                False,
                0,
            )
            listbox.add(row)
        listbox.show_all()

    def _open_dashboard_model(self, model_id: str) -> None:
        search: Gtk.SearchEntry | None = self._build_refs.get("model_search")
        if search is not None:
            search.set_text(model_id)
            self._model_search_changed(search)
        self.show_page("models")

    # ---------- model finder ----------

    def _build_models_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            "ModelFinder",
            self._t("Modelle suchen, Gerätetreffer bewerten und mehrere Datensätze direkt vergleichen.", "Search models, evaluate device matches and compare multiple records directly.", "Vyhledávejte modely, vyhodnocujte shody zařízení a porovnávejte více záznamů."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self._build_refs["model_search"] = Gtk.SearchEntry()
        self._build_refs["model_search"].set_placeholder_text(self._t("Modell-ID, Hersteller, CPU oder Produktnummer", "Model ID, manufacturer, CPU or product number", "ID modelu, výrobce, CPU nebo produktové číslo"))
        self._build_refs["model_search"].connect("search-changed", self._model_search_changed)
        toolbar.pack_start(self._build_refs["model_search"], True, True, 0)
        self._build_refs["model_use_device"] = Gtk.CheckButton(label=self._t("Aktuelles Gerät anzeigen", "Show current device", "Zobrazit aktuální zařízení"))
        self._build_refs["model_use_device"].set_active(True)
        self._build_refs["model_use_device"].connect("toggled", self._model_device_toggled)
        toolbar.pack_start(self._build_refs["model_use_device"], False, False, 0)
        self._build_refs["model_selection_count"] = self._label(self._t("0/3 gewählt", "0/3 selected", "Vybráno 0/3"), "muted")
        toolbar.pack_start(self._build_refs["model_selection_count"], False, False, 0)
        toolbar.pack_start(self._button(self._t("Auswahl leeren", "Clear selection", "Zrušit výběr"), self._clear_model_selection, "secondary-button", "edit-clear-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)

        compare_frame = Gtk.Frame()
        compare_frame.set_shadow_type(Gtk.ShadowType.NONE)
        compare_frame.get_style_context().add_class("card")
        compare_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        compare_frame.add(compare_outer)
        compare_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["model_compare_title"] = self._label(self._t("Modellvergleich mit aktuellem Gerät", "Model comparison with current device", "Porovnání modelů s aktuálním zařízením"), "section-title")
        compare_header.pack_start(self._build_refs["model_compare_title"], True, True, 0)
        compare_header.pack_end(self._button(self._t("Mit gewählten Optionen suchen", "Search selected options", "Hledat vybrané možnosti"), self._search_selected_model_options, "primary-button", "system-search-symbolic"), False, False, 0)
        compare_outer.pack_start(compare_header, False, False, 0)
        compare_scroll = Gtk.ScrolledWindow()
        compare_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        compare_scroll.set_min_content_height(340)
        self._build_refs["compare_box"] = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        compare_scroll.add(self._build_refs["compare_box"])
        compare_outer.pack_start(compare_scroll, True, True, 0)
        outer.pack_start(compare_frame, False, False, 4)

        result_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        result_header.pack_start(self._label(self._t("Modellvorschläge", "Model suggestions", "Návrhy modelů"), "section-title"), False, False, 0)
        self._build_refs["model_result_count"] = self._label(self._t("Datenbank wird geladen …", "Loading database …", "Načítání databáze …"), "muted")
        result_header.pack_start(self._build_refs["model_result_count"], True, True, 0)
        outer.pack_start(result_header, False, False, 8)

        lower = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        lower.set_position(245)
        lower.set_size_request(-1, 390)
        outer.pack_start(lower, True, True, 0)
        store = Gtk.ListStore(str, str, str, str, str, str, str, str, object)
        self._build_refs["model_store"] = store
        tree = Gtk.TreeView(model=store)
        tree.set_headers_clickable(True)
        tree.set_grid_lines(Gtk.TreeViewGridLines.BOTH)
        tree.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
        tree.get_selection().connect("changed", self._model_selection_changed)
        tree.connect("button-press-event", self._model_tree_clicked)
        columns = (
            ("%", 0, 58),
            (self._t("Basis-ID", "Base ID", "Základní ID"), 1, 105),
            (self._t("Refurbished", "Refurbished", "Repasované"), 2, 110),
            (self._t("Hersteller", "Manufacturer", "Výrobce"), 3, 110),
            ("CPU", 4, 210),
            ("RAM", 5, 70),
            (self._t("Speicher", "Storage", "Úložiště"), 6, 170),
            (self._t("Anzeige", "Display", "Displej"), 7, 170),
        )
        for title, index, width in columns:
            renderer = Gtk.CellRendererText()
            renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
            column = Gtk.TreeViewColumn(title, renderer, text=index)
            column.set_min_width(width)
            column.set_resizable(True)
            column.set_sort_column_id(index)
            tree.append_column(column)
            if index == 0:
                self._build_refs["model_score_column"] = column
        model_scroll = Gtk.ScrolledWindow()
        model_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        model_scroll.add(tree)
        lower.pack1(model_scroll, True, False)
        self._build_refs["model_tree"] = tree

        self._build_refs["model_detail"] = Gtk.TextView()
        self._build_refs["model_detail"].set_editable(False)
        self._build_refs["model_detail"].set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        detail_scroll = Gtk.ScrolledWindow()
        detail_scroll.set_min_content_height(120)
        detail_scroll.add(self._build_refs["model_detail"])
        lower.pack2(detail_scroll, True, False)
        return page

    def _model_item_value(self, item: dict[str, object], key: str) -> str:
        if key == "ram":
            return _clean(self.core.model_ram_summary(item))
        if key == "storage":
            return _clean(self.core.model_storage_summary(item))
        if key == "display":
            return _clean(self.core.model_display_summary(item))
        if key == "notebook":
            return _clean(self.core.model_notebook_summary(item))
        if key == "condition":
            return _clean(self.core.model_condition_summary(item))
        aliases = {
            "os": ("operating_system", "os"),
            "software": ("software",),
            "vendor": ("vendor", "manufacturer"),
            "cpu": ("cpu",),
        }
        for alias in aliases.get(key, (key,)):
            value = str(item.get(alias) or "").strip()
            if value:
                return value
        return "–"

    def _model_relation_values(self, item: dict[str, object], selected_ids: set[str] | None = None) -> tuple[str, str]:
        model_id = _clean(item.get("model_id"))
        base_ids, refurbished_ids = self._model_relation_map.get(model_id, ([], []))
        selected_ids = selected_ids or set()

        def marked(values: list[str]) -> str:
            return ", ".join(f"{value} ★" if value in selected_ids else value for value in values)

        if self.core.model_is_refurbished(item):
            base_text = marked(base_ids[:2]) or "–"
            refurbished_text = marked([model_id])
        else:
            base_text = marked([model_id])
            refurbished_text = marked(refurbished_ids[:3]) or "–"
        return base_text, refurbished_text

    @staticmethod
    def _model_family_tokens_match(first: str, second: str) -> bool:
        first = str(first or "").strip().casefold()
        second = str(second or "").strip().casefold()
        if not first or not second:
            return False
        if first == second:
            return True
        common = 0
        for left, right in zip(first, second):
            if left != right:
                break
            common += 1
        return common >= 6 and any(character.isdigit() for character in first[:common])

    def _model_belongs_to_current_family(self, item: dict[str, object]) -> bool:
        if not self.snapshot:
            return False
        snapshot_vendor = self.core.normalize_generic_token(
            str(self.snapshot.get("vendor_short") or self.snapshot.get("vendor") or "")
        )
        item_vendor = self.core.normalize_generic_token(str(item.get("vendor") or ""))
        if not snapshot_vendor or snapshot_vendor != item_vendor:
            return False

        snapshot_products = self.core.snapshot_product_numbers(self.snapshot)
        item_products = self.core.row_product_numbers(item)
        if snapshot_products and item_products:
            return any(
                self._model_family_tokens_match(snapshot_product, item_product)
                for snapshot_product in snapshot_products
                for item_product in item_products
            )

        snapshot_cpu = self.core.normalize_cpu_token(
            str(self.snapshot.get("cpu_short") or self.snapshot.get("cpu") or "")
        )
        item_cpu = self.core.normalize_cpu_token(str(item.get("cpu") or ""))
        if not snapshot_cpu or snapshot_cpu != item_cpu:
            return False
        snapshot_inches = self.core.display_inches_number(self.snapshot.get("display_inches"))
        item_inches = self.core.display_inches_number(item.get("inch"))
        return snapshot_inches is None or item_inches is None or self.core.compare_inches(snapshot_inches, item_inches)

    def _current_family_models(self) -> list[dict[str, object]]:
        hardware_matches = [
            result["item"]
            for result in self.match_results
            if isinstance(result.get("item"), dict)
        ]
        family_matches = [item for item in self.models if self._model_belongs_to_current_family(item)]
        combined: list[dict[str, object]] = []
        combined_ids: set[str] = set()
        for item in hardware_matches + family_matches:
            model_id = str(item.get("model_id") or "")
            if model_id and model_id not in combined_ids:
                combined_ids.add(model_id)
                combined.append(item)
        if combined:
            compact: list[dict[str, object]] = []
            for item in combined:
                model_id = str(item.get("model_id") or "")
                base_ids, _refurbished_ids = self._model_relation_map.get(model_id, ([], []))
                if self.core.model_is_refurbished(item) and any(base_id in combined_ids for base_id in base_ids):
                    continue
                compact.append(item)
            return compact
        return []

    def _refresh_model_table(self) -> None:
        if not self.models:
            self._populate_model_results([])
            self._render_model_comparison()
            return
        query = self._build_refs["model_search"].get_text().strip()
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        if query:
            # An explicit search is deliberately unrestricted: it must also allow
            # comparing unrelated database models with the current device.
            items = self.core.find_model_db_items(query, limit=250, entries=self.models)
        elif use_device:
            items = self._current_family_models()
        else:
            # With the current device disabled the ModelFinder remains a free,
            # independent database comparison tool.
            items = self.models
        results = [(self._model_display_score(item), item) for item in items]
        if self._model_has_score_reference():
            results.sort(key=lambda pair: (-pair[0], self.core.model_value_int(pair[1].get("model_id"))))
        self._populate_model_results(results[:250])
        self._render_model_comparison()

    def _model_has_score_reference(self) -> bool:
        return bool(
            self._build_refs.get("model_use_device")
            and self._build_refs["model_use_device"].get_active()
            and self.snapshot
        ) or bool(self._model_selected_ids)

    def _model_display_score(self, item: dict[str, object]) -> int:
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        if use_device:
            model_id = str(item.get("model_id") or "")
            for result in self.match_results:
                result_item = result.get("item") if isinstance(result.get("item"), dict) else {}
                if str(result_item.get("model_id") or "") == model_id:
                    return int(result.get("score") or 0)
            result = self.core.score_snapshot_model_for_finder(self.snapshot, item)
            return int(result.get("score") or 0)
        selected = self._selected_model_items()
        if selected:
            return int(self.core.model_similarity_score(selected[0], item))
        return 0

    def _populate_model_results(self, results: list[tuple[int, dict[str, object]]]) -> None:
        store: Gtk.ListStore | None = self._build_refs.get("model_store")
        tree: Gtk.TreeView | None = self._build_refs.get("model_tree")
        if store is None or tree is None:
            return
        self._model_visible_results = [(score, item) for score, item in results if isinstance(item, dict)]
        self._model_selection_syncing = True
        try:
            store.clear()
            show_score = self._model_has_score_reference()
            score_column: Gtk.TreeViewColumn | None = self._build_refs.get("model_score_column")
            if score_column is not None:
                score_column.set_title(self._t("% Gerät", "% Device", "% Zařízení") if self._build_refs["model_use_device"].get_active() and self.snapshot else self._t("% Ähnl.", "% Similar", "% Podob."))
            selected_ids = set(self._model_selected_ids)
            selected_paths: list[Gtk.TreePath] = []
            for score, item in self._model_visible_results:
                model_id = _clean(item.get("model_id"))
                base_id, refurbished = self._model_relation_values(item, selected_ids)
                iterator = store.append([
                    f"{score}%" if show_score else "–",
                    base_id,
                    _short(refurbished, 28),
                    _short(self._model_item_value(item, "vendor"), 24),
                    _short(self._model_item_value(item, "cpu"), 42),
                    _short(item.get("ram_total") or item.get("total_ram_gb") or self._model_item_value(item, "ram"), 18),
                    _short(self._model_item_value(item, "storage"), 38),
                    _short(self._model_item_value(item, "display"), 38),
                    item,
                ])
                if model_id in selected_ids:
                    selected_paths.append(store.get_path(iterator))
            selection = tree.get_selection()
            selection.unselect_all()
            for path in selected_paths:
                selection.select_path(path)
        finally:
            self._model_selection_syncing = False
        count = len(self._model_visible_results)
        family_mode = bool(
            self._build_refs["model_use_device"].get_active()
            and self.snapshot
            and not self._build_refs["model_search"].get_text().strip()
        )
        self._build_refs["model_result_count"].set_text(
            self._t(
                f"{count} Geräte-/Familienvorschläge · Anklicken = direkt vergleichen" if family_mode else f"{count} Vorschläge · Anklicken = direkt vergleichen",
                f"{count} device/family suggestions · click to compare" if family_mode else f"{count} suggestions · click to compare",
                f"{count} návrhů zařízení/řady · kliknutím porovnáte" if family_mode else f"{count} návrhů · kliknutím porovnáte",
            )
        )
        self._update_model_selection_count()

    def _model_search_changed(self, _entry) -> None:
        query = self._build_refs["model_search"].get_text().strip()
        exact_ids = re.findall(r"\b\d{4,6}\b", query)
        if exact_ids:
            available = {str(item.get("model_id") or ""): item for item in self.models}
            maximum = self._model_selection_limit()
            selected: list[str] = []
            for model_id in exact_ids:
                if model_id in available and model_id not in selected:
                    selected.append(model_id)
            self._model_selected_ids = selected[:maximum]
        self._refresh_model_table()

    def _model_device_toggled(self, _button) -> None:
        maximum = self._model_selection_limit()
        self._model_selected_ids = self._model_selected_ids[:maximum]
        self._refresh_model_table()

    def _model_selection_limit(self) -> int:
        use_device = bool(
            self._build_refs.get("model_use_device")
            and self._build_refs["model_use_device"].get_active()
            and self.snapshot
        )
        return 3 if use_device else 4

    def _update_model_selection_count(self) -> None:
        maximum = self._model_selection_limit()
        count = len(self._model_selected_ids)
        self._build_refs["model_selection_count"].set_text(
            self._t(f"{count}/{maximum} gewählt", f"{count}/{maximum} selected", f"Vybráno {count}/{maximum}")
        )

    def _selected_model_rows(self) -> list[tuple[int, dict[str, object]]]:
        return [(self._model_display_score(item), item) for item in self._selected_model_items()]

    def _selected_model_items(self) -> list[dict[str, object]]:
        by_id = {str(item.get("model_id") or ""): item for item in self.models}
        return [by_id[model_id] for model_id in self._model_selected_ids if model_id in by_id]

    def _model_tree_clicked(self, tree: Gtk.TreeView, event) -> bool:
        if event.button != 1:
            return False
        path_info = tree.get_path_at_pos(int(event.x), int(event.y))
        if not path_info:
            return False
        path, column, cell_x, _cell_y = path_info
        model = tree.get_model()
        iterator = model.get_iter(path) if model is not None else None
        item = model.get_value(iterator, 8) if model is not None and iterator is not None else None
        column_index = tree.get_columns().index(column) if column in tree.get_columns() else -1
        if isinstance(item, dict) and column_index in {1, 2}:
            model_id = _clean(item.get("model_id"))
            base_ids, refurbished_ids = self._model_relation_map.get(model_id, ([], []))
            if column_index == 1:
                relation_ids = base_ids[:2] if self.core.model_is_refurbished(item) else [model_id]
            else:
                relation_ids = [model_id] if self.core.model_is_refurbished(item) else refurbished_ids[:3]
            if relation_ids:
                slot = min(len(relation_ids) - 1, max(0, int(max(0, cell_x) * len(relation_ids) / max(1, column.get_width()))))
                target_id = relation_ids[slot]
                if target_id in self._model_selected_ids:
                    self._model_selected_ids = [value for value in self._model_selected_ids if value != target_id]
                elif len(self._model_selected_ids) < self._model_selection_limit():
                    self._model_selected_ids.append(target_id)
                else:
                    self.set_status(
                        self._t(
                            "Der Vergleich ist voll. Bitte zuerst ein Modell abwählen.",
                            "The comparison is full. Deselect a model first.",
                            "Porovnání je plné. Nejprve zrušte výběr jednoho modelu.",
                        ),
                        "warn",
                    )
                    return True
                self._refresh_model_table()
                return True
        selection = tree.get_selection()
        if selection.path_is_selected(path):
            selection.unselect_path(path)
            return True
        if len(self._model_selected_ids) >= self._model_selection_limit():
            self.set_status(
                self._t(
                    "Der Vergleich ist voll. Bitte zuerst ein Modell abwählen.",
                    "The comparison is full. Deselect a model first.",
                    "Porovnání je plné. Nejprve zrušte výběr jednoho modelu.",
                ),
                "warn",
            )
            return True
        selection.select_path(path)
        return True

    def _model_selection_changed(self, _selection) -> None:
        if self._model_selection_syncing:
            return
        model, paths = _selection.get_selected_rows()
        visible_ids = {
            str(item.get("model_id") or "")
            for _score, item in self._model_visible_results
            if isinstance(item, dict)
        }
        hidden_ids = [model_id for model_id in self._model_selected_ids if model_id not in visible_ids]
        visible_selected: list[str] = []
        for path in paths:
            row = model[model.get_iter(path)]
            item = row[8]
            if isinstance(item, dict):
                model_id = str(item.get("model_id") or "").strip()
                if model_id and model_id not in visible_selected:
                    visible_selected.append(model_id)
        self._model_selected_ids = (hidden_ids + visible_selected)[: self._model_selection_limit()]
        self._refresh_model_selection_markers()
        self._update_model_selection_count()
        self._render_model_comparison()
        selected = self._selected_model_rows()
        if not selected:
            self._build_refs["model_detail"].get_buffer().set_text("")
            return
        score, item = selected[-1]
        try:
            detail = self.core.format_model_database_detail(item, self.language, percent=score)
        except Exception:
            detail = "\n".join(f"{key}: {value}" for key, value in item.items())
        self._build_refs["model_detail"].get_buffer().set_text(detail)

    def _refresh_model_selection_markers(self) -> None:
        store: Gtk.ListStore | None = self._build_refs.get("model_store")
        if store is None:
            return
        selected_ids = set(self._model_selected_ids)
        iterator = store.get_iter_first()
        while iterator is not None:
            item = store.get_value(iterator, 8)
            if isinstance(item, dict):
                base_id, refurbished = self._model_relation_values(item, selected_ids)
                store.set_value(iterator, 1, base_id)
                store.set_value(iterator, 2, _short(refurbished, 28))
            iterator = store.iter_next(iterator)

    def _clear_model_selection(self, _button=None) -> None:
        self._model_selected_ids = []
        tree: Gtk.TreeView | None = self._build_refs.get("model_tree")
        if tree is not None:
            self._model_selection_syncing = True
            try:
                tree.get_selection().unselect_all()
            finally:
                self._model_selection_syncing = False
        self._refresh_model_selection_markers()
        self._update_model_selection_count()
        self._render_model_comparison()
        self._build_refs["model_detail"].get_buffer().set_text("")

    def _remove_model_from_comparison(self, model_id: str) -> None:
        self._model_selected_ids = [value for value in self._model_selected_ids if value != model_id]
        self._refresh_model_table()

    def _compare_selected_models(self, _button=None) -> None:
        self._render_model_comparison()

    def _render_model_comparison(self) -> None:
        box: Gtk.Box = self._build_refs["compare_box"]
        saved_states = {
            (str(binding.get("source_id") or ""), str(binding.get("key") or "")): bool(binding["check"].get_active())
            for binding in self._model_option_bindings
            if isinstance(binding.get("check"), Gtk.CheckButton)
        }
        self._model_option_bindings = []
        for child in box.get_children():
            box.remove(child)
        selected = self._selected_model_items()
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        sources: list[tuple[str, dict[str, object] | None]] = []
        if use_device:
            sources.append(("device", None))
        sources.extend((str(item.get("model_id") or ""), item) for item in selected)

        if use_device and selected:
            scores = [self._model_display_score(item) for item in selected]
            title = f"{self._t('Modellvergleich mit aktuellem Gerät', 'Model comparison with current device', 'Porovnání modelů s aktuálním zařízením')} · {self._t('Bester Match', 'Best match', 'Nejlepší shoda')}: {max(scores)}%"
        elif use_device:
            title = self._t("Modellvergleich mit aktuellem Gerät", "Model comparison with current device", "Porovnání modelů s aktuálním zařízením")
        elif len(selected) > 1:
            scores = [int(self.core.model_similarity_score(selected[0], item)) for item in selected[1:]]
            title = f"{self._t('Modellvergleich', 'Model comparison', 'Porovnání modelů')} · Match: {min(scores)}%"
        elif selected:
            title = self._t("Vergleichsmodell gewählt – weitere Vorschläge anklicken", "Comparison model selected – click more suggestions", "Vybrán srovnávací model – klikněte na další návrhy")
        else:
            title = self._t("Modelle aus der Vorschlagsliste auswählen", "Select models from the suggestion list", "Vyberte modely ze seznamu návrhů")
        self._build_refs["model_compare_title"].set_text(title)

        if not sources:
            box.pack_start(self._label(self._t("Aktuelles Gerät einschalten oder unten Modelle auswählen.", "Enable the current device or select models below.", "Zapněte aktuální zařízení nebo níže vyberte modely."), "muted", wrap=True), False, False, 12)
            box.show_all()
            return

        grid = Gtk.Grid(column_spacing=2, row_spacing=2)
        grid.attach(self._label("#", "comparison-header", xalign=0.5), 0, 0, 1, 1)
        grid.attach(self._label(self._t("Kategorie", "Category", "Kategorie"), "comparison-header"), 1, 0, 1, 1)
        snapshot_rows = self.core.snapshot_compare_entries(self.snapshot, self.language)
        categories = [(key, label) for key, label, _value, _available in snapshot_rows]
        if not use_device and selected:
            categories = [(key, label) for key, label, _value in self.core.model_compare_entries(selected[0], self.language)]
        snapshot_map = {key: (value, available) for key, _label, value, available in snapshot_rows}
        model_maps = {
            str(item.get("model_id") or ""): {key: value for key, _label, value in self.core.model_compare_entries(item, self.language)}
            for item in selected
        }
        base_model = selected[0] if selected else None

        for column, (source_id, item) in enumerate(sources, start=2):
            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            header.get_style_context().add_class("comparison-header")
            if source_id == "device":
                header_text = self._t("Aktuelles Gerät", "Current device", "Aktuální zařízení")
            elif use_device and item:
                header_text = f"{self._t('Modell', 'Model', 'Model')} {source_id} ★ · {self._model_display_score(item)}%"
            elif item is base_model:
                header_text = f"{self._t('Basis', 'Base', 'Základ')} · {self._t('Modell', 'Model', 'Model')} {source_id} ★"
            else:
                header_text = f"{self._t('Modell', 'Model', 'Model')} {source_id} ★ · {int(self.core.model_similarity_score(base_model or item, item))}%"
            header.pack_start(self._label(header_text, xalign=0.5), True, True, 0)
            if source_id != "device":
                remove_button = Gtk.Button(label="×")
                remove_button.set_relief(Gtk.ReliefStyle.NONE)
                remove_button.set_tooltip_text(self._t("Aus Vergleich entfernen", "Remove from comparison", "Odebrat z porovnání"))
                remove_button.connect("clicked", lambda _b, model_id=source_id: self._remove_model_from_comparison(model_id))
                header.pack_end(remove_button, False, False, 0)
            header.set_size_request(285, 42)
            grid.attach(header, column, 0, 1, 1)

        for row_index, (key, category_title) in enumerate(categories, start=1):
            grid.attach(self._label(str(row_index), "card-subtitle", xalign=0.5), 0, row_index, 1, 1)
            category = self._label(category_title, "card-title")
            category.set_size_request(145, 38)
            grid.attach(category, 1, row_index, 1, 1)
            for column, (source_id, item) in enumerate(sources, start=2):
                if source_id == "device":
                    value, available = snapshot_map.get(key, ("–", False))
                    same: bool | None = None
                    css = "reference-cell" if available else "unavailable-cell"
                else:
                    value = model_maps.get(source_id, {}).get(key, "–")
                    available = value not in {"", "–", "-"}
                    if use_device and item:
                        same = self.core.model_matches_snapshot_option(item, self.snapshot, key)
                    elif item is base_model:
                        same = None
                    elif item and base_model:
                        same = self.core.model_option_matches(item, base_model, key)
                    else:
                        same = None
                    if not available:
                        css = "unavailable-cell"
                    elif item is base_model and not use_device:
                        css = "reference-cell"
                    elif same is True:
                        css = "match-cell"
                    elif same is False:
                        css = "mismatch-cell"
                    else:
                        css = "neutral-cell"
                state_key = (source_id, key)
                default_active = bool(available and (source_id == "device" or same is True or (item is base_model and not use_device)))
                active = saved_states.get(state_key, default_active)
                check = Gtk.CheckButton(label=str(value))
                check.set_active(active)
                check.set_sensitive(bool(available))
                check.set_size_request(285, 38)
                check.get_style_context().add_class(css)
                child = check.get_child()
                if isinstance(child, Gtk.Label):
                    child.set_line_wrap(True)
                    child.set_max_width_chars(42)
                grid.attach(check, column, row_index, 1, 1)
                self._model_option_bindings.append({
                    "check": check,
                    "key": key,
                    "source_id": source_id,
                    "source": "device" if source_id == "device" else "model",
                    "item": item,
                    "available": available,
                })
        box.pack_start(grid, False, False, 0)
        box.show_all()

    def _search_selected_model_options(self, _button=None) -> None:
        filters: dict[str, list[dict[str, object]]] = {}
        for binding in self._model_option_bindings:
            check = binding.get("check")
            if not isinstance(check, Gtk.CheckButton) or not check.get_active() or not binding.get("available"):
                continue
            filters.setdefault(str(binding.get("key") or ""), []).append(binding)
        filters.pop("", None)
        if not filters:
            self.set_status(self._t("Bitte mindestens eine Vergleichsoption markieren.", "Select at least one comparison option.", "Vyberte alespoň jednu možnost porovnání."), "warn")
            return
        matched: list[dict[str, object]] = []
        for candidate in self.models:
            matches_all = True
            for key, bindings in filters.items():
                category_match = False
                for binding in bindings:
                    if binding.get("source") == "device":
                        category_match = self.core.model_matches_snapshot_option(candidate, self.snapshot, key) is True
                    else:
                        source_item = binding.get("item")
                        category_match = isinstance(source_item, dict) and self.core.model_option_matches(candidate, source_item, key)
                    if category_match:
                        break
                if not category_match:
                    matches_all = False
                    break
            if matches_all:
                matched.append(candidate)
        results = [(self._model_display_score(item), item) for item in matched]
        if self._model_has_score_reference():
            results.sort(key=lambda pair: pair[0], reverse=True)
        self._populate_model_results(results[:250])
        self.set_status(
            self._t(f"{len(matched)} Modelle passen zu den gewählten Optionen.", f"{len(matched)} models match the selected options.", f"Vybraným možnostem odpovídá {len(matched)} modelů."),
            "good" if matched else "warn",
        )

    # ---------- battery ----------

    def _build_battery_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Akku-Diagnose", "Battery diagnostics", "Diagnostika baterie"),
            self._t("Kapazität, Gesundheit und echte Lade-/Entladefunktion getrennt bewerten.", "Evaluate capacity, health and actual charge/discharge function separately.", "Samostatně vyhodnoťte kapacitu, zdraví a skutečné nabíjení/vybíjení."),
        )
        flow = self._flow()
        outer.pack_start(flow, False, False, 12)
        for key, title, icon in (
            ("level", self._t("Akkustand", "Battery level", "Stav baterie"), "battery-symbolic"),
            ("health", self._t("Kapazitätsgesundheit", "Capacity health", "Zdraví kapacity"), "emblem-ok-symbolic"),
            ("power", self._t("Leistung", "Power", "Výkon"), "preferences-system-power-symbolic"),
            ("cycles", self._t("Ladezyklen", "Charge cycles", "Nabíjecí cykly"), "view-refresh-symbolic"),
        ):
            card, value, subtitle = self._card(title, icon=icon)
            flow.add(card)
            self._build_refs[f"battery_{key}"] = value
            self._build_refs[f"battery_{key}_sub"] = subtitle

        bars = Gtk.Frame()
        bars.set_shadow_type(Gtk.ShadowType.NONE)
        bars.get_style_context().add_class("card")
        bars_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        bars.add(bars_box)
        bars_box.pack_start(self._label(self._t("Ladezustand", "Charge level", "Úroveň nabití"), "card-title"), False, False, 0)
        self._build_refs["battery_levelbar"] = Gtk.LevelBar.new_for_interval(0, 100)
        bars_box.pack_start(self._build_refs["battery_levelbar"], False, False, 0)
        bars_box.pack_start(self._label(self._t("Kapazitätsgesundheit", "Capacity health", "Zdraví kapacity"), "card-title"), False, False, 0)
        self._build_refs["battery_healthbar"] = Gtk.LevelBar.new_for_interval(0, 100)
        bars_box.pack_start(self._build_refs["battery_healthbar"], False, False, 0)
        outer.pack_start(bars, False, False, 6)

        controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        controls.pack_start(self._button(self._t("Entladen starten", "Start discharge", "Spustit vybíjení"), lambda _b: self._start_battery_test("discharge"), "primary-button", "battery-caution-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Laden starten", "Start charge", "Spustit nabíjení"), lambda _b: self._start_battery_test("charge"), "primary-button", "battery-good-charging-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Stop + Report", "Stop + report", "Stop + report"), self._stop_battery_test, "secondary-button", "media-playback-stop-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Sofort-Report", "Instant report", "Okamžitý report"), self._instant_battery_report, "secondary-button", "document-save-symbolic"), False, False, 0)
        controls.pack_end(self._button(self._t("Reports anzeigen", "Show reports", "Zobrazit reporty"), lambda _b: self.show_page("reports"), "secondary-button", "folder-documents-symbolic"), False, False, 0)
        outer.pack_start(controls, False, False, 8)

        history = Gtk.Frame()
        history.set_shadow_type(Gtk.ShadowType.NONE)
        history.get_style_context().add_class("card")
        history_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        history.add(history_box)
        history_box.pack_start(self._label(self._t("Akku-Verlauf", "Battery history", "Průběh baterie"), "section-title"), False, False, 0)
        canvas = Gtk.DrawingArea()
        canvas.set_size_request(-1, 190)
        canvas.connect("draw", self._draw_battery_history)
        self._build_refs["battery_canvas"] = canvas
        history_box.pack_start(canvas, True, True, 0)
        self._build_refs["battery_details"] = self._label("", "muted", wrap=True)
        history_box.pack_start(self._build_refs["battery_details"], False, False, 0)
        outer.pack_start(history, False, False, 8)

        return page

    def _battery_refresh_tick(self) -> bool:
        if self.window is None:
            return False
        try:
            details = self.core.read_battery_details()
            self._update_battery_ui(details)
        except Exception:
            pass
        return True

    def _update_battery_ui(self, details: dict[str, object]) -> None:
        if not details.get("present"):
            text = self._t("Kein Akku erkannt", "No battery detected", "Baterie nebyla nalezena")
            for key in ("level", "health", "power", "cycles"):
                if f"battery_{key}" in self._build_refs:
                    self._build_refs[f"battery_{key}"].set_text(text if key == "level" else "–")
            self._build_refs["battery_chip"].set_text(self._t("Kein Akku", "No battery", "Bez baterie"))
            return
        capacity = details.get("capacity_percent")
        health = self.core.battery_health_assessment(details, self.language)
        function = self.core.battery_function_assessment(self._battery_mode, self._battery_samples, self.language)
        try:
            level = max(0.0, min(100.0, float(capacity)))
        except (TypeError, ValueError):
            level = 0.0
        try:
            health_level = max(0.0, min(100.0, float(health.get("raw_percent")))) if health.get("reliable") else 0.0
        except (TypeError, ValueError):
            health_level = 0.0
        self._build_refs["battery_levelbar"].set_value(level)
        self._build_refs["battery_healthbar"].set_value(health_level)
        status = self.core.battery_status_label(details.get("status"), self.language)
        self._build_refs["battery_level"].set_text(f"{_clean(capacity)} %")
        self._build_refs["battery_level_sub"].set_text(status)
        self._build_refs["battery_health"].set_text(str(health.get("display") or "–"))
        self._build_refs["battery_health_sub"].set_text(str(health.get("note") or ""))
        power = details.get("power_w")
        self._build_refs["battery_power"].set_text(f"{float(power):.2f} W" if isinstance(power, (float, int)) else "–")
        self._build_refs["battery_power_sub"].set_text(self.core.battery_source_text(details.get("status"), self.language))
        self._build_refs["battery_cycles"].set_text(_clean(details.get("cycle_count")))
        self._build_refs["battery_cycles_sub"].set_text(self._t("Ladezyklen", "Charge cycles", "Nabíjecí cykly"))
        self._build_refs["battery_chip"].set_text(f"{self._t('Akku', 'Battery', 'Baterie')}: {_clean(capacity)}%")
        detail_lines = [
            f"{self._t('Status', 'Status', 'Stav')}: {status}",
            f"{self._t('Funktionsprüfung', 'Functional test', 'Funkční test')}: {function.get('display')} · {function.get('note')}",
            f"{self._t('Spannung', 'Voltage', 'Napětí')}: {_clean(details.get('voltage_v'))} V",
            f"{self._t('Kapazität', 'Capacity', 'Kapacita')}: {self.core.battery_capacity_text(details.get('energy_now'), details.get('capacity_unit'), self.language)} / {self.core.battery_capacity_text(details.get('energy_full'), details.get('capacity_unit'), self.language)}",
        ]
        self._build_refs["battery_details"].set_text("   ·   ".join(detail_lines))
        self._build_refs["battery_canvas"].queue_draw()

    def _draw_battery_history(self, widget: Gtk.DrawingArea, context) -> bool:
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        context.set_source_rgb(0.055, 0.082, 0.12)
        context.paint()
        margin = 24
        context.set_line_width(1)
        for percent in (0, 25, 50, 75, 100):
            y = height - margin - (height - margin * 2) * percent / 100
            context.set_source_rgba(0.35, 0.43, 0.55, 0.32)
            context.move_to(margin, y)
            context.line_to(width - margin, y)
            context.stroke()
        points = []
        for sample in self._battery_samples:
            try:
                points.append(max(0.0, min(100.0, float(sample.get("capacity_percent")))))
            except (TypeError, ValueError):
                continue
        if not points:
            return False
        context.set_source_rgb(0.22, 0.78, 0.76)
        context.set_line_width(3)
        for index, value in enumerate(points):
            x = margin + (width - margin * 2) * (index / max(1, len(points) - 1))
            y = height - margin - (height - margin * 2) * value / 100
            if index == 0:
                context.move_to(x, y)
            else:
                context.line_to(x, y)
        context.stroke()
        return False

    def _start_battery_test(self, mode: str) -> None:
        if self._battery_mode:
            self.set_status(self._t("Ein Akku-Test läuft bereits.", "A battery test is already running.", "Test baterie již probíhá."), "warn")
            return
        details = self.core.read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Kein Akku erkannt.", "No battery detected.", "Baterie nebyla nalezena."), "bad")
            return
        try:
            report_dir = self.core.get_battery_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            basename = self.core.battery_report_basename(self.snapshot or None, mode)
            self._battery_csv_path = report_dir / f"{basename}.csv"
            self.core.append_battery_csv(self._battery_csv_path, mode, details, include_header=True)
        except OSError as exc:
            self.set_status(f"{self._t('Akku-Test konnte nicht gestartet werden', 'Battery test could not be started', 'Test baterie nelze spustit')}: {exc}", "bad")
            return
        self._battery_mode = mode
        self._battery_samples = [details]
        if self._battery_timer_id is not None:
            GLib.source_remove(self._battery_timer_id)
        self._battery_timer_id = GLib.timeout_add_seconds(60, self._battery_sample_tick)
        self.set_status(self._t("Akku-Test gestartet; Messpunkt jede Minute.", "Battery test started; one sample per minute.", "Test baterie spuštěn; jedno měření za minutu."), "good")

    def _battery_sample_tick(self) -> bool:
        if not self._battery_mode:
            return False
        details = self.core.read_battery_details()
        self._battery_samples.append(details)
        if self._battery_csv_path is not None:
            try:
                self.core.append_battery_csv(self._battery_csv_path, self._battery_mode, details)
            except OSError:
                pass
        self._update_battery_ui(details)
        return True

    def _stop_battery_test(self, _button=None) -> None:
        if not self._battery_mode:
            self.set_status(self._t("Kein Akku-Test aktiv.", "No battery test active.", "Není aktivní žádný test baterie."), "warn")
            return
        self._battery_sample_tick()
        mode = self._battery_mode
        samples = list(self._battery_samples)
        csv_path = self._battery_csv_path
        self._battery_mode = ""
        if self._battery_timer_id is not None:
            GLib.source_remove(self._battery_timer_id)
            self._battery_timer_id = None
        self._write_battery_report(mode, samples, csv_path)

    def _instant_battery_report(self, _button=None) -> None:
        details = self.core.read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Kein Akku erkannt.", "No battery detected.", "Baterie nebyla nalezena."), "bad")
            return
        self._write_battery_report("instant", [details], None)

    def _write_battery_report(self, mode: str, samples: list[dict[str, object]], csv_path: pathlib.Path | None) -> None:
        snapshot = dict(self.snapshot)

        def worker():
            report_dir = self.core.get_battery_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            basename = self.core.battery_report_basename(snapshot or None, mode)
            local_csv = csv_path or report_dir / f"{basename}.csv"
            if csv_path is None:
                self.core.append_battery_csv(local_csv, mode, samples[-1], include_header=True)
            txt_path = report_dir / f"{basename}.txt"
            html_path = report_dir / f"{basename}.html"
            report = self.core.build_battery_test_report(mode, samples, snapshot, local_csv, self.language)
            html_report = self.core.build_battery_test_html_report(mode, samples, snapshot, local_csv, txt_path, self.language)
            self.core.write_text_durable(txt_path, report)
            self.core.write_text_durable(html_path, html_report)
            return html_path

        self.run_async("battery-report", worker, lambda path: self.set_status(f"{self._t('Akku-Report gespeichert', 'Battery report saved', 'Report baterie uložen')}: {path}", "good"))

    # ---------- Wi-Fi ----------

    def _open_settings_tool(self, page: str, popover: Gtk.Popover | None = None) -> None:
        if popover is not None:
            popover.popdown()
        self.show_page(page)

    def _set_network_chip(self, text: str, state: str) -> None:
        label: Gtk.Label | None = self._build_refs.get("network_chip")
        button: Gtk.MenuButton | None = self._build_refs.get("network_chip_button")
        if label is not None:
            label.set_text(text)
        if button is not None:
            self._set_chip_state(button, state)

    def _current_wifi_connection(self) -> tuple[str, str]:
        try:
            for iface in self.core.list_network_interfaces(wifi=True):
                ssid = str(self.core.current_wifi_ssid(iface) or "").strip()
                if ssid and self.core.interface_has_ipv4(iface):
                    self._wifi_connected_ssid = ssid
                    return iface, ssid
        except Exception:
            pass
        return "", ""

    def _wifi_quick_toggled(self, button: Gtk.MenuButton) -> None:
        if button.get_active():
            self._refresh_wifi_quick_menu(force=True)

    def _scan_wifi_live_preserving_connection(self) -> tuple[list[dict[str, str]], str]:
        """Scan visible WLANs without resetting an existing association."""
        if not sys.platform.startswith("linux"):
            return [], "WLAN-Scan nur unter Linux verfügbar"
        try:
            ifaces = self.core.list_network_interfaces(wifi=True)
            iw = self.core.find_executable("iw")
            iwlist = self.core.find_executable("iwlist")
            ip_cmd = self.core.find_executable("ip")
        except Exception as exc:
            return [], str(exc)
        if not ifaces:
            return [], self._t("Kein WLAN-Adapter gefunden", "No Wi-Fi adapter found", "Nebyl nalezen adaptér Wi-Fi")

        debug_lines: list[str] = []
        try:
            self.core.unblock_wifi_radios(debug_lines)
            self.core.set_wifi_country(debug_lines)
        except Exception:
            pass
        found: dict[str, dict[str, str]] = {}
        for iface in ifaces:
            if ip_cmd:
                self.core.run_quiet_timeout([ip_cmd, "link", "set", iface, "up"], timeout=3)
            networks: list[dict[str, str]] = []
            if iw:
                output = self.core.run_debug_command([iw, "dev", iface, "scan"], timeout=12)
                networks = self.core.parse_iw_scan(output, iface)
                if not networks:
                    cached = self.core.run_debug_command([iw, "dev", iface, "scan", "dump"], timeout=4)
                    networks = self.core.parse_iw_scan(cached, iface)
            if not networks and iwlist:
                output = self.core.run_debug_command([iwlist, iface, "scan"], timeout=12)
                networks = self.core.parse_iwlist_scan(output, iface)
            for network in networks:
                ssid = str(network.get("ssid") or "").strip()
                if not ssid:
                    continue
                previous = found.get(ssid)
                if previous is None or self.core.wifi_signal_sort_value(network.get("signal", "")) > self.core.wifi_signal_sort_value(previous.get("signal", "")):
                    found[ssid] = network
        networks = sorted(found.values(), key=lambda item: self.core.wifi_signal_sort_value(item.get("signal", "")), reverse=True)
        return networks, self._t(
            f"{len(networks)} sichtbare WLAN-Netze",
            f"{len(networks)} visible Wi-Fi networks",
            f"Viditelné sítě Wi-Fi: {len(networks)}",
        ) if networks else self._t("Keine sichtbaren WLAN-Netze gefunden", "No visible Wi-Fi networks found", "Nebyly nalezeny žádné viditelné sítě Wi-Fi")

    def _refresh_wifi_quick_menu(self, force: bool = False) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("wifi_quick_list")
        status: Gtk.Label | None = self._build_refs.get("wifi_quick_status")
        task_name = "wifi-live-scan"
        if listbox is None or status is None or task_name in self._refresh_tasks:
            return
        if self._wifi_connection_busy:
            status.set_text(self._t("WLAN wird gerade verbunden …", "Wi-Fi is connecting …", "Wi-Fi se právě připojuje …"))
            return
        if self._wifi_quick_networks and not force:
            _iface, connected_ssid = self._current_wifi_connection()
            self._render_wifi_quick_rows(self._wifi_quick_networks, self.core.load_wifi_networks(), connected_ssid)
            return
        status.set_text(self._t("Live-Suche läuft …", "Live scan running …", "Probíhá živé hledání …"))
        if self._wifi_connected_ssid:
            try:
                saved_now = self.core.load_wifi_networks()
            except Exception:
                saved_now = []
            cached = list(self._wifi_quick_networks)
            if not any(str(item.get("ssid") or "") == self._wifi_connected_ssid for item in cached):
                cached.insert(0, {"ssid": self._wifi_connected_ssid, "signal": "–"})
            self._render_wifi_quick_rows(cached, saved_now, self._wifi_connected_ssid)
        else:
            self._clear_listbox(listbox)
            waiting = Gtk.ListBoxRow()
            waiting.add(self._label(self._t("Verfügbare WLANs werden gesucht …", "Searching for available Wi-Fi …", "Vyhledávání dostupných sítí Wi-Fi …"), "muted", wrap=True))
            listbox.add(waiting)
            listbox.show_all()
        self._refresh_tasks.add(task_name)

        def worker():
            iface, connected_ssid = self._current_wifi_connection()
            saved = self.core.load_wifi_networks()
            networks, message = self._scan_wifi_live_preserving_connection()
            return iface, connected_ssid, saved, networks, message

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            _iface, connected_ssid, saved, networks, message = result
            self._wifi_quick_networks = networks
            self._render_wifi_quick_rows(networks, saved, connected_ssid)
            status.set_text(message)

        self.run_async(task_name, worker, done)

    def _render_wifi_quick_rows(self, networks: list[dict[str, str]], saved: list[dict[str, str]], connected_ssid: str) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("wifi_quick_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        saved_by_ssid = {str(item.get("ssid") or ""): item for item in saved}
        visible = {str(item.get("ssid") or ""): dict(item) for item in networks if str(item.get("ssid") or "")}
        if connected_ssid and connected_ssid not in visible:
            visible[connected_ssid] = {"ssid": connected_ssid, "signal": "–"}
        ordered = sorted(
            visible.values(),
            key=lambda item: (
                str(item.get("ssid") or "") == connected_ssid,
                self.core.wifi_signal_sort_value(item.get("signal", "")),
            ),
            reverse=True,
        )
        if not ordered:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Keine WLAN-Netze sichtbar.", "No Wi-Fi networks visible.", "Nejsou viditelné žádné sítě Wi-Fi."), "muted", wrap=True))
            listbox.add(row)
        for network in ordered:
            ssid = str(network.get("ssid") or "")
            saved_profile = saved_by_ssid.get(ssid)
            if saved_profile:
                merged = dict(saved_profile)
                merged.update({key: value for key, value in network.items() if value})
            else:
                merged = network
            listbox.add(self._wifi_quick_row(merged, bool(saved_profile), ssid == connected_ssid))
        listbox.show_all()

    def _wifi_quick_row(self, network: dict[str, str], saved: bool, connected: bool) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.add(box)
        box.pack_start(self._icon("network-wireless-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(network.get("ssid")), "section-title"), False, False, 0)
        if connected:
            detail = self._t("Verbunden", "Connected", "Připojeno")
        else:
            security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security")) or self._t("Sicherheit unbekannt", "Security unknown", "Neznámé zabezpečení")
            signal = _clean(network.get("signal"), self._t("Signal unbekannt", "Signal unknown", "Signál neznámý"))
            detail = f"{security} · {signal}"
        if saved:
            detail += f" · {self._t('gespeichert', 'saved', 'uloženo')}"
        text.pack_start(self._label(detail, "good-text" if connected else "muted", wrap=True), False, False, 0)
        box.pack_start(text, True, True, 0)
        if not connected:
            box.pack_end(
                self._button(
                    self._t("Verbinden", "Connect", "Připojit"),
                    lambda _b, item=dict(network), is_saved=saved: self._connect_wifi(item, is_saved),
                    "primary-button",
                ),
                False,
                False,
                0,
            )
        return row

    def _start_wifi_autoconnect(self) -> bool:
        if self._wifi_autoconnect_started:
            return False
        self._wifi_autoconnect_started = True
        self._set_network_chip(self._t("WLAN verbindet …", "Connecting Wi-Fi …", "Připojování Wi-Fi …"), "warn")
        self._wifi_connection_busy = True

        def progress(state: str, message: str) -> None:
            GLib.idle_add(self._wifi_autoconnect_progress, state, message)

        def worker():
            try:
                saved = self.core.load_wifi_networks()
            except Exception:
                saved = []
            result = self.core.connect_temporary_network(
                progress,
                [],
                networks_override=saved,
                require_internet=True,
                allow_active=True,
                allow_lan=False,
                cleanup_success=False,
            )
            if not result[0]:
                try:
                    result[2]()
                except Exception:
                    pass
            _iface, connected_ssid = self._current_wifi_connection() if result[0] else ("", "")
            return result[0], result[1], connected_ssid, bool(saved)

        self.run_async("wifi-autoconnect", worker, self._wifi_autoconnect_finished)
        return False

    def _wifi_autoconnect_progress(self, state: str, message: str) -> bool:
        translated = self._translate_status(message)
        quick_status: Gtk.Label | None = self._build_refs.get("wifi_quick_status")
        if quick_status is not None:
            quick_status.set_text(translated)
        if state == "online":
            self._set_network_chip(self._t("Netzwerk aktiv", "Network active", "Síť aktivní"), "good")
        else:
            self._set_network_chip(self._t("WLAN verbindet …", "Connecting Wi-Fi …", "Připojování Wi-Fi …"), "warn")
        return False

    def _wifi_autoconnect_finished(self, result) -> None:
        ok, message, ssid, had_saved_profiles = result
        self._wifi_connection_busy = False
        if ok:
            self._wifi_connected_ssid = ssid
            self._set_network_chip(f"{ssid} ✓" if ssid else self._translate_status(message), "good")
            self.set_status(self._translate_status(message), "good")
        else:
            self._wifi_connected_ssid = ""
            self._set_network_chip(self._t("Offline", "Offline", "Offline"), "warn")
            self.set_status(
                self._t("Kein gespeichertes WLAN erreichbar.", "No saved Wi-Fi is reachable.", "Žádná uložená Wi-Fi není dostupná.")
                if had_saved_profiles
                else self._t("Noch kein WLAN gespeichert.", "No Wi-Fi has been saved yet.", "Zatím není uložena žádná Wi-Fi."),
                "warn",
            )
        self._wifi_quick_networks = []
        popover: Gtk.Popover | None = self._build_refs.get("wifi_quick_popover")
        if popover is not None and popover.get_visible():
            self._refresh_wifi_quick_menu(force=True)
        GLib.timeout_add_seconds(2, self._schedule_auto_update_check)

    def _build_wifi_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("WLAN-Zentrale", "Wi-Fi centre", "Centrum Wi-Fi"),
            self._t("Gespeicherte und sichtbare Netzwerke gemeinsam anzeigen, prüfen und verbinden.", "Show, check and connect saved and visible networks together.", "Zobrazujte, kontrolujte a připojujte uložené i viditelné sítě."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["wifi_status"] = self._label(self._t("Bereit zur Suche", "Ready to scan", "Připraveno ke skenování"), "status-chip")
        toolbar.pack_start(self._build_refs["wifi_status"], True, True, 0)
        toolbar.pack_end(self._button(self._t("Netze suchen", "Scan networks", "Vyhledat sítě"), self._scan_wifi, "primary-button", "view-refresh-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)
        self._build_refs["wifi_list"] = Gtk.ListBox()
        self._build_refs["wifi_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        wifi_scroll = Gtk.ScrolledWindow()
        wifi_scroll.set_min_content_height(430)
        wifi_scroll.add(self._build_refs["wifi_list"])
        outer.pack_start(wifi_scroll, True, True, 4)
        return page

    def _clear_listbox(self, widget: Gtk.ListBox) -> None:
        for child in widget.get_children():
            widget.remove(child)

    def _refresh_wifi_saved_rows(self, scanned: list[dict[str, str]] | None = None) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("wifi_list")
        task_name = "wifi-profiles"
        if listbox is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["wifi_status"].set_text(self._t("WLAN-Profile werden geladen …", "Loading Wi-Fi profiles …", "Načítání profilů Wi-Fi …"))

        def worker():
            try:
                return self.core.load_wifi_networks()
            except Exception:
                return []

        def done(saved) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_wifi_rows(saved, scanned)

        self.run_async(task_name, worker, done)

    def _render_wifi_rows(self, saved: list[dict[str, str]], scanned: list[dict[str, str]] | None = None) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("wifi_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        saved_by_ssid = {str(item.get("ssid") or ""): item for item in saved}
        merged: dict[str, dict[str, str]] = {ssid: dict(item) for ssid, item in saved_by_ssid.items() if ssid}
        for item in scanned or []:
            ssid = str(item.get("ssid") or "")
            if not ssid:
                continue
            existing = merged.setdefault(ssid, {})
            existing.update(item)
            if ssid in saved_by_ssid:
                existing["password"] = str(saved_by_ssid[ssid].get("password") or "")
                existing["saved"] = "1"
        if not merged:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Noch keine gespeicherten oder sichtbaren WLAN-Netze.", "No saved or visible Wi-Fi networks yet.", "Zatím žádné uložené ani viditelné sítě Wi-Fi."), "muted", wrap=True))
            listbox.add(row)
        for network in sorted(merged.values(), key=lambda item: self.core.wifi_signal_sort_value(item.get("signal", "")), reverse=True):
            listbox.add(self._wifi_row(network, str(network.get("ssid") or "") in saved_by_ssid))
        listbox.show_all()
        self._build_refs["wifi_status"].set_text(
            self._t(f"{len(merged)} WLAN-Netze", f"{len(merged)} Wi-Fi networks", f"Sítě Wi-Fi: {len(merged)}")
        )

    def _wifi_row(self, network: dict[str, str], saved: bool) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        row.add(box)
        box.pack_start(self._icon("network-wireless-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(network.get("ssid")), "section-title"), False, False, 0)
        security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security"))
        signal = _clean(network.get("signal"), self._t("Signal unbekannt", "Signal unknown", "Signál neznámý"))
        saved_text = self._t("gespeichert", "saved", "uloženo") if saved else self._t("nicht gespeichert", "not saved", "neuloženo")
        text.pack_start(self._label(f"{security} · {signal} · {saved_text}", "muted"), False, False, 0)
        box.pack_start(text, True, True, 0)
        box.pack_end(self._button(self._t("Verbinden", "Connect", "Připojit"), lambda _b, item=dict(network), is_saved=saved: self._connect_wifi(item, is_saved), "primary-button", "network-wireless-symbolic"), False, False, 0)
        if saved:
            box.pack_end(self._button(self._t("Löschen", "Delete", "Smazat"), lambda _b, ssid=str(network.get("ssid") or ""): self._delete_wifi(ssid), "danger-button", "edit-delete-symbolic"), False, False, 0)
        return row

    def _scan_wifi(self, _button=None) -> None:
        task_name = "wifi-settings-scan"
        if self._wifi_connection_busy:
            self._build_refs["wifi_status"].set_text(self._t("Bitte laufende WLAN-Verbindung abwarten …", "Please wait for the Wi-Fi connection …", "Počkejte na dokončení připojení Wi-Fi …"))
            return
        if task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["wifi_status"].set_text(self._t("WLAN-Suche läuft …", "Scanning Wi-Fi …", "Probíhá hledání Wi-Fi …"))
        self.run_async(task_name, self._scan_wifi_live_preserving_connection, self._wifi_scan_finished)

    def _wifi_scan_finished(self, result) -> None:
        self._refresh_tasks.discard("wifi-settings-scan")
        networks, message = result
        self._build_refs["wifi_status"].set_text(self._translate_status(message))
        self._refresh_wifi_saved_rows(networks)
        self.set_status(self._translate_status(message), "good" if networks else "warn")

    def _touch_keyboard(self, entry: Gtk.Entry) -> Gtk.Widget:
        revealer = Gtk.Revealer()
        grid = Gtk.Grid(row_spacing=3, column_spacing=3)
        keys = ("1234567890", "qwertzuiop", "asdfghjkl", "yxcvbnm")
        for row_index, row_keys in enumerate(keys):
            for column, key in enumerate(row_keys):
                button = Gtk.Button(label=key)
                button.set_size_request(42, 34)
                button.connect("clicked", lambda _b, value=key: self._entry_insert(entry, value))
                grid.attach(button, column, row_index, 1, 1)
        back = Gtk.Button(label="⌫")
        back.connect("clicked", lambda _b: self._entry_backspace(entry))
        grid.attach(back, 10, 0, 1, 2)
        specials = ("-", "_", ".", "@", "!", "?", "#", "+")
        for column, key in enumerate(specials):
            button = Gtk.Button(label=key)
            button.connect("clicked", lambda _b, value=key: self._entry_insert(entry, value))
            grid.attach(button, column, 4, 1, 1)
        revealer.add(grid)
        return revealer

    def _entry_backspace(self, entry: Gtk.Entry) -> None:
        position = entry.get_position()
        if position > 0:
            entry.delete_text(position - 1, position)

    def _entry_insert(self, entry: Gtk.Entry, value: str) -> None:
        position = entry.get_position()
        entry.insert_text(value, position)
        entry.set_position(position + len(value))

    def _password_dialog(self, ssid: str) -> str | None:
        dialog = Gtk.Dialog(title=self._t("WLAN verbinden", "Connect Wi-Fi", "Připojit Wi-Fi"), transient_for=self.window, modal=True)
        dialog.add_button(self._t("Abbrechen", "Cancel", "Zrušit"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self._t("Speichern + verbinden", "Save + connect", "Uložit + připojit"), Gtk.ResponseType.OK)
        content = dialog.get_content_area()
        content.set_spacing(8)
        content.set_margin_start(16)
        content.set_margin_end(16)
        content.pack_start(self._label(f"{self._t('Passwort für', 'Password for', 'Heslo pro')} {ssid}", "section-title"), False, False, 4)
        entry = Gtk.Entry()
        entry.set_visibility(False)
        entry.set_activates_default(True)
        content.pack_start(entry, False, False, 0)
        reveal_password = Gtk.CheckButton(label=self._t("Passwort anzeigen", "Show password", "Zobrazit heslo"))
        reveal_password.connect("toggled", lambda button: entry.set_visibility(button.get_active()))
        content.pack_start(reveal_password, False, False, 0)
        keyboard = self._touch_keyboard(entry)
        toggle = Gtk.ToggleButton(label=self._t("Bildschirmtastatur", "On-screen keyboard", "Klávesnice na obrazovce"))
        toggle.connect("toggled", lambda button: keyboard.set_reveal_child(button.get_active()))
        content.pack_start(toggle, False, False, 0)
        content.pack_start(keyboard, False, False, 0)
        dialog.set_default_response(Gtk.ResponseType.OK)
        dialog.show_all()
        keyboard.set_reveal_child(False)
        response = dialog.run()
        value = entry.get_text() if response == Gtk.ResponseType.OK else None
        dialog.destroy()
        return value

    def _connect_wifi(self, network: dict[str, str], saved: bool) -> None:
        if self._wifi_connection_busy:
            self.set_status(self._t("Bitte laufende WLAN-Verbindung abwarten.", "Please wait for the Wi-Fi connection.", "Počkejte na dokončení připojení Wi-Fi."), "warn")
            return
        ssid = str(network.get("ssid") or "").strip()
        security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security"))
        if not ssid:
            return
        if security == "OPEN":
            self.set_status(
                self._t(
                    "Offene WLANs werden in diesem Teststand noch nicht unterstützt.",
                    "Open Wi-Fi networks are not supported by this test build yet.",
                    "Otevřené sítě Wi-Fi zatím tato testovací verze nepodporuje.",
                ),
                "warn",
            )
            return
        saved_networks = {str(item.get("ssid") or ""): item for item in self.core.load_wifi_networks()}
        candidate = dict(saved_networks.get(ssid) or network)
        candidate.update({key: value for key, value in network.items() if value})
        if security != "OPEN" and not str(candidate.get("password") or ""):
            password = self._password_dialog(ssid)
            if password is None:
                return
            candidate["password"] = password
            self.core.save_wifi_network(ssid, password, security)
        elif not saved:
            self.core.save_wifi_network(ssid, "", security)
        self._build_refs["wifi_status"].set_text(f"{self._t('Verbinde', 'Connecting', 'Připojování')} {ssid} …")
        self._wifi_connection_busy = True

        def status(_state: str, message: str) -> None:
            GLib.idle_add(self._build_refs["wifi_status"].set_text, self._translate_status(message))

        def worker():
            result = self.core.connect_temporary_network(
                status,
                [],
                [candidate],
                require_internet=True,
                allow_active=False,
                allow_lan=False,
                cleanup_success=False,
            )
            if not result[0]:
                try:
                    result[2]()
                except Exception:
                    pass
            return result

        self.run_async(
            "wifi-connect",
            worker,
            lambda result: self._wifi_connect_finished(ssid, result),
        )

    def _wifi_connect_finished(self, ssid: str, result) -> None:
        ok, message, _cleanup = result
        self._wifi_connection_busy = False
        state = "good" if ok else "bad"
        self._wifi_connected_ssid = ssid if ok else ""
        self._build_refs["wifi_status"].set_text(self._translate_status(message))
        self._set_network_chip(f"{ssid} ✓" if ok else self._t("WLAN-Fehler", "Wi-Fi error", "Chyba Wi-Fi"), state)
        self.set_status(self._translate_status(message), state)
        popover: Gtk.Popover | None = self._build_refs.get("wifi_quick_popover")
        if popover is not None:
            popover.popdown()
        self._wifi_quick_networks = []
        self._refresh_wifi_saved_rows()
        if ok:
            GLib.timeout_add_seconds(2, lambda: self._schedule_auto_update_check(force=True))

    def _delete_wifi(self, ssid: str) -> None:
        if self.core.delete_wifi_network(ssid):
            self.set_status(f"{self._t('WLAN gelöscht', 'Wi-Fi deleted', 'Wi-Fi smazána')}: {ssid}", "good")
        self._wifi_quick_networks = []
        self._refresh_wifi_saved_rows()

    # ---------- printing ----------

    def _build_print_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Drucken", "Print", "Tisk"),
            self._t(
                "Den aktuellen Hardware-Report prüfen, speichern und direkt an den aktiven Drucker senden.",
                "Review, save and send the current hardware report directly to the active printer.",
                "Zkontrolujte, uložte a odešlete aktuální hardwarový report na aktivní tiskárnu.",
            ),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["print_status"] = self._label(self._t("Hardware wird geladen …", "Loading hardware …", "Načítání hardwaru …"), "status-chip")
        toolbar.pack_start(self._build_refs["print_status"], True, True, 0)
        toolbar.pack_end(
            self._button(
                self._t("Jetzt drucken", "Print now", "Vytisknout nyní"),
                self._print_current_report,
                "primary-button",
                "document-print-symbolic",
            ),
            False,
            False,
            0,
        )
        toolbar.pack_end(
            self._button(
                self._t("Report speichern", "Save report", "Uložit report"),
                self._save_current_report,
                "secondary-button",
                "document-save-symbolic",
            ),
            False,
            False,
            0,
        )
        toolbar.pack_end(
            self._button(
                self._t("Drucker auswählen", "Choose printer", "Vybrat tiskárnu"),
                lambda _b: self.show_page("printers"),
                "secondary-button",
                "printer-symbolic",
            ),
            False,
            False,
            0,
        )
        outer.pack_start(toolbar, False, False, 12)

        preview_frame = Gtk.Frame()
        preview_frame.set_shadow_type(Gtk.ShadowType.NONE)
        preview_frame.get_style_context().add_class("card")
        preview_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        preview_frame.add(preview_box)
        preview_box.pack_start(self._label(self._t("Druckvorschau", "Print preview", "Náhled tisku"), "section-title"), False, False, 0)
        preview = Gtk.TextView()
        preview.set_editable(False)
        preview.set_cursor_visible(False)
        preview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        preview_scroll = Gtk.ScrolledWindow()
        preview_scroll.set_min_content_height(430)
        preview_scroll.add(preview)
        preview_box.pack_start(preview_scroll, True, True, 0)
        outer.pack_start(preview_frame, True, True, 0)
        self._build_refs["print_preview"] = preview
        return page

    def _current_report_text(self) -> str:
        if not self.snapshot:
            return self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen.")
        matches = self.core.format_model_match_results(self.match_results, self.language, limit=6)
        return self.core.build_report(self.snapshot, matches, self.language)

    def _refresh_print_page(self) -> None:
        preview: Gtk.TextView | None = self._build_refs.get("print_preview")
        status: Gtk.Label | None = self._build_refs.get("print_status")
        if preview is not None:
            preview.get_buffer().set_text(self._current_report_text())
        task_name = "print-printer-status"
        if status is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        status.set_text(self._t("Aktiver Drucker wird geprüft …", "Checking active printer …", "Kontrola aktivní tiskárny …"))

        def worker():
            try:
                config, _path = self.core.load_printer_config()
                printer_name = str(config.get("printer_name") or config.get("name") or "").strip()
                printer_target = str(config.get("printer_uri") or config.get("raw_host") or config.get("printer_host") or "").strip()
                return printer_name, printer_target
            except Exception:
                return "", ""

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            printer_name, printer_target = result
            if printer_name or printer_target:
                status.set_text(f"{self._t('Aktiver Drucker', 'Active printer', 'Aktivní tiskárna')}: {printer_name or printer_target}")
                self._set_chip_state(status, "good")
            else:
                status.set_text(self._t("Noch kein aktiver Drucker gewählt", "No active printer selected", "Není vybrána aktivní tiskárna"))
                self._set_chip_state(status, "warn")

        self.run_async(task_name, worker, done)

    def _write_current_report(self, print_after: bool) -> None:
        if not self.snapshot:
            self.set_status(self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen."), "warn")
            return

        def worker():
            report = self._current_report_text()
            report_dir = self.core.get_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            target = report_dir / f"{self.core.report_basename(self.snapshot)}.txt"
            self.core.write_text_durable(target, report)
            if not print_after:
                return target, None

            def progress(_state: str, message: str) -> None:
                status: Gtk.Label | None = self._build_refs.get("print_status")
                if status is not None:
                    GLib.idle_add(status.set_text, self._translate_status(message))

            return target, self.core.run_report_print(target, progress)

        def done(result) -> None:
            target, print_result = result
            if print_result is None:
                message = f"{self._t('Report gespeichert', 'Report saved', 'Report uložen')}: {target.name}"
                self.set_status(message, "good")
                self._build_refs["print_status"].set_text(message)
            else:
                ok, message = print_result
                translated = self._translate_status(message)
                self.set_status(f"{translated} · {target.name}", "good" if ok else "bad")
                self._build_refs["print_status"].set_text(translated)

        self.run_async("current-report-print" if print_after else "current-report-save", worker, done)

    def _save_current_report(self, _button=None) -> None:
        self._write_current_report(False)

    def _print_current_report(self, _button=None) -> None:
        self._write_current_report(True)

    # ---------- printers ----------

    def _build_printers_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Drucker-Zentrale", "Printer centre", "Centrum tiskáren"),
            self._t("Gespeicherte Drucker sofort verwenden und neue IPP-/RAW-Drucker live finden.", "Use saved printers immediately and discover new IPP/RAW printers live.", "Okamžitě používejte uložené tiskárny a vyhledávejte nové tiskárny IPP/RAW."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["printer_status"] = self._label(self._t("Bereit", "Ready", "Připraveno"), "status-chip")
        toolbar.pack_start(self._build_refs["printer_status"], True, True, 0)
        toolbar.pack_end(self._button(self._t("Testseite drucken", "Print test page", "Vytisknout testovací stránku"), self._print_test_report, "secondary-button", "document-print-symbolic"), False, False, 0)
        toolbar.pack_end(self._button(self._t("Drucker suchen", "Find printers", "Vyhledat tiskárny"), self._scan_printers, "primary-button", "system-search-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)

        panes = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        panes.set_position(520)
        outer.pack_start(panes, True, True, 4)
        saved_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        saved_box.pack_start(self._label(self._t("Gespeicherte Drucker", "Saved printers", "Uložené tiskárny"), "section-title"), False, False, 0)
        self._build_refs["printer_saved_list"] = Gtk.ListBox()
        self._build_refs["printer_saved_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        saved_scroll = Gtk.ScrolledWindow()
        saved_scroll.add(self._build_refs["printer_saved_list"])
        saved_box.pack_start(saved_scroll, True, True, 0)
        panes.pack1(saved_box, True, False)
        found_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        found_box.pack_start(self._label(self._t("Gefundene Drucker", "Discovered printers", "Nalezené tiskárny"), "section-title"), False, False, 0)
        self._build_refs["printer_found_list"] = Gtk.ListBox()
        self._build_refs["printer_found_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        found_scroll = Gtk.ScrolledWindow()
        found_scroll.add(self._build_refs["printer_found_list"])
        found_box.pack_start(found_scroll, True, True, 0)
        panes.pack2(found_box, True, False)
        return page

    def _refresh_printer_profiles(self) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("printer_saved_list")
        task_name = "printer-profiles"
        if listbox is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["printer_status"].set_text(self._t("Druckerprofile werden geladen …", "Loading printer profiles …", "Načítání profilů tiskáren …"))

        def worker():
            try:
                profiles = self.core.load_printer_profiles()
                active_config, _path = self.core.load_printer_config()
                return profiles, self.core.printer_config_signature(active_config)
            except Exception:
                return [], ()

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_printer_profiles(result)

        self.run_async(task_name, worker, done)

    def _render_printer_profiles(self, result) -> None:
        profiles, active_signature = result
        listbox: Gtk.ListBox = self._build_refs.get("printer_saved_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        if not profiles:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Noch kein Drucker gespeichert.", "No printer saved yet.", "Zatím není uložena žádná tiskárna."), "muted", wrap=True))
            listbox.add(row)
        for profile in profiles:
            config = self.core.printer_profile_config(profile)
            active = self.core.printer_config_signature(config) == active_signature
            row = Gtk.ListBoxRow()
            row.get_style_context().add_class("list-row")
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.add(box)
            box.pack_start(self._icon("printer-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            name = self.core.printer_profile_name(profile)
            text.pack_start(self._label(name, "section-title"), False, False, 0)
            host = config.get("raw_host") or config.get("printer_host") or config.get("printer_uri") or "–"
            text.pack_start(self._label(f"{_short(host, 54)} · {self._t('aktiv', 'active', 'aktivní') if active else self._t('gespeichert', 'saved', 'uloženo')}", "good-text" if active else "muted"), False, False, 0)
            box.pack_start(text, True, True, 0)
            box.pack_end(self._button(self._t("Aktivieren", "Activate", "Aktivovat"), lambda _b, item=profile: self._activate_printer_profile(item), "primary-button"), False, False, 0)
            box.pack_end(self._button(self._t("Löschen", "Delete", "Smazat"), lambda _b, item=profile: self._delete_printer_profile(item), "danger-button"), False, False, 0)
            listbox.add(row)
        listbox.show_all()
        self._build_refs["printer_status"].set_text(
            self._t(f"{len(profiles)} Drucker gespeichert", f"{len(profiles)} printers saved", f"Uloženo tiskáren: {len(profiles)}")
        )

    def _activate_printer_profile(self, profile: dict[str, object]) -> None:
        try:
            self.core.save_active_printer_profile(profile, manual_selected=True)
            name = self.core.printer_profile_name(profile)
            self.set_status(f"{self._t('Aktiver Drucker', 'Active printer', 'Aktivní tiskárna')}: {name}", "good")
            self._build_refs["printer_status"].set_text(name)
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _delete_printer_profile(self, profile: dict[str, object]) -> None:
        profile_id = str(profile.get("id") or "")
        profiles = [item for item in self.core.load_printer_profiles() if str(item.get("id") or "") != profile_id]
        try:
            self.core.save_printer_profiles(profiles)
            self.set_status(self._t("Druckerprofil gelöscht.", "Printer profile deleted.", "Profil tiskárny smazán."), "good")
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _scan_printers(self, _button=None) -> None:
        self._printer_results = []
        found_list: Gtk.ListBox = self._build_refs["printer_found_list"]
        self._clear_listbox(found_list)
        self._build_refs["printer_status"].set_text(self._t("Druckersuche läuft …", "Printer discovery running …", "Probíhá hledání tiskáren …"))

        def status(_state: str, message: str) -> None:
            GLib.idle_add(self._build_refs["printer_status"].set_text, self._translate_status(message))

        def found(printer: dict[str, object]) -> None:
            GLib.idle_add(self._add_found_printer, printer)

        self.run_async("printer-scan", lambda: self.core.discover_network_printers(status, found), self._printer_scan_finished)

    def _add_found_printer(self, printer: dict[str, object]) -> bool:
        if any(str(item.get("host")) == str(printer.get("host")) for item in self._printer_results):
            return False
        self._printer_results.append(printer)
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.add(box)
        box.pack_start(self._icon("printer-network-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(printer.get("name")), "section-title"), False, False, 0)
        text.pack_start(self._label(f"{_clean(printer.get('host'))} · {_clean(printer.get('method'))} · {_clean(printer.get('ports'))}", "muted", wrap=True), False, False, 0)
        box.pack_start(text, True, True, 0)
        box.pack_end(self._button(self._t("Speichern + aktivieren", "Save + activate", "Uložit + aktivovat"), lambda _b, item=printer: self._save_discovered_printer(item), "primary-button"), False, False, 0)
        self._build_refs["printer_found_list"].add(row)
        self._build_refs["printer_found_list"].show_all()
        return False

    def _printer_scan_finished(self, result) -> None:
        found, message = result
        for printer in found:
            self._add_found_printer(printer)
        self._build_refs["printer_status"].set_text(self._translate_status(message))
        self.set_status(self._translate_status(message), "good" if found else "warn")

    def _save_discovered_printer(self, printer: dict[str, object]) -> None:
        try:
            profile = self.core.discovered_printer_profile(printer)
            self.core.upsert_printer_profile(profile)
            self.core.save_active_printer_profile(profile, manual_selected=True)
            self.set_status(f"{self._t('Drucker gespeichert', 'Printer saved', 'Tiskárna uložena')}: {self.core.printer_profile_name(profile)}", "good")
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _print_test_report(self, _button=None) -> None:
        if not self.snapshot:
            self.set_status(self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen."), "warn")
            return

        def worker():
            matches = self.core.format_model_match_results(self.match_results, self.language, limit=6)
            report = self.core.build_report(self.snapshot, matches, self.language)
            report_dir = self.core.get_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            target = report_dir / f"{self.core.report_basename(self.snapshot)}_v5-testprint.txt"
            self.core.write_text_durable(target, report)
            return target, self.core.run_report_print(target, lambda state, message: GLib.idle_add(self._build_refs["printer_status"].set_text, self._translate_status(message)))

        self.run_async("test-print", worker, self._print_finished)

    def _print_finished(self, result) -> None:
        target, (ok, message) = result
        self.set_status(f"{self._translate_status(message)} · {target.name}", "good" if ok else "bad")
        self._build_refs["printer_status"].set_text(self._translate_status(message))

    # ---------- reports ----------

    def _build_reports_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Report-Center", "Report centre", "Centrum reportů"),
            self._t("Modell- und Akku-Reports zentral öffnen, prüfen und drucken.", "Open, inspect and print model and battery reports in one place.", "Otevírejte, kontrolujte a tiskněte reporty modelů a baterie na jednom místě."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        toolbar.pack_end(self._button(self._t("Aktualisieren", "Refresh", "Obnovit"), lambda _b: self._refresh_reports(), "secondary-button", "view-refresh-symbolic"), False, False, 0)
        toolbar.pack_end(self._button(self._t("Ausgewählten Report drucken", "Print selected report", "Vytisknout vybraný report"), self._print_selected_report, "primary-button", "document-print-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 10)
        panes = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        panes.set_position(430)
        outer.pack_start(panes, True, True, 0)
        store = Gtk.ListStore(str, str, str, object)
        tree = Gtk.TreeView(model=store)
        tree.get_selection().connect("changed", self._report_selection_changed)
        for title, index, width in ((self._t("Typ", "Type", "Typ"), 0, 90), (self._t("Datei", "File", "Soubor"), 1, 230), (self._t("Datum", "Date", "Datum"), 2, 130)):
            renderer = Gtk.CellRendererText()
            renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
            column = Gtk.TreeViewColumn(title, renderer, text=index)
            column.set_min_width(width)
            column.set_resizable(True)
            tree.append_column(column)
        report_scroll = Gtk.ScrolledWindow()
        report_scroll.add(tree)
        panes.pack1(report_scroll, True, False)
        preview = Gtk.TextView()
        preview.set_editable(False)
        preview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        preview_scroll = Gtk.ScrolledWindow()
        preview_scroll.add(preview)
        panes.pack2(preview_scroll, True, False)
        self._build_refs["report_store"] = store
        self._build_refs["report_tree"] = tree
        self._build_refs["report_preview"] = preview
        return page

    def _refresh_reports(self) -> None:
        store: Gtk.ListStore = self._build_refs.get("report_store")
        task_name = "reports"
        if store is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        store.clear()
        self.set_status(self._t("Reports werden geladen …", "Loading reports …", "Načítání reportů …"), "info")

        def worker():
            paths: list[tuple[str, pathlib.Path]] = []
            try:
                report_dir = self.core.get_report_dir()
                paths.extend((self._t("Modell", "Model", "Model"), path) for path in report_dir.glob("*.txt"))
            except OSError:
                pass
            try:
                paths.extend((self._t("Akku", "Battery", "Baterie"), path) for path in self.core.list_battery_report_files())
            except OSError:
                pass
            unique: dict[str, tuple[str, pathlib.Path]] = {}
            for report_type, path in paths:
                unique[str(path)] = (report_type, path)
            return sorted(unique.values(), key=lambda pair: pair[1].stat().st_mtime if pair[1].exists() else 0, reverse=True)

        def done(paths) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_reports(paths)

        self.run_async(task_name, worker, done)

    def _render_reports(self, paths: list[tuple[str, pathlib.Path]]) -> None:
        store: Gtk.ListStore = self._build_refs.get("report_store")
        if store is None:
            return
        store.clear()
        for report_type, path in paths:
            try:
                stamp = datetime.datetime.fromtimestamp(path.stat().st_mtime).strftime("%d.%m.%Y %H:%M")
            except OSError:
                stamp = "–"
            store.append([report_type, path.name, stamp, path])
        self.set_status(self._t(f"{len(paths)} Reports geladen.", f"{len(paths)} reports loaded.", f"Načtené reporty: {len(paths)}."), "good")

    def _selected_report_path(self) -> pathlib.Path | None:
        tree: Gtk.TreeView = self._build_refs["report_tree"]
        model, iterator = tree.get_selection().get_selected()
        return model[iterator][3] if iterator is not None else None

    def _report_selection_changed(self, _selection) -> None:
        path = self._selected_report_path()
        if path is None:
            return
        try:
            if path.suffix.lower() == ".html":
                text = self.core.battery_report_preview_text(path, 120)
            else:
                text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            text = str(exc)
        self._build_refs["report_preview"].get_buffer().set_text(text)

    def _print_selected_report(self, _button=None) -> None:
        path = self._selected_report_path()
        if path is None:
            self.set_status(self._t("Bitte einen Report auswählen.", "Please select a report.", "Vyberte report."), "warn")
            return
        self.run_async("report-print", lambda: self.core.run_report_print(path), lambda result: self.set_status(self._translate_status(result[1]), "good" if result[0] else "bad"))

    # ---------- updates ----------

    def _open_update_settings(self, _button=None) -> None:
        self.show_page("settings")

    def _update_widgets(self) -> list[Gtk.Widget]:
        widgets: list[Gtk.Widget] = []
        for candidate in (
            self._build_refs.get("update_alert_button"),
            self.nav_buttons.get("settings"),
            self._build_refs.get("footer_box"),
        ):
            if isinstance(candidate, Gtk.Widget):
                widgets.append(candidate)
        return widgets

    def _clear_update_phase_classes(self) -> None:
        for widget in self._update_widgets():
            context = widget.get_style_context()
            for css_class in self.UPDATE_PHASE_CLASSES:
                context.remove_class(css_class)

    def _update_alert_tick(self) -> bool:
        if not (self._db_update_available or self._program_update_available):
            self._clear_update_phase_classes()
            self._update_alert_timer_id = None
            return False
        self._clear_update_phase_classes()
        css_class = self.UPDATE_PHASE_CLASSES[self._update_alert_phase % len(self.UPDATE_PHASE_CLASSES)]
        self._update_alert_phase += 1
        for widget in self._update_widgets():
            widget.get_style_context().add_class(css_class)
        return True

    def _refresh_update_alert(self) -> None:
        button: Gtk.Button | None = self._build_refs.get("update_alert_button")
        label: Gtk.Label | None = self._build_refs.get("update_alert_label")
        available = self._db_update_available or self._program_update_available
        if not available:
            if self._update_alert_timer_id is not None:
                try:
                    GLib.source_remove(self._update_alert_timer_id)
                except Exception:
                    pass
                self._update_alert_timer_id = None
            self._clear_update_phase_classes()
            if button is not None:
                button.hide()
            return

        parts: list[str] = []
        if self._db_update_available:
            parts.append("DB")
        if self._program_update_available:
            parts.append(self._t("PROGRAMM", "APP", "PROGRAM"))
        if label is not None:
            label.set_text(
                self._t("UPDATE VERFÜGBAR", "UPDATE AVAILABLE", "AKTUALIZACE K DISPOZICI")
                + ": "
                + " + ".join(parts)
            )
        if button is not None:
            child = button.get_child()
            if child is not None:
                child.show_all()
            button.show()
        if self._update_alert_timer_id is None:
            self._update_alert_phase = 0
            self._update_alert_tick()
            self._update_alert_timer_id = GLib.timeout_add(650, self._update_alert_tick)

    def _set_update_availability(self, db_available: bool | None = None, program_available: bool | None = None) -> None:
        if db_available is not None:
            self._db_update_available = bool(db_available)
        if program_available is not None:
            self._program_update_available = bool(program_available)
        self._refresh_update_alert()

    def _set_update_controls_busy(self, busy: bool) -> None:
        for key in ("db_update_button", "program_update_button", "updates_check_button"):
            button: Gtk.Button | None = self._build_refs.get(key)
            if button is not None:
                button.set_sensitive(not busy)

    def _set_update_progress(self, message: str) -> bool:
        if self._update_progress_determinate:
            return False
        translated = self._translate_status(message)
        label: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if label is not None:
            label.set_text(translated)
        return False

    def _set_update_percentage(self, kind: str, percent: int, message: str) -> bool:
        value = max(0, min(100, int(percent)))
        translated = self._translate_status(message)
        progress: Gtk.ProgressBar | None = self._build_refs.get(f"{kind}_update_progress")
        if progress is not None:
            progress.set_fraction(value / 100.0)
            progress.set_text(f"{value}%")
            progress.show()
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if overall is not None:
            overall.set_text(f"{translated} · {value}%")
        footer: Gtk.ProgressBar | None = self._build_refs.get("footer_progress")
        if footer is not None:
            footer.set_fraction(value / 100.0)
            footer.set_text(f"{value}%")
            footer.show()
        return False

    def _begin_update_percentage(self, kind: str, message: str) -> None:
        self._update_progress_determinate = True
        self._set_update_percentage(kind, 0, message)

    def _finish_update_percentage(self, kind: str, ok: bool, message: str) -> None:
        translated = self._translate_status(message)
        progress: Gtk.ProgressBar | None = self._build_refs.get(f"{kind}_update_progress")
        if progress is not None:
            if ok:
                progress.set_fraction(1.0)
                progress.set_text("100%")
            else:
                progress.set_text(self._t("Fehler", "Error", "Chyba"))
            progress.show()
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if overall is not None:
            overall.set_text(translated)
        self._update_progress_determinate = False

    def _schedule_auto_update_check(self, force: bool = False) -> bool:
        if self._auto_update_check_started and not force:
            return False
        if self._update_operation:
            return False
        self._auto_update_check_started = True
        self._check_updates(auto=True)
        return False

    def _manual_check_updates_clicked(self, _button=None) -> None:
        self._auto_update_check_started = True
        self._check_updates(auto=False)

    def _toggle_update_alert_demo(self, _button=None) -> None:
        self._update_alert_demo = not self._update_alert_demo
        if self._update_alert_demo:
            db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
            program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
            overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
            demo_text = self._t("TESTANZEIGE – DB- und Programmupdate verfügbar", "TEST DISPLAY – DB and application update available", "TESTOVACÍ ZOBRAZENÍ – aktualizace DB a programu je k dispozici")
            if db_label is not None:
                db_label.set_text(self._t("TEST: DB-Update verfügbar", "TEST: DB update available", "TEST: aktualizace DB je k dispozici"))
                self._set_chip_state(db_label, "warn")
            if program_label is not None:
                program_label.set_text(self._t("TEST: Programm-Update verfügbar", "TEST: application update available", "TEST: aktualizace programu je k dispozici"))
                self._set_chip_state(program_label, "warn")
            if overall is not None:
                overall.set_text(demo_text)
            self._set_update_availability(True, True)
            self.set_status(demo_text, "warn")
            return
        self._set_update_availability(False, False)
        self._set_update_progress(self._t("Testanzeige beendet. Jetzt erneut prüfen.", "Test display stopped. Check again now.", "Testovací zobrazení ukončeno. Nyní proveďte novou kontrolu."))

    def _check_updates(self, auto: bool) -> None:
        if self._update_operation:
            if not auto:
                self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "check"
        self._set_update_controls_busy(True)
        self._set_update_progress(self._t("DB und Programm werden geprüft …", "Checking DB and application …", "Kontrola DB a programu …"))
        if not auto:
            self.set_status(self._t("Updates werden geprüft …", "Checking for updates …", "Kontrola aktualizací …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def worker():
            db_ok, db_message, db_available = self.core.check_model_database_update_available(progress)
            app_ok, app_message, app_available = self.core.check_hardwarecheck_update_available(progress)
            return db_ok, db_message, db_available, app_ok, app_message, app_available

        self.run_async("updates-check", worker, self._update_check_finished)

    def _update_check_finished(self, result) -> None:
        db_ok, db_message, db_available, app_ok, app_message, app_available = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        self._set_update_availability(db_available, app_available)
        db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
        program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if db_label is not None:
            db_label.set_text(self._translate_status(db_message))
            self._set_chip_state(db_label, "warn" if db_available else "good" if db_ok else "bad")
        if program_label is not None:
            program_label.set_text(self._translate_status(app_message))
            self._set_chip_state(program_label, "warn" if app_available else "good" if app_ok else "bad")
        messages = [message for message, available in ((db_message, db_available), (app_message, app_available)) if available]
        if messages:
            text = " | ".join(self._translate_status(message) for message in messages)
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "warn")
        elif db_ok and app_ok:
            text = self._t("DB und Programm sind aktuell.", "DB and application are current.", "DB a program jsou aktuální.")
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "good")
        else:
            text = f"{self._translate_status(db_message)} | {self._translate_status(app_message)}"
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "bad")

    def _db_update_clicked(self, _button=None) -> None:
        if self._update_operation:
            self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "db"
        self._set_update_controls_busy(True)
        self._begin_update_percentage("db", self._t("DB-Update wird vorbereitet …", "Preparing DB update …", "Příprava aktualizace DB …"))
        self.set_status(self._t("DB-Update: verbinde …", "DB update: connecting …", "Aktualizace DB: připojování …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def percentage(percent: int, message: str) -> None:
            GLib.idle_add(self._set_update_percentage, "db", percent, message)

        def worker():
            ok, message = self.core.run_model_database_update(progress, percentage)
            if not ok:
                return ok, message, None
            models = self.core.load_model_db()
            manifest = self.core.load_local_model_manifest()
            matches = self.core.get_model_match_results(self.snapshot, models) if self.snapshot else []
            relations = self.core.build_model_relation_map(models)
            return ok, message, (models, manifest, matches, relations)

        self.run_async("db-update", worker, self._db_update_finished)

    def _db_update_finished(self, result) -> None:
        ok, message, refreshed = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
        if db_label is not None:
            db_label.set_text(self._translate_status(message))
            self._set_chip_state(db_label, "good" if ok else "bad")
        self._finish_update_percentage("db", ok, message)
        if ok and refreshed is not None:
            self.models, manifest, self.match_results, self._model_relation_map = refreshed
            version = self.core.format_database_version(str(manifest.get("version") or ""))
            count = manifest.get("models_count") or manifest.get("model_count") or len(self.models)
            db_chip: Gtk.Label | None = self._build_refs.get("db_chip")
            if db_chip is not None:
                db_chip.set_text(f"DB {version or '–'} · {count}")
                self._set_chip_state(db_chip, "good")
            self._render_dashboard_model_suggestions()
            self._refresh_model_table()
            self._set_update_availability(db_available=False)
        self.set_status(self._translate_status(message), "good" if ok else "bad")

    def _program_update_clicked(self, _button=None) -> None:
        if self._update_operation:
            self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "program"
        self._set_update_controls_busy(True)
        self._begin_update_percentage("program", self._t("Programm-Update wird vorbereitet …", "Preparing application update …", "Příprava aktualizace programu …"))
        self.set_status(self._t("Programm-Update: verbinde …", "App update: connecting …", "Aktualizace programu: připojování …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def percentage(percent: int, message: str) -> None:
            GLib.idle_add(self._set_update_percentage, "program", percent, message)

        self.run_async(
            "program-update",
            lambda: self.core.run_hardwarecheck_update_check(progress, percentage),
            self._program_update_finished,
        )

    def _program_update_finished(self, result) -> None:
        ok, message, install_request = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
        if program_label is not None:
            program_label.set_text(self._translate_status(message))
            self._set_chip_state(program_label, "warn" if install_request else "good" if ok else "bad")
        self._finish_update_percentage("program", ok, message)
        self._set_update_availability(program_available=bool(install_request))
        self.set_status(self._translate_status(message), "warn" if install_request else "good" if ok else "bad")
        if ok and install_request:
            self._show_program_update_prompt(install_request)

    def _show_program_update_prompt(self, install_request: dict[str, str]) -> None:
        target_version = str(install_request.get("target_version") or "?")
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=self._t("Programm-Update bereit", "Application update ready", "Aktualizace programu je připravena"),
        )
        dialog.format_secondary_text(
            self._t(
                f"Version {target_version} wurde heruntergeladen, per SHA256 geprüft und kann jetzt installiert werden.",
                f"Version {target_version} was downloaded, verified with SHA256 and can now be installed.",
                f"Verze {target_version} byla stažena, ověřena pomocí SHA256 a nyní ji lze nainstalovat.",
            )
        )
        dialog.add_button(self._t("Später", "Later", "Později"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self._t("Jetzt installieren", "Install now", "Nainstalovat nyní"), Gtk.ResponseType.OK)
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.OK:
            self._start_program_update_install(install_request)

    def _start_program_update_install(self, install_request: dict[str, str]) -> None:
        config_path = pathlib.Path(str(install_request.get("config_path") or ""))
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            self.set_status(f"{self._t('Programm-Update: Installer-Konfiguration fehlt', 'App update: installer configuration is missing', 'Aktualizace programu: chybí konfigurace instalátoru')}: {exc}", "bad")
            return
        if not isinstance(config, dict):
            self.set_status(self._t("Programm-Update: ungültige Installer-Konfiguration", "App update: invalid installer configuration", "Aktualizace programu: neplatná konfigurace instalátoru"), "bad")
            return

        dialog = Gtk.Dialog(
            title=self._t("Programm-Update", "Application update", "Aktualizace programu"),
            transient_for=self.window,
            flags=Gtk.DialogFlags.MODAL,
        )
        dialog.set_deletable(False)
        dialog.set_default_size(640, 240)
        content = dialog.get_content_area()
        content.set_spacing(14)
        content.set_margin_start(24)
        content.set_margin_end(24)
        content.set_margin_top(22)
        content.set_margin_bottom(18)
        title = self._label(self._t("HardwareCheck wird aktualisiert", "Updating HardwareCheck", "Aktualizace HardwareCheck"), "hero-title")
        detail = self._label(self._t("Vorbereitung …", "Preparing …", "Příprava …"), wrap=True)
        progress_bar = Gtk.ProgressBar()
        progress_bar.set_show_text(True)
        close_button = dialog.add_button(self._t("Schließen", "Close", "Zavřít"), Gtk.ResponseType.CLOSE)
        close_button.set_no_show_all(True)
        close_button.hide()
        content.pack_start(title, False, False, 0)
        content.pack_start(detail, False, False, 0)
        content.pack_start(progress_bar, False, False, 0)
        dialog.connect("response", lambda current, _response: current.destroy())
        dialog.show_all()
        close_button.hide()

        self._update_operation = "program-install"
        self._set_update_controls_busy(True)
        self._begin_update_percentage(
            "program",
            self._t("Programm-Update wird installiert …", "Installing application update …", "Instalace aktualizace programu …"),
        )

        def progress(percent: int, message: str) -> None:
            GLib.idle_add(self._program_install_progress, progress_bar, detail, percent, message)

        def worker():
            try:
                app_path = self.core.apply_hardwarecheck_update(config, progress)
                return True, str(app_path), ""
            except Exception as exc:
                return False, str(exc), traceback.format_exc()

        self.run_async(
            "program-install",
            worker,
            lambda result: self._program_install_finished(dialog, detail, progress_bar, close_button, result),
        )

    def _program_install_progress(self, progress_bar: Gtk.ProgressBar, detail: Gtk.Label, percent: int, message: str) -> bool:
        value = max(0, min(100, int(percent)))
        detail.set_text(self._translate_status(message))
        progress_bar.set_fraction(value / 100.0)
        progress_bar.set_text(f"{value}%")
        self._set_update_percentage("program", value, message)
        self.set_status(f"{self._t('Programm-Update', 'App update', 'Aktualizace programu')}: {self._translate_status(message)}", "info")
        return False

    def _program_install_finished(
        self,
        dialog: Gtk.Dialog,
        detail: Gtk.Label,
        progress_bar: Gtk.ProgressBar,
        close_button: Gtk.Button,
        result,
    ) -> None:
        ok, value, error_detail = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        if ok:
            detail.set_text(self._t("Update erfolgreich. HardwareCheck wird neu gestartet …", "Update successful. Restarting HardwareCheck …", "Aktualizace byla úspěšná. HardwareCheck se restartuje …"))
            progress_bar.set_fraction(1.0)
            progress_bar.set_text("100%")
            self._finish_update_percentage("program", True, self._t("Programm-Update erfolgreich", "Application update successful", "Aktualizace programu byla úspěšná"))
            self._set_update_availability(program_available=False)
            self.set_status(self._t("Programm-Update erfolgreich – Neustart …", "Application update successful – restarting …", "Aktualizace programu byla úspěšná – restart …"), "good")
            GLib.timeout_add(900, self._restart_after_program_update, value)
            return

        detail.set_text(f"{self._t('Programm-Update fehlgeschlagen', 'Application update failed', 'Aktualizace programu se nezdařila')}: {value}")
        progress_bar.set_fraction(1.0)
        progress_bar.set_text("!")
        self._finish_update_percentage("program", False, str(value))
        close_button.show()
        self.set_status(f"{self._t('Programm-Update fehlgeschlagen', 'Application update failed', 'Aktualizace programu se nezdařila')}: {value}", "bad")
        try:
            debug_root = self.core.find_external_root() or self.core.SCRIPT_DIR
            debug_dir = pathlib.Path(debug_root) / "hardwarecheck-debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            self.core.write_text_durable(debug_dir / "v5-program-install-error.txt", error_detail)
        except Exception:
            pass

    def _restart_after_program_update(self, app_path: str) -> bool:
        env = os.environ.copy()
        env.pop("HC_USE_LEGACY_UI", None)
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(app_path).resolve())], env)
        return False

    # ---------- settings ----------

    def _build_settings_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Einstellungen", "Settings", "Nastavení"),
            self._t("Updates, WLAN, Drucker, Sprache, Diagnose und sichere Rückfalloptionen für den v5-Teststand.", "Updates, Wi-Fi, printers, language, diagnostics and safe fallback options for the v5 test build.", "Aktualizace, Wi-Fi, tiskárny, jazyk, diagnostika a bezpečné možnosti návratu pro testovací verzi v5."),
        )

        updates = self._section(outer, self._t("Updates", "Updates", "Aktualizace"), 12)
        update_card = Gtk.Frame()
        update_card.set_shadow_type(Gtk.ShadowType.NONE)
        update_card.get_style_context().add_class("card")
        update_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        update_card.add(update_box)
        updates.pack_start(update_card, False, False, 0)
        self._build_refs["updates_overall_status"] = self._label(
            self._t(
                "Automatische Prüfung nach der WLAN-Verbindung.",
                "Automatic check after the Wi-Fi connection.",
                "Automatická kontrola po připojení k Wi-Fi.",
            ),
            "muted",
            wrap=True,
        )
        update_box.pack_start(self._build_refs["updates_overall_status"], False, False, 0)

        db_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        db_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        db_text.pack_start(self._label(self._t("Modelldatenbank", "Model database", "Databáze modelů"), "section-title"), False, False, 0)
        self._build_refs["db_update_status"] = self._label(self._t("Noch nicht geprüft", "Not checked yet", "Dosud nekontrolováno"), "status-chip", wrap=True)
        db_text.pack_start(self._build_refs["db_update_status"], False, False, 0)
        db_progress = Gtk.ProgressBar()
        db_progress.set_show_text(True)
        db_progress.set_no_show_all(True)
        db_progress.hide()
        db_text.pack_start(db_progress, False, False, 4)
        self._build_refs["db_update_progress"] = db_progress
        db_row.pack_start(db_text, True, True, 0)
        db_button = self._button(self._t("DB-Update", "DB update", "Aktualizace DB"), self._db_update_clicked, "primary-button", "view-refresh-symbolic")
        db_row.pack_end(db_button, False, False, 0)
        self._build_refs["db_update_button"] = db_button
        update_box.pack_start(db_row, False, False, 0)

        program_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        program_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        program_text.pack_start(self._label(self._t("HardwareCheck-Programm", "HardwareCheck application", "Program HardwareCheck"), "section-title"), False, False, 0)
        self._build_refs["program_update_status"] = self._label(self._t("Noch nicht geprüft", "Not checked yet", "Dosud nekontrolováno"), "status-chip", wrap=True)
        program_text.pack_start(self._build_refs["program_update_status"], False, False, 0)
        program_progress = Gtk.ProgressBar()
        program_progress.set_show_text(True)
        program_progress.set_no_show_all(True)
        program_progress.hide()
        program_text.pack_start(program_progress, False, False, 4)
        self._build_refs["program_update_progress"] = program_progress
        program_row.pack_start(program_text, True, True, 0)
        program_button = self._button(self._t("Programm-Update", "App update", "Aktualizace programu"), self._program_update_clicked, "primary-button", "software-update-available-symbolic")
        program_row.pack_end(program_button, False, False, 0)
        self._build_refs["program_update_button"] = program_button
        update_box.pack_start(program_row, False, False, 0)

        check_button = self._button(
            self._t("DB und Programm jetzt prüfen", "Check DB and application now", "Zkontrolovat DB a program nyní"),
            self._manual_check_updates_clicked,
            "secondary-button",
            "system-search-symbolic",
        )
        update_box.pack_start(check_button, False, False, 0)
        self._build_refs["updates_check_button"] = check_button
        if any(marker in str(self.core.APP_VERSION).lower() for marker in ("dev", "test")):
            demo_button = self._button(
                self._t("Nur Teststand: Update-Alarm testen", "Test build only: test update alert", "Pouze testovací verze: vyzkoušet upozornění"),
                self._toggle_update_alert_demo,
                "secondary-button",
                "dialog-warning-symbolic",
            )
            update_box.pack_start(demo_button, False, False, 0)

        language_box = self._section(outer, self._t("Sprache", "Language", "Jazyk"), 12)
        languages = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        language_box.pack_start(languages, False, False, 0)
        for language, code in (("CZ", "CZ"), ("DE", "DE"), ("EN", "EN")):
            button = Gtk.Button()
            button.get_style_context().add_class("primary-button" if self.language == language else "secondary-button")
            inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            inner.pack_start(Gtk.Image.new_from_pixbuf(flag_pixbuf(language)), False, False, 0)
            inner.pack_start(self._label(code, "section-title"), False, False, 0)
            button.add(inner)
            button.connect("clicked", lambda _b, target=language: self._select_language(target))
            languages.pack_start(button, False, False, 0)
            self._build_refs[f"language_button_{language}"] = button

        connections = self._section(outer, self._t("Verbindungen & Geräte", "Connections & devices", "Připojení a zařízení"))
        connections.pack_start(
            self._label(
                self._t(
                    "Gespeicherte WLANs und Drucker werden hier verwaltet. Die schnelle WLAN-Auswahl bleibt jederzeit oben erreichbar.",
                    "Manage saved Wi-Fi networks and printers here. Quick Wi-Fi selection remains available at the top.",
                    "Zde můžete spravovat uložené sítě Wi-Fi a tiskárny. Rychlý výběr Wi-Fi zůstává dostupný nahoře.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        connection_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        connection_actions.pack_start(
            self._button(
                self._t("WLANs verwalten", "Manage Wi-Fi", "Spravovat Wi-Fi"),
                lambda _b: self.show_page("wifi"),
                "secondary-button",
                "network-wireless-symbolic",
            ),
            False,
            False,
            0,
        )
        connection_actions.pack_start(
            self._button(
                self._t("Drucker suchen und verwalten", "Find and manage printers", "Vyhledat a spravovat tiskárny"),
                lambda _b: self.show_page("printers"),
                "secondary-button",
                "printer-symbolic",
            ),
            False,
            False,
            0,
        )
        connections.pack_start(connection_actions, False, False, 0)

        service = self._section(outer, self._t("Service", "Service", "Servis"))
        service_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        service.pack_start(service_row, False, False, 0)
        service_row.pack_start(self._button(self._t("Hardware neu scannen", "Rescan hardware", "Znovu skenovat hardware"), self._rescan_clicked, "primary-button", "view-refresh-symbolic"), False, False, 0)
        service_row.pack_start(self._button(self._t("Legacy-Oberfläche starten", "Start legacy interface", "Spustit původní rozhraní"), self._restart_legacy, "secondary-button", "go-previous-symbolic"), False, False, 0)

        about = Gtk.Frame()
        about.set_shadow_type(Gtk.ShadowType.NONE)
        about.get_style_context().add_class("card")
        about_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        about.add(about_box)
        about_box.pack_start(self._label("HardwareCheck v5", "hero-title"), False, False, 0)
        about_box.pack_start(self._label(f"{self.core.APP_VERSION} · GTK {Gtk.get_major_version()}.{Gtk.get_minor_version()} · Python {sys.version.split()[0]}", "muted"), False, False, 0)
        about_box.pack_start(self._label(self._t("Der bewährte v3-Hardwarekern bleibt unverändert als Rückfall verfügbar. v5 lädt aufwendige Suchen erst bei Bedarf.", "The proven v3 hardware core remains available as a fallback. v5 loads expensive searches only when requested.", "Osvědčené jádro hardwaru v3 zůstává k dispozici jako záloha. v5 spouští náročná vyhledávání pouze na vyžádání."), wrap=True), False, False, 0)
        outer.pack_start(about, False, False, 20)
        return page

    def _select_language(self, language: str) -> None:
        if language not in self.core.LANGUAGES:
            return
        self.language = language
        self.core.save_language(language)
        self.set_status(self._t("Sprache gespeichert; Oberfläche wird neu geladen …", "Language saved; reloading the interface …", "Jazyk uložen; rozhraní se znovu načítá …"), "good")
        for key in self.core.LANGUAGES:
            button = self._build_refs.get(f"language_button_{key}")
            if button:
                context = button.get_style_context()
                if key == language:
                    context.add_class("primary-button")
                    context.remove_class("secondary-button")
                else:
                    context.add_class("secondary-button")
                    context.remove_class("primary-button")
        GLib.timeout_add(350, self._restart_v5)

    def _restart_v5(self) -> bool:
        env = os.environ.copy()
        env.pop("HC_USE_LEGACY_UI", None)
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(self.core.__file__).resolve())], env)
        return False

    def _restart_legacy(self, _button=None) -> None:
        env = os.environ.copy()
        env["HC_USE_LEGACY_UI"] = "1"
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(self.core.__file__).resolve())], env)

    def _power_menu_action(self, action: str, popover: Gtk.Popover | None = None) -> None:
        if popover is not None:
            popover.popdown()
        self._execute_power_action(action)

    def _execute_power_action(self, action: str) -> None:
        restart = action == "reboot"
        self.set_status(
            self._t("Computer wird neu gestartet …", "Restarting computer …", "Počítač se restartuje …")
            if restart
            else self._t("Computer wird heruntergefahren …", "Shutting down computer …", "Počítač se vypíná …"),
            "warn",
        )
        try:
            self.core.subprocess.Popen(["reboot" if restart else "poweroff"])
        except OSError as exc:
            self.set_status(str(exc), "bad")

    def _confirm_power_action(self, action: str) -> None:
        self._execute_power_action(action)

    def _confirm_poweroff(self, _button=None) -> None:
        self._execute_power_action("poweroff")

    # ---------- async lifecycle ----------

    def _start_initial_load(self) -> bool:
        self.set_status(self._t("Hardware wird im Hintergrund erkannt …", "Detecting hardware in the background …", "Rozpoznávání hardwaru na pozadí …"), "info")

        def worker():
            snapshot = self.core.get_system_snapshot()
            models = self.core.load_model_db()
            matches = self.core.get_model_match_results(snapshot, models)
            relations = self.core.build_model_relation_map(models)
            battery = self.core.read_battery_details()
            manifest = self.core.load_local_model_manifest()
            network = self.core.active_local_network_message()
            return snapshot, models, matches, relations, battery, manifest, network

        self.run_async("initial-load", worker, self._initial_load_finished)
        return False

    def _initial_load_finished(self, result) -> None:
        self.snapshot, self.models, self.match_results, self._model_relation_map, battery, manifest, network = result
        vendor = _clean(self.snapshot.get("vendor_short") or self.snapshot.get("vendor"))
        model = _clean(self.snapshot.get("model_name"))
        self._build_refs["hero_title"].set_text(f"{vendor} {model}")
        product = _clean(self.snapshot.get("product_no"), self._t("Keine Produktnummer erkannt", "No product number detected", "Nebylo zjištěno produktové číslo"))
        self._build_refs["hero_subtitle"].set_text(f"{product} · {self._t('Scan abgeschlossen', 'Scan complete', 'Sken dokončen')}")
        self._build_refs["metric_system"].set_text(f"{vendor} {model}")
        self._build_refs["metric_system_sub"].set_text(product)
        self._build_refs["metric_cpu"].set_text(_clean(self.snapshot.get("cpu_short") or self.snapshot.get("cpu")))
        self._build_refs["metric_cpu_sub"].set_text(_short(self.snapshot.get("cpu"), 64))
        ram_total = _clean(self.snapshot.get("ram_total_gb"))
        self._build_refs["metric_ram"].set_text(f"{ram_total} GB {self.snapshot.get('ram_type') or ''}".strip())
        self._build_refs["metric_ram_sub"].set_text(_clean(self.snapshot.get("ram_layout")))
        storage_lines = self.snapshot.get("storage_lines") or []
        self._build_refs["metric_storage"].set_text(_short(storage_lines[0] if storage_lines else "–", 72))
        self._build_refs["metric_storage_sub"].set_text(_short(" · ".join(str(line) for line in storage_lines[1:3]), 72))
        display = f"{_clean(self.snapshot.get('display_inches'))}\" {self.snapshot.get('display_type') or ''}".strip()
        self._build_refs["metric_display"].set_text(display)
        self._build_refs["metric_display_sub"].set_text(_clean(self.snapshot.get("resolution")))
        if self.match_results:
            best = self.match_results[0]
            item = best.get("item") if isinstance(best.get("item"), dict) else {}
            self._build_refs["metric_match"].set_text(f"{_clean(item.get('model_id'))} · {int(best.get('score') or 0)}%")
            self._build_refs["metric_match_sub"].set_text(_short(self.core.model_notebook_summary(item), 72))
        else:
            self._build_refs["metric_match"].set_text(self._t("Kein Treffer", "No match", "Žádná shoda"))
            self._build_refs["metric_match_sub"].set_text("")
        self._render_dashboard_model_suggestions()
        version = self.core.format_database_version(str(manifest.get("version") or ""))
        count = manifest.get("models_count") or manifest.get("model_count") or len(self.models)
        self._build_refs["db_chip"].set_text(f"DB {version or '–'} · {count}")
        if network:
            self._set_network_chip(self._translate_status(network), "good")
        else:
            self._set_network_chip(self._t("Offline", "Offline", "Offline"), "warn")
        self._update_battery_ui(battery)
        self._refresh_model_table()
        if self.current_page == "print":
            self._refresh_print_page()
        self.set_status(self._t("HardwareCheck v5 ist bereit.", "HardwareCheck v5 is ready.", "HardwareCheck v5 je připraven."), "good")
        GLib.idle_add(self._start_wifi_autoconnect)

    def _rescan_clicked(self, _button=None) -> None:
        if self._busy_count:
            self.set_status(self._t("Bitte laufenden Vorgang abwarten.", "Please wait for the current task.", "Počkejte na dokončení aktuální úlohy."), "warn")
            return
        self._start_initial_load()

    def run_async(self, name: str, worker: Callable, done: Callable | None = None) -> None:
        self._busy_count += 1
        self._busy_changed()

        def target() -> None:
            try:
                result = worker()
            except Exception as exc:
                detail = traceback.format_exc()
                GLib.idle_add(self._async_failed, name, exc, detail)
                return
            GLib.idle_add(self._async_finished, done, result)

        threading.Thread(target=target, name=f"hc-v5-{name}", daemon=True).start()

    def _async_finished(self, done: Callable | None, result) -> bool:
        self._busy_count = max(0, self._busy_count - 1)
        self._busy_changed()
        if done is not None:
            done(result)
        return False

    def _async_failed(self, name: str, exc: Exception, detail: str) -> bool:
        self._busy_count = max(0, self._busy_count - 1)
        self._refresh_tasks.discard(name)
        if name in {"updates-check", "db-update", "program-update", "program-install"}:
            self._update_operation = ""
            self._set_update_controls_busy(False)
            if name == "db-update":
                self._finish_update_percentage("db", False, str(exc))
            elif name in {"program-update", "program-install"}:
                self._finish_update_percentage("program", False, str(exc))
        if name in {"wifi-autoconnect", "wifi-connect"}:
            self._wifi_connection_busy = False
            self._set_network_chip(self._t("WLAN-Fehler", "Wi-Fi error", "Chyba Wi-Fi"), "bad")
        self._busy_changed()
        try:
            debug_root = self.core.find_external_root() or self.core.SCRIPT_DIR
            debug_dir = pathlib.Path(debug_root) / "hardwarecheck-debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            self.core.write_text_durable(debug_dir / f"v5-{name}-error.txt", detail)
        except Exception:
            pass
        self.set_status(f"{name}: {exc}", "bad")
        return False

    def _busy_changed(self) -> None:
        spinner: Gtk.Spinner | None = self._build_refs.get("top_spinner")
        progress: Gtk.ProgressBar | None = self._build_refs.get("footer_progress")
        if self._busy_count:
            if spinner is not None:
                spinner.start()
            if progress is not None:
                progress.show()
                if not self._update_progress_determinate:
                    progress.pulse()
        else:
            if spinner is not None:
                spinner.stop()
            if progress is not None:
                progress.hide()

    def _clock_tick(self) -> bool:
        clock: Gtk.Label = self._build_refs.get("clock")
        if clock:
            clock.set_text(datetime.datetime.now().strftime("%H:%M · %d.%m.%Y"))
        if self._busy_count:
            progress: Gtk.ProgressBar = self._build_refs.get("footer_progress")
            if progress and not self._update_progress_determinate:
                progress.pulse()
        return True

    def _translate_status(self, message: object) -> str:
        try:
            return self.core.translate_status_text(str(message or ""), self.language)
        except Exception:
            return str(message or "")

    def _set_chip_state(self, chip: Gtk.Label, state: str) -> None:
        context = chip.get_style_context()
        for name in ("good", "warn", "bad"):
            context.remove_class(name)
        if state in {"good", "warn", "bad"}:
            context.add_class(state)

    def set_status(self, message: str, state: str = "info") -> None:
        label: Gtk.Label = self._build_refs.get("footer_status")
        if label:
            label.set_text(self._translate_status(message))
            context = label.get_style_context()
            for name in ("good-text", "warn-text", "bad-text"):
                context.remove_class(name)
            if state == "good":
                context.add_class("good-text")
            elif state == "warn":
                context.add_class("warn-text")
            elif state == "bad":
                context.add_class("bad-text")


def run(core) -> int:
    """Start the v5 GTK application using an already-loaded core module."""
    app = HardwareCheckV5(core)
    return int(app.run([str(pathlib.Path(core.__file__).resolve())]))
