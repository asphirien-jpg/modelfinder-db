"""Read-only safety classification for the HardwareCheck drive lab.

This module deliberately performs no mount, partition, format or erase action.
It turns the already read disk inventory into conservative workshop categories.
Unknown media stay non-destructive by design.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping


PROTECTED_LABELS = frozenset({"MISODEBIAN", "ACRONIS", "MISOLOIMAGES", "MISOLOBOOT"})
TOOL_MARKERS = frozenset({"hardwarecheck", "magic_image_solo_gui.py", "model.json", ".hardwarecheck-portable"})


@dataclass(frozen=True)
class DriveSafety:
    category: str
    title: str
    detail: str
    erase_allowed: bool = False


def _values(value: object) -> tuple[str, ...]:
    if isinstance(value, str):
        return (value,) if value.strip() else ()
    if isinstance(value, Iterable):
        return tuple(str(item).strip() for item in value if str(item).strip())
    return ()


def classify_drive(record: Mapping[str, object]) -> DriveSafety:
    """Classify a disk conservatively; all categories are read-only for now."""

    name = str(record.get("name") or record.get("kname") or "").strip()
    transport = str(record.get("transport") or record.get("tran") or "").strip().lower()
    labels = {item.upper() for item in _values(record.get("labels"))}
    markers = {item.lower() for item in _values(record.get("markers"))}
    boot_disks = set(_values(record.get("boot_disks")))
    tool_disks = set(_values(record.get("tool_disks")))
    mounted = _values(record.get("mountpoints"))

    if name and name in boot_disks:
        return DriveSafety("blocked-system", "Systemlaufwerk gesperrt", "Das aktuell laufende System verwendet dieses Laufwerk.")
    if name and name in tool_disks:
        return DriveSafety("blocked-tool", "Tool-Medium gesperrt", "Dieses Laufwerk gehört zum gestarteten HardwareCheck-/Magic-Image-Medium.")
    protected_labels = sorted(labels & PROTECTED_LABELS)
    if protected_labels:
        return DriveSafety("blocked-tool", "Tool-Medium gesperrt", f"Geschütztes Medienlabel erkannt: {', '.join(protected_labels)}.")
    if markers & TOOL_MARKERS:
        return DriveSafety("blocked-tool", "Tool-Medium gesperrt", "HardwareCheck-/Magic-Image-Dateistruktur erkannt.")
    if mounted:
        return DriveSafety("mounted", "Eingebundenes Laufwerk", "Hat eingehängte Partitionen und bleibt vorsorglich gesperrt.")
    if transport == "usb":
        return DriveSafety(
            "external-candidate",
            "Externe Teststation erkannt",
            "Externes Laufwerk: SMART kann gelesen werden. Eine Bereinigung entfernt Partitionen und Dateisystemsignaturen.",
            erase_allowed=True,
        )
    return DriveSafety(
        "internal-candidate",
        "Interne Ziel-SSD erkannt",
        "Interner Datenträger: nur nach zusätzlicher Bestätigung bereinigen.",
        erase_allowed=True,
    )


def inventory_signature(records: Iterable[Mapping[str, object]]) -> str:
    """Return a stable lightweight identity string for plug-and-play rescans."""

    entries = []
    for record in records:
        name = str(record.get("name") or record.get("kname") or "").strip()
        if not name:
            continue
        entries.append((
            name,
            str(record.get("transport") or record.get("tran") or "").strip().lower(),
            str(record.get("size") or record.get("size_bytes") or "").strip(),
            tuple(sorted(item.upper() for item in _values(record.get("labels")))),
        ))
    return repr(tuple(sorted(entries)))
