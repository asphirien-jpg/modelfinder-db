﻿#!/usr/bin/env python3
"""Fast full-screen hardware inspector for a Porteus USB stick.

This app is designed to launch directly after boot on lightweight Linux media.
It keeps the existing HardwareCheck.sh spirit, but improves two weak spots:
1. RAM type is read from SMBIOS where possible instead of guessed from speed.
2. Display size is derived from EDID physical dimensions instead of model hints.
"""

from __future__ import annotations

import json
import hashlib
import datetime
import email.utils
import math
import os
import pathlib
import queue
import re
import select
import shutil
import socket
import subprocess
import sys
import struct
import tempfile
import threading
import textwrap
import time
import tkinter as tk
import traceback
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from tkinter import messagebox

try:
    import fcntl
except ImportError:  # pragma: no cover - only relevant outside Linux.
    fcntl = None


APP_VERSION = "v3.50"
APP_TITLE = f"HardwareCheck {APP_VERSION}"
SCRIPT_DIR = pathlib.Path(__file__).resolve().parent
REPORT_DIR = SCRIPT_DIR / "Model Report"
PORTABLE_DIR_NAME = "HardwareCheck"
PORTABLE_MARKER = ".hardwarecheck-portable"
COMMON_DISPLAY_SIZES = [10.1, 11.6, 12.5, 13.3, 14.0, 15.6, 16.0, 16.1, 17.3, 18.0]
COMMON_DISK_SIZES = [32, 64, 120, 128, 240, 250, 256, 320, 480, 500, 512, 640, 750, 960, 1000, 1024, 2000, 2048]
LANGUAGES = ("DE", "EN", "CZ")
SETTINGS_FILE = "hardwarecheck-settings.json"
WIFI_NETWORKS_FILE = "wifi_networks.json"
DEFAULT_WIFI_COUNTRY = "CZ"
DEFAULT_MODEL_MANIFEST_URL = "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/model_manifest.json"
DEFAULT_MODEL_DATABASE_URL = "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/model.json"
DEFAULT_HARDWARECHECK_UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/latest_hardwarecheck.json"
XRANDR_MODELINES = {
    "1366x768": ("1366x768_60.00", "85.50", "1366", "1436", "1579", "1792", "768", "771", "774", "798", "-hsync", "+vsync"),
    "1600x900": ("1600x900_60.00", "118.25", "1600", "1696", "1856", "2112", "900", "903", "908", "934", "-hsync", "+vsync"),
    "1920x1080": ("1920x1080_60.00", "173.00", "1920", "2048", "2248", "2576", "1080", "1083", "1088", "1120", "-hsync", "+vsync"),
}

EV_SYN = 0
EV_KEY = 1
EV_REL = 2
EV_ABS = 3
REL_X = 0
REL_Y = 1
ABS_X = 0
ABS_Y = 1
ABS_MT_POSITION_X = 53
ABS_MT_POSITION_Y = 54
BTN_LEFT = 272
BTN_TOUCH = 330
INPUT_EVENT = struct.Struct("qqHHi")
RAW_KEY_CODES = {
    1: "escape",
    19: "reboot",  # R
    24: "appupdate",  # O
    22: "update",  # U
    17: "wifi",  # W
    46: "color",  # C
    20: "report",  # T
    25: "poweroff",  # P
    31: "scan",  # S
    35: "shell",  # H
    38: "language",  # L
    49: "report",  # N (legacy)
    60: "language",  # F2
    63: "scan",  # F5
    64: "report",  # F6
    65: "update",  # F7
    66: "shell",  # F8
    67: "reboot",  # F9
    68: "poweroff",  # F10
    87: "appupdate",  # F11
    88: "wifi",  # F12
}

def run_command(*args: str) -> str:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=3,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""
    return result.stdout.strip()


def run_quiet(*args: str) -> bool:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=3,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def read_text(path: os.PathLike[str] | str) -> str:
    try:
        return pathlib.Path(path).read_text(encoding="utf-8", errors="ignore").strip()
    except OSError:
        return ""


def read_bytes(path: os.PathLike[str] | str) -> bytes:
    try:
        return pathlib.Path(path).read_bytes()
    except OSError:
        return b""


def first_existing_text(paths: list[os.PathLike[str] | str]) -> str:
    for path in paths:
        value = read_text(path)
        if value:
            return value
    return ""


def sanitize_filename(value: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", value).strip() or "report"


def same_path(left: pathlib.Path, right: pathlib.Path) -> bool:
    try:
        return left.resolve() == right.resolve()
    except OSError:
        return left == right


def add_unique_path(paths: list[pathlib.Path], candidate: pathlib.Path) -> None:
    if not candidate:
        return
    if any(same_path(existing, candidate) for existing in paths):
        return
    paths.append(candidate)


def case_insensitive_child(directory: pathlib.Path, filename: str) -> pathlib.Path | None:
    direct = directory / filename
    if direct.is_file():
        return direct
    try:
        for child in directory.iterdir():
            if child.is_file() and child.name.lower() == filename.lower():
                return child
    except OSError:
        return None
    return None


def candidate_external_roots() -> list[pathlib.Path]:
    roots: list[pathlib.Path] = []
    env_root = os.environ.get("HC_DATA_DIR", "").strip()
    if env_root:
        add_unique_path(roots, pathlib.Path(env_root))

    for candidate in [
        pathlib.Path("/cdrom") / PORTABLE_DIR_NAME,
        pathlib.Path("/cdrom"),
    ]:
        add_unique_path(roots, candidate)

    for base in [pathlib.Path("/media"), pathlib.Path("/mnt"), pathlib.Path("/run/media")]:
        if not base.exists():
            continue
        for pattern in [PORTABLE_DIR_NAME, f"*/{PORTABLE_DIR_NAME}", f"*/*/{PORTABLE_DIR_NAME}"]:
            for candidate in base.glob(pattern):
                add_unique_path(roots, candidate)

    return [root for root in roots if root.is_dir()]


def find_external_file(filename: str) -> pathlib.Path | None:
    for root in candidate_external_roots():
        candidate = case_insensitive_child(root, filename)
        if candidate:
            return candidate

    for root in [pathlib.Path("/cdrom"), pathlib.Path("/media"), pathlib.Path("/mnt"), pathlib.Path("/run/media")]:
        if not root.exists():
            continue
        for candidate in root.glob(f"**/{filename}"):
            if candidate.is_file():
                return candidate
    return None


def find_external_root() -> pathlib.Path | None:
    for root in candidate_external_roots():
        if (
            case_insensitive_child(root, "model.json")
            or case_insensitive_child(root, SETTINGS_FILE)
            or (root / PORTABLE_MARKER).is_file()
            or (root / ".alpine-release").is_file()
        ):
            return root

    external_model = find_external_file("model.json")
    if external_model:
        return external_model.parent
    for root in [pathlib.Path("/cdrom"), pathlib.Path("/media"), pathlib.Path("/mnt"), pathlib.Path("/run/media")]:
        if not root.exists():
            continue
        for candidate in root.glob("**/.alpine-release"):
            if candidate.is_file():
                return candidate.parent
    return None


def find_debug_roots() -> list[pathlib.Path]:
    roots: list[pathlib.Path] = []
    external_root = find_external_root()
    if external_root:
        roots.append(external_root)

    patterns = [
        pathlib.Path("/cdrom").glob("*"),
        pathlib.Path("/media").glob("*"),
        pathlib.Path("/mnt").glob("*"),
        pathlib.Path("/run/media").glob("*/*"),
    ]
    for pattern in patterns:
        for candidate in pattern:
            if candidate.is_dir() and candidate not in roots:
                roots.append(candidate)
    if SCRIPT_DIR not in roots:
        roots.append(SCRIPT_DIR)
    return roots


def get_models_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        external_model = case_insensitive_child(external_root, "model.json")
        if external_model:
            return external_model
    return find_external_file("model.json") or (SCRIPT_DIR / "model.json")


def get_report_dir() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / "Model Report"
    return SCRIPT_DIR / "Model Report"


def get_settings_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / SETTINGS_FILE
    return SCRIPT_DIR / SETTINGS_FILE


def load_settings() -> dict[str, object]:
    try:
        data = json.loads(get_settings_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def save_settings(settings: dict[str, object]) -> None:
    try:
        write_text_durable(get_settings_path(), json.dumps(settings, indent=2) + "\n")
    except OSError:
        pass


def write_text_durable(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())

    try:
        directory_fd = os.open(str(path.parent), os.O_RDONLY)
    except OSError:
        directory_fd = -1
    if directory_fd >= 0:
        try:
            os.fsync(directory_fd)
        except OSError:
            pass
        finally:
            os.close(directory_fd)

    if os.environ.get("HC_DURABLE_SYNC") == "1":
        run_quiet("sync")


def write_bytes_atomic(path: pathlib.Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f".{path.name}.tmp")
    try:
        temp_path.write_bytes(payload)
        temp_path.replace(path)
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except OSError:
            pass


def write_json_atomic(path: pathlib.Path, data: object) -> None:
    payload = (json.dumps(data, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    write_bytes_atomic(path, payload)


def get_model_manifest_local_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / "model_manifest_local.json"
    return SCRIPT_DIR / "model_manifest_local.json"


def get_model_backup_dir() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / "backups" / "model_json"
    return SCRIPT_DIR / "backups" / "model_json"


def get_update_download_dir() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / "updates" / "downloads"
    return SCRIPT_DIR / "updates" / "downloads"


def get_update_staging_dir() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / "updates" / "staging"
    return SCRIPT_DIR / "updates" / "staging"


def get_update_backup_dir() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / "updates" / "backups"
    return SCRIPT_DIR / "updates" / "backups"


def get_update_log_dir() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / "updates" / "logs"
    return SCRIPT_DIR / "updates" / "logs"


def get_wifi_networks_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        external_wifi = case_insensitive_child(external_root, WIFI_NETWORKS_FILE)
        if external_wifi:
            return external_wifi
    external_wifi = find_external_file(WIFI_NETWORKS_FILE)
    if external_wifi:
        return external_wifi
    if external_root:
        return external_root / WIFI_NETWORKS_FILE
    return SCRIPT_DIR / WIFI_NETWORKS_FILE


def manifest_value(data: dict[str, object], *keys: str) -> str:
    for key in keys:
        value = data.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def parse_database_version(value: str) -> list[int]:
    return [int(part) for part in re.findall(r"\d+", value or "")]


def version_prerelease_rank(value: str) -> int:
    text = (value or "").lower()
    if any(marker in text for marker in ("test", "alpha", "beta", "rc", "dev")):
        return 0
    return 1


def version_is_newer(remote: str, local: str) -> bool:
    remote_parts = parse_database_version(remote)
    local_parts = parse_database_version(local)
    length = max(len(remote_parts), len(local_parts), 1)
    remote_parts.extend([0] * (length - len(remote_parts)))
    local_parts.extend([0] * (length - len(local_parts)))
    if remote_parts != local_parts:
        return remote_parts > local_parts
    return version_prerelease_rank(remote) > version_prerelease_rank(local)


def normalized_app_version() -> str:
    return APP_VERSION.lstrip("vV").strip()


def load_local_model_manifest() -> dict[str, object]:
    try:
        data = json.loads(get_model_manifest_local_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def local_model_database_info() -> tuple[str, int]:
    manifest = load_local_model_manifest()
    version = manifest_value(manifest, "version", "db_version", "database_version") or "lokal"
    count = 0
    for key in ("models_count", "model_count", "count", "entries"):
        value = manifest.get(key)
        if value in (None, ""):
            continue
        try:
            count = int(float(str(value)))
            break
        except ValueError:
            continue
    if count <= 0:
        count = len(load_model_db())
    return version, count


def download_bytes(url: str, timeout: int = 8, token: str = "") -> bytes:
    headers = {"User-Agent": "HardwareCheck-ModelUpdater/1.0"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def download_json(url: str, timeout: int = 8, token: str = "") -> object:
    return json.loads(download_bytes(url, timeout, token).decode("utf-8-sig"))


def filename_from_url(url: str, fallback: str) -> str:
    try:
        path = urllib.parse.urlparse(url).path
    except Exception:
        path = ""
    name = pathlib.PurePosixPath(path).name if path else ""
    return sanitize_filename(name or fallback)


PROTECTED_UPDATE_PATHS = {
    "model.json",
    "model_manifest_local.json",
    "hardwarecheck-settings.json",
    "wifi_networks.json",
    ".hardwarecheck-portable",
    "model report",
    "hardwarecheck-debug",
    "backups",
    "updates/backups",
}

ALLOWED_UPDATE_REPLACE_PATHS = {
    "hardwarecheck_fast_gui.py",
}


def normalize_update_path(value: object) -> str:
    text = str(value or "").replace("\\", "/").strip().strip("/")
    parts = [part for part in text.split("/") if part and part not in {".", ".."}]
    return "/".join(parts)


def validate_hardwarecheck_update_package(package_dir: pathlib.Path) -> tuple[bool, str]:
    manifest_path = package_dir / "update_manifest.json"
    payload_dir = package_dir / "payload"
    if not manifest_path.is_file():
        return False, "update_manifest.json fehlt"
    if not payload_dir.is_dir():
        return False, "payload/ fehlt"
    try:
        manifest_raw = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return False, "update_manifest.json ungueltig"
    if not isinstance(manifest_raw, dict):
        return False, "update_manifest.json ist kein Objekt"
    app_name = manifest_value(manifest_raw, "app", "name", "product")
    if app_name.lower() != "hardwarecheck":
        return False, f"falsches Paket ({app_name or '?'})"
    replace_raw = manifest_raw.get("replace_paths")
    preserve_raw = manifest_raw.get("preserve_paths")
    if not isinstance(replace_raw, list) or not replace_raw:
        return False, "replace_paths fehlt oder ist leer"
    if not isinstance(preserve_raw, list):
        return False, "preserve_paths fehlt oder ist keine Liste"
    replace_paths = [normalize_update_path(item) for item in replace_raw]
    replace_paths = [item for item in replace_paths if item]
    if not replace_paths:
        return False, "replace_paths enthaelt keine gueltigen Pfade"
    for path in replace_paths:
        if path.lower() in PROTECTED_UPDATE_PATHS:
            return False, f"geschuetzter Pfad in replace_paths: {path}"
        if path not in ALLOWED_UPDATE_REPLACE_PATHS:
            return False, f"nicht erlaubter replace_path: {path}"
        if not (payload_dir / path).is_file():
            return False, f"payload-Datei fehlt: {path}"
    preserve_paths = {normalize_update_path(item).lower() for item in preserve_raw}
    missing_preserves = sorted(PROTECTED_UPDATE_PATHS - preserve_paths)
    if missing_preserves:
        return False, "preserve_paths unvollstaendig: " + ", ".join(missing_preserves[:4])
    return True, f"Paket geprueft: {len(replace_paths)} Datei(en)"


def safe_extract_zip(zip_path: pathlib.Path, target_dir: pathlib.Path) -> None:
    target_root = target_dir.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            member_name = member.filename.replace("\\", "/")
            if member_name.startswith("/") or ".." in pathlib.PurePosixPath(member_name).parts:
                raise ValueError(f"unsicherer ZIP-Pfad: {member.filename}")
            member_target = (target_dir / member_name).resolve()
            if member_target != target_root and not str(member_target).startswith(str(target_root) + os.sep):
                raise ValueError(f"ZIP-Pfad ausserhalb Staging: {member.filename}")
        archive.extractall(target_dir)


def load_update_manifest(package_dir: pathlib.Path) -> dict[str, object]:
    data = json.loads((package_dir / "update_manifest.json").read_text(encoding="utf-8-sig"))
    return data if isinstance(data, dict) else {}


def update_replace_paths(manifest: dict[str, object]) -> list[str]:
    raw = manifest.get("replace_paths")
    if not isinstance(raw, list):
        return []
    return [path for path in (normalize_update_path(item) for item in raw) if path]


def write_hardwarecheck_update_installer(staging_dir: pathlib.Path, target_version: str) -> dict[str, str]:
    manifest = load_update_manifest(staging_dir)
    replace_paths = update_replace_paths(manifest)
    safe_version = sanitize_filename(target_version)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup_dir = get_update_backup_dir() / f"{stamp}_{sanitize_filename(APP_VERSION)}_to_{safe_version}"
    log_dir = get_update_log_dir()
    log_path = log_dir / "update_install.log"
    script_path = staging_dir / "apply_hardwarecheck_update.py"
    config_path = staging_dir / "installer_config.json"
    tool_root = SCRIPT_DIR
    python_exe = sys.executable or "python3"
    config = {
        "tool_root": str(tool_root),
        "payload_dir": str(staging_dir / "payload"),
        "backup_dir": str(backup_dir),
        "log_path": str(log_path),
        "replace_paths": replace_paths,
        "python_exe": python_exe,
        "app_file": "hardwarecheck_fast_gui.py",
        "target_version": target_version,
    }
    installer_script = r'''#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
import traceback


class ProgressWindow:
    def __init__(self) -> None:
        self.root = None
        self.label = None
        self.bar = None
        try:
            import tkinter as tk
            from tkinter import ttk
            self.root = tk.Tk()
            self.root.title("HardwareCheck Update")
            self.root.geometry("520x150+120+120")
            self.root.configure(bg="#12161b")
            self.root.attributes("-topmost", True)
            self.label = tk.Label(
                self.root,
                text="Update wird vorbereitet ...",
                bg="#12161b",
                fg="#f3f6f9",
                font=("Segoe UI", 12, "bold"),
                anchor="w",
                padx=18,
                pady=16,
            )
            self.label.pack(fill="x")
            self.bar = ttk.Progressbar(self.root, orient="horizontal", length=460, mode="determinate", maximum=100)
            self.bar.pack(fill="x", padx=18, pady=(4, 12))
            self.root.update()
        except Exception:
            self.root = None

    def update(self, percent: int, message: str) -> None:
        print(f"{percent}% {message}", flush=True)
        if self.root is None:
            return
        try:
            if self.label is not None:
                self.label.configure(text=message)
            if self.bar is not None:
                self.bar["value"] = max(0, min(100, percent))
            self.root.update()
        except Exception:
            self.root = None

    def close(self, delay: float = 1.5) -> None:
        if self.root is None:
            time.sleep(delay)
            return
        try:
            self.root.after(int(delay * 1000), self.root.destroy)
            self.root.mainloop()
        except Exception:
            pass


def safe_relative(value: str) -> pathlib.PurePosixPath:
    text = str(value or "").replace("\\", "/").strip().strip("/")
    path = pathlib.PurePosixPath(text)
    if not text or path.is_absolute() or ".." in path.parts:
        raise ValueError(f"Unsicherer Pfad: {value}")
    return path


def append_log(log_path: pathlib.Path, message: str) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {message}\n")


def copy_atomic(source: pathlib.Path, target: pathlib.Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_target = target.with_name(f".{target.name}.update_tmp")
    try:
        shutil.copy2(source, temp_target)
        os.replace(temp_target, target)
    finally:
        try:
            if temp_target.exists():
                temp_target.unlink()
        except OSError:
            pass


def restore_backup(tool_root: pathlib.Path, backup_dir: pathlib.Path, replace_paths: list[str], log_path: pathlib.Path) -> None:
    for rel_text in replace_paths:
        rel = safe_relative(rel_text)
        backup_file = backup_dir.joinpath(*rel.parts)
        target_file = tool_root.joinpath(*rel.parts)
        if backup_file.is_file():
            append_log(log_path, f"Rollback {backup_file} -> {target_file}")
            copy_atomic(backup_file, target_file)


def main() -> int:
    if len(sys.argv) < 2:
        print("installer_config.json fehlt", file=sys.stderr)
        return 2
    config_path = pathlib.Path(sys.argv[1]).resolve()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    tool_root = pathlib.Path(config["tool_root"]).resolve()
    payload_dir = pathlib.Path(config["payload_dir"]).resolve()
    backup_dir = pathlib.Path(config["backup_dir"]).resolve()
    log_path = pathlib.Path(config["log_path"]).resolve()
    replace_paths = [str(item) for item in config.get("replace_paths", [])]
    python_exe = str(config.get("python_exe") or sys.executable or "python3")
    app_file = str(config.get("app_file") or "hardwarecheck_fast_gui.py")
    progress = ProgressWindow()
    try:
        append_log(log_path, "HardwareCheck Update gestartet")
        progress.update(5, "Warte auf HardwareCheck ...")
        time.sleep(1.2)

        progress.update(18, "Backup wird erstellt ...")
        backup_dir.mkdir(parents=True, exist_ok=True)
        for rel_text in replace_paths:
            rel = safe_relative(rel_text)
            source_current = tool_root.joinpath(*rel.parts)
            backup_target = backup_dir.joinpath(*rel.parts)
            if source_current.is_file():
                backup_target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_current, backup_target)
                append_log(log_path, f"Backup {source_current} -> {backup_target}")

        progress.update(42, "Neue Dateien werden kopiert ...")
        for rel_text in replace_paths:
            rel = safe_relative(rel_text)
            source_new = payload_dir.joinpath(*rel.parts)
            target_file = tool_root.joinpath(*rel.parts)
            if not source_new.is_file():
                raise FileNotFoundError(f"Payload fehlt: {source_new}")
            append_log(log_path, f"Kopiere {source_new} -> {target_file}")
            copy_atomic(source_new, target_file)

        progress.update(70, "Installation wird geprueft ...")
        for rel_text in replace_paths:
            rel = safe_relative(rel_text)
            target_file = tool_root.joinpath(*rel.parts)
            if not target_file.is_file() or target_file.stat().st_size <= 0:
                raise RuntimeError(f"Zieldatei ungueltig: {target_file}")

        progress.update(84, "Daten werden geschrieben ...")
        if hasattr(os, "sync"):
            try:
                os.sync()
            except OSError:
                pass

        progress.update(96, "HardwareCheck wird neu gestartet ...")
        append_log(log_path, "Update erfolgreich")
        app_path = tool_root / app_file
        subprocess.Popen([python_exe, str(app_path)], cwd=str(tool_root))
        progress.update(100, "Update abgeschlossen")
        progress.close(1.3)
        return 0
    except Exception as exc:
        append_log(log_path, "Update fehlgeschlagen: " + repr(exc))
        append_log(log_path, traceback.format_exc())
        try:
            progress.update(88, "Fehler - alte Version wird wiederhergestellt ...")
            restore_backup(tool_root, backup_dir, replace_paths, log_path)
            if hasattr(os, "sync"):
                os.sync()
        except Exception as restore_exc:
            append_log(log_path, "Rollback fehlgeschlagen: " + repr(restore_exc))
        progress.update(100, "Update fehlgeschlagen - siehe Log")
        progress.close(6.0)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
'''
    write_text_durable(script_path, installer_script)
    write_json_atomic(config_path, config)
    try:
        script_path.chmod(0o755)
    except OSError:
        pass
    return {
        "script_path": str(script_path),
        "config_path": str(config_path),
        "target_version": target_version,
    }


def set_system_utc_time(timestamp: int, debug_lines: list[str] | None = None) -> bool:
    if timestamp < 1_700_000_000 or timestamp > 2_100_000_000:
        if debug_lines is not None:
            append_network_debug(debug_lines, f"time sync ignored implausible timestamp: {timestamp}")
        return False
    date_cmd = find_executable("date")
    if not date_cmd:
        if debug_lines is not None:
            append_network_debug(debug_lines, "time sync failed: date command missing")
        return False
    try:
        result = subprocess.run(
            [date_cmd, "-u", "-s", f"@{timestamp}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=4,
            check=False,
        )
        output = (result.stdout or "").strip()
        ok = result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        output = str(exc)
        ok = False
    if debug_lines is not None:
        stamp = datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc).isoformat()
        append_network_debug(debug_lines, f"time sync set {stamp}: {output or ('ok' if ok else 'failed')}")
    return ok


def ntp_timestamp(host: str, timeout: float = 3.0) -> int | None:
    packet = b"\x1b" + (b"\0" * 47)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(timeout)
            sock.sendto(packet, (host, 123))
            data, _ = sock.recvfrom(48)
    except OSError:
        return None
    if len(data) < 48:
        return None
    seconds = struct.unpack("!I", data[40:44])[0]
    return int(seconds - 2_208_988_800)


def http_date_timestamp(host: str, timeout: float = 3.0) -> int | None:
    request = f"HEAD / HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n".encode("ascii")
    try:
        with socket.create_connection((host, 80), timeout=timeout) as sock:
            sock.settimeout(timeout)
            sock.sendall(request)
            data = sock.recv(4096).decode("iso-8859-1", errors="ignore")
    except OSError:
        return None
    for line in data.splitlines():
        if not line.lower().startswith("date:"):
            continue
        try:
            parsed = email.utils.parsedate_to_datetime(line.split(":", 1)[1].strip())
        except (TypeError, ValueError):
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=datetime.timezone.utc)
        return int(parsed.timestamp())
    return None


def sync_system_time_from_network(debug_lines: list[str], status_callback=None) -> bool:
    if sys.platform != "linux":
        return False
    if status_callback is not None:
        status_callback("online", "synchronisiere Uhr")
    append_network_debug(debug_lines, f"time before sync: {time.strftime('%Y-%m-%dT%H:%M:%S')}")

    for host in ["time.cloudflare.com", "time.google.com", "pool.ntp.org", "162.159.200.1", "216.239.35.0"]:
        timestamp = ntp_timestamp(host)
        if timestamp and set_system_utc_time(timestamp, debug_lines):
            append_network_debug(debug_lines, f"time sync ok via NTP {host}")
            return True
        append_network_debug(debug_lines, f"time sync NTP failed: {host}")

    for host in ["example.com", "neverssl.com", "google.com"]:
        timestamp = http_date_timestamp(host)
        if timestamp and set_system_utc_time(timestamp, debug_lines):
            append_network_debug(debug_lines, f"time sync ok via HTTP Date {host}")
            return True
        append_network_debug(debug_lines, f"time sync HTTP Date failed: {host}")

    append_network_debug(debug_lines, "time sync failed: all methods failed")
    return False


def is_certificate_time_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    return (
        "certificate_verify_failed" in text
        or "certificate verify failed" in text
        or "certificate is not yet valid" in text
        or "certificate has expired" in text
    )


def find_executable(*names: str) -> str:
    search_paths = os.environ.get("PATH", "").split(os.pathsep) + ["/usr/sbin", "/sbin", "/usr/bin", "/bin"]
    for name in names:
        found = shutil.which(name)
        if found:
            return found
        for directory in search_paths:
            candidate = pathlib.Path(directory) / name
            if candidate.exists() and os.access(candidate, os.X_OK):
                return str(candidate)
    return ""


def run_quiet_timeout(args: list[str], timeout: int = 8) -> bool:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def run_debug_command(args: list[str], timeout: int = 5) -> str:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return str(exc)
    return (result.stdout or "").strip()


def is_wifi_interface(name: str) -> bool:
    return (pathlib.Path("/sys/class/net") / name / "wireless").exists()


def list_network_interfaces(wifi: bool) -> list[str]:
    root = pathlib.Path("/sys/class/net")
    if not root.exists():
        return []
    names: list[str] = []
    for path in sorted(root.iterdir()):
        name = path.name
        if name == "lo":
            continue
        if is_wifi_interface(name) == wifi:
            names.append(name)
    return names


def interface_operstate(name: str) -> str:
    return read_text(pathlib.Path("/sys/class/net") / name / "operstate") or "unknown"


def interface_carrier(name: str) -> str:
    carrier_path = pathlib.Path("/sys/class/net") / name / "carrier"
    if not carrier_path.exists():
        return "unknown"
    return read_text(carrier_path) or "unknown"


def wait_for_wired_link(interface: str, timeout: float = 3.0) -> bool:
    carrier_path = pathlib.Path("/sys/class/net") / interface / "carrier"
    if not carrier_path.exists():
        return True
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if read_text(carrier_path) == "1":
            return True
        time.sleep(0.3)
    return read_text(carrier_path) == "1"


def wifi_country() -> str:
    country = str(load_settings().get("wifi_country") or DEFAULT_WIFI_COUNTRY).strip().upper()
    return country if re.fullmatch(r"[A-Z]{2}", country) else DEFAULT_WIFI_COUNTRY


def unblock_wifi_radios(debug_lines: list[str] | None = None) -> None:
    rfkill = find_executable("rfkill")
    if rfkill:
        append_network_debug(debug_lines or [], "rfkill unblock wifi")
        run_quiet_timeout([rfkill, "unblock", "wifi"], timeout=3)
    for rfkill_type in pathlib.Path("/sys/class/rfkill").glob("rfkill*/type"):
        if read_text(rfkill_type).lower() not in {"wlan", "wifi"}:
            continue
        soft = rfkill_type.parent / "soft"
        try:
            if soft.exists():
                soft.write_text("0\n", encoding="ascii")
                if debug_lines is not None:
                    append_network_debug(debug_lines, f"sysfs rfkill unblock: {rfkill_type.parent.name}")
        except OSError as exc:
            if debug_lines is not None:
                append_network_debug(debug_lines, f"sysfs rfkill unblock failed: {exc}")


def set_wifi_country(debug_lines: list[str] | None = None) -> None:
    iw = find_executable("iw")
    if not iw:
        return
    country = wifi_country()
    output = run_debug_command([iw, "reg", "set", country], timeout=3)
    if debug_lines is not None:
        append_network_debug(debug_lines, f"iw reg set {country}: {output or 'ok'}")


def prepare_wifi_interface(interface: str, debug_lines: list[str] | None = None) -> None:
    ip_cmd = find_executable("ip")
    iw = find_executable("iw")
    unblock_wifi_radios(debug_lines)
    set_wifi_country(debug_lines)
    if ip_cmd:
        down = run_debug_command([ip_cmd, "link", "set", interface, "down"], timeout=2)
        up = run_debug_command([ip_cmd, "link", "set", interface, "up"], timeout=4)
        if debug_lines is not None:
            append_network_debug(debug_lines, f"ip link reset {interface}: down={down or 'ok'} up={up or 'ok'}")
    if iw:
        run_quiet_timeout([iw, "dev", interface, "set", "power_save", "off"], timeout=2)
    time.sleep(0.8)
    if debug_lines is not None:
        append_network_debug(
            debug_lines,
            f"{interface} state after prepare: oper={interface_operstate(interface)} carrier={interface_carrier(interface)}",
        )


def wifi_associated(interface: str, ctrl_dir: str = "/tmp") -> bool:
    wpa_cli = find_executable("wpa_cli")
    if wpa_cli:
        status = run_debug_command([wpa_cli, "-p", ctrl_dir, "-i", interface, "status"], timeout=2)
        if "wpa_state=COMPLETED" in status:
            return True
    iw = find_executable("iw")
    if iw:
        link = run_debug_command([iw, "dev", interface, "link"], timeout=2)
        if "Connected to" in link:
            return True
    return False


def wait_for_wifi_association(interface: str, ctrl_dir: str = "/tmp", timeout: float = 12.0) -> bool:
    if not find_executable("wpa_cli") and not find_executable("iw"):
        time.sleep(min(timeout, 7.0))
        return True
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if wifi_associated(interface, ctrl_dir):
            return True
        time.sleep(0.5)
    return wifi_associated(interface, ctrl_dir)


def append_network_debug(debug_lines: list[str], text: str) -> None:
    stamp = time.strftime("%H:%M:%S")
    debug_lines.append(f"[{stamp}] {text}")


def write_network_update_debug(ok: bool, message: str, debug_lines: list[str]) -> None:
    if sys.platform != "linux":
        return
    if ok and os.environ.get("HC_DEBUG") != "1":
        return
    sections = [
        f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
        f"ok={ok}",
        f"message={message}",
        f"version={APP_VERSION}",
        "",
        "=== attempts ===",
        "\n".join(debug_lines) or "no attempts recorded",
        "",
        "=== tools ===",
    ]
    for tool in ["ip", "dhcpcd", "dhclient", "wpa_supplicant", "wpa_cli", "iw", "rfkill", "lspci", "lsusb"]:
        sections.append(f"{tool}={find_executable(tool) or 'missing'}")
    commands = [
        ("ip -br link", ["sh", "-c", "ip -br link 2>&1 || true"]),
        ("ip -br addr", ["sh", "-c", "ip -br addr 2>&1 || true"]),
        ("ip route", ["sh", "-c", "ip route 2>&1 || true"]),
        ("resolv.conf", ["sh", "-c", "cat /etc/resolv.conf 2>&1 || true"]),
        ("rfkill", ["sh", "-c", "rfkill list 2>&1 || true"]),
        ("iw dev", ["sh", "-c", "iw dev 2>&1 || true"]),
        (
            "sysfs net",
            [
                "sh",
                "-c",
                "for i in /sys/class/net/*; do n=${i##*/}; echo \"$n carrier=$(cat $i/carrier 2>/dev/null) oper=$(cat $i/operstate 2>/dev/null) wifi=$([ -d $i/wireless ] && echo yes || echo no)\"; done",
            ],
        ),
        (
            "wifi scan",
            [
                "sh",
                "-c",
                "for i in /sys/class/net/*; do n=${i##*/}; [ -d $i/wireless ] || continue; echo \"--- $n scan ---\"; ip link set $n up 2>/dev/null; iw dev $n scan 2>&1 | grep -E 'SSID:|signal:' | head -n 40; done",
            ],
        ),
        ("lspci network", ["sh", "-c", "lspci -nnk 2>&1 | grep -A4 -Ei 'network|ethernet|wireless|wifi' || true"]),
        ("lsusb", ["sh", "-c", "lsusb 2>&1 || true"]),
        (
            "dmesg network",
            [
                "sh",
                "-c",
                "dmesg 2>&1 | grep -Ei 'firmware|wifi|wlan|wireless|iwlwifi|rtw|rtl|ath|mt76|brcm|r8169|igc|e1000|ethernet|enp|wlp' | tail -n 140 || true",
            ],
        ),
    ]
    for title, command in commands:
        sections.extend(["", f"=== {title} ===", run_debug_command(command, timeout=8)])
    text = "\n".join(sections).rstrip() + "\n"
    for root in find_debug_roots():
        try:
            write_text_durable(root / "hardwarecheck-debug" / "network-update.txt", text)
        except OSError:
            pass


def load_wifi_networks(debug_lines: list[str] | None = None) -> list[dict[str, str]]:
    path = get_wifi_networks_path()
    if debug_lines is not None:
        append_network_debug(debug_lines, f"WLAN-Datei: {path} exists={path.is_file()}")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        if debug_lines is not None:
            append_network_debug(debug_lines, f"WLAN-Datei nicht lesbar: {exc}")
        return []
    if isinstance(data, dict):
        raw_networks = data.get("wifi_networks") or data.get("networks") or []
    else:
        raw_networks = data
    networks: list[dict[str, str]] = []
    if isinstance(raw_networks, list):
        for item in raw_networks:
            if not isinstance(item, dict):
                continue
            ssid = str(item.get("ssid") or "").strip()
            password = str(item.get("password") or item.get("psk") or "")
            if ssid and password:
                networks.append({"ssid": ssid, "password": password})
    if debug_lines is not None:
        append_network_debug(debug_lines, f"WLAN-Netze geladen: {len(networks)}")
    return networks


def saved_wifi_passwords() -> dict[str, str]:
    return {network["ssid"]: network["password"] for network in load_wifi_networks()}


def save_wifi_network(ssid: str, password: str) -> None:
    ssid = ssid.strip()
    if not ssid:
        raise ValueError("SSID fehlt")
    password = password.strip()
    if not password:
        raise ValueError("Passwort fehlt")
    networks = load_wifi_networks()
    updated = [{"ssid": ssid, "password": password}]
    for network in networks:
        if network["ssid"] != ssid:
            updated.append(network)
    write_json_atomic(get_wifi_networks_path(), {"wifi_networks": updated})


def parse_iw_scan(output: str, interface: str) -> list[dict[str, str]]:
    networks: list[dict[str, str]] = []
    current_signal = ""
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if line.startswith("BSS "):
            current_signal = ""
        elif line.startswith("signal:"):
            current_signal = line.split(":", 1)[1].strip()
        elif line.startswith("SSID:"):
            ssid = line.split(":", 1)[1].strip()
            if ssid:
                networks.append({"ssid": ssid, "signal": current_signal, "interface": interface})
    return networks


def parse_iwlist_scan(output: str, interface: str) -> list[dict[str, str]]:
    networks: list[dict[str, str]] = []
    current_signal = ""
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if "Signal level=" in line:
            current_signal = line.split("Signal level=", 1)[1].split()[0].strip()
        match = re.search(r'ESSID:"(.*)"', line)
        if match:
            ssid = match.group(1).strip()
            if ssid:
                networks.append({"ssid": ssid, "signal": current_signal, "interface": interface})
    return networks


def wifi_signal_sort_value(value: str) -> float:
    match = re.search(r"-?\d+(?:\.\d+)?", value or "")
    if not match:
        return -999.0
    try:
        return float(match.group(0))
    except ValueError:
        return -999.0


def scan_wifi_networks(status_callback=None, debug_lines: list[str] | None = None) -> tuple[list[dict[str, str]], str]:
    if sys.platform != "linux":
        return [], "WLAN-Scan nur unter Linux verfuegbar"
    if debug_lines is None:
        debug_lines = []
    iw = find_executable("iw")
    iwlist = find_executable("iwlist")
    ifaces = list_network_interfaces(wifi=True)
    if not ifaces:
        return [], "Kein WLAN-Adapter gefunden"
    found: dict[str, dict[str, str]] = {}
    for iface in ifaces:
        if status_callback is not None:
            status_callback("searching", f"scanne WLAN {iface}")
        prepare_wifi_interface(iface, debug_lines)
        output = ""
        networks: list[dict[str, str]] = []
        if iw:
            output = run_debug_command([iw, "dev", iface, "scan"], timeout=18)
            networks = parse_iw_scan(output, iface)
        if not networks and iwlist:
            output = run_debug_command([iwlist, iface, "scan"], timeout=18)
            networks = parse_iwlist_scan(output, iface)
        append_network_debug(debug_lines, f"WLAN-Scan {iface}: {len(networks)} Netze")
        for network in networks:
            ssid = network["ssid"]
            old = found.get(ssid)
            if old is None or wifi_signal_sort_value(network.get("signal", "")) > wifi_signal_sort_value(old.get("signal", "")):
                found[ssid] = network
    networks = sorted(found.values(), key=lambda item: wifi_signal_sort_value(item.get("signal", "")), reverse=True)
    if not networks:
        return [], "Keine WLAN-Netze gefunden"
    return networks, f"{len(networks)} WLAN-Netze gefunden"


def wpa_quote(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def wifi_config_variants(network: dict[str, str], ctrl_dir: str) -> list[tuple[str, str]]:
    ssid = wpa_quote(network["ssid"])
    password = wpa_quote(network["password"])
    country = wifi_country()
    base = f"ctrl_interface={ctrl_dir}\nap_scan=1\ncountry={country}\nsae_pwe=2\n"
    wpa3 = (
        base
        + "network={\n"
        f"    ssid={ssid}\n"
        "    scan_ssid=1\n"
        "    key_mgmt=SAE\n"
        "    ieee80211w=2\n"
        f"    sae_password={password}\n"
        "}\n"
    )
    transition = (
        base
        + "network={\n"
        f"    ssid={ssid}\n"
        "    scan_ssid=1\n"
        "    key_mgmt=SAE WPA-PSK\n"
        "    ieee80211w=1\n"
        f"    sae_password={password}\n"
        f"    psk={password}\n"
        "}\n"
    )
    wpa2 = (
        base
        + "network={\n"
        f"    ssid={ssid}\n"
        "    scan_ssid=1\n"
        "    key_mgmt=WPA-PSK\n"
        f"    psk={password}\n"
        "}\n"
    )
    return [("WPA3", wpa3), ("WPA3/WPA2", transition), ("WPA2", wpa2)]


def start_dhcp(interface: str) -> bool:
    dhcpcd = find_executable("dhcpcd")
    if dhcpcd:
        return run_quiet_timeout([dhcpcd, "-4", "-q", "-t", "8", interface], timeout=10)
    dhclient = find_executable("dhclient")
    if dhclient:
        return run_quiet_timeout([dhclient, "-1", interface], timeout=12)
    return False


def stop_dhcp(interface: str) -> None:
    dhcpcd = find_executable("dhcpcd")
    if dhcpcd:
        run_quiet_timeout([dhcpcd, "-k", interface], timeout=3)
    dhclient = find_executable("dhclient")
    if dhclient:
        run_quiet_timeout([dhclient, "-r", interface], timeout=3)


def write_public_dns() -> bool:
    resolv_path = pathlib.Path("/etc/resolv.conf")
    try:
        if resolv_path.is_symlink():
            resolv_path.unlink()
        resolv_path.write_text("nameserver 1.1.1.1\nnameserver 8.8.8.8\n", encoding="ascii")
        return True
    except OSError:
        try:
            if resolv_path.exists() or resolv_path.is_symlink():
                resolv_path.unlink()
            resolv_path.write_text("nameserver 1.1.1.1\nnameserver 8.8.8.8\n", encoding="ascii")
            return True
        except OSError:
            return False


def install_temporary_dns() -> callable:
    resolv_path = pathlib.Path("/etc/resolv.conf")
    backup = b""
    was_symlink = resolv_path.is_symlink()
    symlink_target = ""
    existed = resolv_path.exists()
    try:
        if was_symlink:
            symlink_target = os.readlink(resolv_path)
        backup = resolv_path.read_bytes() if existed else b""
    except OSError:
        pass
    if not write_public_dns():
        return lambda: None

    def restore() -> None:
        try:
            if was_symlink and symlink_target:
                try:
                    resolv_path.unlink()
                except OSError:
                    pass
                resolv_path.symlink_to(symlink_target)
            elif existed:
                resolv_path.write_bytes(backup)
            else:
                resolv_path.unlink(missing_ok=True)
        except OSError:
            pass

    return restore


def interface_has_ipv4(interface: str) -> bool:
    ip_cmd = find_executable("ip")
    if not ip_cmd:
        return False
    try:
        result = subprocess.run(
            [ip_cmd, "-o", "-4", "addr", "show", "dev", interface, "scope", "global"],
            check=False,
            capture_output=True,
            text=True,
            timeout=2,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0 and " inet " in f" {result.stdout} "


def wait_for_ipv4(interface: str, timeout: float = 6.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if interface_has_ipv4(interface):
            return True
        time.sleep(0.4)
    return interface_has_ipv4(interface)


def dns_resolves(host: str = "raw.githubusercontent.com", timeout: float = 6.0) -> bool:
    getent = find_executable("getent")
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if getent:
            try:
                result = subprocess.run(
                    [getent, "hosts", host],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=2,
                )
                if result.returncode == 0:
                    return True
            except (OSError, subprocess.TimeoutExpired):
                pass
        else:
            old_timeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(2)
            try:
                socket.gethostbyname(host)
                return True
            except OSError:
                pass
            finally:
                socket.setdefaulttimeout(old_timeout)
        time.sleep(0.5)
    return False


def wait_for_internet(interface: str) -> tuple[bool, str]:
    write_public_dns()
    if not wait_for_ipv4(interface):
        return False, "keine IPv4-Adresse"
    write_public_dns()
    if not dns_resolves():
        return False, "DNS/Internet nicht erreichbar"
    return True, "ok"


def internet_already_available(timeout: float = 2.5) -> bool:
    write_public_dns()
    return dns_resolves(timeout=timeout)


def connect_temporary_network(status_callback=None, debug_lines: list[str] | None = None) -> tuple[bool, str, callable]:
    if sys.platform != "linux":
        return False, "Netzwerk nur unter Linux verfuegbar", lambda: None
    if debug_lines is None:
        debug_lines = []

    ip_cmd = find_executable("ip")
    wpa_supplicant = find_executable("wpa_supplicant")
    rfkill = find_executable("rfkill")
    started_ifaces: list[str] = []
    processes: list[subprocess.Popen[bytes]] = []
    temp_files: list[pathlib.Path] = []
    temp_dirs: list[pathlib.Path] = []
    restore_dns: callable | None = None
    last_error = ""

    def notify(state: str, message: str) -> None:
        append_network_debug(debug_lines, f"{state}: {message}")
        if status_callback is not None:
            status_callback(state, message)

    def cleanup() -> None:
        if restore_dns is not None:
            restore_dns()
        for iface in started_ifaces:
            stop_dhcp(iface)
        for process in processes:
            try:
                process.terminate()
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    process.kill()
                except OSError:
                    pass
        if ip_cmd:
            for iface in started_ifaces:
                run_quiet_timeout([ip_cmd, "link", "set", iface, "down"], timeout=3)
        for path in temp_files:
            try:
                path.unlink()
            except OSError:
                pass
        for path in temp_dirs:
            try:
                shutil.rmtree(path, ignore_errors=True)
            except OSError:
                pass

    notify("searching", "suche Netzwerk")
    if internet_already_available():
        notify("online", "Internet bereits aktiv")
        return True, "Internet bereits aktiv", lambda: None

    if rfkill:
        run_quiet_timeout([rfkill, "unblock", "wifi"], timeout=3)

    restore_dns = install_temporary_dns()

    if ip_cmd:
        for iface in list_network_interfaces(wifi=False):
            notify("searching", f"teste LAN {iface}")
            run_quiet_timeout([ip_cmd, "link", "set", iface, "up"], timeout=3)
            started_ifaces.append(iface)
            if not wait_for_wired_link(iface):
                last_error = f"LAN {iface}: kein Link/Kabel"
                notify("searching", last_error)
                continue
            stop_dhcp(iface)
            if start_dhcp(iface):
                notify("searching", f"LAN {iface}: pruefe Internet")
                ready, reason = wait_for_internet(iface)
                if ready:
                    notify("online", f"LAN online ({iface})")
                    return True, f"LAN aktiv ({iface})", lambda: None
                last_error = f"LAN {iface}: {reason}"
                notify("searching", last_error)
                stop_dhcp(iface)
            else:
                last_error = f"LAN {iface}: kein DHCP"
                notify("searching", last_error)

    networks = load_wifi_networks(debug_lines)
    if not networks:
        wifi_config_error = f"Keine WLAN-Konfiguration gefunden ({get_wifi_networks_path()})"
        notify("error", f"{last_error} | {wifi_config_error}" if last_error else wifi_config_error)
        return False, f"{last_error} | {wifi_config_error}" if last_error else wifi_config_error, cleanup
    if not ip_cmd or not wpa_supplicant:
        notify("error", last_error or "WLAN-Tools fehlen")
        return False, last_error or "WLAN-Tools fehlen", cleanup

    wifi_ifaces = list_network_interfaces(wifi=True)
    if not wifi_ifaces:
        wifi_error = "WLAN nicht gefunden (Treiber/Firmware?)"
        notify("error", f"{last_error} | {wifi_error}" if last_error else wifi_error)
        return False, f"{last_error} | {wifi_error}" if last_error else wifi_error, cleanup

    for iface in wifi_ifaces:
        prepare_wifi_interface(iface, debug_lines)
        started_ifaces.append(iface)
        for network in networks:
            for mode in ["WPA3", "WPA3/WPA2", "WPA2"]:
                notify("searching", f"teste WLAN {network['ssid']} ({mode})")
                stop_dhcp(iface)
                prepare_wifi_interface(iface, debug_lines)
                config_path: pathlib.Path | None = None
                ctrl_dir_path: pathlib.Path | None = None
                log_path: pathlib.Path | None = None
                log_handle = None
                process: subprocess.Popen[bytes] | None = None
                keep_connection = False
                try:
                    ctrl_dir_path = pathlib.Path(tempfile.mkdtemp(prefix=f"hc_wpa_{iface}_"))
                    temp_dirs.append(ctrl_dir_path)
                    config = dict(wifi_config_variants(network, str(ctrl_dir_path)))[mode]
                    handle = tempfile.NamedTemporaryFile("w", encoding="utf-8", prefix="hc_wifi_", suffix=".conf", delete=False)
                    with handle:
                        handle.write(config)
                    config_path = pathlib.Path(handle.name)
                    temp_files.append(config_path)
                    log_file = tempfile.NamedTemporaryFile("w+", encoding="utf-8", prefix="hc_wpa_", suffix=".log", delete=False)
                    log_path = pathlib.Path(log_file.name)
                    temp_files.append(log_path)
                    log_handle = log_file
                    process = subprocess.Popen(
                        [wpa_supplicant, "-D", "nl80211,wext", "-i", iface, "-c", str(config_path)],
                        stdout=log_handle,
                        stderr=subprocess.STDOUT,
                    )
                    processes.append(process)
                    if not wait_for_wifi_association(iface, str(ctrl_dir_path)):
                        last_error = f"WLAN {iface}/{network['ssid']} ({mode}): keine Verbindung"
                        if find_executable("wpa_cli"):
                            append_network_debug(
                                debug_lines,
                                "wpa_cli status: " + run_debug_command([find_executable("wpa_cli"), "-p", str(ctrl_dir_path), "-i", iface, "status"], timeout=2),
                            )
                        if find_executable("iw"):
                            append_network_debug(
                                debug_lines,
                                "iw link: " + run_debug_command([find_executable("iw"), "dev", iface, "link"], timeout=2),
                            )
                        notify("searching", last_error)
                    elif start_dhcp(iface):
                        notify("searching", f"WLAN {network['ssid']}: pruefe Internet")
                        ready, reason = wait_for_internet(iface)
                        if ready:
                            notify("online", f"WLAN online ({network['ssid']})")
                            keep_connection = True
                            return True, f"WLAN aktiv ({iface}, {network['ssid']})", lambda: None
                        last_error = f"WLAN {iface}/{network['ssid']}: {reason}"
                        notify("searching", last_error)
                        stop_dhcp(iface)
                    else:
                        last_error = f"WLAN {iface}/{network['ssid']} ({mode}): kein DHCP"
                        notify("searching", last_error)
                except OSError as exc:
                    last_error = f"WLAN {iface}/{network['ssid']} ({mode}): wpa_supplicant startet nicht"
                    append_network_debug(debug_lines, f"{last_error}: {exc}")
                    notify("searching", last_error)
                finally:
                    if process is not None and not keep_connection:
                        try:
                            process.terminate()
                            process.wait(timeout=2)
                        except (OSError, subprocess.TimeoutExpired):
                            try:
                                process.kill()
                            except OSError:
                                pass
                        if process in processes:
                            processes.remove(process)
                    if log_handle is not None:
                        try:
                            log_handle.flush()
                            log_handle.close()
                        except OSError:
                            pass
                    if log_path is not None:
                        try:
                            log_text = log_path.read_text(encoding="utf-8", errors="ignore")
                            if log_text.strip():
                                tail = "\n".join(log_text.strip().splitlines()[-30:])
                                append_network_debug(debug_lines, f"wpa_supplicant log {network['ssid']} ({mode}):\n{tail}")
                        except OSError:
                            pass
                    if not keep_connection:
                        if config_path is not None:
                            try:
                                config_path.unlink()
                            except OSError:
                                pass
                        if log_path is not None:
                            try:
                                log_path.unlink()
                            except OSError:
                                pass
                        if ctrl_dir_path is not None:
                            try:
                                shutil.rmtree(ctrl_dir_path, ignore_errors=True)
                            except OSError:
                                pass
    notify("error", last_error or "Kein Netzwerk verbunden")
    return False, last_error or "Kein Netzwerk verbunden", cleanup


def backup_current_model(model_path: pathlib.Path, version: str) -> None:
    if not model_path.is_file():
        return
    backup_dir = get_model_backup_dir()
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    safe_version = sanitize_filename(version or "unknown")
    target = backup_dir / f"model_{stamp}_{safe_version}.json"
    try:
        shutil.copy2(model_path, target)
    except OSError:
        return
    backups = sorted(backup_dir.glob("model_*.json"), key=lambda path: path.stat().st_mtime, reverse=True)
    for old in backups[3:]:
        try:
            old.unlink()
        except OSError:
            pass


def run_model_database_update(status_callback=None) -> tuple[bool, str]:
    settings = load_settings()
    token = str(settings.get("github_token") or "").strip()
    manifest_url = str(settings.get("model_manifest_url") or DEFAULT_MODEL_MANIFEST_URL).strip()
    database_url_default = str(settings.get("model_database_url") or DEFAULT_MODEL_DATABASE_URL).strip()
    debug_lines: list[str] = []

    def complete(ok: bool, message: str) -> tuple[bool, str]:
        write_network_update_debug(ok, message, debug_lines)
        return ok, message

    connected, network_message, cleanup = connect_temporary_network(status_callback, debug_lines)
    if not connected:
        message = f"Model-Update: {network_message}"
        write_network_update_debug(False, message, debug_lines)
        cleanup()
        return False, message

    try:
        write_public_dns()
        sync_system_time_from_network(debug_lines, status_callback)
        if status_callback is not None:
            status_callback("online", "lade Manifest")
        remote_manifest_raw = download_json(manifest_url, token=token)
        if not isinstance(remote_manifest_raw, dict):
            return complete(False, "Model-Update: Manifest ungueltig")
        remote_manifest: dict[str, object] = remote_manifest_raw
        local_manifest = load_local_model_manifest()
        remote_version = manifest_value(remote_manifest, "version", "db_version", "database_version")
        local_version = manifest_value(local_manifest, "version", "db_version", "database_version")
        remote_sha = manifest_value(remote_manifest, "sha256", "model_sha256", "database_sha256")
        database_url = manifest_value(remote_manifest, "database_url", "model_url", "raw_database_url") or database_url_default
        model_path = get_models_path()
        current_sha = hashlib.sha256(model_path.read_bytes()).hexdigest() if model_path.is_file() else ""
        if remote_sha and current_sha.lower() == remote_sha.lower() and not version_is_newer(remote_version, local_version):
            write_json_atomic(get_model_manifest_local_path(), remote_manifest)
            return complete(True, f"Model-Update: aktuell ({remote_version or 'ok'})")
        if remote_version and local_version and not version_is_newer(remote_version, local_version) and not remote_sha:
            return complete(True, f"Model-Update: aktuell ({remote_version})")

        if status_callback is not None:
            status_callback("online", "lade model.json")
        write_public_dns()
        payload = download_bytes(database_url, token=token)
        if remote_sha:
            payload_sha = hashlib.sha256(payload).hexdigest()
            if payload_sha.lower() != remote_sha.lower():
                return complete(False, "Model-Update: SHA256 passt nicht")
        try:
            database = json.loads(payload.decode("utf-8-sig"))
        except json.JSONDecodeError:
            return complete(False, "Model-Update: model.json ist ungueltig")
        if not isinstance(database, list) or not all(isinstance(item, dict) for item in database):
            return complete(False, "Model-Update: model.json ist keine Modell-Liste")

        backup_current_model(model_path, local_version or "old")
        write_bytes_atomic(model_path, payload)
        write_json_atomic(get_model_manifest_local_path(), remote_manifest)
        return complete(True, f"Model-Update: {len(database)} Modelle geladen ({remote_version or 'GitHub'})")
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, socket.gaierror):
            return complete(False, "Model-Update: DNS-Aufloesung fehlgeschlagen")
        if isinstance(reason, TimeoutError):
            return complete(False, "Model-Update: Verbindung zu GitHub dauert zu lange")
        if is_certificate_time_error(exc):
            return complete(False, "Model-Update: Uhrzeit/Zertifikat falsch")
        return complete(False, f"Model-Update: GitHub nicht erreichbar ({reason})")
    except TimeoutError:
        return complete(False, "Model-Update: Verbindung zu GitHub dauert zu lange")
    except OSError as exc:
        return complete(False, f"Model-Update: Netzwerk/Datei-Fehler ({exc})")
    except json.JSONDecodeError:
        return complete(False, "Model-Update: Antwort von GitHub ungueltig")
    finally:
        cleanup()


def run_hardwarecheck_update_check(status_callback=None) -> tuple[bool, str, dict[str, str] | None]:
    settings = load_settings()
    token = str(settings.get("github_token") or "").strip()
    manifest_url = str(
        settings.get("hardwarecheck_update_manifest_url") or DEFAULT_HARDWARECHECK_UPDATE_MANIFEST_URL
    ).strip()
    debug_lines: list[str] = []

    def complete(ok: bool, message: str, install_request: dict[str, str] | None = None) -> tuple[bool, str, dict[str, str] | None]:
        write_network_update_debug(ok, message, debug_lines)
        return ok, message, install_request

    connected, network_message, cleanup = connect_temporary_network(status_callback, debug_lines)
    if not connected:
        message = f"Programm-Update: {network_message}"
        write_network_update_debug(False, message, debug_lines)
        cleanup()
        return False, message, None

    try:
        write_public_dns()
        sync_system_time_from_network(debug_lines, status_callback)
        if status_callback is not None:
            status_callback("online", "lade Programm-Manifest")
        raw_manifest = download_json(manifest_url, token=token)
        if not isinstance(raw_manifest, dict):
            return complete(False, "Programm-Update: Manifest ungueltig")
        app_name = manifest_value(raw_manifest, "app", "name", "product")
        if app_name and app_name.lower() != "hardwarecheck":
            return complete(False, f"Programm-Update: falsches Paket ({app_name})")
        remote_version = manifest_value(raw_manifest, "version", "app_version")
        download_url = manifest_value(raw_manifest, "download_url", "url")
        remote_sha = manifest_value(raw_manifest, "sha256")
        if not remote_version:
            return complete(False, "Programm-Update: Version fehlt")
        if not download_url:
            return complete(False, "Programm-Update: Download-URL fehlt")
        if not remote_sha:
            return complete(False, "Programm-Update: SHA256 fehlt")
        local_version = normalized_app_version()
        if version_is_newer(remote_version, local_version):
            if status_callback is not None:
                status_callback("online", "lade Programm-ZIP")
            payload = download_bytes(download_url, token=token)
            payload_sha = hashlib.sha256(payload).hexdigest()
            if payload_sha.lower() != remote_sha.lower():
                return complete(False, "Programm-Update: SHA256 passt nicht")
            download_dir = get_update_download_dir()
            download_dir.mkdir(parents=True, exist_ok=True)
            safe_version = sanitize_filename(remote_version)
            fallback_name = f"HardwareCheck_update_{safe_version}.zip"
            target = download_dir / filename_from_url(download_url, fallback_name)
            write_bytes_atomic(target, payload)
            if status_callback is not None:
                status_callback("online", "pruefe Programm-ZIP")
            staging_root = get_update_staging_dir()
            staging_dir = staging_root / safe_version
            if staging_dir.exists():
                shutil.rmtree(staging_dir, ignore_errors=True)
            staging_dir.mkdir(parents=True, exist_ok=True)
            try:
                safe_extract_zip(target, staging_dir)
            except (OSError, ValueError, zipfile.BadZipFile):
                return complete(False, "Programm-Update: ZIP ungueltig")
            package_ok, package_message = validate_hardwarecheck_update_package(staging_dir)
            if not package_ok:
                return complete(False, f"Programm-Update: {package_message}")
            install_request = write_hardwarecheck_update_installer(staging_dir, remote_version)
            return complete(
                True,
                f"Programm-Update bereit: {remote_version} | {package_message}",
                install_request,
            )
        return complete(True, f"Programm-Update: aktuell ({APP_VERSION})")
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, socket.gaierror):
            return complete(False, "Programm-Update: DNS-Aufloesung fehlgeschlagen")
        if isinstance(reason, TimeoutError):
            return complete(False, "Programm-Update: Verbindung zu GitHub dauert zu lange")
        if is_certificate_time_error(exc):
            return complete(False, "Programm-Update: Uhrzeit/Zertifikat falsch")
        return complete(False, f"Programm-Update: GitHub nicht erreichbar ({reason})")
    except TimeoutError:
        return complete(False, "Programm-Update: Verbindung zu GitHub dauert zu lange")
    except OSError as exc:
        return complete(False, f"Programm-Update: Netzwerk/Datei-Fehler ({exc})")
    except json.JSONDecodeError:
        return complete(False, "Programm-Update: Antwort von GitHub ungueltig")
    finally:
        cleanup()


def load_language_index() -> int:
    language = str(load_settings().get("language") or "DE").upper()
    return LANGUAGES.index(language) if language in LANGUAGES else 0


def save_language(language: str) -> None:
    settings = load_settings()
    settings["language"] = language
    save_settings(settings)


def get_input_summary() -> str:
    input_root = pathlib.Path("/dev/input")
    events = sorted(input_root.glob("event*")) if input_root.exists() else []
    names = []
    for name_file in sorted(pathlib.Path("/sys/class/input").glob("event*/device/name")):
        name = read_text(name_file)
        if name:
            names.append(name[:24])
    if not events:
        return "Input: 0 events"
    suffix = ", ".join(names[:2])
    if len(names) > 2:
        suffix += f" +{len(names) - 2}"
    return f"Input: {len(events)} events" + (f" ({suffix})" if suffix else "")


def to_int(value: str) -> int | None:
    match = re.search(r"(\d+)", value or "")
    return int(match.group(1)) if match else None


def normalize_generic_token(value: str) -> str:
    return re.sub(r"\s+", "", (value or "").lower().replace("gb", ""))


PRODUCT_NUMBER_RE = re.compile(
    r"\b(?=[a-z0-9#-]{5,}\b)(?=[a-z0-9#-]*\d)(?=[a-z0-9#-]*[a-z])[a-z0-9]+(?:#[a-z0-9]+)?\b",
    re.IGNORECASE,
)


def product_number_variants(value: object) -> list[str]:
    text = str(value or "").casefold().replace("-", "").replace("_", " ")
    values: list[str] = []

    def add(candidate: str) -> None:
        candidate = candidate.strip().strip("#")
        if len(candidate) >= 5 and candidate not in values:
            values.append(candidate)

    for match in PRODUCT_NUMBER_RE.findall(text):
        candidate = match.strip("#")
        add(candidate)
        if "#" in candidate:
            add(candidate.split("#", 1)[0])

    return values


def row_product_numbers(row: dict[str, object]) -> list[str]:
    values: list[str] = []
    sources = (
        row.get("product_number", ""),
        row.get("product_number_2", ""),
        row.get("product_no", ""),
        row.get("note", ""),
    )
    for source in sources:
        for candidate in product_number_variants(source):
            if candidate not in values:
                values.append(candidate)
    return values


def snapshot_product_numbers(snapshot: dict[str, object]) -> list[str]:
    values: list[str] = []
    sources = (
        snapshot.get("product_no", ""),
        snapshot.get("model_name", ""),
        snapshot.get("product_version", ""),
    )
    for source in sources:
        for candidate in product_number_variants(source):
            if candidate not in values:
                values.append(candidate)
    return values


def product_number_matches(snapshot: dict[str, object], item: dict[str, object]) -> bool:
    hw_product_numbers = set(snapshot_product_numbers(snapshot))
    db_product_numbers = set(row_product_numbers(item))
    return bool(hw_product_numbers and db_product_numbers and hw_product_numbers.intersection(db_product_numbers))


def normalize_cpu_token(value: str) -> str:
    raw = (value or "").lower()
    patterns = [
        r"n\d{4}",
        r"n\d{3}",
        r"core\s+ultra\s+[3579]\s+\d{3,4}[a-z0-9-]*",
        r"core\s+[3579]\s+\d{3,4}[a-z0-9-]*",
        r"i[3579][- ]?\d{4,5}[a-z0-9-]*",
        r"ryzen\s+[3579]\s+\d{4}[a-z0-9]*",
        r"athlon\s+silver\s+\d{4}u",
        r"athlon\s+\d{4}u",
        r"u300",
        r"7220u",
        r"7520u",
        r"5825u",
        r"7730u",
        r"5300u",
        r"5625u",
        r"7530u",
        r"n100",
        r"n200",
        r"n305",
    ]
    for pattern in patterns:
        match = re.search(pattern, raw)
        if match:
            return re.sub(r"[^a-z0-9]", "", match.group(0))
    return re.sub(r"[^a-z0-9]", "", raw)


def vendor_short(value: str) -> str:
    lowered = (value or "").lower()
    known = {
        "lenovo": "Lenovo",
        "hp": "HP",
        "asus": "Asus",
        "acer": "Acer",
        "dell": "Dell",
    }
    for key, label in known.items():
        if key in lowered:
            return label
    return value.strip() or "Unbekannt"


def get_cpu_short(full_cpu: str) -> str:
    patterns = [
        r"N\d{3,4}",
        r"(?:Intel\s+)?Core\s+Ultra\s+[3579]\s+\d{3,4}[A-Z0-9-]*",
        r"(?:Intel\s+)?Core\s+[3579]\s+\d{3,4}[A-Z0-9-]*",
        r"i[3579]-\d{4,5}[A-Z0-9-]*",
        r"i[3579]\s+\d{4,5}[A-Z0-9-]*",
        r"Ryzen\s+[3579]\s+\d{4}[A-Z0-9]*",
        r"Athlon\s+Silver\s+\d{4}U",
    ]
    for pattern in patterns:
        match = re.search(pattern, full_cpu or "", flags=re.IGNORECASE)
        if match:
            value = re.sub(r"^Intel\s+", "", match.group(0), flags=re.IGNORECASE)
            return re.sub(r"\s+", " ", value).strip()
    return " ".join((full_cpu or "").split()[:2]).strip() or full_cpu or "Unknown CPU"


def report_basename(snapshot: dict[str, object]) -> str:
    vendor = str(snapshot.get("vendor_short") or snapshot.get("vendor") or "Unknown").strip()
    cpu = str(snapshot.get("cpu_short") or get_cpu_short(str(snapshot.get("cpu") or ""))).strip()
    cpu = re.sub(r"^Intel\s+", "", cpu, flags=re.IGNORECASE)
    cpu = re.sub(r"\bi([3579])[-\s]+(\d{4,5}[A-Z0-9-]*)\b", r"i\1 \2", cpu, flags=re.IGNORECASE)
    return sanitize_filename(f"{vendor} {cpu}".strip())


def storage_family(value: str) -> str:
    token = normalize_generic_token(value)
    if "nvme" in token or token == "ssd":
        return "ssd"
    if "ssd" in token:
        return "ssd"
    if "hdd" in token:
        return "hdd"
    if "emmc" in token:
        return "emmc"
    return token


def clean_storage_model(model: object, vendor: object = "") -> str:
    text = re.sub(r"\s+", " ", str(model or "")).strip()
    vendor_text = re.sub(r"\s+", " ", str(vendor or "")).strip()
    if not text:
        return vendor_text

    generic_vendors = {"ata", "nvme", "usb", "scsi", "sata"}
    if vendor_text and vendor_text.lower() not in generic_vendors:
        if vendor_text.lower() not in text.lower():
            text = f"{vendor_text} {text}".strip()

    replacements = [
        (r"^SMI\s+", "Silicon Motion SMI "),
        (r"^WDC\s+", "Western Digital WDC "),
        (r"^WD\s+", "Western Digital WD "),
        (r"^SKHYNIX\s+", "SK hynix "),
        (r"^KBG", "Kioxia KBG"),
        (r"^ST(?=\d)", "Seagate ST"),
    ]
    for pattern, replacement in replacements:
        if re.search(pattern, text, flags=re.IGNORECASE):
            text = re.sub(pattern, replacement, text, count=1, flags=re.IGNORECASE)
            break
    if re.search(r"SSD_M\.2_512GB_In", text, flags=re.IGNORECASE):
        text = "SSD_M.2_512GB_Inovation IT"
    return re.sub(r"\s+", " ", text).strip()


def same_or_empty(left: str, right: str) -> bool:
    if not left or not right:
        return True
    return normalize_generic_token(left) == normalize_generic_token(right)


def normalize_ram_layout_token(value: str) -> str:
    text = normalize_generic_token(value)
    parts: list[int] = []
    for count_text, size_text in re.findall(r"(\d+)x(\d+)", text):
        count = int(count_text)
        size = int(size_text)
        parts.extend([size] * max(0, min(count, 8)))
    if not parts:
        parts = [int(number) for number in re.findall(r"\d+", text)]
    return "+".join(str(size) for size in sorted(parts))


def same_ram_layout_or_empty(left: str, right: str) -> bool:
    if not left or not right:
        return True
    left_token = normalize_ram_layout_token(left)
    right_token = normalize_ram_layout_token(right)
    return bool(left_token and right_token and left_token == right_token)


def normalize_optical_drive(value: str) -> str:
    token = normalize_generic_token(value)
    if token in {"", "0", "none", "no", "notavailable", "n/a", "na", "kein", "keins", "ohne"}:
        return ""
    return token


def compare_inches(left: float | None, right: float | None) -> bool:
    if left is None or right is None:
        return False
    return abs(left - right) <= 0.25


def guess_ram_type_by_speed(max_mhz: int | None) -> str:
    if not max_mhz:
        return ""
    if max_mhz >= 6000:
        return "LPDDR5"
    if max_mhz >= 4800:
        return "DDR5"
    if max_mhz >= 3733:
        return "LPDDR4"
    if max_mhz >= 2666:
        return "DDR4"
    if max_mhz >= 1600:
        return "DDR3"
    return ""


def detect_display_type(resolution: str, oled: bool = False) -> str:
    width = to_int((resolution or "").split("x", 1)[0])
    base = ""
    if width:
        if width >= 3840:
            base = "4K"
        elif width >= 2560:
            base = "QHD"
        elif width >= 1920:
            base = "Full HD"
        elif width >= 1600:
            base = "HD+"
        elif width >= 1280:
            base = "HD"
    if oled and base:
        return f"{base} OLED"
    return base


def is_fallback_resolution(resolution: str) -> bool:
    parts = (resolution or "").strip().split()
    return bool(parts) and parts[0] in {"1024x768", "800x600", "640x480"}


def parse_resolution(value: str) -> tuple[int, int] | None:
    match = re.search(r"\b(\d{3,5})x(\d{3,5})\b", value or "")
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def xrandr_output_name(xrandr_text: str) -> str:
    for line in xrandr_text.splitlines():
        if " connected" in line:
            return line.split()[0]
    for line in xrandr_text.splitlines():
        if line.startswith(("default ", "None-")):
            return line.split()[0]
    return ""


def try_apply_native_xrandr_mode(snapshot: dict[str, object]) -> bool:
    expected = str(snapshot.get("resolution") or "")
    xorg_resolution = str(snapshot.get("xorg_resolution") or snapshot.get("resolution") or "")
    if not expected or expected == xorg_resolution:
        return False
    if not parse_resolution(expected) or expected not in XRANDR_MODELINES:
        return False

    xrandr_text = run_command("xrandr")
    output = xrandr_output_name(xrandr_text)
    if not output:
        return False

    mode = expected
    if re.search(rf"^\s+{re.escape(expected)}\s", xrandr_text, flags=re.MULTILINE):
        return run_quiet("xrandr", "--output", output, "--mode", mode)

    modeline = XRANDR_MODELINES[expected]
    mode = modeline[0]
    if mode not in xrandr_text:
        run_quiet("xrandr", "--newmode", *modeline)
    run_quiet("xrandr", "--addmode", output, mode)
    return run_quiet("xrandr", "--output", output, "--mode", mode)


def display_inches_number(value: object) -> float | None:
    if isinstance(value, (float, int)):
        return float(value)
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None


def normalize_display_type_for_size(display_type: str, inches: object) -> str:
    diagonal = display_inches_number(inches)
    if normalize_generic_token(display_type) == "hd" and diagonal is not None and diagonal >= 17.0:
        return "HD+"
    return display_type


def expected_resolution_from_display_type(display_type: str, inches: object = None) -> str:
    token = normalize_generic_token(display_type)
    if "4k" in token or "uhd" in token:
        return "3840x2160"
    if "qhd" in token or "wqhd" in token:
        return "2560x1440"
    if "fullhd" in token or token == "fhd":
        return "1920x1080"
    if "hd++" in display_type.lower() or "hdplusplus" in token:
        return "1600x900"
    if "hd+" in display_type.lower() or "hdplus" in token:
        return "1600x900"
    if token == "hd":
        diagonal = display_inches_number(inches)
        if diagonal is not None and diagonal >= 17.0:
            return "1600x900"
        return "1366x768"
    return ""


def nearest_disk_size_gb(size_bytes: int | None) -> int | None:
    if not size_bytes:
        return None
    value = size_bytes / 1_000_000_000
    return min(COMMON_DISK_SIZES, key=lambda candidate: abs(candidate - value))


def nearest_display_size(diagonal_inch: float | None) -> float | None:
    if diagonal_inch is None:
        return None
    nearest = min(COMMON_DISPLAY_SIZES, key=lambda candidate: abs(candidate - diagonal_inch))
    if abs(nearest - diagonal_inch) <= 0.7:
        return nearest
    return round(diagonal_inch, 1)


def get_cpu_name() -> str:
    cpu = run_command("lscpu")
    for line in cpu.splitlines():
        if "Model name:" in line:
            return line.split(":", 1)[1].replace("(R)", "").replace("(TM)", "").strip()

    for line in read_text("/proc/cpuinfo").splitlines():
        if line.lower().startswith("model name"):
            return line.split(":", 1)[1].replace("(R)", "").replace("(TM)", "").strip()

    dmi_cpu = run_command("dmidecode", "-s", "processor-version")
    return dmi_cpu.replace("(R)", "").replace("(TM)", "").strip()


@dataclass
class RamModule:
    locator: str
    size_gb: int
    speed_mhz: int | None
    configured_speed_mhz: int | None
    ram_type: str


def parse_dmidecode_memory() -> tuple[list[RamModule], int]:
    output = run_command("dmidecode", "-t", "memory")
    total_slots = 0
    slot_match = re.search(r"Number Of Devices:\s*(\d+)", output)
    if slot_match:
        total_slots = int(slot_match.group(1))

    blocks = output.split("Memory Device")
    modules: list[RamModule] = []
    for block in blocks:
        size_match = re.search(r"^\s*Size:\s*(.+)$", block, flags=re.MULTILINE)
        if not size_match:
            continue
        size_value = size_match.group(1).strip()
        if "No Module Installed" in size_value:
            continue

        size_number = to_int(size_value)
        if not size_number:
            continue
        size_gb = size_number if "GB" in size_value else math.ceil(size_number / 1024)
        locator = re.search(r"^\s*Locator:\s*(.+)$", block, flags=re.MULTILINE)
        speed = re.search(r"^\s*Speed:\s*(.+)$", block, flags=re.MULTILINE)
        configured = re.search(r"^\s*Configured Memory Speed:\s*(.+)$", block, flags=re.MULTILINE)
        ram_type = re.search(r"^\s*Type:\s*(.+)$", block, flags=re.MULTILINE)
        module = RamModule(
            locator=locator.group(1).strip() if locator else "",
            size_gb=size_gb,
            speed_mhz=to_int(speed.group(1)) if speed else None,
            configured_speed_mhz=to_int(configured.group(1)) if configured else None,
            ram_type=(ram_type.group(1).strip() if ram_type else ""),
        )
        modules.append(module)

    if total_slots <= 0:
        total_slots = len(modules)
    return modules, total_slots


def best_ram_type(modules: list[RamModule]) -> str:
    for module in modules:
        module_type = module.ram_type.upper()
        if "LPDDR5" in module_type:
            return "LPDDR5"
        if "LPDDR4" in module_type:
            return "LPDDR4"
        if "DDR5" in module_type:
            return "DDR5"
        if "DDR4" in module_type:
            return "DDR4"
        if "DDR3" in module_type:
            return "DDR3"
    max_mhz = max(
        [value for module in modules for value in (module.configured_speed_mhz, module.speed_mhz) if value],
        default=None,
    )
    return guess_ram_type_by_speed(max_mhz)


def build_ram_layout(modules: list[RamModule]) -> str:
    sizes = [module.size_gb for module in modules if module.size_gb]
    if not sizes:
        return ""
    if len(sizes) == 1:
        return f"1x{sizes[0]}"
    if len(sizes) == 2 and sizes[0] == sizes[1]:
        return f"2x{sizes[0]}"
    return " + ".join(f"1x{size}" for size in sizes[:4])


def infer_min_ram_slots(
    vendor: str,
    model: str,
    product_no: str,
    version: str,
    modules: list[RamModule],
    reported_total_slots: int,
) -> int:
    total_slots = max(reported_total_slots, len(modules))
    identity = " ".join([vendor, model, product_no, version]).upper()

    # Some ASUS VivoBook boards report only the soldered memory device via DMI,
    # even though the mainboard has one physical SO-DIMM expansion slot.
    asus_onboard_plus_sodimm_models = ("X712EA", "F712EA")
    if "ASUS" in identity and any(token in identity for token in asus_onboard_plus_sodimm_models):
        return max(total_slots, len(modules) + 1, 2)

    return total_slots


def get_drm_resolution() -> str:
    drm_root = pathlib.Path("/sys/class/drm")
    if not drm_root.exists():
        return ""
    status_files = sorted(drm_root.glob("card*-*/status"))
    internal_names = ("edp", "lvds", "dsi")
    ordered_status_files = [
        path for path in status_files if any(name in path.parent.name.lower() for name in internal_names)
    ]
    ordered_status_files.extend(path for path in status_files if path not in ordered_status_files)
    for status_file in ordered_status_files:
        if read_text(status_file) != "connected":
            continue
        modes_file = status_file.with_name("modes")
        modes = read_text(modes_file).splitlines()
        if modes:
            return modes[0].strip()
    return ""


def get_xrandr_resolution() -> str:
    xrandr = run_command("xrandr")
    for line in xrandr.splitlines():
        if "*" in line:
            return line.split()[0]
    return ""


def get_resolution() -> str:
    return get_drm_resolution() or get_xrandr_resolution()


def parse_edid_inches() -> float | None:
    drm_root = pathlib.Path("/sys/class/drm")
    if not drm_root.exists():
        return None
    for status_file in sorted(drm_root.glob("card*-*/status")):
        if read_text(status_file) != "connected":
            continue
        edid_data = read_bytes(status_file.with_name("edid"))
        if len(edid_data) < 23:
            continue
        width_cm = edid_data[21]
        height_cm = edid_data[22]
        if width_cm and height_cm:
            diagonal = math.sqrt(width_cm ** 2 + height_cm ** 2) / 2.54
            return diagonal
    return None


def infer_display_size_from_model(model: str, resolution: str) -> float | None:
    text = re.sub(r"[_/]+", " ", f"{model} {resolution}".lower())
    if re.search(r"\b(18|18t|18-|18s)\b", text):
        return 18.0
    if re.search(r"\b(17|17t|17z|17-|17s|470|670|730|770|8730)\b", text):
        return 17.3
    if re.search(r"\b(laptop|notebook|ideapad|vivo?book|aspire|thinkbook|probook|elitebook)\s+17\b", text):
        return 17.3
    if re.search(r"\b(18)\b", text):
        return 18.0
    if re.search(r"\b(v15|15|15s|15t|15z|15-|156|83gw|250|255|350|355|450|455|550|555|650|655)\b", text):
        return 15.6
    if re.search(r"\b(laptop|notebook|ideapad|vivo?book|aspire|thinkbook|probook|elitebook)\s+15\b", text):
        return 15.6
    if re.search(r"\b(14|14s|14t|14z|14-|440|640|840|1040|x1 carbon)\b", text):
        return 14.0
    if re.search(r"\b(13|13s|13t|13z|13-|330|430|830|1030)\b", text):
        return 13.3
    return None


def add_missing_optical_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    existing = {str(row.get("name") or row.get("kname") or "") for row in rows}
    sys_block = pathlib.Path("/sys/block")
    for device in sorted(sys_block.glob("sr*")) if sys_block.exists() else []:
        if device.name in existing:
            continue
        sectors = to_int(read_text(device / "size")) or 0
        rows.append(
            {
                "name": device.name,
                "type": "rom",
                "tran": "",
                "size": sectors * 512,
                "model": first_existing_text([device / "device/model", device / "device/name"]),
                "vendor": read_text(device / "device/vendor"),
                "rota": read_text(device / "queue/rotational") or "1",
            }
        )
    return rows


def get_storage_rows() -> list[dict[str, object]]:
    output = run_command("lsblk", "-J", "-b", "-o", "NAME,KNAME,TYPE,TRAN,SIZE,MODEL,VENDOR,ROTA")
    rows = []
    if output:
        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            data = {}
        for row in data.get("blockdevices", []):
            row_type = str(row.get("type") or "").lower()
            transport = str(row.get("tran") or "").lower()
            if row_type == "disk":
                if transport == "usb":
                    continue
                rows.append(row)
            elif row_type == "rom":
                rows.append(row)
        rows = add_missing_optical_rows(rows)
    if rows:
        return rows

    sys_block = pathlib.Path("/sys/block")
    for device in sorted(sys_block.iterdir()) if sys_block.exists() else []:
        name = device.name
        if re.match(r"^(loop|ram|fd|zram)", name):
            continue
        row_type = "rom" if name.startswith("sr") else "disk"
        if read_text(device / "removable") == "1":
            if row_type != "rom":
                continue
        sectors = to_int(read_text(device / "size")) or 0
        if not sectors and row_type != "rom":
            continue
        model = first_existing_text([device / "device/model", device / "device/name"])
        vendor = read_text(device / "device/vendor")
        rotational = read_text(device / "queue/rotational") or "0"
        transport = "nvme" if name.startswith("nvme") else "mmc" if name.startswith("mmcblk") else ""
        rows.append(
            {
                "name": name,
                "type": row_type,
                "tran": transport,
                "size": sectors * 512,
                "model": model,
                "vendor": vendor,
                "rota": rotational,
            }
        )
    return rows


def detect_optical_type(row: dict[str, object]) -> str:
    model = clean_storage_model(row.get("model"), row.get("vendor"))
    combined = f"{row.get('name') or ''} {model}".lower()
    if re.search(r"\b(bd|blu[ -]?ray)\b", combined):
        return "Blu-ray/DVD"
    if "dvd" in combined:
        if re.search(r"rw|ram|multi|writer|re", combined):
            return "DVD-RW"
        return "DVD-ROM"
    if "cd" in combined:
        return "CD/DVD-Laufwerk"
    return "Optisches Laufwerk"


def detect_disk_type(row: dict[str, object]) -> str:
    name = str(row.get("name") or "")
    transport = str(row.get("tran") or "").lower()
    model = clean_storage_model(row.get("model"), row.get("vendor"))
    rotational = str(row.get("rota") or "")
    combined = f"{name} {transport} {model}".lower()
    if name.startswith("nvme") or transport == "nvme":
        return "NVMe M.2 SSD"
    if name.startswith("mmcblk") or transport in {"mmc", "sdio"}:
        return "eMMC Flash"
    if rotational == "1":
        return "SATA HDD 2.5"
    if re.search(r"sd9|sd8|x400|x600|m[._ -]?2|ngff", combined):
        return "M.2 SATA SSD"
    if transport in {"sata", "ata", "ahci"} and re.search(r"\bin+n?ovation\s*it\b", combined):
        return "M.2 SATA SSD"
    if transport in {"sata", "ata", "ahci"}:
        return "SATA SSD 2.5"
    if rotational == "0":
        return "SATA SSD 2.5" if transport in {"", "sata", "ata", "ahci"} else "SSD/Flash intern"
    if re.search(r"ssd|micron|sandisk|kingston|crucial|liteon|skhynix|spcc|silicon|samsung|wd blue|wd green", model, re.I):
        return "SATA SSD 2.5"
    return "Unbekannter DatentrÃ¤ger"


def get_battery_info() -> tuple[str, str]:
    power_root = pathlib.Path("/sys/class/power_supply")
    if not power_root.exists():
        return ("Kein Akku erkannt", "")
    battery_dirs = sorted(power_root.glob("BAT*"))
    if not battery_dirs:
        return ("Kein Akku erkannt", "")
    battery = battery_dirs[0]
    status = read_text(battery / "status") or "Unknown"
    capacity = read_text(battery / "capacity")
    return (status, f"{capacity} %" if capacity else "")


def get_system_snapshot() -> dict[str, object]:
    vendor = read_text("/sys/class/dmi/id/sys_vendor")
    model = read_text("/sys/class/dmi/id/product_name")
    serial = read_text("/sys/class/dmi/id/product_serial")
    product_no = read_text("/sys/class/dmi/id/product_sku")
    version = read_text("/sys/class/dmi/id/product_version")
    cpu_name = get_cpu_name()

    modules, total_slots = parse_dmidecode_memory()
    total_slots = infer_min_ram_slots(vendor, model, product_no, version, modules, total_slots)
    installed_gb = sum(module.size_gb for module in modules)
    ram_type = best_ram_type(modules)
    max_speed = max(
        [value for module in modules for value in (module.configured_speed_mhz, module.speed_mhz) if value],
        default=None,
    )
    ram_layout = build_ram_layout(modules)

    drm_resolution = get_drm_resolution()
    xrandr_resolution = get_xrandr_resolution()
    resolution = drm_resolution or xrandr_resolution
    raw_inches = parse_edid_inches()
    display_size_source = "EDID" if raw_inches else "Fallback"
    model_hint = " ".join([model, version, product_no])
    inches = nearest_display_size(raw_inches) or infer_display_size_from_model(model_hint, resolution)
    oled = "OLED" in run_command("xrandr", "--prop").upper()
    display_type = detect_display_type(resolution, oled)

    storage_rows = get_storage_rows()
    primary_row = next((row for row in storage_rows if str(row.get("type") or "").lower() == "disk"), {})
    primary_type = detect_disk_type(primary_row) if primary_row else ""
    primary_size = nearest_disk_size_gb(int(primary_row.get("size") or 0)) if primary_row else None
    storage_lines = []
    disk_index = 0
    optical_index = 0
    for index, row in enumerate(storage_rows):
        row_type = str(row.get("type") or "").lower()
        model_name = clean_storage_model(row.get("model"), row.get("vendor"))
        if row_type == "rom":
            optical_type = detect_optical_type(row)
            suffix = f" ({model_name})" if model_name else ""
            storage_lines.append(f"DVD {optical_index}: {optical_type}{suffix}".strip())
            optical_index += 1
            continue

        disk_type = detect_disk_type(row)
        size_bytes = int(row.get("size") or 0)
        size_gb = nearest_disk_size_gb(size_bytes)
        size_text = f"{size_gb} GB" if size_gb else f"{round(size_bytes / (1024 ** 3), 1)} GiB"
        if disk_type == "M.2 SATA SSD" and size_gb and re.search(r"\bin+n?ovation\s*it\b", model_name, flags=re.IGNORECASE):
            model_name = f"SSD M.2 {size_gb}GB Innovation IT"
        suffix = f" ({model_name})" if model_name else ""
        storage_lines.append(f"Disk {disk_index}: {size_text} {disk_type}{suffix}".strip())
        disk_index += 1

    battery_status, battery_capacity = get_battery_info()

    snapshot: dict[str, object] = {
        "vendor": vendor,
        "vendor_short": vendor_short(vendor),
        "model_name": model,
        "product_version": version,
        "serial": serial,
        "product_no": product_no if product_no not in {"", "Not Specified", "Default string"} else "",
        "cpu": cpu_name or "Unbekannte CPU",
        "cpu_short": get_cpu_short(cpu_name or ""),
        "ram_modules": modules,
        "ram_total_gb": installed_gb,
        "ram_slots_total": total_slots,
        "ram_type": ram_type,
        "ram_layout": ram_layout,
        "ram_max_mhz": max_speed,
        "resolution": resolution,
        "xorg_resolution": xrandr_resolution or resolution,
        "expected_resolution": "",
        "resolution_source": "DRM" if drm_resolution else ("Xorg" if xrandr_resolution else ""),
        "display_type": display_type,
        "display_inches": inches,
        "display_size_source": display_size_source if inches else "",
        "storage_lines": storage_lines,
        "primary_storage_type": primary_type,
        "primary_disk_gb": primary_size,
        "battery_status": battery_status,
        "battery_capacity": battery_capacity,
    }
    apply_resolution_label_fallback(snapshot)
    return snapshot


def load_model_db() -> list[dict[str, object]]:
    try:
        return json.loads(get_models_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []


def ssd_size_match_score(hw: int | None, db: int | float | None) -> int:
    if hw is None or db is None:
        return 0
    diff = abs(hw - int(float(db)))
    if diff == 0:
        return 12
    if diff <= 16:
        return 6
    if diff <= 32:
        return 2
    return -8


def apply_display_database_fallback(snapshot: dict[str, object], model_hint: str) -> None:
    resolution = str(snapshot.get("resolution") or "")
    inches = display_inches_number(snapshot.get("display_inches"))
    is_large_hd_panel = inches is not None and inches >= 17.0 and parse_resolution(resolution) == (1366, 768)
    if not is_fallback_resolution(resolution) and snapshot.get("display_type") and not is_large_hd_panel:
        return

    best_score = -1
    best_item: dict[str, object] | None = None
    for item in load_model_db():
        if normalize_generic_token(str(item.get("vendor") or "")) != normalize_generic_token(str(snapshot["vendor_short"])):
            continue

        cpu_db = normalize_cpu_token(str(item.get("cpu") or ""))
        cpu_hw = normalize_cpu_token(str(snapshot["cpu_short"]))
        if not cpu_db or not cpu_hw:
            continue
        if cpu_db == cpu_hw:
            score = 40
        elif cpu_db in cpu_hw or cpu_hw in cpu_db:
            score = 25
        else:
            continue

        if product_number_matches(snapshot, item):
            score += 35

        db_ram_total = item.get("ram_total")
        if db_ram_total not in (None, ""):
            if int(float(db_ram_total)) != int(snapshot["ram_total_gb"]):
                continue
            score += 8

        score += max(0, ssd_size_match_score(snapshot["primary_disk_gb"], item.get("ssd")))

        storage_type = str(snapshot["primary_storage_type"])
        db_storage = str(item.get("storage_type") or "")
        if storage_type and db_storage and storage_family(storage_type) == storage_family(db_storage):
            score += 6

        note_text = str(item.get("note") or "").lower()
        model_text = model_hint.lower()
        model_family = re.search(r"\b\d{2}-[a-z]{2}", model_text)
        if model_family and model_family.group(0) in note_text:
            score += 15

        db_inch = item.get("inch")
        hw_inch = snapshot.get("display_inches")
        if db_inch not in (None, "") and isinstance(hw_inch, (float, int)) and compare_inches(float(hw_inch), float(db_inch)):
            score += 10

        if score > best_score:
            best_score = score
            best_item = item

    if best_score >= 45 and best_item:
        db_type = str(best_item.get("display_type") or "").strip()
        db_inch = best_item.get("inch")
        changed = False
        if db_inch not in (None, "") and not snapshot.get("display_inches"):
            snapshot["display_inches"] = float(db_inch)
            changed = True
        effective_inches = snapshot.get("display_inches") or db_inch
        db_type = normalize_display_type_for_size(db_type, effective_inches)
        if db_type and (not snapshot.get("display_type") or is_large_hd_panel):
            snapshot["display_type"] = db_type
            changed = True
        expected_resolution = expected_resolution_from_display_type(db_type, effective_inches)
        if expected_resolution:
            snapshot["expected_resolution"] = expected_resolution
        if changed:
            snapshot["display_size_source"] = "Datenbank"

    if not snapshot.get("display_type") and is_fallback_resolution(resolution):
        inches = snapshot.get("display_inches")
        model_text = model_hint.lower()
        if (isinstance(inches, (float, int)) and float(inches) >= 17.0) or re.search(r"\b17[-\s]", model_text):
            snapshot["display_type"] = "Full HD"
            snapshot["expected_resolution"] = expected_resolution_from_display_type("Full HD")
            if not snapshot.get("display_size_source"):
                snapshot["display_size_source"] = "Fallback"


def apply_resolution_label_fallback(snapshot: dict[str, object]) -> None:
    resolution = str(snapshot.get("resolution") or "")
    if resolution and not snapshot.get("xorg_resolution"):
        snapshot["xorg_resolution"] = resolution
    if resolution and not snapshot.get("resolution_source"):
        snapshot["resolution_source"] = "System"


def translated_match_word(language: str) -> str:
    return {"DE": "Treffer", "EN": "Match", "CZ": "Shoda"}.get(language, "Match")


def translated_best_match(language: str) -> str:
    return {"DE": "BESTER TREFFER", "EN": "BEST MATCH", "CZ": "NEJLEPÅ Ã SHODA"}.get(language, "BEST MATCH")


def t_lang(language: str, de: str, en: str, cz: str) -> str:
    return {"DE": de, "EN": en, "CZ": cz}.get(language, de)


def translated_battery_line(status: str, capacity: str, language: str) -> str:
    normalized = normalize_generic_token(status)
    status_text = {
        "charging": t_lang(language, "lÃ¤dt", "Charging", "NabÃ­jÃ­ se"),
        "discharging": t_lang(language, "entlÃ¤dt", "Discharging", "VybÃ­jÃ­ se"),
        "notcharging": t_lang(language, "lÃ¤dt nicht", "Not charging", "NenabÃ­jÃ­ se"),
        "full": t_lang(language, "voll", "Full", "PlnÄ› nabito"),
        "unknown": t_lang(language, "unbekannt", "Unknown", "NeznÃ¡mÃ½"),
        "keinakkuerkannt": t_lang(language, "kein Akku erkannt", "No battery detected", "Baterie nenalezena"),
    }.get(normalized, status)
    return f"{t_lang(language, 'Akku', 'Battery', 'Baterie')}: {status_text} {capacity}".strip()


def format_match_line(score: int, item: dict[str, object], best: bool, language: str = "DE") -> str:
    max_score = 99 if best else 98
    score = max(0, min(max_score, score))
    line = str(item.get("model_id") or "Unknown")
    keyboard = str(item.get("keyboard_layout") or "").strip().upper()
    condition = str(item.get("condition") or "").strip().upper()
    color = str(item.get("color") or "").strip()
    suffixes = []
    if keyboard in {"DE", "FR", "IT", "EN", "CZ", "ES", "PT", "US", "UK", "BE", "NL", "PL", "SK"}:
        suffixes.append(keyboard)
    if condition in {"REF", "REFURB", "REFURBISHED", "RFB"}:
        suffixes.append("REF")
    if color and color.upper() != "NONE":
        suffixes.append(color)
    if suffixes:
        line += " (" + ", ".join(suffixes) + ")"
    line += f" ({score}% {translated_match_word(language)})"
    if best:
        return f"{translated_best_match(language)}: {line}"
    return line


def get_model_matches(snapshot: dict[str, object], language: str = "DE") -> list[str]:
    entries = load_model_db()
    if not entries:
        return ["Keine model.json geladen"]

    results: list[tuple[int, dict[str, object]]] = []
    for item in entries:
        if normalize_generic_token(str(item.get("vendor") or "")) != normalize_generic_token(str(snapshot["vendor_short"])):
            continue

        score = 0
        if product_number_matches(snapshot, item):
            score += 35

        cpu_db = normalize_cpu_token(str(item.get("cpu") or ""))
        cpu_hw = normalize_cpu_token(str(snapshot["cpu_short"]))
        if cpu_db == cpu_hw:
            score += 40
        elif cpu_db and cpu_hw and (cpu_db in cpu_hw or cpu_hw in cpu_db):
            score += 25
        else:
            continue

        db_ram_total = item.get("ram_total")
        if db_ram_total not in (None, "") and int(float(db_ram_total)) != int(snapshot["ram_total_gb"]):
            continue

        if same_or_empty(str(snapshot["ram_type"]), str(item.get("ram_type") or "")):
            if snapshot["ram_type"] and item.get("ram_type"):
                score += 10

        if same_ram_layout_or_empty(str(snapshot["ram_layout"]), str(item.get("ram_layout") or "")):
            if snapshot["ram_layout"] and item.get("ram_layout"):
                score += 10

        ssd_score = ssd_size_match_score(snapshot["primary_disk_gb"], item.get("ssd"))
        score += ssd_score
        ssd_mismatch = snapshot["primary_disk_gb"] is not None and item.get("ssd") not in (None, "") and ssd_score < 12
        storage_type_mismatch = False

        storage_type = str(snapshot["primary_storage_type"])
        db_storage = str(item.get("storage_type") or "")
        if storage_type and db_storage:
            if normalize_generic_token(storage_type) == normalize_generic_token(db_storage):
                score += 10
            elif storage_family(storage_type) == storage_family(db_storage):
                score += 4
            else:
                score -= 8
                storage_type_mismatch = True

        if same_or_empty(str(snapshot["display_type"]), str(item.get("display_type") or "")):
            if snapshot["display_type"] and item.get("display_type"):
                score += 10

        db_optical = normalize_optical_drive(str(item.get("optical_drive") or ""))
        hw_optical = "DVD-RW" if any(
            re.search(r"\b(DVD|CD|Blu-ray)\b", line, flags=re.IGNORECASE)
            for line in snapshot["storage_lines"]
        ) else ""
        hw_optical = normalize_optical_drive(hw_optical)
        if db_optical and hw_optical:
            score += 12 if normalize_generic_token(db_optical) == normalize_generic_token(hw_optical) else -12
        elif db_optical or hw_optical:
            score -= 12

        db_inch = item.get("inch")
        hw_inch = snapshot["display_inches"]
        if db_inch not in (None, "") and compare_inches(hw_inch, float(db_inch)):
            score += 10

        if ssd_mismatch:
            score = min(score, 90)
        if storage_type_mismatch:
            score = min(score, 80)

        results.append((score, item))

    if not results:
        return ["Kein Treffer in der Datenbank"]

    lines = []
    for index, (score, item) in enumerate(sorted(results, key=lambda pair: pair[0], reverse=True)[:4]):
        lines.append(format_match_line(score, item, best=(index == 0), language=language))
    return lines


def build_report(snapshot: dict[str, object], matches: list[str], language: str = "DE") -> str:
    unknown = t_lang(language, "Unbekannt", "Unknown", "NeznÃ¡mÃ©")
    lines = [
        f"{APP_TITLE}",
        "",
        f"CPU: {snapshot['cpu']}",
        "",
        "RAM:",
    ]
    modules: list[RamModule] = snapshot["ram_modules"]  # type: ignore[assignment]
    for index, module in enumerate(modules, start=1):
        speed = module.configured_speed_mhz or module.speed_mhz or "?"
        rtype = module.ram_type or snapshot["ram_type"] or "Unknown"
        lines.append(f"  Slot {index}: {module.size_gb} GB, {speed} MT/s, {rtype}")
    if snapshot["ram_slots_total"] and snapshot["ram_slots_total"] > len(modules):
        for index in range(len(modules) + 1, int(snapshot["ram_slots_total"]) + 1):
            lines.append(f"  Slot {index}: {t_lang(language, 'LEER', 'EMPTY', 'PRÃZDNÃ')}")
    lines.extend(
        [
            f"  {t_lang(language, 'Installiert', 'Installed', 'InstalovÃ¡no')}: {snapshot['ram_total_gb']} GB",
            f"  {t_lang(language, 'Typ', 'Type', 'Typ')}: {snapshot['ram_type'] or unknown}",
            f"  Layout: {snapshot['ram_layout'] or unknown}",
            "",
            f"{t_lang(language, 'Anzeige', 'Display', 'Displej')}:",
            f"  {t_lang(language, 'AuflÃ¶sung', 'Resolution', 'RozliÅ¡enÃ­')}: {snapshot['resolution'] or unknown}",
            f"  {t_lang(language, 'Typ', 'Type', 'Typ')}: {snapshot['display_type'] or unknown}",
            f"  {t_lang(language, 'GrÃ¶ÃŸe', 'Size', 'Velikost')}: {snapshot['display_inches'] or unknown}\"",
            "",
            f"{t_lang(language, 'DatentrÃ¤ger', 'Storage', 'ÃšloÅ¾iÅ¡tÄ›')}:",
        ]
    )
    lines.extend(f"  {line}" for line in snapshot["storage_lines"])
    lines.extend(
        [
            "",
            f"{t_lang(language, 'Identifikation', 'Identification', 'Identifikace')}:",
            f"  {t_lang(language, 'Hersteller', 'Vendor', 'VÃ½robce')}: {snapshot['vendor'] or unknown}",
            f"  {t_lang(language, 'Modell', 'Model', 'Model')}: {snapshot['model_name'] or unknown}",
            f"  {t_lang(language, 'Seriennummer', 'Serial', 'SÃ©riovÃ© ÄÃ­slo')}: {snapshot['serial'] or unknown}",
            f"  {t_lang(language, 'Produktnummer', 'Product number', 'ProduktovÃ© ÄÃ­slo')}: {snapshot['product_no'] or unknown}",
            "",
            f"{t_lang(language, 'ModellvorschlÃ¤ge', 'Model suggestions', 'NÃ¡vrhy modelu')}:",
        ]
    )
    lines.extend(f"  {line}" for line in matches)
    lines.extend(
        [
            "",
            translated_battery_line(str(snapshot["battery_status"]), str(snapshot["battery_capacity"]), language),
        ]
    )
    return "\n".join(lines).strip() + "\n"


def write_report_save_debug(target: pathlib.Path, ok: bool, error: str = "") -> None:
    if os.environ.get("HC_DEBUG") != "1":
        return

    lines = [
        f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
        f"target={target}",
        f"ok={ok}",
        f"exists={target.exists()}",
        f"size={target.stat().st_size if target.exists() else 0}",
        f"error={error}",
        "",
        "=== report dir ===",
        run_command("sh", "-c", f"ls -la {str(target.parent)!r} 2>&1 || true"),
        "",
        "=== mount media ===",
        run_command("sh", "-c", "mount | grep -E '/media|/mnt|modloop|loop' || true"),
        "",
        "=== df ===",
        run_command("df", "-h", str(target.parent)),
    ]
    for root in find_debug_roots():
        debug_dir = root / "hardwarecheck-debug"
        try:
            debug_dir.mkdir(parents=True, exist_ok=True)
            write_text_durable(debug_dir / "last-report-save.txt", "\n".join(lines) + "\n")
        except OSError:
            pass


class HardwareCheckApp:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title(APP_TITLE)
        self.root.configure(bg="#12161b")

        # If Xorg starts in a safe 4:3 fallback mode, try the native panel mode
        # before the main window is sized. Failure is harmless and keeps fallback.
        initial_snapshot: dict[str, object] = {}
        if os.environ.get("HC_APPLY_NATIVE_MODE") == "1":
            initial_snapshot = get_system_snapshot()
            if try_apply_native_xrandr_mode(initial_snapshot):
                time.sleep(0.4)
                self.root.update_idletasks()

        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        self.compact_ui = self.screen_width <= 1100 or self.screen_height <= 800
        if self.compact_ui:
            inset = 4
            safe_width = max(800, self.screen_width - (inset * 2))
            safe_height = max(560, self.screen_height - (inset * 2))
            self.root.geometry(f"{safe_width}x{safe_height}+{inset}+{inset}")
            self.root.minsize(min(800, safe_width), min(560, safe_height))
        else:
            self.root.geometry(f"{self.screen_width}x{self.screen_height}+0+0")
            self.root.minsize(self.screen_width, self.screen_height)
            self.root.attributes("-fullscreen", True)
        self.root.overrideredirect(True)
        self.root.bind("<Escape>", lambda _event: self.root.destroy())

        self.snapshot: dict[str, object] = initial_snapshot
        self.matches: list[str] = []
        self.language_index = load_language_index()
        self.action_buttons: list[tk.Button] = []
        self.panel_title_vars: dict[str, tk.StringVar] = {}
        self.raw_input_seen = False
        self.raw_pointer_x = self.screen_width // 2
        self.raw_pointer_y = self.screen_height // 2
        self.raw_pointer: tk.Label | None = None
        self.raw_input_queue: queue.Queue[tuple[str, object]] = queue.Queue()
        self.raw_input_errors: list[str] = []
        self._scan_busy = False
        self._report_busy = False
        self._model_update_busy = False
        self._wifi_busy = False
        self._pending_model_update = False
        self._pending_program_update = False
        self._color_theme_index = 0
        self._last_language_toggle = 0.0

        self.header_var = tk.StringVar(value=APP_TITLE)
        self.status_var = tk.StringVar(value="")
        self.system_lines_var = tk.StringVar(value="")
        self.ram_lines_var = tk.StringVar(value="")
        self.display_lines_var = tk.StringVar(value="")
        self.storage_lines_var = tk.StringVar(value="")
        self.match_lines_var = tk.StringVar(value="")
        self.battery_var = tk.StringVar(value="")
        self.db_var = tk.StringVar(value="")
        self.internet_var = tk.StringVar(value="")
        self.internet_state = "offline"
        self.internet_message = ""
        self.internet_light_canvas: tk.Canvas | None = None

        self._build_ui()
        self._bind_keys()
        if os.environ.get("HC_RAW_INPUT") == "1":
            self._start_raw_input_listener()
        self.root.after(50, self._poll_raw_input_queue)
        self.root.after(250, self._force_focus)
        self.root.after(1500, self._force_focus)
        if os.environ.get("HC_DEBUG") == "1":
            self.root.after(4000, lambda: self._write_gui_debug("delayed"))
        self.refresh()
        self._schedule_battery_refresh()
        if sys.platform.startswith("linux"):
            self.root.after(2200, self.connect_saved_wifi)

    @property
    def language(self) -> str:
        return LANGUAGES[self.language_index]

    def _t(self, de: str, en: str, cz: str) -> str:
        return {"DE": de, "EN": en, "CZ": cz}[self.language]

    def _make_panel(self, parent: tk.Widget, title_key: str) -> tk.Frame:
        frame = tk.Frame(parent, bg="#1a2028", bd=0, highlightthickness=1, highlightbackground="#2a3440")
        title_var = tk.StringVar(value="")
        self.panel_title_vars[title_key] = title_var
        heading = tk.Label(
            frame,
            textvariable=title_var,
            bg="#1a2028",
            fg="#f7d37c",
            font=("Segoe UI", 11 if self.compact_ui else 16, "bold"),
            anchor="w",
            padx=8 if self.compact_ui else 16,
            pady=5 if self.compact_ui else 12,
        )
        heading.pack(fill="x")
        return frame

    def _make_text_label(self, parent: tk.Widget, variable: tk.StringVar) -> tk.Label:
        label = tk.Label(
            parent,
            textvariable=variable,
            justify="left",
            anchor="nw",
            bg="#1a2028",
            fg="#f3f6f9",
            font=("Consolas", 9 if self.compact_ui else 13),
            padx=7 if self.compact_ui else 16,
            pady=4 if self.compact_ui else 8,
        )
        label.pack(fill="both", expand=True)
        return label

    def _build_ui(self) -> None:
        top = tk.Frame(self.root, bg="#101418")
        top.pack(fill="x")
        tk.Label(
            top,
            textvariable=self.header_var,
            bg="#101418",
            fg="#ffffff",
            font=("Segoe UI", 14 if self.compact_ui else 26, "bold"),
            padx=8 if self.compact_ui else 18,
            pady=4 if self.compact_ui else 16,
            anchor="w",
        ).pack(side="left")
        top_status = tk.Frame(top, bg="#101418")
        top_status.pack(side="right", padx=8 if self.compact_ui else 18, pady=4 if self.compact_ui else 12)

        internet_row = tk.Frame(top_status, bg="#101418")
        internet_row.pack(anchor="e")
        light_size = 10 if self.compact_ui else 14
        self.internet_light_canvas = tk.Canvas(
            internet_row,
            width=light_size,
            height=light_size,
            bg="#101418",
            highlightthickness=0,
            bd=0,
        )
        self.internet_light_canvas.pack(side="left", padx=(0, 5))
        tk.Label(
            internet_row,
            textvariable=self.internet_var,
            bg="#101418",
            fg="#8d9aa6",
            font=("Segoe UI", 8 if self.compact_ui else 12, "bold"),
            anchor="e",
        ).pack(side="left")
        tk.Label(
            top_status,
            textvariable=self.db_var,
            bg="#101418",
            fg="#f7d37c",
            font=("Segoe UI", 8 if self.compact_ui else 12, "bold"),
            anchor="e",
        ).pack(anchor="e")
        tk.Label(
            top_status,
            textvariable=self.battery_var,
            bg="#101418",
            fg="#9ad3a8",
            font=("Segoe UI", 9 if self.compact_ui else 14, "bold"),
            anchor="e",
        ).pack(anchor="e")
        self._set_internet_indicator("offline")
        self._update_db_indicator()

        body = tk.Frame(self.root, bg="#12161b")
        body.pack(fill="both", expand=True, padx=4 if self.compact_ui else 16, pady=(0, 4 if self.compact_ui else 12))
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.columnconfigure(2, weight=3)
        body.rowconfigure(0, weight=1)
        body.rowconfigure(1, weight=1)

        system_panel = self._make_panel(body, "system")
        system_panel.grid(row=0, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(system_panel, self.system_lines_var)

        ram_panel = self._make_panel(body, "ram")
        ram_panel.grid(row=1, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(ram_panel, self.ram_lines_var)

        display_panel = self._make_panel(body, "display")
        display_panel.grid(row=0, column=1, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(display_panel, self.display_lines_var)

        storage_panel = self._make_panel(body, "storage")
        storage_panel.grid(row=1, column=1, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(storage_panel, self.storage_lines_var)

        right = tk.Frame(body, bg="#12161b")
        right.grid(row=0, column=2, rowspan=2, sticky="nsew")
        right.rowconfigure(0, weight=3)
        right.rowconfigure(1, weight=2)

        match_panel = self._make_panel(right, "match")
        match_panel.grid(row=0, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(match_panel, self.match_lines_var)

        action_panel = self._make_panel(right, "actions")
        action_panel.grid(row=1, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        button_area = tk.Frame(action_panel, bg="#1a2028")
        button_area.pack(fill="both", expand=True, padx=8 if self.compact_ui else 16, pady=4 if self.compact_ui else 8)

        actions = [
            ("language", self.toggle_language),
            ("wifi", self.open_wifi_manager),
            ("color", self.cycle_color_theme),
            ("report", self.save_report),
            ("update", self.update_model_database),
            ("appupdate", self.check_hardwarecheck_update),
            ("poweroff", lambda: self._system_action("poweroff", confirm=False)),
        ]
        for key, command in actions:
            button = self._button(button_area, "", command)
            button._hc_action_key = key  # type: ignore[attr-defined]
            button.pack(fill="x", pady=4)
            self.action_buttons.append(button)

        footer = tk.Label(
            self.root,
            textvariable=self.status_var,
            bg="#0e1216",
            fg="#9fb4c7",
            font=("Segoe UI", 8 if self.compact_ui else 11),
            anchor="w",
            padx=8 if self.compact_ui else 16,
            pady=4 if self.compact_ui else 10,
        )
        footer.pack(fill="x")

    def _button(self, parent: tk.Widget, text: str, command) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg="#d4a84d",
            fg="#101418",
            activebackground="#e4bc69",
            activeforeground="#101418",
            font=("Segoe UI", 9 if self.compact_ui else 12, "bold"),
            relief="flat",
            padx=6 if self.compact_ui else 12,
            pady=4 if self.compact_ui else 10,
            cursor="hand2",
        )

    def _internet_default_text(self, state: str) -> str:
        if state == "online":
            return self._t("Internet: online", "Internet: online", "Internet: online")
        if state == "searching":
            return self._t("Internet: suche", "Internet: searching", "Internet: hledam")
        if state == "error":
            return self._t("Internet: Fehler", "Internet: error", "Internet: chyba")
        return self._t("Internet: aus", "Internet: off", "Internet: vyp.")

    def _set_internet_indicator(self, state: str, message: str = "") -> None:
        self.internet_state = state
        self.internet_message = message
        colors = {
            "online": "#4fd16a",
            "searching": "#d4a84d",
            "error": "#d85b5b",
            "offline": "#65717d",
        }
        color = colors.get(state, colors["offline"])
        label = message or self._internet_default_text(state)
        if message and not message.startswith("Internet"):
            label = f"Internet: {message}"
        max_len = 34 if self.compact_ui else 52
        if len(label) > max_len:
            label = label[: max_len - 3] + "..."
        self.internet_var.set(label)
        if self.internet_light_canvas is not None:
            self.internet_light_canvas.delete("all")
            size = 10 if self.compact_ui else 14
            self.internet_light_canvas.create_oval(1, 1, size - 2, size - 2, fill=color, outline=color)

    def _update_db_indicator(self) -> None:
        version, count = local_model_database_info()
        model_word = self._t("Modelle", "models", "modelu")
        self.db_var.set(f"DB: {version} | {count} {model_word}" if count else f"DB: {version}")

    def _force_focus(self) -> None:
        self.root.lift()
        self.root.focus_force()
        self.root.focus_set()

    def _start_raw_input_listener(self) -> None:
        if os.environ.get("HC_RAW_POINTER") == "1":
            self.raw_pointer = tk.Label(
                self.root,
                text="+",
                bg="#12161b",
                fg="#ffe08a",
                font=("Consolas", 18, "bold"),
                padx=2,
                pady=0,
            )
            self._set_raw_pointer(self.raw_pointer_x, self.raw_pointer_y)
        thread = threading.Thread(target=self._raw_input_loop, name="raw-input-listener", daemon=True)
        thread.start()

    def _poll_raw_input_queue(self) -> None:
        while True:
            try:
                event, payload = self.raw_input_queue.get_nowait()
            except queue.Empty:
                break
            if event == "mark":
                self._mark_raw_input_seen()
            elif event == "key":
                self._handle_raw_key(int(payload))
            elif event == "click":
                self._raw_click()
            elif event == "move":
                x, y = payload  # type: ignore[misc]
                self._set_raw_pointer(int(x), int(y))
            elif event == "error":
                self.raw_input_errors.append(str(payload))
                self.raw_input_errors = self.raw_input_errors[-8:]
        self.root.after(30, self._poll_raw_input_queue)

    def _raw_input_loop(self) -> None:
        devices: dict[int, str] = {}
        abs_ranges: dict[int, dict[int, tuple[int, int]]] = {}
        pointer_x = self.raw_pointer_x
        pointer_y = self.raw_pointer_y
        last_scan = 0.0
        pointer_enabled = self.raw_pointer is not None

        while True:
            now = time.monotonic()
            if now - last_scan > 2.0:
                last_scan = now
                for path in sorted(pathlib.Path("/dev/input").glob("event*")):
                    path_text = str(path)
                    if path_text in devices.values():
                        continue
                    try:
                        fd = os.open(path_text, os.O_RDONLY | os.O_NONBLOCK)
                    except OSError as exc:
                        self.raw_input_queue.put(("error", f"open {path_text}: {exc}"))
                        continue
                    devices[fd] = path_text
                    abs_ranges[fd] = self._read_abs_ranges(fd)
                    self.raw_input_queue.put(("error", f"opened {path_text}"))

            if not devices:
                time.sleep(1)
                continue

            try:
                readable, _, _ = select.select(list(devices), [], [], 1.0)
            except OSError:
                readable = []

            for fd in readable:
                try:
                    data = os.read(fd, INPUT_EVENT.size * 64)
                except BlockingIOError:
                    continue
                except OSError:
                    devices.pop(fd, None)
                    abs_ranges.pop(fd, None)
                    try:
                        os.close(fd)
                    except OSError:
                        pass
                    continue

                moved = False
                for offset in range(0, len(data) - INPUT_EVENT.size + 1, INPUT_EVENT.size):
                    _sec, _usec, event_type, code, value = INPUT_EVENT.unpack_from(data, offset)
                    if event_type == EV_KEY and value == 1:
                        self.raw_input_queue.put(("mark", ""))
                        if code in RAW_KEY_CODES:
                            self.raw_input_queue.put(("key", code))
                        elif pointer_enabled and code == BTN_LEFT:
                            self.raw_input_queue.put(("click", ""))
                        elif pointer_enabled and code == BTN_TOUCH:
                            self.raw_input_queue.put(("click", ""))
                    elif pointer_enabled and event_type == EV_REL:
                        if code == REL_X:
                            pointer_x += int(value * 1.8)
                            moved = True
                        elif code == REL_Y:
                            pointer_y += int(value * 1.8)
                            moved = True
                    elif pointer_enabled and event_type == EV_ABS:
                        ranges = abs_ranges.get(fd, {})
                        if code in (ABS_X, ABS_MT_POSITION_X):
                            pointer_x = self._scale_abs(value, ranges.get(code), self.screen_width)
                            moved = True
                        elif code in (ABS_Y, ABS_MT_POSITION_Y):
                            pointer_y = self._scale_abs(value, ranges.get(code), self.screen_height)
                            moved = True
                    elif event_type == EV_SYN and moved:
                        pointer_x = max(0, min(self.screen_width - 1, pointer_x))
                        pointer_y = max(0, min(self.screen_height - 1, pointer_y))
                        self.raw_input_queue.put(("move", (pointer_x, pointer_y)))
                        moved = False

                if moved:
                    pointer_x = max(0, min(self.screen_width - 1, pointer_x))
                    pointer_y = max(0, min(self.screen_height - 1, pointer_y))
                    self.raw_input_queue.put(("move", (pointer_x, pointer_y)))

    def _read_abs_ranges(self, fd: int) -> dict[int, tuple[int, int]]:
        ranges: dict[int, tuple[int, int]] = {}
        if fcntl is None:
            return ranges
        for code in (ABS_X, ABS_Y, ABS_MT_POSITION_X, ABS_MT_POSITION_Y):
            buffer = bytearray(24)
            try:
                fcntl.ioctl(fd, 0x80184540 + code, buffer, True)
            except OSError:
                continue
            _value, minimum, maximum, _fuzz, _flat, _resolution = struct.unpack("iiiiii", buffer)
            if maximum > minimum:
                ranges[code] = (minimum, maximum)
        return ranges

    def _scale_abs(self, value: int, range_pair: tuple[int, int] | None, target_size: int) -> int:
        if not range_pair:
            return max(0, min(target_size - 1, value))
        minimum, maximum = range_pair
        ratio = (value - minimum) / max(1, maximum - minimum)
        return max(0, min(target_size - 1, int(ratio * (target_size - 1))))

    def _set_raw_pointer(self, x: int, y: int) -> None:
        self.raw_pointer_x = max(0, min(self.screen_width - 1, int(x)))
        self.raw_pointer_y = max(0, min(self.screen_height - 1, int(y)))
        if self.raw_pointer is not None:
            self.raw_pointer.place(x=self.raw_pointer_x - 8, y=self.raw_pointer_y - 12)

    def _raw_click(self) -> None:
        self._mark_raw_input_seen()
        root_x = self.root.winfo_rootx()
        root_y = self.root.winfo_rooty()
        for button in self.action_buttons:
            left = button.winfo_rootx() - root_x
            top = button.winfo_rooty() - root_y
            right = left + button.winfo_width()
            bottom = top + button.winfo_height()
            if left <= self.raw_pointer_x <= right and top <= self.raw_pointer_y <= bottom:
                button.invoke()
                return
        self.status_var.set("Roh-Maus erkannt. Gelbes + auf einen Aktionsbutton bewegen und klicken.")

    def _mark_raw_input_seen(self) -> None:
        if self.raw_input_seen:
            return
        self.raw_input_seen = True
        self.status_var.set("Roh-Eingabe aktiv: L/S/T/W/C/U/O/P oder gelbes + nutzen.")

    def _show_input_status(self) -> None:
        self.status_var.set(f"{get_input_summary()} | Debug/Reports: {get_report_dir()}")
        self._write_gui_debug("input-status")

    def _handle_raw_key(self, code: int) -> None:
        action = RAW_KEY_CODES.get(code)
        self._run_input_action(action)

    def _run_input_action(self, action: str | None) -> None:
        if action == "language":
            self.toggle_language()
        elif action == "scan":
            self.refresh()
        elif action == "report":
            self.save_report()
        elif action == "wifi":
            self.open_wifi_manager()
        elif action == "color":
            self.cycle_color_theme()
        elif action == "update":
            self.update_model_database()
        elif action == "appupdate":
            self.check_hardwarecheck_update()
        elif action == "shell":
            self.run_shell_fallback()
        elif action == "reboot":
            self._system_action("reboot", confirm=False)
        elif action == "poweroff":
            self._system_action("poweroff", confirm=False)
        elif action == "escape":
            self.root.destroy()

    def _write_gui_debug(self, reason: str) -> None:
        if os.environ.get("HC_DEBUG") != "1":
            return

        input_entries = []
        input_root = pathlib.Path("/dev/input")
        if input_root.exists():
            for path in sorted(input_root.iterdir()):
                try:
                    stat = path.stat()
                    input_entries.append(f"{path}: mode={oct(stat.st_mode)} size={stat.st_size}")
                except OSError as exc:
                    input_entries.append(f"{path}: {exc}")

        lines = [
            f"reason={reason}",
            f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
            f"display={os.environ.get('DISPLAY', '')}",
            f"screen={self.screen_width}x{self.screen_height}",
            f"model_path={get_models_path()}",
            f"report_dir={get_report_dir()}",
            f"input_summary={get_input_summary()}",
            f"debug_roots={', '.join(str(path) for path in find_debug_roots())}",
            f"raw_input_seen={self.raw_input_seen}",
            f"raw_input_errors={self.raw_input_errors}",
            "",
            "=== /proc/cmdline ===",
            read_text("/proc/cmdline"),
            "",
            "=== /dev/input ===",
            "\n".join(input_entries) or "no /dev/input entries",
            "",
            "=== /proc/bus/input/devices ===",
            read_text("/proc/bus/input/devices"),
            "",
            "=== lsmod input ===",
            run_command("sh", "-c", "lsmod | grep -E 'hid|input|mouse|psmouse|i2c' || true"),
            "",
            "=== mount media ===",
            run_command("sh", "-c", "mount | grep -E '/media|/mnt|modloop|loop' || true"),
            "",
            "=== drm modes ===",
            run_command("sh", "-c", "for s in /sys/class/drm/card*-*/status; do [ -e \"$s\" ] || continue; echo \"$s: $(cat \"$s\" 2>/dev/null)\"; m=${s%/*}/modes; [ -r \"$m\" ] && head -n 8 \"$m\"; done"),
            "",
        ]
        for root in find_debug_roots():
            debug_dir = root / "hardwarecheck-debug"
            try:
                debug_dir.mkdir(parents=True, exist_ok=True)
                (debug_dir / "gui-input.txt").write_text("\n".join(lines), encoding="utf-8")
            except OSError:
                continue

            for source, target in [
                (pathlib.Path("/root/.local/share/xorg/Xorg.0.log"), debug_dir / "Xorg.0.log"),
                (pathlib.Path("/var/log/Xorg.0.log"), debug_dir / "Xorg-var.log"),
            ]:
                data = read_text(source)
                if data:
                    try:
                        target.write_text(data, encoding="utf-8")
                    except OSError:
                        pass

    def _bind_keys(self) -> None:
        bindings = {
            "<F2>": self.toggle_language,
            "<F6>": self.save_report,
            "<F7>": self.update_model_database,
            "<F8>": self.run_shell_fallback,
            "<F11>": self.check_hardwarecheck_update,
            "<F12>": self.open_wifi_manager,
            "<F10>": lambda: self._system_action("poweroff", confirm=False),
            "1": self.toggle_language,
            "2": self.save_report,
            "3": lambda: self._system_action("poweroff", confirm=False),
            "l": self.toggle_language,
            "L": self.toggle_language,
            "t": self.save_report,
            "T": self.save_report,
            "n": self.save_report,
            "N": self.save_report,
            "w": self.open_wifi_manager,
            "W": self.open_wifi_manager,
            "c": self.cycle_color_theme,
            "C": self.cycle_color_theme,
            "u": self.update_model_database,
            "U": self.update_model_database,
            "o": self.check_hardwarecheck_update,
            "O": self.check_hardwarecheck_update,
            "h": self.run_shell_fallback,
            "H": self.run_shell_fallback,
            "p": lambda: self._system_action("poweroff", confirm=False),
            "P": lambda: self._system_action("poweroff", confirm=False),
        }
        for key, command in bindings.items():
            self.root.bind_all(key, lambda _event, cmd=command: cmd())

    def toggle_language(self) -> None:
        now = time.monotonic()
        if now - self._last_language_toggle < 0.35:
            return
        self._last_language_toggle = now
        self.language_index = (self.language_index + 1) % len(LANGUAGES)
        save_language(self.language)
        self.refresh(rescan=False)

    def _update_static_texts(self) -> None:
        titles = {
            "system": self._t("System", "System", "System"),
            "ram": self._t("RAM", "RAM", "RAM"),
            "display": self._t("Anzeige", "Display", "Displej"),
            "storage": self._t("DatentrÃ¤ger", "Storage", "ÃšloÅ¾iÅ¡tÄ›"),
            "match": self._t("Modelltreffer", "Model Match", "Shoda modelu"),
            "actions": self._t("Aktionen", "Actions", "Akce"),
        }
        for key, value in titles.items():
            if key in self.panel_title_vars:
                self.panel_title_vars[key].set(value)

        button_texts = {
            "language": self._t("Sprache (L)", "Language (L)", "Jazyk (L)"),
            "wifi": self._t("WLAN (W)", "Wi-Fi (W)", "Wi-Fi (W)"),
            "color": self._t("Farbe (C)", "Color (C)", "Barva (C)"),
            "report": self._t("Text (T)", "Text (T)", "Text (T)"),
            "update": self._t("DB-Update (U)", "DB update (U)", "DB update (U)"),
            "appupdate": self._t("Programm-Update (O)", "App update (O)", "Update programu (O)"),
            "poweroff": self._t("Aus (P)", "Power off (P)", "Vypnout (P)"),
        }
        for button in self.action_buttons:
            key = getattr(button, "_hc_action_key", "")
            if key in button_texts:
                button.configure(text=button_texts[key])
        self._set_internet_indicator(self.internet_state, self.internet_message)
        self._update_db_indicator()

    def _translated_battery(self, status: str, capacity: str) -> str:
        return translated_battery_line(status, capacity, self.language)

    def _system_action(self, action: str, confirm: bool = True) -> None:
        prompt = self._t(f"Wirklich {action} ausfÃ¼hren?", f"Really run {action}?", f"Opravdu spustit {action}?")
        if confirm and not messagebox.askyesno(APP_TITLE, prompt):
            return
        subprocess.Popen([action])

    def run_shell_fallback(self) -> None:
        shell_script = SCRIPT_DIR / "HardwareCheck.sh"
        if shell_script.exists():
            self.status_var.set("Starte Shell-Fallback ...")
            self.root.destroy()
            os.execv("/bin/bash", ["/bin/bash", str(shell_script)])
        messagebox.showerror(APP_TITLE, "HardwareCheck.sh wurde nicht gefunden.")

    def _schedule_battery_refresh(self) -> None:
        status, capacity = get_battery_info()
        self.battery_var.set(self._translated_battery(status, capacity))
        self.root.after(1500, self._schedule_battery_refresh)

    def refresh(self, rescan: bool = True) -> None:
        self._update_static_texts()
        if rescan or not self.snapshot:
            if self._scan_busy:
                self.status_var.set(self._t("Hardware-Scan lÃ¤uft ...", "Hardware scan running ...", "Scan hardwaru bezi ..."))
                return
            self._scan_busy = True
            self.status_var.set(self._t("Scanne Hardware ...", "Scanning hardware ...", "Skenuji hardware ..."))
            self.root.update_idletasks()

            def worker() -> None:
                try:
                    snapshot = get_system_snapshot()
                except Exception as exc:  # pragma: no cover - visible status is better than a dead UI.
                    error = str(exc)
                    self.root.after(0, lambda error=error: self._finish_scan(None, error))
                    return
                self.root.after(0, lambda snapshot=snapshot: self._finish_scan(snapshot, None))

            threading.Thread(target=worker, name="hardware-scan", daemon=True).start()
            return

        self.status_var.set(
            self._t("Scanne Hardware ...", "Scanning hardware ...", "Skenuji hardware ...")
            if rescan or not self.snapshot
            else self._t("Aktualisiere Sprache ...", "Updating language ...", "Aktualizuji jazyk ...")
        )
        self.root.update_idletasks()
        self.matches = get_model_matches(self.snapshot, self.language)

        self.header_var.set(
            f"{APP_TITLE}   {self.snapshot['vendor_short']} {self.snapshot['cpu_short']}   ({self.language})".strip()
        )
        self.system_lines_var.set(
            "\n".join(
                [
                    f"{self._t('CPU', 'CPU', 'CPU')}: {self.snapshot['cpu']}",
                    f"{self._t('Hersteller', 'Vendor', 'VÃ½robce')}: {self.snapshot['vendor'] or self._t('Unbekannt', 'Unknown', 'NeznÃ¡mÃ©')}",
                    f"{self._t('Modell', 'Model', 'Model')}: {self.snapshot['model_name'] or self._t('Unbekannt', 'Unknown', 'NeznÃ¡mÃ©')}",
                    f"{self._t('Produkt-Nr', 'Product No', 'Produkt')}: {self.snapshot['product_no'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
                    f"{self._t('Seriennummer', 'Serial', 'Seriove cislo')}: {self.snapshot['serial'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
                ]
            )
        )

        ram_lines = []
        modules: list[RamModule] = self.snapshot["ram_modules"]  # type: ignore[assignment]
        for index, module in enumerate(modules, start=1):
            speed = module.configured_speed_mhz or module.speed_mhz or "?"
            ram_type = module.ram_type or self.snapshot["ram_type"] or "Unknown"
            ram_lines.append(f"Slot {index}: {module.size_gb} GB | {speed} MT/s | {ram_type}")
        if self.snapshot["ram_slots_total"] and int(self.snapshot["ram_slots_total"]) > len(modules):
            for index in range(len(modules) + 1, int(self.snapshot["ram_slots_total"]) + 1):
                ram_lines.append(f"{self._t('Slot', 'Slot', 'Slot')} {index}: {self._t('LEER', 'EMPTY', 'PRÃZDNÃ')}")
        ram_lines.extend(
            [
                "",
                f"{self._t('Installiert', 'Installed', 'Instalovano')}: {self.snapshot['ram_total_gb']} GB",
                f"{self._t('Typ', 'Type', 'Typ')}: {self.snapshot['ram_type'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
                f"Layout: {self.snapshot['ram_layout'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
            ]
        )
        self.ram_lines_var.set("\n".join(ram_lines))

        display_lines = [
            f"{self._t('AuflÃ¶sung', 'Resolution', 'RozliÅ¡enÃ­')}: {self.snapshot['resolution'] or self._t('Unbekannt', 'Unknown', 'NeznÃ¡mÃ©')}",
        ]
        display_lines.extend(
            [
                f"{self._t('Typ', 'Type', 'Typ')}: {self.snapshot['display_type'] or self._t('Unbekannt', 'Unknown', 'NeznÃ¡mÃ©')}",
                f"{self._t('GrÃ¶ÃŸe', 'Size', 'Velikost')}: {self.snapshot['display_inches'] or self._t('Unbekannt', 'Unknown', 'NeznÃ¡mÃ©')}\"",
            ]
        )
        self.display_lines_var.set("\n".join(display_lines))
        storage_width = 38 if self.compact_ui else 46
        self.storage_lines_var.set(
            "\n".join(textwrap.fill(line, width=storage_width) for line in self.snapshot["storage_lines"])
            or self._t("Keine internen DatentrÃ¤ger erkannt", "No internal disks detected", "Nenalezen internÃ­ disk")
        )
        self.match_lines_var.set("\n\n".join(textwrap.fill(line, width=42 if self.compact_ui else 58) for line in self.matches))
        self.status_var.set(
            f"{self._t('Hardware-Scan abgeschlossen', 'Hardware scan complete', 'Scan hotov')} | "
            f"{self.db_var.get()} | model.json: {get_models_path()}"
        )
        self._write_gui_debug("refresh")

    def _finish_scan(self, snapshot: dict[str, object] | None, error: str | None) -> None:
        self._scan_busy = False
        if error or snapshot is None:
            self.status_var.set(
                f"{self._t('Hardware-Scan fehlgeschlagen', 'Hardware scan failed', 'Scan hardwaru selhal')}: {error}"
            )
            return
        self.snapshot = snapshot
        self.refresh(rescan=False)

    def update_model_database(self) -> None:
        if self._model_update_busy:
            self.status_var.set("Update laeuft bereits ...")
            return
        if self._wifi_busy:
            self._pending_model_update = True
            self.status_var.set("DB-Update wartet auf WLAN-Verbindung ...")
            return
        self._model_update_busy = True
        self._pending_model_update = False
        self._set_internet_indicator("searching", "suche Netzwerk")
        self.status_var.set(self._t("Model-Update: verbinde ...", "Model update: connecting ...", "Model update: pripojuji ..."))

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._finish_model_update_progress(state, message))

        def worker() -> None:
            ok, message = run_model_database_update(progress)
            self.root.after(0, lambda ok=ok, message=message: self._finish_model_database_update(ok, message))

        threading.Thread(target=worker, name="model-json-update", daemon=True).start()

    def _finish_model_update_progress(self, state: str, message: str) -> None:
        self._set_internet_indicator(state, message)
        self.status_var.set(f"Model-Update: {message}")

    def _finish_model_database_update(self, ok: bool, message: str) -> None:
        self._model_update_busy = False
        self._update_db_indicator()
        if ok and self.snapshot:
            self.refresh(rescan=False)
        self._set_internet_indicator("online" if ok else "error")
        suffix = self._t("Treffer neu berechnet", "matches refreshed", "shoda prepocitana") if ok and self.snapshot else self.db_var.get()
        self.status_var.set(f"{message} | {suffix}" if suffix else message)

    def check_hardwarecheck_update(self) -> None:
        if self._model_update_busy:
            self.status_var.set("Update laeuft bereits ...")
            return
        if self._wifi_busy:
            self._pending_program_update = True
            self.status_var.set("Programm-Update wartet auf WLAN-Verbindung ...")
            return
        self._model_update_busy = True
        self._pending_program_update = False
        self._set_internet_indicator("searching", "suche Netzwerk")
        self.status_var.set(
            self._t(
                "Programm-Update: verbinde ...",
                "App update: connecting ...",
                "Update programu: pripojuji ...",
            )
        )

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._finish_model_update_progress(state, message))

        def worker() -> None:
            ok, message, install_request = run_hardwarecheck_update_check(progress)
            self.root.after(
                0,
                lambda ok=ok, message=message, install_request=install_request: self._finish_hardwarecheck_update_check(
                    ok,
                    message,
                    install_request,
                ),
            )

        threading.Thread(target=worker, name="hardwarecheck-update-check", daemon=True).start()

    def _finish_hardwarecheck_update_check(
        self,
        ok: bool,
        message: str,
        install_request: dict[str, str] | None = None,
    ) -> None:
        self._model_update_busy = False
        self._set_internet_indicator("online" if ok else "error")
        self.status_var.set(message)
        if not ok or not install_request:
            return
        self._show_update_install_prompt(install_request)

    def _show_update_install_prompt(self, install_request: dict[str, str]) -> None:
        target_version = install_request.get("target_version", "?")
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        dialog_width = min(760, max(420, self.screen_width - 80))
        dialog_height = min(420, max(320, self.screen_height - 80))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("Programm-Update bereit", "App update ready", "Update programu pripraven"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 16, "bold"),
            anchor="w",
            padx=18,
            pady=16,
        ).place(relx=0, rely=0, relwidth=1, relheight=0.22)
        tk.Label(
            dialog,
            text=self._t(
                f"Version {target_version} wurde heruntergeladen und geprueft.",
                f"Version {target_version} has been downloaded and verified.",
                f"Verze {target_version} byla stazena a overena.",
            ),
            bg="#12161b",
            fg="#f3f6f9",
            font=("Segoe UI", 12),
            anchor="w",
            justify="left",
            padx=18,
            pady=6,
            wraplength=dialog_width - 36,
        ).place(relx=0, rely=0.23, relwidth=1, relheight=0.18)
        tk.Label(
            dialog,
            text=self._t(
                "Zum Installieren: gelben Button anklicken oder Taste I / Enter / J druecken.\nHardwareCheck schliesst kurz, der Installer zeigt danach den Fortschritt.",
                "To install: click the yellow button or press I / Enter / Y.\nHardwareCheck closes briefly, then the installer shows progress.",
                "Pro instalaci klikni na zlute tlacitko nebo stiskni I / Enter / A.\nHardwareCheck se kratce zavre, potom instalator ukaze prubeh.",
            ),
            bg="#12161b",
            fg="#d8e2ea",
            font=("Segoe UI", 10),
            anchor="w",
            justify="left",
            padx=18,
            pady=6,
            wraplength=dialog_width - 36,
        ).place(relx=0, rely=0.42, relwidth=1, relheight=0.24)

        def close_prompt() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            self.root.unbind_all("<Return>")
            self.root.unbind_all("<KP_Enter>")
            self.root.unbind_all("<space>")
            self.root.unbind_all("<Escape>")
            self.root.unbind_all("i")
            self.root.unbind_all("I")
            self.root.unbind_all("j")
            self.root.unbind_all("J")
            self.root.unbind_all("y")
            self.root.unbind_all("Y")
            self.root.unbind_all("p")
            self.root.unbind_all("P")
            overlay.destroy()
            self.status_var.set(f"Programm-Update bereit: {target_version}")
            self._bind_keys()

        def install_now() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            self.root.unbind_all("<Return>")
            self.root.unbind_all("<KP_Enter>")
            self.root.unbind_all("<space>")
            self.root.unbind_all("<Escape>")
            self.root.unbind_all("i")
            self.root.unbind_all("I")
            self.root.unbind_all("j")
            self.root.unbind_all("J")
            self.root.unbind_all("y")
            self.root.unbind_all("Y")
            self.root.unbind_all("p")
            self.root.unbind_all("P")
            overlay.destroy()
            self._start_hardwarecheck_update_installer(install_request)

        install_button = tk.Button(
            dialog,
            text=self._t("Jetzt installieren", "Install now", "Instalovat nyni"),
            command=install_now,
            bg="#d4a84d",
            fg="#101418",
            relief="flat",
            padx=18,
            pady=10,
            font=("Segoe UI", 14, "bold"),
        )
        install_button.place(relx=0.06, rely=0.73, relwidth=0.52, relheight=0.18)
        later_button = tk.Button(
            dialog,
            text=self._t("Spaeter", "Later", "Pozdeji"),
            command=close_prompt,
            bg="#2a3440",
            fg="#f3f6f9",
            relief="flat",
            padx=18,
            pady=10,
            font=("Segoe UI", 14, "bold"),
        )
        later_button.place(relx=0.64, rely=0.73, relwidth=0.30, relheight=0.18)

        overlay.bind("<Return>", lambda _event: install_now())
        overlay.bind("<KP_Enter>", lambda _event: install_now())
        overlay.bind("<space>", lambda _event: install_now())
        overlay.bind("<Escape>", lambda _event: close_prompt())
        overlay.bind("i", lambda _event: install_now())
        overlay.bind("I", lambda _event: install_now())
        overlay.bind("j", lambda _event: install_now())
        overlay.bind("J", lambda _event: install_now())
        overlay.bind("y", lambda _event: install_now())
        overlay.bind("Y", lambda _event: install_now())
        overlay.bind("p", lambda _event: close_prompt())
        overlay.bind("P", lambda _event: close_prompt())
        self.root.bind_all("<Return>", lambda _event: install_now())
        self.root.bind_all("<KP_Enter>", lambda _event: install_now())
        self.root.bind_all("<space>", lambda _event: install_now())
        self.root.bind_all("<Escape>", lambda _event: close_prompt())
        self.root.bind_all("i", lambda _event: install_now())
        self.root.bind_all("I", lambda _event: install_now())
        self.root.bind_all("j", lambda _event: install_now())
        self.root.bind_all("J", lambda _event: install_now())
        self.root.bind_all("y", lambda _event: install_now())
        self.root.bind_all("Y", lambda _event: install_now())
        self.root.bind_all("p", lambda _event: close_prompt())
        self.root.bind_all("P", lambda _event: close_prompt())

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
                dialog.lift()
                install_button.focus_set()
            except tk.TclError:
                pass

        bring_to_front()
        overlay.after(100, bring_to_front)
        overlay.after(500, bring_to_front)

    def _start_hardwarecheck_update_installer(self, install_request: dict[str, str]) -> None:
        config_path = install_request.get("config_path", "")
        if not config_path:
            self.status_var.set("Programm-Update: Installer fehlt")
            return
        try:
            config = json.loads(pathlib.Path(config_path).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            self.status_var.set(f"Programm-Update: Installer-Konfig fehlt ({exc})")
            return
        if not isinstance(config, dict):
            self.status_var.set("Programm-Update: Installer-Konfig ungueltig")
            return
        self._run_inprocess_update_installer(config)

    def _run_inprocess_update_installer(self, config: dict[str, object]) -> None:
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        dialog_width = min(680, max(380, self.screen_width - 80))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=230)
        title_var = tk.StringVar(value="Programm-Update wird installiert")
        detail_var = tk.StringVar(value="Vorbereitung ...")
        percent_var = tk.StringVar(value="0%")

        tk.Label(
            dialog,
            textvariable=title_var,
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 15, "bold"),
            anchor="w",
            padx=18,
            pady=12,
        ).place(relx=0, rely=0, relwidth=1, relheight=0.28)
        tk.Label(
            dialog,
            textvariable=detail_var,
            bg="#12161b",
            fg="#f3f6f9",
            font=("Segoe UI", 11),
            anchor="w",
            justify="left",
            padx=18,
            pady=6,
            wraplength=dialog_width - 36,
        ).place(relx=0, rely=0.30, relwidth=1, relheight=0.26)
        bar_frame = tk.Frame(dialog, bg="#2a3440")
        bar_frame.place(relx=0.05, rely=0.62, relwidth=0.72, relheight=0.13)
        bar_fill = tk.Frame(bar_frame, bg="#d4a84d")
        bar_fill.place(relx=0, rely=0, relwidth=0.01, relheight=1)
        tk.Label(
            dialog,
            textvariable=percent_var,
            bg="#12161b",
            fg="#f3f6f9",
            font=("Segoe UI", 12, "bold"),
            anchor="e",
            padx=12,
        ).place(relx=0.78, rely=0.60, relwidth=0.17, relheight=0.17)
        tk.Label(
            dialog,
            text="Bitte nicht ausschalten.",
            bg="#12161b",
            fg="#d8e2ea",
            font=("Segoe UI", 10),
            anchor="w",
            padx=18,
        ).place(relx=0, rely=0.80, relwidth=1, relheight=0.14)

        def set_progress(percent: int, message: str) -> None:
            value = max(0, min(100, int(percent)))

            def apply_progress() -> None:
                detail_var.set(message)
                percent_var.set(f"{value}%")
                bar_fill.place_configure(relwidth=max(0.01, value / 100))
                self.status_var.set(f"Programm-Update: {message}")

            self.root.after(0, apply_progress)

        def append_log(log_path: pathlib.Path, message: str) -> None:
            try:
                log_path.parent.mkdir(parents=True, exist_ok=True)
                with log_path.open("a", encoding="utf-8", newline="\n") as handle:
                    handle.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {message}\n")
            except OSError:
                pass

        def safe_relative(value: object) -> pathlib.PurePosixPath:
            text = str(value or "").replace("\\", "/").strip().strip("/")
            path = pathlib.PurePosixPath(text)
            if not text or path.is_absolute() or ".." in path.parts:
                raise ValueError(f"Unsicherer Pfad: {value}")
            return path

        def worker() -> None:
            try:
                tool_root = pathlib.Path(str(config["tool_root"])).resolve()
                payload_dir = pathlib.Path(str(config["payload_dir"])).resolve()
                backup_dir = pathlib.Path(str(config["backup_dir"])).resolve()
                log_path = pathlib.Path(str(config["log_path"])).resolve()
                replace_paths = [str(item) for item in config.get("replace_paths", [])]
                app_file = str(config.get("app_file") or "hardwarecheck_fast_gui.py")
                if not replace_paths:
                    raise ValueError("replace_paths leer")

                append_log(log_path, "HardwareCheck In-Process-Update gestartet")
                set_progress(10, "Backup wird erstellt ...")
                backup_dir.mkdir(parents=True, exist_ok=True)
                rel_paths = [safe_relative(path) for path in replace_paths]
                for rel in rel_paths:
                    source_current = tool_root.joinpath(*rel.parts)
                    backup_target = backup_dir.joinpath(*rel.parts)
                    if source_current.is_file():
                        backup_target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source_current, backup_target)
                        append_log(log_path, f"Backup {source_current} -> {backup_target}")

                set_progress(42, "Neue Dateien werden kopiert ...")
                copied: list[pathlib.PurePosixPath] = []
                try:
                    for rel in rel_paths:
                        source_new = payload_dir.joinpath(*rel.parts)
                        target_file = tool_root.joinpath(*rel.parts)
                        if not source_new.is_file():
                            raise FileNotFoundError(f"Payload fehlt: {source_new}")
                        write_bytes_atomic(target_file, source_new.read_bytes())
                        copied.append(rel)
                        append_log(log_path, f"Kopiere {source_new} -> {target_file}")

                    set_progress(72, "Installation wird geprueft ...")
                    for rel in rel_paths:
                        target_file = tool_root.joinpath(*rel.parts)
                        if not target_file.is_file() or target_file.stat().st_size <= 0:
                            raise RuntimeError(f"Zieldatei ungueltig: {target_file}")
                except Exception:
                    set_progress(82, "Fehler - alte Version wird wiederhergestellt ...")
                    for rel in copied:
                        backup_file = backup_dir.joinpath(*rel.parts)
                        target_file = tool_root.joinpath(*rel.parts)
                        if backup_file.is_file():
                            write_bytes_atomic(target_file, backup_file.read_bytes())
                    raise

                set_progress(90, "Daten werden geschrieben ...")
                if hasattr(os, "sync"):
                    try:
                        os.sync()
                    except OSError:
                        pass
                append_log(log_path, "Update erfolgreich")
                set_progress(100, "Neustart ...")
                app_path = tool_root / app_file
                self.root.after(900, lambda: self._exec_restart_after_update(config, app_path))
            except Exception as exc:
                log_path = pathlib.Path(str(config.get("log_path") or (SCRIPT_DIR / "updates" / "logs" / "update_install.log")))
                append_log(log_path, "Update fehlgeschlagen: " + repr(exc))
                append_log(log_path, traceback.format_exc())

                def show_error() -> None:
                    title_var.set("Programm-Update fehlgeschlagen")
                    detail_var.set(f"{exc}\nLog: {log_path}")
                    percent_var.set("!")
                    bar_fill.configure(bg="#b94a48")
                    bar_fill.place_configure(relwidth=1)
                    self.status_var.set("Programm-Update fehlgeschlagen")

                self.root.after(0, show_error)

        threading.Thread(target=worker, name="hardwarecheck-inprocess-update", daemon=True).start()

    def _exec_restart_after_update(self, config: dict[str, object], app_path: pathlib.Path) -> None:
        python_exe = str(config.get("python_exe") or sys.executable or "python3")
        argv = [python_exe, str(app_path)]
        try:
            os.chdir(str(app_path.parent))
        except OSError:
            pass
        if os.path.sep in python_exe or (os.path.altsep and os.path.altsep in python_exe):
            os.execv(python_exe, argv)
        os.execvp(python_exe, argv)

    def cycle_color_theme(self) -> None:
        themes = [
            {"name": "Standard", "root": "#12161b", "panel": "#1a2028", "footer": "#0e1216", "accent": "#d4a84d", "text": "#f3f6f9"},
            {"name": "Gruen", "root": "#101711", "panel": "#1a2a1f", "footer": "#0b120d", "accent": "#74c476", "text": "#eff8ef"},
            {"name": "Blau", "root": "#101620", "panel": "#1a2638", "footer": "#0b1018", "accent": "#7fb3ff", "text": "#eef5ff"},
            {"name": "Hell", "root": "#e9edf2", "panel": "#f8fafc", "footer": "#d8dee8", "accent": "#315d8c", "text": "#111827"},
        ]
        self._color_theme_index = (self._color_theme_index + 1) % len(themes)
        theme = themes[self._color_theme_index]

        def apply(widget: tk.Widget) -> None:
            try:
                if isinstance(widget, tk.Button):
                    widget.configure(
                        bg=theme["accent"],
                        fg=theme["root"],
                        activebackground=theme["accent"],
                        activeforeground=theme["root"],
                    )
                elif isinstance(widget, (tk.Frame, tk.Canvas)):
                    widget.configure(bg=theme["panel"])
                elif isinstance(widget, tk.Label):
                    current_fg = str(widget.cget("fg"))
                    widget.configure(bg=theme["panel"], fg=theme["accent"] if current_fg.lower() == "#f7d37c" else theme["text"])
            except tk.TclError:
                pass
            for child in widget.winfo_children():
                apply(child)

        try:
            self.root.configure(bg=theme["root"])
        except tk.TclError:
            pass
        apply(self.root)
        self.status_var.set(f"Farbtest: {theme['name']}")

    def open_wifi_manager(self) -> None:
        if self._wifi_busy:
            return
        self._wifi_busy = True
        self._set_internet_indicator("searching", "scanne WLAN")
        self.status_var.set(self._t("WLAN: scanne ...", "Wi-Fi: scanning ...", "Wi-Fi: hledam ..."))

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._finish_wifi_progress(state, message))

        def worker() -> None:
            debug_lines: list[str] = []
            networks, message = scan_wifi_networks(progress, debug_lines)
            self.root.after(0, lambda networks=networks, message=message: self._show_wifi_manager(networks, message))

        threading.Thread(target=worker, name="wifi-scan", daemon=True).start()

    def _finish_wifi_progress(self, state: str, message: str) -> None:
        self._set_internet_indicator(state, message)
        self.status_var.set(f"WLAN: {message}")

    def _show_wifi_manager(self, networks: list[dict[str, str]], message: str) -> None:
        self._wifi_busy = False
        self._set_internet_indicator("offline")
        self.status_var.set(f"WLAN: {message}")

        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        dialog_width = min(560, max(420, self.screen_width - 24))
        dialog_height = min(460, max(360, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("WLAN auswÃ¤hlen oder SSID eingeben", "Select Wi-Fi or enter SSID", "Vyber Wi-Fi nebo zadej SSID"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
            padx=14,
            pady=12,
        ).pack(fill="x")

        list_frame = tk.Frame(dialog, bg="#12161b")
        list_frame.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        listbox = tk.Listbox(
            list_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            selectbackground="#d4a84d",
            selectforeground="#101418",
            height=8,
            activestyle="none",
            font=("Consolas", 11),
        )
        listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
        scrollbar.pack(side="right", fill="y")
        listbox.configure(yscrollcommand=scrollbar.set)

        for network in networks:
            label = network["ssid"]
            if network.get("signal"):
                label = f"{label}   {network['signal']}"
            listbox.insert("end", label)

        form = tk.Frame(dialog, bg="#12161b")
        form.pack(fill="x", padx=14, pady=4)
        ssid_var = tk.StringVar(value=networks[0]["ssid"] if networks else "")
        password_var = tk.StringVar()
        known_passwords = saved_wifi_passwords()
        if ssid_var.get() in known_passwords:
            password_var.set(known_passwords[ssid_var.get()])

        tk.Label(form, text="SSID", bg="#12161b", fg="#f3f6f9", anchor="w").grid(row=0, column=0, sticky="w", pady=4)
        ssid_entry = tk.Entry(form, textvariable=ssid_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9")
        ssid_entry.grid(row=0, column=1, sticky="ew", padx=(10, 0), pady=4)
        tk.Label(form, text=self._t("Passwort", "Password", "Heslo"), bg="#12161b", fg="#f3f6f9", anchor="w").grid(row=1, column=0, sticky="w", pady=4)
        password_entry = tk.Entry(
            form,
            textvariable=password_var,
            show="*",
            bg="#1a2028",
            fg="#f3f6f9",
            insertbackground="#f3f6f9",
        )
        password_entry.grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=4)
        form.columnconfigure(1, weight=1)

        def on_select(_event=None) -> None:
            selection = listbox.curselection()
            if not selection:
                return
            ssid = networks[selection[0]]["ssid"]
            ssid_var.set(ssid)
            password_var.set(known_passwords.get(ssid, ""))
            password_entry.focus_set()

        listbox.bind("<<ListboxSelect>>", on_select)
        if networks:
            listbox.selection_set(0)

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="x", padx=14, pady=(8, 14))

        def close_dialog() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            overlay.destroy()

        def save_selected() -> None:
            ssid = ssid_var.get().strip()
            password = password_var.get().strip()
            try:
                save_wifi_network(ssid, password)
            except (OSError, ValueError) as exc:
                messagebox.showerror(APP_TITLE, f"WLAN konnte nicht gespeichert werden:\n{exc}")
                return
            self.status_var.set(f"WLAN gespeichert: {ssid}")
            close_dialog()
            self.connect_saved_wifi()

        tk.Button(
            buttons,
            text=self._t("Speichern", "Save", "Ulozit"),
            command=save_selected,
            bg="#d4a84d",
            fg="#101418",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left")
        tk.Button(
            buttons,
            text=self._t("Abbrechen", "Cancel", "Zrusit"),
            command=close_dialog,
            bg="#2a3440",
            fg="#f3f6f9",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="right")

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
                dialog.lift()
                ssid_entry.focus_set()
            except tk.TclError:
                pass

        bring_to_front()
        overlay.after(100, bring_to_front)
        overlay.after(500, bring_to_front)

    def connect_saved_wifi(self) -> None:
        if self._wifi_busy:
            return
        self._wifi_busy = True
        self._set_internet_indicator("searching", "verbinde WLAN")
        self.status_var.set("WLAN: verbinde ...")

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._finish_wifi_progress(state, message))

        def worker() -> None:
            debug_lines: list[str] = []
            ok, message, cleanup = connect_temporary_network(progress, debug_lines)
            if not ok:
                cleanup()
            self.root.after(0, lambda ok=ok, message=message: self._finish_saved_wifi_connect(ok, message))

        threading.Thread(target=worker, name="wifi-connect", daemon=True).start()

    def _finish_saved_wifi_connect(self, ok: bool, message: str) -> None:
        self._wifi_busy = False
        self._set_internet_indicator("online" if ok else "error", message)
        self.status_var.set(f"WLAN: {message}")
        if self._pending_model_update:
            self._pending_model_update = False
            self.root.after(250, self.update_model_database)
        elif self._pending_program_update:
            self._pending_program_update = False
            self.root.after(250, self.check_hardwarecheck_update)

    def save_report(self) -> None:
        self._save_report_async()
        return
        report_dir = get_report_dir()
        report_dir.mkdir(parents=True, exist_ok=True)
        snapshot = self.snapshot or get_system_snapshot()
        matches = self.matches or get_model_matches(snapshot, self.language)
        report = build_report(snapshot, matches, self.language)
        filename = f"{report_basename(snapshot)}.txt"
        target = report_dir / filename
        try:
            write_text_durable(target, report)
            write_report_save_debug(target, ok=True)
        except OSError as exc:
            write_report_save_debug(target, ok=False, error=str(exc))
            self.status_var.set(
                f"{self._t('Bericht konnte nicht gespeichert werden', 'Report could not be saved', 'ZprÃ¡vu se nepodaÅ™ilo uloÅ¾it')}: {exc}"
            )
            return
        self.status_var.set(
            f"{self._t('Bericht gespeichert', 'Report saved', 'ZprÃ¡va uloÅ¾ena')}: {target} ({target.stat().st_size} Bytes)"
        )

    def _save_report_async(self) -> None:
        if getattr(self, "_report_busy", False):
            return
        self._report_busy = True
        language = self.language
        snapshot = dict(self.snapshot) if self.snapshot else {}
        matches = list(self.matches)
        self.status_var.set(self._t("Speichere Bericht ...", "Saving report ...", "Ukladam zpravu ..."))

        def worker() -> None:
            target: pathlib.Path | None = None
            try:
                report_dir = get_report_dir()
                report_dir.mkdir(parents=True, exist_ok=True)
                local_snapshot = snapshot or get_system_snapshot()
                local_matches = matches or get_model_matches(local_snapshot, language)
                report = build_report(local_snapshot, local_matches, language)
                target = report_dir / f"{report_basename(local_snapshot)}.txt"
                write_text_durable(target, report)
                write_report_save_debug(target, ok=True)
                size = target.stat().st_size
                self.root.after(0, lambda target=target, size=size: self._finish_report_save(target, size, None))
            except OSError as exc:
                error = str(exc)
                if target is not None:
                    write_report_save_debug(target, ok=False, error=error)
                self.root.after(0, lambda target=target, error=error: self._finish_report_save(target, 0, error))

        threading.Thread(target=worker, name="report-save", daemon=True).start()

    def _finish_report_save(self, target: pathlib.Path | None, size: int, error: str | None) -> None:
        self._report_busy = False
        if error:
            self.status_var.set(
                f"{self._t('Bericht konnte nicht gespeichert werden', 'Report could not be saved', 'Zpravu se nepodarilo ulozit')}: {error}"
            )
            return
        self.status_var.set(
            f"{self._t('Bericht gespeichert', 'Report saved', 'Zprava ulozena')}: {target} ({size} Bytes)"
        )

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    app = HardwareCheckApp()
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
