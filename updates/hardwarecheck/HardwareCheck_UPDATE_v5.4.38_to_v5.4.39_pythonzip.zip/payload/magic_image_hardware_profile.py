"""Pure hardware-profile normalization used by the shared Magic Image core.

This module deliberately accepts already collected values only.  It does not
read hardware, mount media, start Clonezilla, modify firmware or write files.
"""

from __future__ import annotations

import re

from magic_image_normalize import normalise_token
from magic_image_text import text


def vendor_token(value: object) -> str:
    token = normalise_token(value)
    aliases = {"hewlettpackard": "hp", "hpinc": "hp", "asustekcomputerinc": "asus", "asustek": "asus"}
    return aliases.get(token, token)


def cpu_token(value: object) -> str:
    raw = re.sub(r"\((?:r|tm)\)", "", text(value).casefold())
    core_match = re.search(r"\b(?:intel\s+)?core\s+(?:ultra\s+)?[3579]\s*\d{3,5}[a-z0-9-]*\b", raw)
    if core_match:
        return normalise_token(re.sub(r"^intel\s+", "", core_match.group(0)))
    for pattern in (r"\bi[3579][\s-]*\d{4,5}[a-z0-9-]*\b", r"\b(?:n|u|h|p)\d{3,5}[a-z0-9-]*\b", r"\b(?:ryzen\s*)?\d{4,5}[a-z0-9-]*\b"):
        match = re.search(pattern, raw)
        if match:
            return normalise_token(match.group(0))
    return normalise_token(raw)


def ram_type_token(value: object) -> str:
    token = normalise_token(value)
    for candidate in ("lpddr5", "lpddr4", "ddr5", "ddr4", "ddr3"):
        if candidate in token:
            return candidate
    return token


def ram_layout_token(value: object) -> str:
    pairs = [(int(count), int(size)) for count, size in re.findall(r"\b(\d+)\s*x\s*(\d+)\b", text(value).casefold())]
    if not pairs:
        return normalise_token(value)
    modules = [size for count, size in pairs for _index in range(count)]
    return f"{len(modules)}x{modules[0]}" if len(set(modules)) == 1 else "+".join(f"1x{size}" for size in sorted(modules))


def ram_module_count(value: object) -> int | None:
    pairs = re.findall(r"\b(\d+)\s*x\s*\d+\b", text(value).casefold())
    return sum(int(count) for count in pairs) if pairs else None


def storage_kind(value: object) -> str:
    token = normalise_token(value)
    if "nvme" in token:
        return "nvme"
    if "emmc" in token:
        return "emmc"
    if "hdd" in token or "harddisk" in token:
        return "hdd"
    if "ssd" in token:
        return "sata-ssd"
    return token


def display_type_token(value: object) -> str:
    raw = text(value).casefold()
    token = normalise_token(raw)
    if "3840x2160" in token or "4k" in token or "uhd" in token:
        return "uhd"
    if "2560x1440" in token or "qhd" in token:
        return "qhd"
    if "1920x1080" in token or "fullhd" in token or token == "fhd":
        return "full-hd"
    if "1600x900" in token or "hdplus" in token or "hdplusplus" in token:
        return "hd-plus"
    if "1366x768" in token or token == "hd":
        return "hd"
    return token
