"""Pure value parsing for legacy Magic Image config text files."""

from __future__ import annotations

import re

from magic_image_text import text


def number(value: object) -> float | None:
    match = re.search(r"[-+]?\d+(?:[.,]\d+)?", text(value))
    if not match:
        return None
    try:
        return float(match.group(0).replace(",", "."))
    except ValueError:
        return None


def ssd_capacity_gb(value: object) -> int | None:
    raw = number(value)
    if raw is None or raw <= 0:
        return None
    capacities = (128, 256, 512, 1000, 2000, 4000)
    capacity = min(capacities, key=lambda item: min(abs(raw - item), abs(raw - (item * 0.931))))
    tolerance = max(16.0, capacity * 0.10)
    return capacity if min(abs(raw - capacity), abs(raw - (capacity * 0.931))) <= tolerance else int(round(raw))


def ram_capacity_gb(value: object) -> int | None:
    raw = number(value)
    if raw is None or raw <= 0:
        return None
    common_sizes = (4, 8, 12, 16, 20, 24, 32, 40, 48, 64)
    reserved_capacity = next((capacity for capacity in common_sizes if capacity * 0.75 <= raw <= capacity), None)
    if reserved_capacity is not None:
        return reserved_capacity
    capacity = min(common_sizes, key=lambda item: abs(raw - item))
    return capacity if abs(raw - capacity) <= 1.0 else int(round(raw))
