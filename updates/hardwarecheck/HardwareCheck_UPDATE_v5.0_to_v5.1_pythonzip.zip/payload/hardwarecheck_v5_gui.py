#!/usr/bin/env python3
"""Native GTK 3 interface for the HardwareCheck v5 line.

The proven HardwareCheck module remains the functional core.  This file only
owns the new navigation, presentation and asynchronous UI orchestration so the
legacy Tk interface remains available as a safe fallback.
"""

from __future__ import annotations

import datetime
import json
import os
import pathlib
import re
import sys
import threading
import traceback
from typing import Callable

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango  # noqa: E402


APP_ID = "de.hardwarecheck.v5"
ACCENT = "#f7b733"
GOOD = "#2ec98f"
WARN = "#f0a83b"
BAD = "#ed5d68"
INFO = "#4aa7ff"


CSS = b"""
* {
  font-family: Inter, "Segoe UI", sans-serif;
}
window, .app-root {
  background: #0b1018;
  color: #ecf2f8;
}
.topbar {
  background: #111824;
  border-bottom: 1px solid #283347;
  padding: 10px 18px;
}
.brand {
  color: #ffffff;
  font-size: 22px;
  font-weight: 800;
}
.version {
  color: #8fa2b8;
  font-size: 11px;
  font-weight: 700;
}
.status-chip {
  background: #192334;
  border: 1px solid #30405a;
  border-radius: 18px;
  color: #cfe0ef;
  padding: 7px 12px;
  font-weight: 700;
}
.status-chip.good { color: #74e1b5; border-color: #286b54; }
.status-chip.warn { color: #ffd07b; border-color: #735824; }
.status-chip.bad { color: #ff969e; border-color: #71313a; }
.update-alert {
  border: 2px solid #ffffff;
  border-radius: 10px;
  padding: 8px 14px;
  font-weight: 900;
}
.update-phase-red { background: #b51f32; color: #ffffff; border-color: #ff8a98; }
.update-phase-gold { background: #e6a82e; color: #10151d; border-color: #fff2ad; }
.update-phase-blue { background: #176fc1; color: #ffffff; border-color: #92ccff; }
.update-phase-purple { background: #8138a6; color: #ffffff; border-color: #e4a8ff; }
popover, popover.background, .dark-popover, .dark-popover > contents {
  background: #111824;
  color: #ecf2f8;
  border-color: #34435b;
}
.dark-popover { border: 1px solid #34435b; border-radius: 12px; }
.sidebar {
  background: #0e1520;
  border-right: 1px solid #253146;
  padding: 14px 10px;
}
.nav-button {
  background: transparent;
  color: #aebdcd;
  border: 0;
  border-radius: 10px;
  padding: 12px 14px;
  margin: 2px 0;
  font-size: 14px;
  font-weight: 700;
}
.nav-button:hover { background: #182235; color: #ffffff; }
.nav-button.active {
  background: #253044;
  color: #ffd06a;
  border-left: 4px solid #f7b733;
}
.content { background: #0b1018; padding: 20px; }
.page-title { color: #ffffff; font-size: 26px; font-weight: 800; }
.page-subtitle { color: #8fa2b8; font-size: 13px; }
.hero {
  background: linear-gradient(135deg, #18253a, #172033);
  border: 1px solid #33435e;
  border-radius: 16px;
  padding: 22px;
}
.hero-title { color: #ffffff; font-size: 25px; font-weight: 800; }
.hero-subtitle { color: #aebed0; font-size: 14px; }
.section-title { color: #f5f8fb; font-size: 17px; font-weight: 800; }
.card {
  background: #141c29;
  border: 1px solid #2b374c;
  border-radius: 14px;
  padding: 16px;
}
.card:hover { border-color: #435674; }
.card-icon { color: #f7b733; }
.card-title { color: #92a5ba; font-size: 12px; font-weight: 700; }
.card-value { color: #ffffff; font-size: 19px; font-weight: 800; }
.card-subtitle { color: #7f91a7; font-size: 11px; }
.battery-live-panel {
  background: #102920;
  border: 1px solid #2f755a;
  border-radius: 12px;
  padding: 11px 14px;
}
.battery-live-panel.warn { background: #302510; border-color: #8b6725; }
.battery-live-panel.bad { background: #351920; border-color: #8b3946; }
.battery-live-title { color: #70e2b5; font-size: 14px; font-weight: 800; }
.battery-live-panel.warn .battery-live-title { color: #ffd071; }
.battery-live-panel.bad .battery-live-title { color: #ff969e; }
.battery-live-subtitle { color: #9eb3c2; font-size: 11px; }
.battery-metric-card {
  background: #101827;
  border: 1px solid #30405a;
  border-radius: 12px;
  padding: 12px 14px;
}
.battery-metric-card .card-value { font-size: 26px; }
.battery-metric-card.compact .card-value { font-size: 20px; }
.battery-history-card {
  background: #0d1522;
  border: 1px solid #30405a;
  border-radius: 12px;
  padding: 12px 14px;
}
.battery-chart { background: #0e151f; }
.battery-mini-panel {
  background: #11222b;
  border: 1px solid #2b6170;
  border-radius: 11px;
  padding: 10px;
  margin: 8px 0;
}
.battery-mini-panel.warn { background: #302510; border-color: #8b6725; }
.battery-mini-panel.bad { background: #351920; border-color: #8b3946; }
.battery-mini-title { color: #65dfae; font-size: 11px; font-weight: 800; }
.battery-mini-panel.warn .battery-mini-title { color: #ffd071; }
.battery-mini-panel.bad .battery-mini-title { color: #ff969e; }
.battery-mini-value { color: #ffffff; font-size: 16px; font-weight: 800; }
.battery-mini-subtitle { color: #8fa2b8; font-size: 10px; }
.battery-mini-panel levelbar trough { min-height: 9px; }
.quick-button {
  background: #162234;
  border: 1px solid #344763;
  border-radius: 13px;
  color: #ffffff;
  padding: 16px;
  font-size: 14px;
  font-weight: 800;
}
.quick-button:hover { background: #21314a; border-color: #f7b733; }
.primary-button {
  background: #e6a82e;
  color: #11151d;
  border: 0;
  border-radius: 9px;
  padding: 9px 16px;
  font-weight: 800;
}
.primary-button:hover { background: #ffc957; }
.secondary-button {
  background: #1b2739;
  color: #e8eef5;
  border: 1px solid #354762;
  border-radius: 9px;
  padding: 9px 14px;
  font-weight: 700;
}
.secondary-button:hover { background: #25354d; }
.danger-button {
  background: #42212a;
  color: #ffabb2;
  border: 1px solid #78343f;
  border-radius: 9px;
  padding: 9px 14px;
  font-weight: 800;
}
entry, searchentry, spinbutton {
  background: #101825;
  color: #f7f9fc;
  border: 1px solid #3b4b64;
  border-radius: 9px;
  padding: 9px 12px;
}
treeview, list, textview, textview text {
  background: #101722;
  color: #eaf0f6;
}
treeview header button {
  background: #d9d6cf;
  color: #121820;
  border: 1px solid #b9b5ad;
  font-weight: 800;
  padding: 8px;
}
treeview:selected, row:selected { background: #a96b00; color: #ffffff; }
.list-row { background: #121b28; border-bottom: 1px solid #29364a; padding: 10px; }
.list-row:hover { background: #192538; }
.muted { color: #8da0b5; }
.good-text { color: #55dca8; font-weight: 800; }
.warn-text { color: #ffc86b; font-weight: 800; }
.bad-text { color: #ff858f; font-weight: 800; }
.match-cell { background: #176b61; color: #ffffff; padding: 8px; }
.mismatch-cell { background: #85242b; color: #ffffff; padding: 8px; }
.reference-cell { background: #18506b; color: #ffffff; padding: 8px; }
.neutral-cell { background: #151e2b; color: #dce6f0; padding: 8px; }
.unavailable-cell { background: #171d27; color: #748397; padding: 8px; }
.comparison-header { background: #d9d6cf; color: #111820; padding: 8px; font-weight: 800; }
.footer {
  background: #101722;
  border-top: 1px solid #263247;
  color: #91a3b8;
  padding: 7px 14px;
}
.footer.update-phase-red, .nav-button.update-phase-red { background: #b51f32; color: #ffffff; border-color: #ff8a98; }
.footer.update-phase-gold, .nav-button.update-phase-gold { background: #e6a82e; color: #10151d; border-color: #fff2ad; }
.footer.update-phase-blue, .nav-button.update-phase-blue { background: #176fc1; color: #ffffff; border-color: #92ccff; }
.footer.update-phase-purple, .nav-button.update-phase-purple { background: #8138a6; color: #ffffff; border-color: #e4a8ff; }
.footer.update-phase-red label, .footer.update-phase-blue label, .footer.update-phase-purple label,
.nav-button.update-phase-red label, .nav-button.update-phase-blue label, .nav-button.update-phase-purple label { color: #ffffff; }
.footer.update-phase-gold label, .nav-button.update-phase-gold label { color: #10151d; }
progressbar trough, levelbar trough {
  background: #253044;
  border: 0;
  border-radius: 6px;
  min-height: 12px;
}
progressbar progress, levelbar block.filled {
  background: #2ec98f;
  border: 0;
  border-radius: 6px;
}
separator { background: #2a374b; }
"""


def _clean(value: object, fallback: str = "–") -> str:
    text = str(value or "").strip()
    return text if text else fallback


def _short(value: object, maximum: int = 80) -> str:
    text = " ".join(str(value or "").split())
    return text if len(text) <= maximum else text[: maximum - 1].rstrip() + "…"


def _flag_rgb(language: str, width: int = 42, height: int = 26) -> bytes:
    language = str(language or "DE").upper()
    data = bytearray()
    for y in range(height):
        for x in range(width):
            nx = x / max(1, width - 1)
            ny = y / max(1, height - 1)
            if language == "CZ":
                color = (248, 248, 248) if ny < 0.5 else (215, 20, 26)
                if nx <= 0.5 * (1.0 - abs(2.0 * ny - 1.0)):
                    color = (17, 69, 126)
            elif language == "EN":
                color = (33, 70, 139)
                if abs(ny - nx) <= 0.13 or abs(ny - (1.0 - nx)) <= 0.13:
                    color = (247, 247, 247)
                if abs(ny - nx) <= 0.05 or abs(ny - (1.0 - nx)) <= 0.05:
                    color = (207, 20, 43)
                if abs(nx - 0.5) <= 0.13 or abs(ny - 0.5) <= 0.20:
                    color = (247, 247, 247)
                if abs(nx - 0.5) <= 0.06 or abs(ny - 0.5) <= 0.09:
                    color = (207, 20, 43)
            else:
                color = (20, 20, 20) if ny < 1 / 3 else (221, 30, 47) if ny < 2 / 3 else (245, 202, 40)
            data.extend(color)
    return bytes(data)


def flag_pixbuf(language: str, width: int = 42, height: int = 26) -> GdkPixbuf.Pixbuf:
    raw = GLib.Bytes.new(_flag_rgb(language, width, height))
    return GdkPixbuf.Pixbuf.new_from_bytes(raw, GdkPixbuf.Colorspace.RGB, False, 8, width, height, width * 3)


class BatteryHistoryArea(Gtk.DrawingArea):
    """Drawing widget that owns its render pass on all supported GTK 3 builds."""

    def __init__(self, draw_callback: Callable[[Gtk.DrawingArea, object], bool]) -> None:
        super().__init__()
        self._draw_callback = draw_callback
        self.set_app_paintable(True)
        self.get_style_context().add_class("battery-chart")

    def do_draw(self, context) -> bool:
        self._draw_callback(self, context)
        # The chart paints its full allocation. Stopping propagation prevents
        # some live-system themes from painting their background over it.
        return True


class HardwareCheckV5(Gtk.Application):
    """GTK shell using the proven v3 core functions without blocking startup."""

    UPDATE_PHASE_CLASSES = (
        "update-phase-red",
        "update-phase-gold",
        "update-phase-blue",
        "update-phase-purple",
    )

    NAV_ITEMS = (
        ("dashboard", "view-grid-symbolic", ("Übersicht", "Overview", "Přehled")),
        ("models", "system-search-symbolic", ("ModelFinder", "Model finder", "Vyhledávač modelů")),
        ("battery", "battery-symbolic", ("Akku-Test", "Battery test", "Test baterie")),
        ("print", "document-print-symbolic", ("Drucken", "Print", "Tisk")),
        ("reports", "folder-documents-symbolic", ("Reports", "Reports", "Reporty")),
        ("settings", "preferences-system-symbolic", ("Einstellungen", "Settings", "Nastavení")),
    )

    # User-facing milestones rather than a technical commit log. Keep this
    # list current whenever a stable HardwareCheck version is published.
    VERSION_HISTORY = (
        {
            "version": "V5.1",
            "date": "06.08.2026",
            "title": ("Akku-Werkstatttest", "Battery workshop test", "Dílenský test baterie"),
            "items": (
                (
                    "Adaptiver Lade-/Entladetest: mindestens 30 Minuten und 5 % Änderung, maximal 60 Minuten.",
                    "Adaptive charge/discharge test: at least 30 minutes and 5% change, maximum 60 minutes.",
                    "Adaptivní test nabíjení/vybíjení: nejméně 30 minut a změna 5 %, maximálně 60 minut.",
                ),
                (
                    "Klare Gesamtbewertung mit Handlungsempfehlung und automatischem Abbruch bei kritischen Auffälligkeiten.",
                    "Clear overall result with recommendation and automatic stop for critical anomalies.",
                    "Jasné celkové hodnocení s doporučením a automatickým ukončením při kritických odchylkách.",
                ),
                (
                    "Live-Akkuanzeige, Verlaufsgrafik, Restlaufzeit sowie verständlicher kompakter Druckbericht.",
                    "Live battery display, history chart, runtime estimate and a concise readable print report.",
                    "Živý stav baterie, graf průběhu, odhad výdrže a stručný srozumitelný tiskový report.",
                ),
                (
                    "Versionsverlauf direkt in den Einstellungen nachlesbar.",
                    "Version history can be read directly in Settings.",
                    "Historie verzí je dostupná přímo v nastavení.",
                ),
            ),
        },
        {
            "version": "V5.0",
            "date": "05.08.2026",
            "title": ("Neue native GTK-Oberfläche", "New native GTK interface", "Nové nativní rozhraní GTK"),
            "items": (
                (
                    "Modernes Werkstatt-Dashboard mit schneller Navigation und weiterhin schnellem Programmstart.",
                    "Modern workshop dashboard with quick navigation and fast application startup.",
                    "Moderní dílenský panel s rychlou navigací a rychlým spuštěním aplikace.",
                ),
                (
                    "Erweiterter ModelFinder: aktuelles Gerät, Familienvorschläge, Refurbished-Modelle und Mehrfachvergleich.",
                    "Expanded ModelFinder: current device, family suggestions, refurbished models and multi-model comparison.",
                    "Rozšířený ModelFinder: aktuální zařízení, návrhy řady, repasované modely a vícenásobné porovnání.",
                ),
                (
                    "WLAN-Schnellauswahl, automatische Wiederverbindung, Drucken, Reports und sichtbarer Updatefortschritt.",
                    "Quick Wi-Fi selection, automatic reconnect, printing, reports and visible update progress.",
                    "Rychlý výběr Wi-Fi, automatické opětovné připojení, tisk, reporty a viditelný průběh aktualizace.",
                ),
                (
                    "Die bewährte Legacy-Oberfläche bleibt als sicherer Rückfall verfügbar.",
                    "The proven legacy interface remains available as a safe fallback.",
                    "Osvědčené původní rozhraní zůstává k dispozici jako bezpečná záloha.",
                ),
            ),
        },
        {
            "version": "V4",
            "date": "2026",
            "title": ("Linux- und Update-Brückengeneration", "Linux and update bridge generation", "Generace Linuxu a aktualizačního mostu"),
            "items": (
                (
                    "Vierte interne Linux-/Stick-Generation als stabile technische Basis für HardwareCheck V5.",
                    "Fourth internal Linux/USB generation as the stable technical foundation for HardwareCheck V5.",
                    "Čtvrtá interní generace Linuxu/USB jako stabilní technický základ pro HardwareCheck V5.",
                ),
                (
                    "Sichere Updatebrücke von V3.78 zu V5; WLANs, Drucker, Datenbank, Reports und Geräteidentität bleiben erhalten.",
                    "Safe update bridge from V3.78 to V5 while preserving Wi-Fi, printers, database, reports and device identity.",
                    "Bezpečný aktualizační most z V3.78 na V5 se zachováním Wi-Fi, tiskáren, databáze, reportů a identity zařízení.",
                ),
            ),
        },
        {
            "version": "V3",
            "date": "2026",
            "title": ("Bewährte Werkstatt- und Legacy-Linie", "Proven workshop and legacy line", "Osvědčená dílenská a původní řada"),
            "items": (
                (
                    "Modelldatenbank, Modellvorschläge, Gerätestatus sowie sichere DB- und Programmupdates.",
                    "Model database, model suggestions, device status and safe database/application updates.",
                    "Databáze modelů, návrhy modelů, stav zařízení a bezpečné aktualizace databáze i programu.",
                ),
                (
                    "Gespeicherte WLAN-Profile mit automatischer Verbindung sowie Druckersuche und Druckerprofile.",
                    "Saved Wi-Fi profiles with automatic connection plus printer discovery and printer profiles.",
                    "Uložené profily Wi-Fi s automatickým připojením, vyhledávání tiskáren a profily tiskáren.",
                ),
                (
                    "Robustere Hardwareerkennung, beschreibbare USB-Pfade, Reports und Bedienung in DE/EN/CZ.",
                    "More robust hardware detection, writable USB paths, reports and DE/EN/CZ operation.",
                    "Robustnější detekce hardwaru, zapisovatelné cesty USB, reporty a ovládání v DE/EN/CZ.",
                ),
                (
                    "V3.78 ist die letzte stabile klassische Oberfläche und bleibt in V5 weiterhin aufrufbar.",
                    "V3.78 is the final stable classic interface and remains accessible from V5.",
                    "V3.78 je poslední stabilní klasické rozhraní a zůstává dostupné z V5.",
                ),
            ),
        },
        {
            "version": "V2",
            "date": "Grundgeneration",
            "title": ("Ausbau zum Werkstattwerkzeug", "Expansion into a workshop tool", "Rozšíření na dílenský nástroj"),
            "items": (
                (
                    "Erweiterte Erkennung von CPU, RAM, Speicher, Anzeige und Geräteidentifikation.",
                    "Expanded detection of CPU, RAM, storage, display and device identity.",
                    "Rozšířená detekce CPU, RAM, úložiště, displeje a identity zařízení.",
                ),
                (
                    "Übersichtlichere Ergebnisse und speicherbare Werkstattberichte.",
                    "Clearer results and savable workshop reports.",
                    "Přehlednější výsledky a ukládatelné dílenské reporty.",
                ),
            ),
        },
        {
            "version": "V1",
            "date": "Start",
            "title": ("Erste HardwareCheck-Version", "First HardwareCheck version", "První verze HardwareCheck"),
            "items": (
                (
                    "Automatischer Hardware-Scan für den schnellen Notebook- und PC-Eingangstest.",
                    "Automatic hardware scan for quick incoming notebook and PC checks.",
                    "Automatické skenování hardwaru pro rychlou vstupní kontrolu notebooků a PC.",
                ),
                (
                    "Grundlegende Systemübersicht als Basis für alle späteren Werkstattfunktionen.",
                    "Basic system overview as the foundation for all later workshop functions.",
                    "Základní přehled systému jako základ všech pozdějších dílenských funkcí.",
                ),
            ),
        },
    )

    def __init__(self, core) -> None:
        super().__init__(application_id=APP_ID, flags=0)
        self.core = core
        try:
            self.language = core.LANGUAGES[core.load_language_index()]
        except Exception:
            self.language = "DE"
        self.window: Gtk.ApplicationWindow | None = None
        self.stack: Gtk.Stack | None = None
        self.nav_buttons: dict[str, Gtk.Button] = {}
        self.pages: dict[str, Gtk.Widget] = {}
        self.current_page = "dashboard"
        self.snapshot: dict[str, object] = {}
        self.models: list[dict[str, object]] = []
        self.match_results: list[dict[str, object]] = []
        self._model_relation_map: dict[str, tuple[list[str], list[str]]] = {}
        self._model_selected_ids: list[str] = []
        self._model_visible_results: list[tuple[int, dict[str, object]]] = []
        self._model_option_bindings: list[dict[str, object]] = []
        self._model_selection_syncing = False
        self._busy_count = 0
        self._refresh_tasks: set[str] = set()
        self._battery_samples: list[dict[str, object]] = []
        self._battery_mode = ""
        self._battery_csv_path: pathlib.Path | None = None
        self._battery_timer_id: int | None = None
        self._battery_display_details: dict[str, object] = {}
        self._battery_last_metrics: dict[str, object] = {}
        self._battery_last_result: dict[str, object] = {}
        self._battery_last_report_path: pathlib.Path | None = None
        self._battery_chart_signature = ""
        self._printer_results: list[dict[str, object]] = []
        self._report_paths: list[pathlib.Path] = []
        self._wifi_autoconnect_started = False
        self._wifi_connection_busy = False
        self._wifi_connected_ssid = ""
        self._wifi_quick_networks: list[dict[str, str]] = []
        self._auto_update_check_started = False
        self._update_operation = ""
        self._db_update_available = False
        self._program_update_available = False
        self._update_alert_demo = False
        self._update_alert_timer_id: int | None = None
        self._update_alert_phase = 0
        self._update_progress_determinate = False
        self._build_refs: dict[str, object] = {}

    def _t(self, de: str, en: str, cz: str) -> str:
        return {"DE": de, "EN": en, "CZ": cz}.get(self.language, de)

    def do_activate(self) -> None:
        if self.window is not None:
            self.window.present()
            return
        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.window = Gtk.ApplicationWindow(application=self)
        self.window.set_title(f"HardwareCheck {self.core.APP_VERSION}")
        self.window.set_default_size(1366, 820)
        self.window.set_size_request(900, 600)
        self.window.get_style_context().add_class("app-root")
        if os.environ.get("HC_V5_WINDOWED") == "1":
            self.window.set_position(Gtk.WindowPosition.CENTER)
        else:
            self.window.fullscreen()

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.window.add(root)
        root.pack_start(self._build_topbar(), False, False, 0)

        middle = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        root.pack_start(middle, True, True, 0)
        middle.pack_start(self._build_sidebar(), False, False, 0)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=180)
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        middle.pack_start(self.stack, True, True, 0)
        self._build_pages()
        root.pack_end(self._build_footer(), False, False, 0)

        self.window.show_all()
        self._restore_battery_test()
        self.show_page("dashboard")
        GLib.timeout_add_seconds(1, self._clock_tick)
        GLib.timeout_add_seconds(2, self._battery_refresh_tick)
        GLib.idle_add(self._start_initial_load)

    # ---------- shared widgets ----------

    def _icon(self, name: str, size: Gtk.IconSize = Gtk.IconSize.BUTTON) -> Gtk.Image:
        return Gtk.Image.new_from_icon_name(name, size)

    def _label(self, text: str = "", css: str = "", xalign: float = 0.0, wrap: bool = False) -> Gtk.Label:
        label = Gtk.Label(label=text, xalign=xalign)
        if css:
            label.get_style_context().add_class(css)
        label.set_line_wrap(wrap)
        label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        label.set_selectable(False)
        return label

    def _button(self, text: str, callback: Callable, css: str = "secondary-button", icon: str = "") -> Gtk.Button:
        button = Gtk.Button()
        button.get_style_context().add_class(css)
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        box.set_halign(Gtk.Align.CENTER)
        if icon:
            box.pack_start(self._icon(icon), False, False, 0)
        box.pack_start(self._label(text), False, False, 0)
        button.add(box)
        button.connect("clicked", callback)
        return button

    def _page_shell(self, title: str, subtitle: str) -> tuple[Gtk.ScrolledWindow, Gtk.Box]:
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.get_style_context().add_class("content")
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        outer.set_margin_start(22)
        outer.set_margin_end(22)
        outer.set_margin_top(18)
        outer.set_margin_bottom(22)
        outer.pack_start(self._label(title, "page-title"), False, False, 0)
        if subtitle:
            outer.pack_start(self._label(subtitle, "page-subtitle", wrap=True), False, False, 2)
        scroll.add(outer)
        return scroll, outer

    def _card(self, title: str, value: str = "–", subtitle: str = "", icon: str = "computer-symbolic") -> tuple[Gtk.Frame, Gtk.Label, Gtk.Label]:
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.NONE)
        frame.set_size_request(245, 128)
        frame.get_style_context().add_class("card")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        frame.add(box)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        image = self._icon(icon, Gtk.IconSize.LARGE_TOOLBAR)
        image.get_style_context().add_class("card-icon")
        top.pack_start(image, False, False, 0)
        top.pack_start(self._label(title, "card-title"), True, True, 0)
        box.pack_start(top, False, False, 0)
        value_label = self._label(value, "card-value", wrap=True)
        value_label.set_ellipsize(Pango.EllipsizeMode.END)
        box.pack_start(value_label, True, True, 0)
        subtitle_label = self._label(subtitle, "card-subtitle", wrap=True)
        box.pack_start(subtitle_label, False, False, 0)
        return frame, value_label, subtitle_label

    def _section(self, parent: Gtk.Box, title: str, margin_top: int = 16) -> Gtk.Box:
        title_label = self._label(title, "section-title")
        title_label.set_margin_top(margin_top)
        parent.pack_start(title_label, False, False, 4)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        parent.pack_start(box, False, False, 0)
        return box

    def _flow(self) -> Gtk.FlowBox:
        flow = Gtk.FlowBox()
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_row_spacing(12)
        flow.set_column_spacing(12)
        flow.set_homogeneous(True)
        flow.set_max_children_per_line(4)
        flow.set_min_children_per_line(1)
        return flow

    # ---------- application chrome ----------

    def _build_topbar(self) -> Gtk.Widget:
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        bar.get_style_context().add_class("topbar")
        brand_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        brand_box.pack_start(self._label("HardwareCheck", "brand"), False, False, 0)
        brand_box.pack_start(self._label(f"VERSION {self.core.APP_VERSION.upper()} · GTK DEVELOPMENT", "version"), False, False, 0)
        bar.pack_start(brand_box, False, False, 0)

        self._build_refs["top_spinner"] = Gtk.Spinner()
        bar.pack_start(self._build_refs["top_spinner"], False, False, 0)
        bar.pack_start(Gtk.Box(), True, True, 0)

        network_button = self._build_wifi_quick_menu()
        update_button = self._build_update_alert_button()
        self._build_refs["db_chip"] = self._label("DB: –", "status-chip")
        self._build_refs["battery_chip"] = self._label(self._t("Akku: –", "Battery: –", "Baterie: –"), "status-chip")
        self._build_refs["clock"] = self._label("", "status-chip")
        bar.pack_start(network_button, False, False, 0)
        bar.pack_start(update_button, False, False, 0)
        for key in ("db_chip", "battery_chip", "clock"):
            bar.pack_start(self._build_refs[key], False, False, 0)
        return bar

    def _build_update_alert_button(self) -> Gtk.Button:
        button = Gtk.Button()
        button.get_style_context().add_class("update-alert")
        button.set_no_show_all(True)
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        inner.pack_start(self._icon("software-update-available-symbolic"), False, False, 0)
        label = self._label(self._t("UPDATE VERFÜGBAR", "UPDATE AVAILABLE", "AKTUALIZACE K DISPOZICI"))
        inner.pack_start(label, False, False, 0)
        button.add(inner)
        button.connect("clicked", self._open_update_settings)
        self._build_refs["update_alert_button"] = button
        self._build_refs["update_alert_label"] = label
        return button

    def _build_wifi_quick_menu(self) -> Gtk.MenuButton:
        button = Gtk.MenuButton()
        button.get_style_context().add_class("status-chip")
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        inner.pack_start(self._icon("network-wireless-symbolic"), False, False, 0)
        label = self._label(self._t("WLAN wird geprüft", "Checking Wi-Fi", "Kontrola Wi-Fi"))
        inner.pack_start(label, False, False, 0)
        button.add(inner)

        popover = Gtk.Popover.new(button)
        popover.get_style_context().add_class("dark-popover")
        popover.set_size_request(440, 430)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        content.set_margin_start(12)
        content.set_margin_end(12)
        content.set_margin_top(12)
        content.set_margin_bottom(12)

        heading = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        heading.pack_start(self._label("WLAN", "section-title"), True, True, 0)
        heading.pack_end(
            self._button(
                self._t("Aktualisieren", "Refresh", "Obnovit"),
                lambda _b: self._refresh_wifi_quick_menu(force=True),
                "secondary-button",
                "view-refresh-symbolic",
            ),
            False,
            False,
            0,
        )
        content.pack_start(heading, False, False, 0)
        quick_status = self._label(self._t("Verbindung wird geprüft …", "Checking connection …", "Kontrola připojení …"), "muted", wrap=True)
        content.pack_start(quick_status, False, False, 0)

        quick_list = Gtk.ListBox()
        quick_list.set_selection_mode(Gtk.SelectionMode.NONE)
        quick_scroll = Gtk.ScrolledWindow()
        quick_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        quick_scroll.set_min_content_height(270)
        quick_scroll.add(quick_list)
        content.pack_start(quick_scroll, True, True, 0)
        content.pack_start(
            self._button(
                self._t("Gespeicherte WLANs verwalten", "Manage saved Wi-Fi", "Spravovat uložené Wi-Fi"),
                lambda _b: self._open_settings_tool("wifi", popover),
                "secondary-button",
                "preferences-system-symbolic",
            ),
            False,
            False,
            0,
        )
        popover.add(content)
        content.show_all()
        button.set_popover(popover)
        button.connect("toggled", self._wifi_quick_toggled)
        self._build_refs["network_chip_button"] = button
        self._build_refs["network_chip"] = label
        self._build_refs["wifi_quick_popover"] = popover
        self._build_refs["wifi_quick_status"] = quick_status
        self._build_refs["wifi_quick_list"] = quick_list
        return button

    def _build_sidebar(self) -> Gtk.Widget:
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        side.set_size_request(225, -1)
        side.get_style_context().add_class("sidebar")
        for name, icon, texts in self.NAV_ITEMS:
            button = Gtk.Button()
            button.get_style_context().add_class("nav-button")
            inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            inner.pack_start(self._icon(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            label = self._label(self._t(*texts))
            inner.pack_start(label, True, True, 0)
            button.add(inner)
            button.connect("clicked", lambda _button, page=name: self.show_page(page))
            side.pack_start(button, False, False, 0)
            self.nav_buttons[name] = button
            self._build_refs[f"nav_label_{name}"] = label
        side.pack_start(Gtk.Box(), True, True, 0)
        battery_monitor = Gtk.Frame()
        battery_monitor.set_shadow_type(Gtk.ShadowType.NONE)
        battery_monitor.get_style_context().add_class("battery-mini-panel")
        battery_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        battery_monitor.add(battery_box)
        battery_head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        battery_head.pack_start(self._icon("battery-symbolic"), False, False, 0)
        battery_title = self._label(self._t("Akku-Test bereit", "Battery test ready", "Test baterie připraven"), "battery-mini-title", wrap=True)
        battery_head.pack_start(battery_title, True, True, 0)
        battery_value = self._label("–", "battery-mini-value")
        battery_head.pack_end(battery_value, False, False, 0)
        battery_box.pack_start(battery_head, False, False, 0)
        battery_level = Gtk.LevelBar.new_for_interval(0, 100)
        battery_box.pack_start(battery_level, False, False, 0)
        battery_subtitle = self._label("", "battery-mini-subtitle", wrap=True)
        battery_box.pack_start(battery_subtitle, False, False, 0)
        battery_monitor.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        battery_monitor.connect("button-press-event", lambda *_args: self.show_page("battery"))
        side.pack_start(battery_monitor, False, False, 0)
        self._build_refs["battery_mini_panel"] = battery_monitor
        self._build_refs["battery_mini_title"] = battery_title
        self._build_refs["battery_mini_value"] = battery_value
        self._build_refs["battery_mini_level"] = battery_level
        self._build_refs["battery_mini_subtitle"] = battery_subtitle
        side.pack_start(self._label(self._t("Native GTK-Oberfläche", "Native GTK interface", "Nativní rozhraní GTK"), "version", wrap=True), False, False, 8)
        side.pack_start(self._build_power_menu(), False, False, 0)
        return side

    def _build_power_menu(self) -> Gtk.MenuButton:
        button = Gtk.MenuButton()
        button.get_style_context().add_class("danger-button")
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        inner.set_halign(Gtk.Align.CENTER)
        inner.pack_start(self._icon("system-shutdown-symbolic"), False, False, 0)
        inner.pack_start(self._label(self._t("Ein/Aus", "Power", "Napájení")), False, False, 0)
        button.add(inner)

        popover = Gtk.Popover.new(button)
        popover.get_style_context().add_class("dark-popover")
        actions = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        actions.set_margin_start(6)
        actions.set_margin_end(6)
        actions.set_margin_top(6)
        actions.set_margin_bottom(6)
        actions.pack_start(
            self._button(
                self._t("Herunterfahren", "Shut down", "Vypnout"),
                lambda _b: self._power_menu_action("poweroff", popover),
                "secondary-button",
                "system-shutdown-symbolic",
            ),
            False,
            False,
            0,
        )
        actions.pack_start(
            self._button(
                self._t("Neu starten", "Restart", "Restartovat"),
                lambda _b: self._power_menu_action("reboot", popover),
                "secondary-button",
                "view-refresh-symbolic",
            ),
            False,
            False,
            0,
        )
        popover.add(actions)
        actions.show_all()
        button.set_popover(popover)
        self._build_refs["power_menu"] = popover
        return button

    def _build_footer(self) -> Gtk.Widget:
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        footer.get_style_context().add_class("footer")
        self._build_refs["footer_box"] = footer
        self._build_refs["footer_icon"] = self._icon("emblem-system-symbolic")
        self._build_refs["footer_status"] = self._label(self._t("v5 wird gestartet …", "Starting v5 …", "Spouštění v5 …"), wrap=True)
        footer.pack_start(self._build_refs["footer_icon"], False, False, 0)
        footer.pack_start(self._build_refs["footer_status"], True, True, 0)
        self._build_refs["footer_progress"] = Gtk.ProgressBar()
        self._build_refs["footer_progress"].set_size_request(170, -1)
        self._build_refs["footer_progress"].set_no_show_all(True)
        footer.pack_end(self._build_refs["footer_progress"], False, False, 0)
        return footer

    def _build_pages(self) -> None:
        builders = {
            "dashboard": self._build_dashboard,
            "models": self._build_models_page,
            "battery": self._build_battery_page,
            "wifi": self._build_wifi_page,
            "printers": self._build_printers_page,
            "print": self._build_print_page,
            "reports": self._build_reports_page,
            "settings": self._build_settings_page,
        }
        for name, builder in builders.items():
            page = builder()
            self.pages[name] = page
            self.stack.add_named(page, name)

    def show_page(self, name: str) -> None:
        if self.stack is None or name not in self.pages:
            return
        self.current_page = name
        self.stack.set_visible_child_name(name)
        active_nav = "settings" if name in {"wifi", "printers"} else name
        for key, button in self.nav_buttons.items():
            context = button.get_style_context()
            if key == active_nav:
                context.add_class("active")
            else:
                context.remove_class("active")
        if name == "wifi":
            self._refresh_wifi_saved_rows()
        elif name == "printers":
            self._refresh_printer_profiles()
        elif name == "print":
            self._refresh_print_page()
        elif name == "reports":
            self._refresh_reports()
        elif name == "models":
            self._refresh_model_table()

    # ---------- dashboard ----------

    def _build_dashboard(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Werkstatt-Dashboard", "Workshop dashboard", "Dílenský přehled"),
            self._t("Hardware, Modellabgleich und Servicetools auf einen Blick.", "Hardware, model matching and service tools at a glance.", "Hardware, porovnání modelů a servisní nástroje na jednom místě."),
        )
        hero = Gtk.Frame()
        hero.set_shadow_type(Gtk.ShadowType.NONE)
        hero.get_style_context().add_class("hero")
        hero_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hero.add(hero_box)
        hero_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self._build_refs["hero_title"] = self._label(self._t("Gerät wird erkannt …", "Detecting device …", "Rozpoznávání zařízení …"), "hero-title", wrap=True)
        self._build_refs["hero_subtitle"] = self._label(self._t("Die Oberfläche ist bereits bereit; der Hardware-Scan läuft im Hintergrund.", "The interface is ready while hardware scanning continues in the background.", "Rozhraní je připraveno, sken hardwaru probíhá na pozadí."), "hero-subtitle", wrap=True)
        hero_text.pack_start(self._build_refs["hero_title"], False, False, 0)
        hero_text.pack_start(self._build_refs["hero_subtitle"], False, False, 0)
        hero_box.pack_start(hero_text, True, True, 0)
        hero_box.pack_end(self._button(self._t("Neu scannen", "Scan again", "Skenovat znovu"), self._rescan_clicked, "primary-button", "view-refresh-symbolic"), False, False, 0)
        outer.pack_start(hero, False, False, 12)

        metrics = self._section(outer, self._t("Systemübersicht", "System overview", "Přehled systému"))
        flow = self._flow()
        metrics.pack_start(flow, False, False, 0)
        card_specs = (
            ("system", self._t("Gerät", "Device", "Zařízení"), "computer-symbolic"),
            ("cpu", "CPU", "cpu-symbolic"),
            ("ram", "RAM", "drive-harddisk-symbolic"),
            ("storage", self._t("Speicher", "Storage", "Úložiště"), "drive-harddisk-symbolic"),
            ("display", self._t("Anzeige", "Display", "Displej"), "video-display-symbolic"),
            ("match", self._t("Bester Modelltreffer", "Best model match", "Nejlepší shoda modelu"), "system-search-symbolic"),
        )
        for key, title, icon in card_specs:
            card, value, subtitle = self._card(title, icon=icon)
            flow.add(card)
            self._build_refs[f"metric_{key}"] = value
            self._build_refs[f"metric_{key}_sub"] = subtitle

        battery_live = Gtk.Frame()
        battery_live.set_shadow_type(Gtk.ShadowType.NONE)
        battery_live.get_style_context().add_class("battery-live-panel")
        battery_live.set_no_show_all(True)
        battery_live.hide()
        battery_live_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        battery_live.add(battery_live_row)
        battery_live_row.pack_start(self._icon("battery-good-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        battery_live_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        dashboard_battery_title = self._label("", "battery-live-title", wrap=True)
        dashboard_battery_subtitle = self._label("", "battery-live-subtitle", wrap=True)
        battery_live_text.pack_start(dashboard_battery_title, False, False, 0)
        battery_live_text.pack_start(dashboard_battery_subtitle, False, False, 0)
        battery_live_row.pack_start(battery_live_text, True, True, 0)
        dashboard_battery_level = Gtk.LevelBar.new_for_interval(0, 100)
        dashboard_battery_level.set_size_request(180, -1)
        battery_live_row.pack_start(dashboard_battery_level, False, False, 0)
        battery_live_row.pack_end(
            self._button(self._t("Akku-Test öffnen", "Open battery test", "Otevřít test baterie"), lambda _b: self.show_page("battery"), "secondary-button", "go-next-symbolic"),
            False,
            False,
            0,
        )
        outer.pack_start(battery_live, False, False, 12)
        self._build_refs["dashboard_battery_live"] = battery_live
        self._build_refs["dashboard_battery_title"] = dashboard_battery_title
        self._build_refs["dashboard_battery_subtitle"] = dashboard_battery_subtitle
        self._build_refs["dashboard_battery_level"] = dashboard_battery_level

        suggestions = self._section(outer, self._t("Modellvorschläge", "Model suggestions", "Návrhy modelů"))
        self._build_refs["dashboard_model_count"] = self._label(
            self._t("Hardware wird ausgewertet …", "Evaluating hardware …", "Vyhodnocování hardwaru …"),
            "muted",
        )
        suggestions.pack_start(self._build_refs["dashboard_model_count"], False, False, 0)
        self._build_refs["dashboard_model_list"] = Gtk.ListBox()
        self._build_refs["dashboard_model_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        suggestion_scroll = Gtk.ScrolledWindow()
        suggestion_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        suggestion_scroll.set_min_content_height(190)
        suggestion_scroll.add(self._build_refs["dashboard_model_list"])
        suggestions.pack_start(suggestion_scroll, False, False, 0)
        return page

    def _render_dashboard_model_suggestions(self) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("dashboard_model_list")
        count_label: Gtk.Label | None = self._build_refs.get("dashboard_model_count")
        if listbox is None or count_label is None:
            return
        self._clear_listbox(listbox)
        shown = self.match_results[:6]
        count_label.set_text(
            self._t(
                f"{len(self.match_results)} passende Geräte · die besten {len(shown)} werden angezeigt",
                f"{len(self.match_results)} matching devices · showing the best {len(shown)}",
                f"Odpovídající zařízení: {len(self.match_results)} · zobrazeno nejlepších {len(shown)}",
            )
        )
        if not shown:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Kein passendes Modell gefunden.", "No matching model found.", "Nebyl nalezen odpovídající model."), "muted", wrap=True))
            listbox.add(row)
        for index, result in enumerate(shown):
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            model_id = _clean(item.get("model_id"))
            score = int(result.get("score") or 0)
            row = Gtk.ListBoxRow()
            row.get_style_context().add_class("list-row")
            content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            row.add(content)
            rank = self._label("★" if index == 0 else str(index + 1), "good-text" if index == 0 else "muted", xalign=0.5)
            rank.set_size_request(32, -1)
            content.pack_start(rank, False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            title = f"{model_id} · {score}%"
            if index == 0:
                title = f"{self._t('Bester Treffer', 'Best match', 'Nejlepší shoda')}: {title}"
            text.pack_start(self._label(title, "section-title"), False, False, 0)
            text.pack_start(self._label(_short(self.core.model_notebook_summary(item), 100), "muted", wrap=True), False, False, 0)
            content.pack_start(text, True, True, 0)
            content.pack_end(
                self._button(
                    self._t("Vergleichen", "Compare", "Porovnat"),
                    lambda _b, value=model_id: self._open_dashboard_model(value),
                    "secondary-button",
                    "system-search-symbolic",
                ),
                False,
                False,
                0,
            )
            listbox.add(row)
        listbox.show_all()

    def _open_dashboard_model(self, model_id: str) -> None:
        search: Gtk.SearchEntry | None = self._build_refs.get("model_search")
        if search is not None:
            search.set_text(model_id)
            self._model_search_changed(search)
        self.show_page("models")

    # ---------- model finder ----------

    def _build_models_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            "ModelFinder",
            self._t("Modelle suchen, Gerätetreffer bewerten und mehrere Datensätze direkt vergleichen.", "Search models, evaluate device matches and compare multiple records directly.", "Vyhledávejte modely, vyhodnocujte shody zařízení a porovnávejte více záznamů."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self._build_refs["model_search"] = Gtk.SearchEntry()
        self._build_refs["model_search"].set_placeholder_text(self._t("Modell-ID, Hersteller, CPU oder Produktnummer", "Model ID, manufacturer, CPU or product number", "ID modelu, výrobce, CPU nebo produktové číslo"))
        self._build_refs["model_search"].connect("search-changed", self._model_search_changed)
        toolbar.pack_start(self._build_refs["model_search"], True, True, 0)
        self._build_refs["model_use_device"] = Gtk.CheckButton(label=self._t("Aktuelles Gerät anzeigen", "Show current device", "Zobrazit aktuální zařízení"))
        self._build_refs["model_use_device"].set_active(True)
        self._build_refs["model_use_device"].connect("toggled", self._model_device_toggled)
        toolbar.pack_start(self._build_refs["model_use_device"], False, False, 0)
        self._build_refs["model_selection_count"] = self._label(self._t("0/3 gewählt", "0/3 selected", "Vybráno 0/3"), "muted")
        toolbar.pack_start(self._build_refs["model_selection_count"], False, False, 0)
        toolbar.pack_start(self._button(self._t("Auswahl leeren", "Clear selection", "Zrušit výběr"), self._clear_model_selection, "secondary-button", "edit-clear-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)

        compare_frame = Gtk.Frame()
        compare_frame.set_shadow_type(Gtk.ShadowType.NONE)
        compare_frame.get_style_context().add_class("card")
        compare_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        compare_frame.add(compare_outer)
        compare_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["model_compare_title"] = self._label(self._t("Modellvergleich mit aktuellem Gerät", "Model comparison with current device", "Porovnání modelů s aktuálním zařízením"), "section-title")
        compare_header.pack_start(self._build_refs["model_compare_title"], True, True, 0)
        compare_header.pack_end(self._button(self._t("Mit gewählten Optionen suchen", "Search selected options", "Hledat vybrané možnosti"), self._search_selected_model_options, "primary-button", "system-search-symbolic"), False, False, 0)
        compare_outer.pack_start(compare_header, False, False, 0)
        compare_scroll = Gtk.ScrolledWindow()
        compare_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        compare_scroll.set_min_content_height(340)
        self._build_refs["compare_box"] = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        compare_scroll.add(self._build_refs["compare_box"])
        compare_outer.pack_start(compare_scroll, True, True, 0)
        outer.pack_start(compare_frame, False, False, 4)

        result_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        result_header.pack_start(self._label(self._t("Modellvorschläge", "Model suggestions", "Návrhy modelů"), "section-title"), False, False, 0)
        self._build_refs["model_result_count"] = self._label(self._t("Datenbank wird geladen …", "Loading database …", "Načítání databáze …"), "muted")
        result_header.pack_start(self._build_refs["model_result_count"], True, True, 0)
        outer.pack_start(result_header, False, False, 8)

        lower = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        lower.set_position(245)
        lower.set_size_request(-1, 390)
        outer.pack_start(lower, True, True, 0)
        store = Gtk.ListStore(str, str, str, str, str, str, str, str, object)
        self._build_refs["model_store"] = store
        tree = Gtk.TreeView(model=store)
        tree.set_headers_clickable(True)
        tree.set_grid_lines(Gtk.TreeViewGridLines.BOTH)
        tree.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
        tree.get_selection().connect("changed", self._model_selection_changed)
        tree.connect("button-press-event", self._model_tree_clicked)
        columns = (
            ("%", 0, 58),
            (self._t("Basis-ID", "Base ID", "Základní ID"), 1, 105),
            (self._t("Refurbished", "Refurbished", "Repasované"), 2, 110),
            (self._t("Hersteller", "Manufacturer", "Výrobce"), 3, 110),
            ("CPU", 4, 210),
            ("RAM", 5, 70),
            (self._t("Speicher", "Storage", "Úložiště"), 6, 170),
            (self._t("Anzeige", "Display", "Displej"), 7, 170),
        )
        for title, index, width in columns:
            renderer = Gtk.CellRendererText()
            renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
            column = Gtk.TreeViewColumn(title, renderer, text=index)
            column.set_min_width(width)
            column.set_resizable(True)
            column.set_sort_column_id(index)
            tree.append_column(column)
            if index == 0:
                self._build_refs["model_score_column"] = column
        model_scroll = Gtk.ScrolledWindow()
        model_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        model_scroll.add(tree)
        lower.pack1(model_scroll, True, False)
        self._build_refs["model_tree"] = tree

        self._build_refs["model_detail"] = Gtk.TextView()
        self._build_refs["model_detail"].set_editable(False)
        self._build_refs["model_detail"].set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        detail_scroll = Gtk.ScrolledWindow()
        detail_scroll.set_min_content_height(120)
        detail_scroll.add(self._build_refs["model_detail"])
        lower.pack2(detail_scroll, True, False)
        return page

    def _model_item_value(self, item: dict[str, object], key: str) -> str:
        if key == "ram":
            return _clean(self.core.model_ram_summary(item))
        if key == "storage":
            return _clean(self.core.model_storage_summary(item))
        if key == "display":
            return _clean(self.core.model_display_summary(item))
        if key == "notebook":
            return _clean(self.core.model_notebook_summary(item))
        if key == "condition":
            return _clean(self.core.model_condition_summary(item))
        aliases = {
            "os": ("operating_system", "os"),
            "software": ("software",),
            "vendor": ("vendor", "manufacturer"),
            "cpu": ("cpu",),
        }
        for alias in aliases.get(key, (key,)):
            value = str(item.get(alias) or "").strip()
            if value:
                return value
        return "–"

    def _model_relation_values(self, item: dict[str, object], selected_ids: set[str] | None = None) -> tuple[str, str]:
        model_id = _clean(item.get("model_id"))
        base_ids, refurbished_ids = self._model_relation_map.get(model_id, ([], []))
        selected_ids = selected_ids or set()

        def marked(values: list[str]) -> str:
            return ", ".join(f"{value} ★" if value in selected_ids else value for value in values)

        if self.core.model_is_refurbished(item):
            base_text = marked(base_ids[:2]) or "–"
            refurbished_text = marked([model_id])
        else:
            base_text = marked([model_id])
            refurbished_text = marked(refurbished_ids[:3]) or "–"
        return base_text, refurbished_text

    @staticmethod
    def _model_family_tokens_match(first: str, second: str) -> bool:
        first = str(first or "").strip().casefold()
        second = str(second or "").strip().casefold()
        if not first or not second:
            return False
        if first == second:
            return True
        common = 0
        for left, right in zip(first, second):
            if left != right:
                break
            common += 1
        return common >= 6 and any(character.isdigit() for character in first[:common])

    def _model_belongs_to_current_family(self, item: dict[str, object]) -> bool:
        if not self.snapshot:
            return False
        snapshot_vendor = self.core.normalize_generic_token(
            str(self.snapshot.get("vendor_short") or self.snapshot.get("vendor") or "")
        )
        item_vendor = self.core.normalize_generic_token(str(item.get("vendor") or ""))
        if not snapshot_vendor or snapshot_vendor != item_vendor:
            return False

        snapshot_products = self.core.snapshot_product_numbers(self.snapshot)
        item_products = self.core.row_product_numbers(item)
        if snapshot_products and item_products:
            return any(
                self._model_family_tokens_match(snapshot_product, item_product)
                for snapshot_product in snapshot_products
                for item_product in item_products
            )

        snapshot_cpu = self.core.normalize_cpu_token(
            str(self.snapshot.get("cpu_short") or self.snapshot.get("cpu") or "")
        )
        item_cpu = self.core.normalize_cpu_token(str(item.get("cpu") or ""))
        if not snapshot_cpu or snapshot_cpu != item_cpu:
            return False
        snapshot_inches = self.core.display_inches_number(self.snapshot.get("display_inches"))
        item_inches = self.core.display_inches_number(item.get("inch"))
        return snapshot_inches is None or item_inches is None or self.core.compare_inches(snapshot_inches, item_inches)

    def _current_family_models(self) -> list[dict[str, object]]:
        hardware_matches = [
            result["item"]
            for result in self.match_results
            if isinstance(result.get("item"), dict)
        ]
        family_matches = [item for item in self.models if self._model_belongs_to_current_family(item)]
        combined: list[dict[str, object]] = []
        combined_ids: set[str] = set()
        for item in hardware_matches + family_matches:
            model_id = str(item.get("model_id") or "")
            if model_id and model_id not in combined_ids:
                combined_ids.add(model_id)
                combined.append(item)
        if combined:
            compact: list[dict[str, object]] = []
            for item in combined:
                model_id = str(item.get("model_id") or "")
                base_ids, _refurbished_ids = self._model_relation_map.get(model_id, ([], []))
                if self.core.model_is_refurbished(item) and any(base_id in combined_ids for base_id in base_ids):
                    continue
                compact.append(item)
            return compact
        return []

    def _refresh_model_table(self) -> None:
        if not self.models:
            self._populate_model_results([])
            self._render_model_comparison()
            return
        query = self._build_refs["model_search"].get_text().strip()
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        if query:
            # An explicit search is deliberately unrestricted: it must also allow
            # comparing unrelated database models with the current device.
            items = self.core.find_model_db_items(query, limit=250, entries=self.models)
        elif use_device:
            items = self._current_family_models()
        else:
            # With the current device disabled the ModelFinder remains a free,
            # independent database comparison tool.
            items = self.models
        results = [(self._model_display_score(item), item) for item in items]
        if self._model_has_score_reference():
            results.sort(key=lambda pair: (-pair[0], self.core.model_value_int(pair[1].get("model_id"))))
        self._populate_model_results(results[:250])
        self._render_model_comparison()

    def _model_has_score_reference(self) -> bool:
        return bool(
            self._build_refs.get("model_use_device")
            and self._build_refs["model_use_device"].get_active()
            and self.snapshot
        ) or bool(self._model_selected_ids)

    def _model_display_score(self, item: dict[str, object]) -> int:
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        if use_device:
            model_id = str(item.get("model_id") or "")
            for result in self.match_results:
                result_item = result.get("item") if isinstance(result.get("item"), dict) else {}
                if str(result_item.get("model_id") or "") == model_id:
                    return int(result.get("score") or 0)
            result = self.core.score_snapshot_model_for_finder(self.snapshot, item)
            return int(result.get("score") or 0)
        selected = self._selected_model_items()
        if selected:
            return int(self.core.model_similarity_score(selected[0], item))
        return 0

    def _populate_model_results(self, results: list[tuple[int, dict[str, object]]]) -> None:
        store: Gtk.ListStore | None = self._build_refs.get("model_store")
        tree: Gtk.TreeView | None = self._build_refs.get("model_tree")
        if store is None or tree is None:
            return
        self._model_visible_results = [(score, item) for score, item in results if isinstance(item, dict)]
        self._model_selection_syncing = True
        try:
            store.clear()
            show_score = self._model_has_score_reference()
            score_column: Gtk.TreeViewColumn | None = self._build_refs.get("model_score_column")
            if score_column is not None:
                score_column.set_title(self._t("% Gerät", "% Device", "% Zařízení") if self._build_refs["model_use_device"].get_active() and self.snapshot else self._t("% Ähnl.", "% Similar", "% Podob."))
            selected_ids = set(self._model_selected_ids)
            selected_paths: list[Gtk.TreePath] = []
            for score, item in self._model_visible_results:
                model_id = _clean(item.get("model_id"))
                base_id, refurbished = self._model_relation_values(item, selected_ids)
                iterator = store.append([
                    f"{score}%" if show_score else "–",
                    base_id,
                    _short(refurbished, 28),
                    _short(self._model_item_value(item, "vendor"), 24),
                    _short(self._model_item_value(item, "cpu"), 42),
                    _short(item.get("ram_total") or item.get("total_ram_gb") or self._model_item_value(item, "ram"), 18),
                    _short(self._model_item_value(item, "storage"), 38),
                    _short(self._model_item_value(item, "display"), 38),
                    item,
                ])
                if model_id in selected_ids:
                    selected_paths.append(store.get_path(iterator))
            selection = tree.get_selection()
            selection.unselect_all()
            for path in selected_paths:
                selection.select_path(path)
        finally:
            self._model_selection_syncing = False
        count = len(self._model_visible_results)
        family_mode = bool(
            self._build_refs["model_use_device"].get_active()
            and self.snapshot
            and not self._build_refs["model_search"].get_text().strip()
        )
        self._build_refs["model_result_count"].set_text(
            self._t(
                f"{count} Geräte-/Familienvorschläge · Anklicken = direkt vergleichen" if family_mode else f"{count} Vorschläge · Anklicken = direkt vergleichen",
                f"{count} device/family suggestions · click to compare" if family_mode else f"{count} suggestions · click to compare",
                f"{count} návrhů zařízení/řady · kliknutím porovnáte" if family_mode else f"{count} návrhů · kliknutím porovnáte",
            )
        )
        self._update_model_selection_count()

    def _model_search_changed(self, _entry) -> None:
        query = self._build_refs["model_search"].get_text().strip()
        exact_ids = re.findall(r"\b\d{4,6}\b", query)
        if exact_ids:
            available = {str(item.get("model_id") or ""): item for item in self.models}
            maximum = self._model_selection_limit()
            selected: list[str] = []
            for model_id in exact_ids:
                if model_id in available and model_id not in selected:
                    selected.append(model_id)
            self._model_selected_ids = selected[:maximum]
        self._refresh_model_table()

    def _model_device_toggled(self, _button) -> None:
        maximum = self._model_selection_limit()
        self._model_selected_ids = self._model_selected_ids[:maximum]
        self._refresh_model_table()

    def _model_selection_limit(self) -> int:
        use_device = bool(
            self._build_refs.get("model_use_device")
            and self._build_refs["model_use_device"].get_active()
            and self.snapshot
        )
        return 3 if use_device else 4

    def _update_model_selection_count(self) -> None:
        maximum = self._model_selection_limit()
        count = len(self._model_selected_ids)
        self._build_refs["model_selection_count"].set_text(
            self._t(f"{count}/{maximum} gewählt", f"{count}/{maximum} selected", f"Vybráno {count}/{maximum}")
        )

    def _selected_model_rows(self) -> list[tuple[int, dict[str, object]]]:
        return [(self._model_display_score(item), item) for item in self._selected_model_items()]

    def _selected_model_items(self) -> list[dict[str, object]]:
        by_id = {str(item.get("model_id") or ""): item for item in self.models}
        return [by_id[model_id] for model_id in self._model_selected_ids if model_id in by_id]

    def _model_tree_clicked(self, tree: Gtk.TreeView, event) -> bool:
        if event.button != 1:
            return False
        path_info = tree.get_path_at_pos(int(event.x), int(event.y))
        if not path_info:
            return False
        path, column, cell_x, _cell_y = path_info
        model = tree.get_model()
        iterator = model.get_iter(path) if model is not None else None
        item = model.get_value(iterator, 8) if model is not None and iterator is not None else None
        column_index = tree.get_columns().index(column) if column in tree.get_columns() else -1
        if isinstance(item, dict) and column_index in {1, 2}:
            model_id = _clean(item.get("model_id"))
            base_ids, refurbished_ids = self._model_relation_map.get(model_id, ([], []))
            if column_index == 1:
                relation_ids = base_ids[:2] if self.core.model_is_refurbished(item) else [model_id]
            else:
                relation_ids = [model_id] if self.core.model_is_refurbished(item) else refurbished_ids[:3]
            if relation_ids:
                slot = min(len(relation_ids) - 1, max(0, int(max(0, cell_x) * len(relation_ids) / max(1, column.get_width()))))
                target_id = relation_ids[slot]
                if target_id in self._model_selected_ids:
                    self._model_selected_ids = [value for value in self._model_selected_ids if value != target_id]
                elif len(self._model_selected_ids) < self._model_selection_limit():
                    self._model_selected_ids.append(target_id)
                else:
                    self.set_status(
                        self._t(
                            "Der Vergleich ist voll. Bitte zuerst ein Modell abwählen.",
                            "The comparison is full. Deselect a model first.",
                            "Porovnání je plné. Nejprve zrušte výběr jednoho modelu.",
                        ),
                        "warn",
                    )
                    return True
                self._refresh_model_table()
                return True
        selection = tree.get_selection()
        if selection.path_is_selected(path):
            selection.unselect_path(path)
            return True
        if len(self._model_selected_ids) >= self._model_selection_limit():
            self.set_status(
                self._t(
                    "Der Vergleich ist voll. Bitte zuerst ein Modell abwählen.",
                    "The comparison is full. Deselect a model first.",
                    "Porovnání je plné. Nejprve zrušte výběr jednoho modelu.",
                ),
                "warn",
            )
            return True
        selection.select_path(path)
        return True

    def _model_selection_changed(self, _selection) -> None:
        if self._model_selection_syncing:
            return
        model, paths = _selection.get_selected_rows()
        visible_ids = {
            str(item.get("model_id") or "")
            for _score, item in self._model_visible_results
            if isinstance(item, dict)
        }
        hidden_ids = [model_id for model_id in self._model_selected_ids if model_id not in visible_ids]
        visible_selected: list[str] = []
        for path in paths:
            row = model[model.get_iter(path)]
            item = row[8]
            if isinstance(item, dict):
                model_id = str(item.get("model_id") or "").strip()
                if model_id and model_id not in visible_selected:
                    visible_selected.append(model_id)
        self._model_selected_ids = (hidden_ids + visible_selected)[: self._model_selection_limit()]
        self._refresh_model_selection_markers()
        self._update_model_selection_count()
        self._render_model_comparison()
        selected = self._selected_model_rows()
        if not selected:
            self._build_refs["model_detail"].get_buffer().set_text("")
            return
        score, item = selected[-1]
        try:
            detail = self.core.format_model_database_detail(item, self.language, percent=score)
        except Exception:
            detail = "\n".join(f"{key}: {value}" for key, value in item.items())
        self._build_refs["model_detail"].get_buffer().set_text(detail)

    def _refresh_model_selection_markers(self) -> None:
        store: Gtk.ListStore | None = self._build_refs.get("model_store")
        if store is None:
            return
        selected_ids = set(self._model_selected_ids)
        iterator = store.get_iter_first()
        while iterator is not None:
            item = store.get_value(iterator, 8)
            if isinstance(item, dict):
                base_id, refurbished = self._model_relation_values(item, selected_ids)
                store.set_value(iterator, 1, base_id)
                store.set_value(iterator, 2, _short(refurbished, 28))
            iterator = store.iter_next(iterator)

    def _clear_model_selection(self, _button=None) -> None:
        self._model_selected_ids = []
        tree: Gtk.TreeView | None = self._build_refs.get("model_tree")
        if tree is not None:
            self._model_selection_syncing = True
            try:
                tree.get_selection().unselect_all()
            finally:
                self._model_selection_syncing = False
        self._refresh_model_selection_markers()
        self._update_model_selection_count()
        self._render_model_comparison()
        self._build_refs["model_detail"].get_buffer().set_text("")

    def _remove_model_from_comparison(self, model_id: str) -> None:
        self._model_selected_ids = [value for value in self._model_selected_ids if value != model_id]
        self._refresh_model_table()

    def _compare_selected_models(self, _button=None) -> None:
        self._render_model_comparison()

    def _render_model_comparison(self) -> None:
        box: Gtk.Box = self._build_refs["compare_box"]
        saved_states = {
            (str(binding.get("source_id") or ""), str(binding.get("key") or "")): bool(binding["check"].get_active())
            for binding in self._model_option_bindings
            if isinstance(binding.get("check"), Gtk.CheckButton)
        }
        self._model_option_bindings = []
        for child in box.get_children():
            box.remove(child)
        selected = self._selected_model_items()
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        sources: list[tuple[str, dict[str, object] | None]] = []
        if use_device:
            sources.append(("device", None))
        sources.extend((str(item.get("model_id") or ""), item) for item in selected)

        if use_device and selected:
            scores = [self._model_display_score(item) for item in selected]
            title = f"{self._t('Modellvergleich mit aktuellem Gerät', 'Model comparison with current device', 'Porovnání modelů s aktuálním zařízením')} · {self._t('Bester Match', 'Best match', 'Nejlepší shoda')}: {max(scores)}%"
        elif use_device:
            title = self._t("Modellvergleich mit aktuellem Gerät", "Model comparison with current device", "Porovnání modelů s aktuálním zařízením")
        elif len(selected) > 1:
            scores = [int(self.core.model_similarity_score(selected[0], item)) for item in selected[1:]]
            title = f"{self._t('Modellvergleich', 'Model comparison', 'Porovnání modelů')} · Match: {min(scores)}%"
        elif selected:
            title = self._t("Vergleichsmodell gewählt – weitere Vorschläge anklicken", "Comparison model selected – click more suggestions", "Vybrán srovnávací model – klikněte na další návrhy")
        else:
            title = self._t("Modelle aus der Vorschlagsliste auswählen", "Select models from the suggestion list", "Vyberte modely ze seznamu návrhů")
        self._build_refs["model_compare_title"].set_text(title)

        if not sources:
            box.pack_start(self._label(self._t("Aktuelles Gerät einschalten oder unten Modelle auswählen.", "Enable the current device or select models below.", "Zapněte aktuální zařízení nebo níže vyberte modely."), "muted", wrap=True), False, False, 12)
            box.show_all()
            return

        grid = Gtk.Grid(column_spacing=2, row_spacing=2)
        grid.attach(self._label("#", "comparison-header", xalign=0.5), 0, 0, 1, 1)
        grid.attach(self._label(self._t("Kategorie", "Category", "Kategorie"), "comparison-header"), 1, 0, 1, 1)
        snapshot_rows = self.core.snapshot_compare_entries(self.snapshot, self.language)
        categories = [(key, label) for key, label, _value, _available in snapshot_rows]
        if not use_device and selected:
            categories = [(key, label) for key, label, _value in self.core.model_compare_entries(selected[0], self.language)]
        snapshot_map = {key: (value, available) for key, _label, value, available in snapshot_rows}
        model_maps = {
            str(item.get("model_id") or ""): {key: value for key, _label, value in self.core.model_compare_entries(item, self.language)}
            for item in selected
        }
        base_model = selected[0] if selected else None

        for column, (source_id, item) in enumerate(sources, start=2):
            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            header.get_style_context().add_class("comparison-header")
            if source_id == "device":
                header_text = self._t("Aktuelles Gerät", "Current device", "Aktuální zařízení")
            elif use_device and item:
                header_text = f"{self._t('Modell', 'Model', 'Model')} {source_id} ★ · {self._model_display_score(item)}%"
            elif item is base_model:
                header_text = f"{self._t('Basis', 'Base', 'Základ')} · {self._t('Modell', 'Model', 'Model')} {source_id} ★"
            else:
                header_text = f"{self._t('Modell', 'Model', 'Model')} {source_id} ★ · {int(self.core.model_similarity_score(base_model or item, item))}%"
            header.pack_start(self._label(header_text, xalign=0.5), True, True, 0)
            if source_id != "device":
                remove_button = Gtk.Button(label="×")
                remove_button.set_relief(Gtk.ReliefStyle.NONE)
                remove_button.set_tooltip_text(self._t("Aus Vergleich entfernen", "Remove from comparison", "Odebrat z porovnání"))
                remove_button.connect("clicked", lambda _b, model_id=source_id: self._remove_model_from_comparison(model_id))
                header.pack_end(remove_button, False, False, 0)
            header.set_size_request(285, 42)
            grid.attach(header, column, 0, 1, 1)

        for row_index, (key, category_title) in enumerate(categories, start=1):
            grid.attach(self._label(str(row_index), "card-subtitle", xalign=0.5), 0, row_index, 1, 1)
            category = self._label(category_title, "card-title")
            category.set_size_request(145, 38)
            grid.attach(category, 1, row_index, 1, 1)
            for column, (source_id, item) in enumerate(sources, start=2):
                if source_id == "device":
                    value, available = snapshot_map.get(key, ("–", False))
                    same: bool | None = None
                    css = "reference-cell" if available else "unavailable-cell"
                else:
                    value = model_maps.get(source_id, {}).get(key, "–")
                    available = value not in {"", "–", "-"}
                    if use_device and item:
                        same = self.core.model_matches_snapshot_option(item, self.snapshot, key)
                    elif item is base_model:
                        same = None
                    elif item and base_model:
                        same = self.core.model_option_matches(item, base_model, key)
                    else:
                        same = None
                    if not available:
                        css = "unavailable-cell"
                    elif item is base_model and not use_device:
                        css = "reference-cell"
                    elif same is True:
                        css = "match-cell"
                    elif same is False:
                        css = "mismatch-cell"
                    else:
                        css = "neutral-cell"
                state_key = (source_id, key)
                default_active = bool(available and (source_id == "device" or same is True or (item is base_model and not use_device)))
                active = saved_states.get(state_key, default_active)
                check = Gtk.CheckButton(label=str(value))
                check.set_active(active)
                check.set_sensitive(bool(available))
                check.set_size_request(285, 38)
                check.get_style_context().add_class(css)
                child = check.get_child()
                if isinstance(child, Gtk.Label):
                    child.set_line_wrap(True)
                    child.set_max_width_chars(42)
                grid.attach(check, column, row_index, 1, 1)
                self._model_option_bindings.append({
                    "check": check,
                    "key": key,
                    "source_id": source_id,
                    "source": "device" if source_id == "device" else "model",
                    "item": item,
                    "available": available,
                })
        box.pack_start(grid, False, False, 0)
        box.show_all()

    def _search_selected_model_options(self, _button=None) -> None:
        filters: dict[str, list[dict[str, object]]] = {}
        for binding in self._model_option_bindings:
            check = binding.get("check")
            if not isinstance(check, Gtk.CheckButton) or not check.get_active() or not binding.get("available"):
                continue
            filters.setdefault(str(binding.get("key") or ""), []).append(binding)
        filters.pop("", None)
        if not filters:
            self.set_status(self._t("Bitte mindestens eine Vergleichsoption markieren.", "Select at least one comparison option.", "Vyberte alespoň jednu možnost porovnání."), "warn")
            return
        matched: list[dict[str, object]] = []
        for candidate in self.models:
            matches_all = True
            for key, bindings in filters.items():
                category_match = False
                for binding in bindings:
                    if binding.get("source") == "device":
                        category_match = self.core.model_matches_snapshot_option(candidate, self.snapshot, key) is True
                    else:
                        source_item = binding.get("item")
                        category_match = isinstance(source_item, dict) and self.core.model_option_matches(candidate, source_item, key)
                    if category_match:
                        break
                if not category_match:
                    matches_all = False
                    break
            if matches_all:
                matched.append(candidate)
        results = [(self._model_display_score(item), item) for item in matched]
        if self._model_has_score_reference():
            results.sort(key=lambda pair: pair[0], reverse=True)
        self._populate_model_results(results[:250])
        self.set_status(
            self._t(f"{len(matched)} Modelle passen zu den gewählten Optionen.", f"{len(matched)} models match the selected options.", f"Vybraným možnostem odpovídá {len(matched)} modelů."),
            "good" if matched else "warn",
        )

    # ---------- battery ----------

    def _build_battery_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Akku-Test", "Battery test", "Test baterie"),
            "",
        )
        live_panel = Gtk.Frame()
        live_panel.set_shadow_type(Gtk.ShadowType.NONE)
        live_panel.get_style_context().add_class("battery-live-panel")
        live_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        live_panel.add(live_row)
        live_row.pack_start(self._icon("battery-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        live_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self._build_refs["battery_live_title"] = self._label(self._t("Akku-Test bereit", "Battery test ready", "Test baterie připraven"), "battery-live-title", wrap=True)
        self._build_refs["battery_live_subtitle"] = self._label("", "battery-live-subtitle", wrap=True)
        live_text.pack_start(self._build_refs["battery_live_title"], False, False, 0)
        live_text.pack_start(self._build_refs["battery_live_subtitle"], False, False, 0)
        live_row.pack_start(live_text, True, True, 0)
        self._build_refs["battery_live_panel"] = live_panel
        outer.pack_start(live_panel, False, False, 8)

        flow = self._flow()
        flow.set_min_children_per_line(3)
        flow.set_max_children_per_line(3)
        outer.pack_start(flow, False, False, 12)
        for key, title, icon in (
            ("level", self._t("Akkustand", "Battery level", "Stav baterie"), "battery-symbolic"),
            ("runtime", self._t("Restlaufzeit", "Remaining runtime", "Zbývající výdrž"), "alarm-symbolic"),
            ("power", self._t("Leistung", "Power", "Výkon"), "preferences-system-power-symbolic"),
            ("capacity", self._t("Kapazität", "Capacity", "Kapacita"), "battery-symbolic"),
            ("health", self._t("Kapazitätsgesundheit", "Capacity health", "Zdraví kapacity"), "emblem-ok-symbolic"),
            ("voltage_cycles", self._t("Spannung · Ladezyklen", "Voltage · charge cycles", "Napětí · nabíjecí cykly"), "view-refresh-symbolic"),
        ):
            card, value, subtitle = self._card(title, icon=icon)
            card.set_size_request(245, 102)
            card.get_style_context().add_class("battery-metric-card")
            if key in {"capacity", "voltage_cycles"}:
                card.get_style_context().add_class("compact")
            flow.add(card)
            self._build_refs[f"battery_{key}"] = value
            self._build_refs[f"battery_{key}_sub"] = subtitle

        controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        controls.pack_start(self._button(self._t("Entladen starten", "Start discharge", "Spustit vybíjení"), lambda _b: self._start_battery_test("discharge"), "primary-button", "battery-caution-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Laden starten", "Start charge", "Spustit nabíjení"), lambda _b: self._start_battery_test("charge"), "primary-button", "battery-good-charging-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Stop + Report", "Stop + report", "Stop + report"), self._stop_battery_test, "secondary-button", "media-playback-stop-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Sofort-Report", "Instant report", "Okamžitý report"), self._instant_battery_report, "secondary-button", "document-save-symbolic"), False, False, 0)
        outer.pack_start(controls, False, False, 8)

        history = Gtk.Frame()
        history.set_shadow_type(Gtk.ShadowType.NONE)
        history.get_style_context().add_class("battery-history-card")
        history_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        history.add(history_box)
        history_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        history_header.pack_start(self._label(self._t("Akku-Verlauf · Live-Messung", "Battery history · live measurement", "Průběh baterie · živé měření"), "section-title"), True, True, 0)
        self._build_refs["battery_measure_state"] = self._label("", "good-text")
        history_header.pack_end(self._build_refs["battery_measure_state"], False, False, 0)
        history_box.pack_start(history_header, False, False, 0)
        chart = Gtk.Overlay()
        chart.set_hexpand(True)
        chart.set_vexpand(True)
        chart.set_size_request(-1, 300)
        chart_image = Gtk.Image()
        chart_image.set_halign(Gtk.Align.CENTER)
        chart_image.set_valign(Gtk.Align.CENTER)
        chart.add(chart_image)
        chart_error = self._label("", "bad-text", xalign=0.5, wrap=True)
        chart_error.set_no_show_all(True)
        chart_error.hide()
        chart.add_overlay(chart_error)
        self._build_refs["battery_chart"] = chart
        self._build_refs["battery_chart_image"] = chart_image
        self._build_refs["battery_chart_error"] = chart_error
        history_box.pack_start(chart, True, True, 0)
        outer.pack_start(history, False, False, 8)

        return page

    def _battery_refresh_tick(self) -> bool:
        if self.window is None:
            return False
        try:
            details = self.core.read_battery_details()
            self._update_battery_ui(details)
        except Exception:
            pass
        return True

    def _battery_display_samples_for(self, details: dict[str, object]) -> list[dict[str, object]]:
        samples = list(self._battery_samples)
        if details.get("present"):
            current_stamp = str(details.get("timestamp") or "")
            last_stamp = str(samples[-1].get("timestamp") or "") if samples else ""
            if current_stamp != last_stamp:
                samples.append(details)
        return samples or ([details] if details.get("present") else [])

    def _battery_estimate_display(self, metrics: dict[str, object]) -> tuple[str, str]:
        estimate = metrics.get("estimate_seconds")
        if not isinstance(estimate, (float, int)) or estimate <= 0:
            return (
                self._t("wird berechnet", "calculating", "počítá se"),
                self._t("nach messbarer Änderung", "after a measurable change", "po měřitelné změně"),
            )
        duration = self.core.battery_elapsed_text(float(estimate), self.language)
        kind = str(metrics.get("estimate_kind") or "")
        value = (
            self._t(f"voll in {duration}", f"full in {duration}", f"plná za {duration}")
            if kind == "to_full"
            else self._t(f"ca. {duration}", f"approx. {duration}", f"cca {duration}")
        )
        source = str(metrics.get("estimate_source") or "")
        subtitle = {
            "measured": self._t("aus dem Testverlauf", "from the measured test trend", "z průběhu testu"),
            "controller": self._t("Controller-Prognose", "controller estimate", "odhad řadiče"),
            "power": self._t("bei aktueller Leistung", "at current power draw", "při aktuálním odběru"),
        }.get(source, self._t("Schätzwert", "estimate", "odhad"))
        return value, subtitle

    @staticmethod
    def _battery_panel_state(widget: Gtk.Widget | None, state: str) -> None:
        if widget is None:
            return
        context = widget.get_style_context()
        for name in ("warn", "bad"):
            context.remove_class(name)
        if state in {"warn", "bad"}:
            context.add_class(state)

    def _battery_next_sample_seconds(self) -> int:
        if not self._battery_mode or not self._battery_samples:
            return 0
        last = self.core.parse_battery_timestamp(self._battery_samples[-1].get("timestamp"))
        if last is None:
            return 60
        now = datetime.datetime.now(last.tzinfo) if last.tzinfo is not None else datetime.datetime.now()
        return max(0, min(60, 60 - int(max(0.0, (now - last).total_seconds()))))

    def _update_battery_ui(self, details: dict[str, object]) -> None:
        self._battery_display_details = dict(details)
        if not details.get("present"):
            text = self._t("Kein Akku erkannt", "No battery detected", "Baterie nebyla nalezena")
            for key in ("level", "runtime", "power", "capacity", "health", "voltage_cycles"):
                if f"battery_{key}" in self._build_refs:
                    self._build_refs[f"battery_{key}"].set_text(text if key == "level" else "–")
                    self._build_refs[f"battery_{key}_sub"].set_text("")
            self._build_refs["battery_chip"].set_text(self._t("Kein Akku", "No battery", "Bez baterie"))
            self._set_chip_state(self._build_refs.get("battery_chip"), "bad")
            self._build_refs["battery_mini_title"].set_text(text)
            self._build_refs["battery_mini_value"].set_text("–")
            self._build_refs["battery_mini_level"].set_value(0)
            self._build_refs["battery_mini_subtitle"].set_text("")
            self._battery_panel_state(self._build_refs.get("battery_mini_panel"), "bad")
            dashboard_panel: Gtk.Frame | None = self._build_refs.get("dashboard_battery_live")
            if dashboard_panel is not None:
                dashboard_panel.hide()
                dashboard_panel.set_no_show_all(True)
            self._build_refs["battery_measure_state"].set_text("")
            self._battery_chart_signature = ""
            self._update_battery_history_image()
            return
        capacity = details.get("capacity_percent")
        health = self.core.battery_health_assessment(details, self.language)
        display_samples = self._battery_display_samples_for(details)
        metrics = self.core.battery_dashboard_metrics(self._battery_mode, display_samples)
        self._battery_last_metrics = metrics
        function = self.core.battery_function_assessment(self._battery_mode, display_samples, self.language)
        try:
            level = max(0.0, min(100.0, float(capacity)))
        except (TypeError, ValueError):
            level = 0.0
        status = self.core.battery_status_label(details.get("status"), self.language)
        self._build_refs["battery_level"].set_text(f"{_clean(capacity)} %")
        self._build_refs["battery_level_sub"].set_text(status)
        runtime_value, runtime_subtitle = self._battery_estimate_display(metrics)
        self._build_refs["battery_runtime"].set_text(runtime_value)
        self._build_refs["battery_runtime_sub"].set_text(runtime_subtitle)
        power = details.get("power_w")
        self._build_refs["battery_power"].set_text(f"{float(power):.2f} W" if isinstance(power, (float, int)) else "–")
        self._build_refs["battery_power_sub"].set_text(self.core.battery_source_text(details.get("status"), self.language))
        capacity_now = self.core.battery_capacity_text(details.get("energy_now"), details.get("capacity_unit"), self.language)
        capacity_full = self.core.battery_capacity_text(details.get("energy_full"), details.get("capacity_unit"), self.language)
        capacity_unit = self.core.battery_capacity_unit_label(details.get("capacity_unit"))
        if capacity_unit and capacity_now.endswith(f" {capacity_unit}") and capacity_full.endswith(f" {capacity_unit}"):
            capacity_now = capacity_now[: -(len(capacity_unit) + 1)]
        self._build_refs["battery_capacity"].set_text(f"{capacity_now} / {capacity_full}")
        self._build_refs["battery_capacity_sub"].set_text(self._t("aktuell / volle Kapazität", "current / full capacity", "aktuální / plná kapacita"))
        self._build_refs["battery_health"].set_text(str(health.get("display") or "–"))
        self._build_refs["battery_health_sub"].set_text(str(health.get("note") or ""))
        voltage = details.get("voltage_v")
        try:
            voltage_text = f"{float(voltage):.2f} V"
        except (TypeError, ValueError):
            voltage_text = "–"
        cycles_text = _clean(details.get("cycle_count"))
        self._build_refs["battery_voltage_cycles"].set_text(f"{voltage_text} · {cycles_text}")
        self._build_refs["battery_voltage_cycles_sub"].set_text(self._t("aktuelle Spannung · Zyklen", "current voltage · cycles", "aktuální napětí · cykly"))
        estimate_short = runtime_value.replace("ca. ", "").replace("approx. ", "").replace("cca ", "")
        drop_state = str(metrics.get("drop_state") or "")
        panel_state = "bad" if drop_state == "critical" else "warn" if drop_state == "warn" else ""
        function_problem = self._battery_mode and str(function.get("class_name") or "") == "bad"
        if function_problem and not panel_state:
            panel_state = "bad"
        delta = metrics.get("delta_percent")
        try:
            delta_text = f"{float(delta):+g} %"
        except (TypeError, ValueError):
            delta_text = "±0 %"
        if self._battery_mode:
            mode_text = self._t("entlädt", "discharging", "vybíjí se") if self._battery_mode == "discharge" else self._t("lädt", "charging", "nabíjí se")
            test_title = self._t("Entlade-Test läuft", "Discharge test running", "Probíhá test vybíjení") if self._battery_mode == "discharge" else self._t("Lade-Test läuft", "Charge test running", "Probíhá test nabíjení")
            count = int(metrics.get("sample_count") or len(display_samples))
            elapsed_text = self.core.battery_elapsed_text(float(metrics.get("elapsed_seconds") or 0.0), self.language)
            if drop_state:
                live_title = self._t("Achtung: ungewöhnlich schneller Akkuabfall", "Warning: unusually rapid battery drop", "Pozor: neobvykle rychlý pokles baterie")
                rate = float(metrics.get("rate_percent_per_hour") or 0.0)
                live_subtitle = self._t(
                    f"{delta_text} · hochgerechnet {rate:.0f} % pro Stunde · {count} Messpunkte",
                    f"{delta_text} · projected {rate:.0f} % per hour · {count} samples",
                    f"{delta_text} · odhad {rate:.0f} % za hodinu · {count} měření",
                )
            elif function_problem:
                live_title = f"{self._t('Achtung', 'Warning', 'Pozor')}: {function.get('display')}"
                live_subtitle = str(function.get("note") or "")
            else:
                live_title = f"{test_title} · {delta_text} · {count} {self._t('Messpunkte', 'samples', 'měření')} · {elapsed_text}"
                live_subtitle = ""
            chip_text = f"{self._t('Akku-Test', 'Battery test', 'Test baterie')}: {mode_text} · {_clean(capacity)}% · {estimate_short}"
            mini_title = test_title
            mini_subtitle = f"{delta_text} · {count} {self._t('Messpunkte', 'samples', 'měření')} · {elapsed_text}"
        elif self._battery_last_result:
            verdict = str(self._battery_last_result.get("verdict") or self._t("abgeschlossen", "completed", "dokončeno"))
            result_class = str(self._battery_last_result.get("class_name") or "warn")
            panel_state = "bad" if result_class == "bad" else "warn" if result_class == "warn" else ""
            live_title = f"{self._t('Akku-Test abgeschlossen', 'Battery test completed', 'Test baterie dokončen')}: {verdict}"
            live_subtitle = str(self._battery_last_result.get("summary") or "")
            chip_text = f"{self._t('Akku-Test', 'Battery test', 'Test baterie')}: {verdict}"
            mini_title = live_title
            mini_subtitle = str(self._battery_last_result.get("completion_text") or runtime_value)
        else:
            live_title = self._t("Akku-Test bereit", "Battery test ready", "Test baterie připraven")
            live_subtitle = ""
            chip_text = f"{self._t('Akku', 'Battery', 'Baterie')}: {_clean(capacity)}%"
            mini_title = live_title
            mini_subtitle = runtime_value
        self._build_refs["battery_chip"].set_text(chip_text)
        self._set_chip_state(self._build_refs.get("battery_chip"), panel_state or ("good" if self._battery_mode else ""))
        self._build_refs["battery_live_title"].set_text(live_title)
        self._build_refs["battery_live_subtitle"].set_text(live_subtitle)
        if live_subtitle:
            self._build_refs["battery_live_subtitle"].set_no_show_all(False)
            self._build_refs["battery_live_subtitle"].show()
        else:
            self._build_refs["battery_live_subtitle"].hide()
            self._build_refs["battery_live_subtitle"].set_no_show_all(True)
        self._battery_panel_state(self._build_refs.get("battery_live_panel"), panel_state)
        self._build_refs["battery_mini_title"].set_text(mini_title)
        self._build_refs["battery_mini_value"].set_text(f"{_clean(capacity)}%")
        self._build_refs["battery_mini_level"].set_value(level)
        self._build_refs["battery_mini_subtitle"].set_text(mini_subtitle)
        self._battery_panel_state(self._build_refs.get("battery_mini_panel"), panel_state)
        dashboard_panel: Gtk.Frame | None = self._build_refs.get("dashboard_battery_live")
        if (self._battery_mode or self._battery_last_result) and dashboard_panel is not None:
            self._build_refs["dashboard_battery_title"].set_text(live_title)
            self._build_refs["dashboard_battery_subtitle"].set_text(f"{_clean(capacity)} % · {mini_subtitle}")
            self._build_refs["dashboard_battery_level"].set_value(level)
            self._battery_panel_state(dashboard_panel, panel_state)
            dashboard_panel.set_no_show_all(False)
            dashboard_panel.show_all()
        elif dashboard_panel is not None:
            dashboard_panel.hide()
            dashboard_panel.set_no_show_all(True)
        next_sample = self._battery_next_sample_seconds()
        measure_state = self._build_refs.get("battery_measure_state")
        if measure_state is not None:
            if self._battery_mode:
                completion = self.core.battery_test_completion(self._battery_mode, display_samples)
                elapsed_minutes = int(float(completion.get("elapsed_seconds") or 0.0) // 60)
                change = float(completion.get("directional_change_percent") or 0.0)
                time_progress = f"{elapsed_minutes}/30" if elapsed_minutes <= 30 else f"{elapsed_minutes}/60"
                measure_state.set_text(
                    self._t(
                        f"● aktiv · {time_progress} Min. · {change:.0f}/5 % · nächster Messpunkt in {next_sample} Sek.",
                        f"● active · {time_progress} min · {change:.0f}/5 % · next sample in {next_sample} sec",
                        f"● aktivní · {time_progress} min · {change:.0f}/5 % · další měření za {next_sample} s",
                    )
                )
            elif self._battery_last_result:
                measure_state.set_text(str(self._battery_last_result.get("recommendation") or ""))
            else:
                measure_state.set_text("")
        self._update_battery_history_image()

    def _update_battery_history_image(self) -> None:
        image: Gtk.Image | None = self._build_refs.get("battery_chart_image")
        error: Gtk.Label | None = self._build_refs.get("battery_chart_error")
        if image is None or error is None:
            return
        try:
            allocated_width = image.get_allocated_width()
            width = allocated_width if allocated_width >= 760 else 1040
            width = max(760, min(1280, width))
            height = 285
            samples = list(self._battery_samples) if self._battery_samples else []
            if not samples and self._battery_display_details.get("present"):
                samples = [self._battery_display_details]
            points: list[tuple[datetime.datetime | None, float]] = []
            for sample in samples:
                try:
                    value = max(0.0, min(100.0, float(sample.get("capacity_percent"))))
                except (TypeError, ValueError):
                    continue
                points.append((self.core.parse_battery_timestamp(sample.get("timestamp")), value))

            signature = repr((width, self._battery_mode, [(str(stamp), value) for stamp, value in points]))
            if signature == self._battery_chart_signature:
                return

            current_level = points[-1][1] if points else 0.0
            level_color = "#ef5c68" if current_level < 20 else "#efaa3b" if current_level < 50 else "#4edca6"
            graph_left = 188.0
            graph_right = float(width - 28)
            graph_top = 42.0
            graph_bottom = float(height - 42)
            values = [value for _stamp, value in points]
            if values:
                y_min = max(0.0, min(values) - 5.0)
                y_max = min(100.0, max(values) + 5.0)
                if y_max - y_min < 10.0:
                    middle = (y_min + y_max) / 2.0
                    y_min = max(0.0, middle - 5.0)
                    y_max = min(100.0, y_min + 10.0)
                    y_min = max(0.0, y_max - 10.0)
            else:
                y_min, y_max = 0.0, 100.0

            valid_times = [stamp for stamp, _value in points if stamp is not None]
            start_time = valid_times[0] if valid_times else None
            end_time = valid_times[-1] if valid_times else None
            elapsed = (end_time - start_time).total_seconds() if start_time is not None and end_time is not None else 0.0

            def point_xy(index: int, stamp: datetime.datetime | None, value: float) -> tuple[float, float]:
                if elapsed > 0 and stamp is not None and start_time is not None:
                    fraction = max(0.0, min(1.0, (stamp - start_time).total_seconds() / elapsed))
                else:
                    fraction = index / max(1, len(points) - 1)
                x = graph_left + (graph_right - graph_left) * fraction
                y_fraction = (value - y_min) / max(1.0, y_max - y_min)
                y = graph_bottom - (graph_bottom - graph_top) * y_fraction
                return x, y

            coordinates = [point_xy(index, stamp, value) for index, (stamp, value) in enumerate(points)]
            parts = [
                f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
                '<defs><linearGradient id="area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#36d4cb" stop-opacity="0.30"/><stop offset="1" stop-color="#36d4cb" stop-opacity="0.03"/></linearGradient></defs>',
                f'<rect width="{width}" height="{height}" rx="10" fill="#0e151f"/>',
                '<text x="42" y="31" fill="#8fa7bd" font-family="Sans" font-size="11">Akkustand</text>',
                '<rect x="48" y="53" width="82" height="188" rx="10" fill="#111a27" stroke="#91a5b8" stroke-width="4"/>',
                '<rect x="75" y="43" width="28" height="10" rx="3" fill="#91a5b8"/>',
            ]
            inner_height = 168.0
            fill_height = inner_height * current_level / 100.0
            fill_y = 63.0 + inner_height - fill_height
            parts.append(f'<rect x="57" y="{fill_y:.1f}" width="64" height="{fill_height:.1f}" rx="5" fill="{level_color}"/>')
            parts.append(f'<text x="89" y="158" text-anchor="middle" fill="#07131c" font-family="Sans" font-size="22" font-weight="700">{current_level:.0f}%</text>')

            for index in range(5):
                fraction = index / 4.0
                y = graph_bottom - (graph_bottom - graph_top) * fraction
                value = y_min + (y_max - y_min) * fraction
                parts.append(f'<line x1="{graph_left:.1f}" y1="{y:.1f}" x2="{graph_right:.1f}" y2="{y:.1f}" stroke="#334156" stroke-width="1"/>')
                parts.append(f'<text x="{graph_left - 10:.1f}" y="{y + 4:.1f}" text-anchor="end" fill="#8fa7bd" font-family="Sans" font-size="10">{value:.0f}%</text>')

            if coordinates:
                if len(coordinates) > 1:
                    line_path = " ".join(("M" if index == 0 else "L") + f" {x:.1f} {y:.1f}" for index, (x, y) in enumerate(coordinates))
                    area_path = line_path + f" L {coordinates[-1][0]:.1f} {graph_bottom:.1f} L {coordinates[0][0]:.1f} {graph_bottom:.1f} Z"
                    parts.append(f'<path d="{area_path}" fill="url(#area)"/>')
                    parts.append(f'<path d="{line_path}" fill="none" stroke="#36d4cb" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>')
                for index, (x, y) in enumerate(coordinates):
                    radius = 6 if index == len(coordinates) - 1 else 4
                    fill = level_color if index == len(coordinates) - 1 else "#0e151f"
                    parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{radius}" fill="{fill}" stroke="#36d4cb" stroke-width="3"/>')
                last_x, last_y = coordinates[-1]
                parts.append(f'<text x="{max(graph_left, last_x - 10):.1f}" y="{max(graph_top + 14, last_y - 12):.1f}" text-anchor="end" fill="#dce8f2" font-family="Sans" font-size="11">{points[-1][1]:.0f}%</text>')
            else:
                parts.append(f'<text x="{(graph_left + graph_right) / 2:.1f}" y="145" text-anchor="middle" fill="#8fa7bd" font-family="Sans" font-size="14">Akku-Test starten</text>')

            for index in range(4):
                fraction = index / 3.0
                x = graph_left + (graph_right - graph_left) * fraction
                if index == 0:
                    label = "Start"
                else:
                    label = self.core.battery_elapsed_text(elapsed * fraction, self.language) if elapsed > 0 else ""
                parts.append(f'<text x="{x:.1f}" y="{height - 17}" text-anchor="middle" fill="#8fa7bd" font-family="Sans" font-size="10">{GLib.markup_escape_text(label)}</text>')
            parts.append('</svg>')

            loader = GdkPixbuf.PixbufLoader.new_with_type("svg")
            loader.write("".join(parts).encode("utf-8"))
            loader.close()
            pixbuf = loader.get_pixbuf()
            if pixbuf is None:
                raise RuntimeError("SVG konnte nicht geladen werden")
            image.set_from_pixbuf(pixbuf.copy())
            error.hide()
            error.set_no_show_all(True)
            self._battery_chart_signature = signature
        except Exception as exc:
            image.set_from_icon_name("dialog-error-symbolic", Gtk.IconSize.DIALOG)
            error.set_text(f"{self._t('Akku-Diagramm konnte nicht geladen werden', 'Battery chart could not be loaded', 'Graf baterie nelze načíst')}: {exc}")
            error.set_no_show_all(False)
            error.show()

    def _draw_battery_history(self, widget: Gtk.DrawingArea, context) -> bool:
        try:
            return self._draw_battery_history_content(widget, context)
        except Exception as exc:
            context.set_source_rgb(0.055, 0.082, 0.12)
            context.paint()
            context.set_source_rgb(0.94, 0.36, 0.41)
            context.set_font_size(14)
            context.move_to(24, 38)
            context.show_text(self._t("Akku-Diagramm konnte nicht gezeichnet werden", "Battery chart could not be drawn", "Graf baterie se nepodařilo vykreslit"))
            context.set_source_rgb(0.56, 0.64, 0.73)
            context.set_font_size(10)
            context.move_to(24, 58)
            context.show_text(_short(str(exc), 120))
            return False

    def _draw_battery_history_content(self, widget: Gtk.DrawingArea, context) -> bool:
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        context.set_source_rgb(0.055, 0.082, 0.12)
        context.paint()
        samples = self._battery_display_samples_for(self._battery_display_details)
        points: list[tuple[datetime.datetime | None, float]] = []
        for sample in samples:
            try:
                value = max(0.0, min(100.0, float(sample.get("capacity_percent"))))
            except (TypeError, ValueError):
                continue
            points.append((self.core.parse_battery_timestamp(sample.get("timestamp")), value))

        context.select_font_face("Sans", 0, 0)

        def text_size(text: str) -> tuple[float, float]:
            extent = context.text_extents(text)
            width_value = getattr(extent, "width", None)
            height_value = getattr(extent, "height", None)
            if width_value is None:
                width_value = extent[2]
            if height_value is None:
                height_value = extent[3]
            return float(width_value), float(height_value)

        current_level = points[-1][1] if points else 0.0
        battery_x, battery_y, battery_w, battery_h = 38.0, 48.0, 78.0, max(120.0, height - 92.0)
        context.set_line_width(3)
        context.set_source_rgb(0.58, 0.67, 0.75)
        context.rectangle(battery_x, battery_y, battery_w, battery_h)
        context.stroke()
        context.rectangle(battery_x + 24, battery_y - 9, 30, 7)
        context.fill()
        inner_margin = 6.0
        fill_height = max(0.0, (battery_h - inner_margin * 2) * current_level / 100.0)
        if current_level < 20:
            context.set_source_rgb(0.94, 0.36, 0.41)
        elif current_level < 50:
            context.set_source_rgb(0.94, 0.66, 0.23)
        else:
            context.set_source_rgb(0.18, 0.79, 0.56)
        context.rectangle(battery_x + inner_margin, battery_y + battery_h - inner_margin - fill_height, battery_w - inner_margin * 2, fill_height)
        context.fill()
        context.set_source_rgb(1.0, 1.0, 1.0)
        context.set_font_size(19)
        level_text = f"{current_level:.0f}%" if points else "–"
        text_width, text_height = text_size(level_text)
        context.move_to(battery_x + (battery_w - text_width) / 2, battery_y + battery_h / 2 + text_height / 2)
        context.show_text(level_text)

        graph_left = 168.0
        graph_right = max(graph_left + 80.0, width - 34.0)
        graph_top = 30.0
        graph_bottom = max(graph_top + 80.0, height - 42.0)
        values = [value for _stamp, value in points]
        if values:
            y_min = max(0.0, min(values) - 5.0)
            y_max = min(100.0, max(values) + 5.0)
            if y_max - y_min < 10.0:
                middle = (y_min + y_max) / 2.0
                y_min = max(0.0, middle - 5.0)
                y_max = min(100.0, y_min + 10.0)
                y_min = max(0.0, y_max - 10.0)
        else:
            y_min, y_max = 0.0, 100.0
        context.set_font_size(10)
        context.set_line_width(1)
        for index in range(5):
            fraction = index / 4.0
            y = graph_bottom - (graph_bottom - graph_top) * fraction
            value = y_min + (y_max - y_min) * fraction
            context.set_source_rgba(0.35, 0.43, 0.55, 0.32)
            context.move_to(graph_left, y)
            context.line_to(graph_right, y)
            context.stroke()
            context.set_source_rgb(0.56, 0.64, 0.73)
            context.move_to(graph_left - 34, y + 4)
            context.show_text(f"{value:.0f}%")

        if not points:
            context.set_source_rgb(0.56, 0.64, 0.73)
            context.set_font_size(14)
            context.move_to(graph_left + 20, graph_top + 45)
            context.show_text(self._t("Akku-Test starten", "Start a battery test", "Spusťte test baterie"))
            return False

        valid_times = [stamp for stamp, _value in points if stamp is not None]
        start_time = valid_times[0] if valid_times else None
        end_time = valid_times[-1] if valid_times else None
        elapsed = (end_time - start_time).total_seconds() if start_time is not None and end_time is not None else 0.0

        def point_xy(index: int, stamp: datetime.datetime | None, value: float) -> tuple[float, float]:
            if elapsed > 0 and stamp is not None and start_time is not None:
                x_fraction = max(0.0, min(1.0, (stamp - start_time).total_seconds() / elapsed))
            else:
                x_fraction = index / max(1, len(points) - 1)
            x = graph_left + (graph_right - graph_left) * x_fraction
            y_fraction = (value - y_min) / max(1.0, y_max - y_min)
            y = graph_bottom - (graph_bottom - graph_top) * y_fraction
            return x, y

        coordinates = [point_xy(index, stamp, value) for index, (stamp, value) in enumerate(points)]
        if len(coordinates) > 1:
            context.move_to(*coordinates[0])
            for x, y in coordinates[1:]:
                context.line_to(x, y)
            context.line_to(coordinates[-1][0], graph_bottom)
            context.line_to(coordinates[0][0], graph_bottom)
            context.close_path()
            context.set_source_rgba(0.22, 0.88, 0.82, 0.13)
            context.fill()
            context.move_to(*coordinates[0])
            for x, y in coordinates[1:]:
                context.line_to(x, y)
            context.set_source_rgb(0.22, 0.82, 0.78)
            context.set_line_width(3)
            context.stroke()
        for index, (x, y) in enumerate(coordinates):
            context.arc(x, y, 5 if index == len(coordinates) - 1 else 3, 0, 6.28318)
            if index == len(coordinates) - 1:
                context.set_source_rgb(0.32, 0.89, 0.69)
            else:
                context.set_source_rgb(0.22, 0.82, 0.78)
            context.fill()
        context.set_source_rgb(0.93, 0.96, 0.99)
        context.set_font_size(12)
        last_x, last_y = coordinates[-1]
        context.move_to(max(graph_left, last_x - 24), max(graph_top + 12, last_y - 10))
        context.show_text(f"{points[-1][1]:.0f}%")
        context.set_source_rgb(0.56, 0.64, 0.73)
        context.set_font_size(10)
        context.move_to(graph_left, height - 16)
        context.show_text(self._t("Start", "Start", "Start"))
        if elapsed > 0:
            elapsed_text = self.core.battery_elapsed_text(elapsed, self.language)
            text_width, _text_height = text_size(elapsed_text)
            context.move_to(graph_right - text_width, height - 16)
            context.show_text(elapsed_text)
        return False

    def _battery_state_path(self) -> pathlib.Path:
        return pathlib.Path(self.core.tempfile.gettempdir()) / "hardwarecheck-v5-active-battery-test.json"

    def _save_battery_state(self) -> None:
        if self._battery_mode not in {"charge", "discharge"}:
            return
        path = self._battery_state_path()
        payload = {
            "mode": self._battery_mode,
            "csv_path": str(self._battery_csv_path or ""),
            "saved_at": datetime.datetime.now().astimezone().replace(microsecond=0).isoformat(),
            "samples": self._battery_samples[-720:],
        }
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(path.suffix + ".tmp")
            temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            temporary.replace(path)
        except OSError:
            pass

    def _clear_battery_state(self) -> None:
        try:
            self._battery_state_path().unlink(missing_ok=True)
        except OSError:
            pass

    def _restore_battery_test(self) -> None:
        path = self._battery_state_path()
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            mode = str(payload.get("mode") or "")
            saved_at = self.core.parse_battery_timestamp(payload.get("saved_at"))
            samples = payload.get("samples")
            if mode not in {"charge", "discharge"} or saved_at is None or not isinstance(samples, list) or not samples:
                raise ValueError("invalid active battery state")
            now = datetime.datetime.now(saved_at.tzinfo) if saved_at.tzinfo is not None else datetime.datetime.now()
            if (now - saved_at).total_seconds() > 30 * 60 or (now - saved_at).total_seconds() < -60:
                raise ValueError("stale active battery state")
            self._battery_mode = mode
            self._battery_samples = [sample for sample in samples if isinstance(sample, dict)]
            csv_value = str(payload.get("csv_path") or "").strip()
            self._battery_csv_path = pathlib.Path(csv_value) if csv_value else None
            if self._battery_timer_id is not None:
                GLib.source_remove(self._battery_timer_id)
            self._battery_timer_id = GLib.timeout_add_seconds(60, self._battery_sample_tick)
            details = self.core.read_battery_details()
            self._update_battery_ui(details)
            self.set_status(self._t("Laufender Akku-Test wurde fortgesetzt.", "Running battery test resumed.", "Probíhající test baterie byl obnoven."), "good")
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            self._battery_mode = ""
            self._battery_samples = []
            self._battery_csv_path = None
            self._clear_battery_state()

    def _start_battery_test(self, mode: str) -> None:
        if self._battery_mode:
            self.set_status(self._t("Ein Akku-Test läuft bereits.", "A battery test is already running.", "Test baterie již probíhá."), "warn")
            return
        details = self.core.read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Kein Akku erkannt.", "No battery detected.", "Baterie nebyla nalezena."), "bad")
            return
        try:
            start_percent = float(details.get("capacity_percent"))
        except (TypeError, ValueError):
            start_percent = None
        if mode == "discharge" and details.get("ac_online") is True:
            self.set_status(self._t("Für den Entlade-Test bitte das Netzteil entfernen.", "Disconnect the adapter for the discharge test.", "Pro test vybíjení odpojte napájecí adaptér."), "warn")
            return
        if mode == "charge" and details.get("ac_online") is False:
            self.set_status(self._t("Für den Lade-Test bitte das Netzteil anschließen.", "Connect the adapter for the charge test.", "Pro test nabíjení připojte napájecí adaptér."), "warn")
            return
        if mode == "discharge" and start_percent is not None and start_percent <= self.core.BATTERY_TEST_LOW_LEVEL_PERCENT:
            self.set_status(self._t("Akkustand zu niedrig: Entlade-Test erst oberhalb von 15 % starten.", "Battery level too low: start the discharge test above 15 %.", "Stav baterie je příliš nízký: test vybíjení spusťte nad 15 %."), "warn")
            return
        if mode == "charge" and start_percent is not None and start_percent >= self.core.BATTERY_TEST_CHARGE_STOP_PERCENT:
            self.set_status(self._t("Akku bereits nahezu voll; Lade-Test unter 95 % starten.", "Battery already nearly full; start the charge test below 95 %.", "Baterie je téměř plná; test nabíjení spusťte pod 95 %."), "warn")
            return
        try:
            report_dir = self.core.get_battery_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            basename = self.core.battery_report_basename(self.snapshot or None, mode)
            self._battery_csv_path = report_dir / f"{basename}.csv"
            self.core.append_battery_csv(self._battery_csv_path, mode, details, include_header=True)
        except OSError as exc:
            self.set_status(f"{self._t('Akku-Test konnte nicht gestartet werden', 'Battery test could not be started', 'Test baterie nelze spustit')}: {exc}", "bad")
            return
        self._battery_mode = mode
        self._battery_samples = [details]
        self._battery_last_result = {}
        self._battery_last_report_path = None
        if self._battery_timer_id is not None:
            GLib.source_remove(self._battery_timer_id)
        self._battery_timer_id = GLib.timeout_add_seconds(60, self._battery_sample_tick)
        self._save_battery_state()
        self._update_battery_ui(details)
        self.set_status(self._t("Standardtest gestartet: mindestens 30 Minuten und 5 % Veränderung, maximal 60 Minuten.", "Standard test started: at least 30 minutes and 5 % change, maximum 60 minutes.", "Standardní test spuštěn: nejméně 30 minut a změna 5 %, maximálně 60 minut."), "good")

    def _battery_sample_tick(self) -> bool:
        if not self._battery_mode:
            return False
        details = self.core.read_battery_details()
        self._battery_samples.append(details)
        if self._battery_csv_path is not None:
            try:
                self.core.append_battery_csv(self._battery_csv_path, self._battery_mode, details)
            except OSError:
                pass
        self._save_battery_state()
        self._update_battery_ui(details)
        completion = self.core.battery_test_completion(self._battery_mode, self._battery_samples)
        if completion.get("should_finish"):
            self._battery_timer_id = None
            self._finish_battery_test(str(completion.get("reason") or "max_duration"), automatic=True)
            return False
        return True

    def _stop_battery_test(self, _button=None) -> None:
        if not self._battery_mode:
            self.set_status(self._t("Kein Akku-Test aktiv.", "No battery test active.", "Není aktivní žádný test baterie."), "warn")
            return
        details = self.core.read_battery_details()
        last_stamp = str(self._battery_samples[-1].get("timestamp") or "") if self._battery_samples else ""
        if str(details.get("timestamp") or "") != last_stamp:
            self._battery_samples.append(details)
            if self._battery_csv_path is not None:
                try:
                    self.core.append_battery_csv(self._battery_csv_path, self._battery_mode, details)
                except OSError:
                    pass
        self._finish_battery_test("manual", automatic=False)

    def _finish_battery_test(self, reason: str, automatic: bool) -> None:
        if not self._battery_mode:
            return
        mode = self._battery_mode
        samples = list(self._battery_samples)
        csv_path = self._battery_csv_path
        self._battery_last_result = self.core.battery_test_result(mode, samples, self.language, reason)
        self._battery_mode = ""
        if self._battery_timer_id is not None:
            GLib.source_remove(self._battery_timer_id)
            self._battery_timer_id = None
        self._clear_battery_state()
        self._update_battery_ui(samples[-1])
        if automatic:
            self.set_status(
                f"{self._t('Akku-Test automatisch abgeschlossen', 'Battery test completed automatically', 'Test baterie byl automaticky dokončen')}: {self._battery_last_result.get('verdict')}",
                "good" if self._battery_last_result.get("class_name") == "ok" else "warn" if self._battery_last_result.get("class_name") == "warn" else "bad",
            )
        self._write_battery_report(mode, samples, csv_path, reason)

    def _instant_battery_report(self, _button=None) -> None:
        details = self.core.read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Kein Akku erkannt.", "No battery detected.", "Baterie nebyla nalezena."), "bad")
            return
        self._write_battery_report("instant", [details], None, "instant")

    def _write_battery_report(self, mode: str, samples: list[dict[str, object]], csv_path: pathlib.Path | None, completion_reason: str = "manual") -> None:
        snapshot = dict(self.snapshot)

        def worker():
            report_dir = self.core.get_battery_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            basename = self.core.battery_report_basename(snapshot or None, mode)
            local_csv = csv_path or report_dir / f"{basename}.csv"
            if csv_path is None:
                self.core.append_battery_csv(local_csv, mode, samples[-1], include_header=True)
            txt_path = report_dir / f"{basename}.txt"
            html_path = report_dir / f"{basename}.html"
            report = self.core.build_battery_workshop_report(mode, samples, snapshot, local_csv, self.language, completion_reason)
            html_report = self.core.build_battery_test_html_report(mode, samples, snapshot, local_csv, txt_path, self.language, completion_reason)
            self.core.write_text_durable(txt_path, report)
            self.core.write_text_durable(html_path, html_report)
            return html_path, txt_path

        def done(paths) -> None:
            html_path, txt_path = paths
            self._battery_last_report_path = txt_path
            self.set_status(f"{self._t('Akku-Ergebnis gespeichert', 'Battery result saved', 'Výsledek testu baterie uložen')}: {txt_path.name}", "good")
            if self._battery_display_details:
                self._update_battery_ui(self._battery_display_details)
            self._refresh_reports()

        self.run_async("battery-report", worker, done)

    # ---------- Wi-Fi ----------

    def _open_settings_tool(self, page: str, popover: Gtk.Popover | None = None) -> None:
        if popover is not None:
            popover.popdown()
        self.show_page(page)

    def _set_network_chip(self, text: str, state: str) -> None:
        label: Gtk.Label | None = self._build_refs.get("network_chip")
        button: Gtk.MenuButton | None = self._build_refs.get("network_chip_button")
        if label is not None:
            label.set_text(text)
        if button is not None:
            self._set_chip_state(button, state)

    def _current_wifi_connection(self) -> tuple[str, str]:
        try:
            for iface in self.core.list_network_interfaces(wifi=True):
                ssid = str(self.core.current_wifi_ssid(iface) or "").strip()
                if ssid and self.core.interface_has_ipv4(iface):
                    self._wifi_connected_ssid = ssid
                    return iface, ssid
        except Exception:
            pass
        return "", ""

    def _wifi_quick_toggled(self, button: Gtk.MenuButton) -> None:
        if button.get_active():
            self._refresh_wifi_quick_menu(force=True)

    def _scan_wifi_live_preserving_connection(self) -> tuple[list[dict[str, str]], str]:
        """Scan visible WLANs without resetting an existing association."""
        if not sys.platform.startswith("linux"):
            return [], "WLAN-Scan nur unter Linux verfügbar"
        try:
            ifaces = self.core.list_network_interfaces(wifi=True)
            iw = self.core.find_executable("iw")
            iwlist = self.core.find_executable("iwlist")
            ip_cmd = self.core.find_executable("ip")
        except Exception as exc:
            return [], str(exc)
        if not ifaces:
            return [], self._t("Kein WLAN-Adapter gefunden", "No Wi-Fi adapter found", "Nebyl nalezen adaptér Wi-Fi")

        debug_lines: list[str] = []
        try:
            self.core.unblock_wifi_radios(debug_lines)
            self.core.set_wifi_country(debug_lines)
        except Exception:
            pass
        found: dict[str, dict[str, str]] = {}
        for iface in ifaces:
            if ip_cmd:
                self.core.run_quiet_timeout([ip_cmd, "link", "set", iface, "up"], timeout=3)
            networks: list[dict[str, str]] = []
            if iw:
                output = self.core.run_debug_command([iw, "dev", iface, "scan"], timeout=12)
                networks = self.core.parse_iw_scan(output, iface)
                if not networks:
                    cached = self.core.run_debug_command([iw, "dev", iface, "scan", "dump"], timeout=4)
                    networks = self.core.parse_iw_scan(cached, iface)
            if not networks and iwlist:
                output = self.core.run_debug_command([iwlist, iface, "scan"], timeout=12)
                networks = self.core.parse_iwlist_scan(output, iface)
            for network in networks:
                ssid = str(network.get("ssid") or "").strip()
                if not ssid:
                    continue
                previous = found.get(ssid)
                if previous is None or self.core.wifi_signal_sort_value(network.get("signal", "")) > self.core.wifi_signal_sort_value(previous.get("signal", "")):
                    found[ssid] = network
        networks = sorted(found.values(), key=lambda item: self.core.wifi_signal_sort_value(item.get("signal", "")), reverse=True)
        return networks, self._t(
            f"{len(networks)} sichtbare WLAN-Netze",
            f"{len(networks)} visible Wi-Fi networks",
            f"Viditelné sítě Wi-Fi: {len(networks)}",
        ) if networks else self._t("Keine sichtbaren WLAN-Netze gefunden", "No visible Wi-Fi networks found", "Nebyly nalezeny žádné viditelné sítě Wi-Fi")

    def _refresh_wifi_quick_menu(self, force: bool = False) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("wifi_quick_list")
        status: Gtk.Label | None = self._build_refs.get("wifi_quick_status")
        task_name = "wifi-live-scan"
        if listbox is None or status is None or task_name in self._refresh_tasks:
            return
        if self._wifi_connection_busy:
            status.set_text(self._t("WLAN wird gerade verbunden …", "Wi-Fi is connecting …", "Wi-Fi se právě připojuje …"))
            return
        if self._wifi_quick_networks and not force:
            _iface, connected_ssid = self._current_wifi_connection()
            self._render_wifi_quick_rows(self._wifi_quick_networks, self.core.load_wifi_networks(), connected_ssid)
            return
        status.set_text(self._t("Live-Suche läuft …", "Live scan running …", "Probíhá živé hledání …"))
        if self._wifi_connected_ssid:
            try:
                saved_now = self.core.load_wifi_networks()
            except Exception:
                saved_now = []
            cached = list(self._wifi_quick_networks)
            if not any(str(item.get("ssid") or "") == self._wifi_connected_ssid for item in cached):
                cached.insert(0, {"ssid": self._wifi_connected_ssid, "signal": "–"})
            self._render_wifi_quick_rows(cached, saved_now, self._wifi_connected_ssid)
        else:
            self._clear_listbox(listbox)
            waiting = Gtk.ListBoxRow()
            waiting.add(self._label(self._t("Verfügbare WLANs werden gesucht …", "Searching for available Wi-Fi …", "Vyhledávání dostupných sítí Wi-Fi …"), "muted", wrap=True))
            listbox.add(waiting)
            listbox.show_all()
        self._refresh_tasks.add(task_name)

        def worker():
            iface, connected_ssid = self._current_wifi_connection()
            saved = self.core.load_wifi_networks()
            networks, message = self._scan_wifi_live_preserving_connection()
            return iface, connected_ssid, saved, networks, message

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            _iface, connected_ssid, saved, networks, message = result
            self._wifi_quick_networks = networks
            self._render_wifi_quick_rows(networks, saved, connected_ssid)
            status.set_text(message)

        self.run_async(task_name, worker, done)

    def _render_wifi_quick_rows(self, networks: list[dict[str, str]], saved: list[dict[str, str]], connected_ssid: str) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("wifi_quick_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        saved_by_ssid = {str(item.get("ssid") or ""): item for item in saved}
        visible = {str(item.get("ssid") or ""): dict(item) for item in networks if str(item.get("ssid") or "")}
        if connected_ssid and connected_ssid not in visible:
            visible[connected_ssid] = {"ssid": connected_ssid, "signal": "–"}
        ordered = sorted(
            visible.values(),
            key=lambda item: (
                str(item.get("ssid") or "") == connected_ssid,
                self.core.wifi_signal_sort_value(item.get("signal", "")),
            ),
            reverse=True,
        )
        if not ordered:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Keine WLAN-Netze sichtbar.", "No Wi-Fi networks visible.", "Nejsou viditelné žádné sítě Wi-Fi."), "muted", wrap=True))
            listbox.add(row)
        for network in ordered:
            ssid = str(network.get("ssid") or "")
            saved_profile = saved_by_ssid.get(ssid)
            if saved_profile:
                merged = dict(saved_profile)
                merged.update({key: value for key, value in network.items() if value})
            else:
                merged = network
            listbox.add(self._wifi_quick_row(merged, bool(saved_profile), ssid == connected_ssid))
        listbox.show_all()

    def _wifi_quick_row(self, network: dict[str, str], saved: bool, connected: bool) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.add(box)
        box.pack_start(self._icon("network-wireless-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(network.get("ssid")), "section-title"), False, False, 0)
        if connected:
            detail = self._t("Verbunden", "Connected", "Připojeno")
        else:
            security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security")) or self._t("Sicherheit unbekannt", "Security unknown", "Neznámé zabezpečení")
            signal = _clean(network.get("signal"), self._t("Signal unbekannt", "Signal unknown", "Signál neznámý"))
            detail = f"{security} · {signal}"
        if saved:
            detail += f" · {self._t('gespeichert', 'saved', 'uloženo')}"
        text.pack_start(self._label(detail, "good-text" if connected else "muted", wrap=True), False, False, 0)
        box.pack_start(text, True, True, 0)
        if not connected:
            box.pack_end(
                self._button(
                    self._t("Verbinden", "Connect", "Připojit"),
                    lambda _b, item=dict(network), is_saved=saved: self._connect_wifi(item, is_saved),
                    "primary-button",
                ),
                False,
                False,
                0,
            )
        return row

    def _start_wifi_autoconnect(self) -> bool:
        if self._wifi_autoconnect_started:
            return False
        self._wifi_autoconnect_started = True
        self._set_network_chip(self._t("WLAN verbindet …", "Connecting Wi-Fi …", "Připojování Wi-Fi …"), "warn")
        self._wifi_connection_busy = True

        def progress(state: str, message: str) -> None:
            GLib.idle_add(self._wifi_autoconnect_progress, state, message)

        def worker():
            try:
                saved = self.core.load_wifi_networks()
            except Exception:
                saved = []
            result = self.core.connect_temporary_network(
                progress,
                [],
                networks_override=saved,
                require_internet=True,
                allow_active=True,
                allow_lan=False,
                cleanup_success=False,
            )
            if not result[0]:
                try:
                    result[2]()
                except Exception:
                    pass
            _iface, connected_ssid = self._current_wifi_connection() if result[0] else ("", "")
            return result[0], result[1], connected_ssid, bool(saved)

        self.run_async("wifi-autoconnect", worker, self._wifi_autoconnect_finished)
        return False

    def _wifi_autoconnect_progress(self, state: str, message: str) -> bool:
        translated = self._translate_status(message)
        quick_status: Gtk.Label | None = self._build_refs.get("wifi_quick_status")
        if quick_status is not None:
            quick_status.set_text(translated)
        if state == "online":
            self._set_network_chip(self._t("Netzwerk aktiv", "Network active", "Síť aktivní"), "good")
        else:
            self._set_network_chip(self._t("WLAN verbindet …", "Connecting Wi-Fi …", "Připojování Wi-Fi …"), "warn")
        return False

    def _wifi_autoconnect_finished(self, result) -> None:
        ok, message, ssid, had_saved_profiles = result
        self._wifi_connection_busy = False
        if ok:
            self._wifi_connected_ssid = ssid
            self._set_network_chip(f"{ssid} ✓" if ssid else self._translate_status(message), "good")
            self.set_status(self._translate_status(message), "good")
        else:
            self._wifi_connected_ssid = ""
            self._set_network_chip(self._t("Offline", "Offline", "Offline"), "warn")
            self.set_status(
                self._t("Kein gespeichertes WLAN erreichbar.", "No saved Wi-Fi is reachable.", "Žádná uložená Wi-Fi není dostupná.")
                if had_saved_profiles
                else self._t("Noch kein WLAN gespeichert.", "No Wi-Fi has been saved yet.", "Zatím není uložena žádná Wi-Fi."),
                "warn",
            )
        self._wifi_quick_networks = []
        popover: Gtk.Popover | None = self._build_refs.get("wifi_quick_popover")
        if popover is not None and popover.get_visible():
            self._refresh_wifi_quick_menu(force=True)
        GLib.timeout_add_seconds(2, self._schedule_auto_update_check)

    def _build_wifi_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("WLAN-Zentrale", "Wi-Fi centre", "Centrum Wi-Fi"),
            self._t("Gespeicherte und sichtbare Netzwerke gemeinsam anzeigen, prüfen und verbinden.", "Show, check and connect saved and visible networks together.", "Zobrazujte, kontrolujte a připojujte uložené i viditelné sítě."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["wifi_status"] = self._label(self._t("Bereit zur Suche", "Ready to scan", "Připraveno ke skenování"), "status-chip")
        toolbar.pack_start(self._build_refs["wifi_status"], True, True, 0)
        toolbar.pack_end(self._button(self._t("Netze suchen", "Scan networks", "Vyhledat sítě"), self._scan_wifi, "primary-button", "view-refresh-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)
        self._build_refs["wifi_list"] = Gtk.ListBox()
        self._build_refs["wifi_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        wifi_scroll = Gtk.ScrolledWindow()
        wifi_scroll.set_min_content_height(430)
        wifi_scroll.add(self._build_refs["wifi_list"])
        outer.pack_start(wifi_scroll, True, True, 4)
        return page

    def _clear_listbox(self, widget: Gtk.ListBox) -> None:
        for child in widget.get_children():
            widget.remove(child)

    def _refresh_wifi_saved_rows(self, scanned: list[dict[str, str]] | None = None) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("wifi_list")
        task_name = "wifi-profiles"
        if listbox is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["wifi_status"].set_text(self._t("WLAN-Profile werden geladen …", "Loading Wi-Fi profiles …", "Načítání profilů Wi-Fi …"))

        def worker():
            try:
                return self.core.load_wifi_networks()
            except Exception:
                return []

        def done(saved) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_wifi_rows(saved, scanned)

        self.run_async(task_name, worker, done)

    def _render_wifi_rows(self, saved: list[dict[str, str]], scanned: list[dict[str, str]] | None = None) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("wifi_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        saved_by_ssid = {str(item.get("ssid") or ""): item for item in saved}
        merged: dict[str, dict[str, str]] = {ssid: dict(item) for ssid, item in saved_by_ssid.items() if ssid}
        for item in scanned or []:
            ssid = str(item.get("ssid") or "")
            if not ssid:
                continue
            existing = merged.setdefault(ssid, {})
            existing.update(item)
            if ssid in saved_by_ssid:
                existing["password"] = str(saved_by_ssid[ssid].get("password") or "")
                existing["saved"] = "1"
        if not merged:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Noch keine gespeicherten oder sichtbaren WLAN-Netze.", "No saved or visible Wi-Fi networks yet.", "Zatím žádné uložené ani viditelné sítě Wi-Fi."), "muted", wrap=True))
            listbox.add(row)
        for network in sorted(merged.values(), key=lambda item: self.core.wifi_signal_sort_value(item.get("signal", "")), reverse=True):
            listbox.add(self._wifi_row(network, str(network.get("ssid") or "") in saved_by_ssid))
        listbox.show_all()
        self._build_refs["wifi_status"].set_text(
            self._t(f"{len(merged)} WLAN-Netze", f"{len(merged)} Wi-Fi networks", f"Sítě Wi-Fi: {len(merged)}")
        )

    def _wifi_row(self, network: dict[str, str], saved: bool) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        row.add(box)
        box.pack_start(self._icon("network-wireless-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(network.get("ssid")), "section-title"), False, False, 0)
        security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security"))
        signal = _clean(network.get("signal"), self._t("Signal unbekannt", "Signal unknown", "Signál neznámý"))
        saved_text = self._t("gespeichert", "saved", "uloženo") if saved else self._t("nicht gespeichert", "not saved", "neuloženo")
        text.pack_start(self._label(f"{security} · {signal} · {saved_text}", "muted"), False, False, 0)
        box.pack_start(text, True, True, 0)
        box.pack_end(self._button(self._t("Verbinden", "Connect", "Připojit"), lambda _b, item=dict(network), is_saved=saved: self._connect_wifi(item, is_saved), "primary-button", "network-wireless-symbolic"), False, False, 0)
        if saved:
            box.pack_end(self._button(self._t("Löschen", "Delete", "Smazat"), lambda _b, ssid=str(network.get("ssid") or ""): self._delete_wifi(ssid), "danger-button", "edit-delete-symbolic"), False, False, 0)
        return row

    def _scan_wifi(self, _button=None) -> None:
        task_name = "wifi-settings-scan"
        if self._wifi_connection_busy:
            self._build_refs["wifi_status"].set_text(self._t("Bitte laufende WLAN-Verbindung abwarten …", "Please wait for the Wi-Fi connection …", "Počkejte na dokončení připojení Wi-Fi …"))
            return
        if task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["wifi_status"].set_text(self._t("WLAN-Suche läuft …", "Scanning Wi-Fi …", "Probíhá hledání Wi-Fi …"))
        self.run_async(task_name, self._scan_wifi_live_preserving_connection, self._wifi_scan_finished)

    def _wifi_scan_finished(self, result) -> None:
        self._refresh_tasks.discard("wifi-settings-scan")
        networks, message = result
        self._build_refs["wifi_status"].set_text(self._translate_status(message))
        self._refresh_wifi_saved_rows(networks)
        self.set_status(self._translate_status(message), "good" if networks else "warn")

    def _touch_keyboard(self, entry: Gtk.Entry) -> Gtk.Widget:
        revealer = Gtk.Revealer()
        grid = Gtk.Grid(row_spacing=3, column_spacing=3)
        keys = ("1234567890", "qwertzuiop", "asdfghjkl", "yxcvbnm")
        for row_index, row_keys in enumerate(keys):
            for column, key in enumerate(row_keys):
                button = Gtk.Button(label=key)
                button.set_size_request(42, 34)
                button.connect("clicked", lambda _b, value=key: self._entry_insert(entry, value))
                grid.attach(button, column, row_index, 1, 1)
        back = Gtk.Button(label="⌫")
        back.connect("clicked", lambda _b: self._entry_backspace(entry))
        grid.attach(back, 10, 0, 1, 2)
        specials = ("-", "_", ".", "@", "!", "?", "#", "+")
        for column, key in enumerate(specials):
            button = Gtk.Button(label=key)
            button.connect("clicked", lambda _b, value=key: self._entry_insert(entry, value))
            grid.attach(button, column, 4, 1, 1)
        revealer.add(grid)
        return revealer

    def _entry_backspace(self, entry: Gtk.Entry) -> None:
        position = entry.get_position()
        if position > 0:
            entry.delete_text(position - 1, position)

    def _entry_insert(self, entry: Gtk.Entry, value: str) -> None:
        position = entry.get_position()
        entry.insert_text(value, position)
        entry.set_position(position + len(value))

    def _password_dialog(self, ssid: str) -> str | None:
        dialog = Gtk.Dialog(title=self._t("WLAN verbinden", "Connect Wi-Fi", "Připojit Wi-Fi"), transient_for=self.window, modal=True)
        dialog.add_button(self._t("Abbrechen", "Cancel", "Zrušit"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self._t("Speichern + verbinden", "Save + connect", "Uložit + připojit"), Gtk.ResponseType.OK)
        content = dialog.get_content_area()
        content.set_spacing(8)
        content.set_margin_start(16)
        content.set_margin_end(16)
        content.pack_start(self._label(f"{self._t('Passwort für', 'Password for', 'Heslo pro')} {ssid}", "section-title"), False, False, 4)
        entry = Gtk.Entry()
        entry.set_visibility(False)
        entry.set_activates_default(True)
        content.pack_start(entry, False, False, 0)
        reveal_password = Gtk.CheckButton(label=self._t("Passwort anzeigen", "Show password", "Zobrazit heslo"))
        reveal_password.connect("toggled", lambda button: entry.set_visibility(button.get_active()))
        content.pack_start(reveal_password, False, False, 0)
        keyboard = self._touch_keyboard(entry)
        toggle = Gtk.ToggleButton(label=self._t("Bildschirmtastatur", "On-screen keyboard", "Klávesnice na obrazovce"))
        toggle.connect("toggled", lambda button: keyboard.set_reveal_child(button.get_active()))
        content.pack_start(toggle, False, False, 0)
        content.pack_start(keyboard, False, False, 0)
        dialog.set_default_response(Gtk.ResponseType.OK)
        dialog.show_all()
        keyboard.set_reveal_child(False)
        response = dialog.run()
        value = entry.get_text() if response == Gtk.ResponseType.OK else None
        dialog.destroy()
        return value

    def _connect_wifi(self, network: dict[str, str], saved: bool) -> None:
        if self._wifi_connection_busy:
            self.set_status(self._t("Bitte laufende WLAN-Verbindung abwarten.", "Please wait for the Wi-Fi connection.", "Počkejte na dokončení připojení Wi-Fi."), "warn")
            return
        ssid = str(network.get("ssid") or "").strip()
        security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security"))
        if not ssid:
            return
        if security == "OPEN":
            self.set_status(
                self._t(
                    "Offene WLANs werden in diesem Teststand noch nicht unterstützt.",
                    "Open Wi-Fi networks are not supported by this test build yet.",
                    "Otevřené sítě Wi-Fi zatím tato testovací verze nepodporuje.",
                ),
                "warn",
            )
            return
        saved_networks = {str(item.get("ssid") or ""): item for item in self.core.load_wifi_networks()}
        candidate = dict(saved_networks.get(ssid) or network)
        candidate.update({key: value for key, value in network.items() if value})
        if security != "OPEN" and not str(candidate.get("password") or ""):
            password = self._password_dialog(ssid)
            if password is None:
                return
            candidate["password"] = password
            self.core.save_wifi_network(ssid, password, security)
        elif not saved:
            self.core.save_wifi_network(ssid, "", security)
        self._build_refs["wifi_status"].set_text(f"{self._t('Verbinde', 'Connecting', 'Připojování')} {ssid} …")
        self._wifi_connection_busy = True

        def status(_state: str, message: str) -> None:
            GLib.idle_add(self._build_refs["wifi_status"].set_text, self._translate_status(message))

        def worker():
            result = self.core.connect_temporary_network(
                status,
                [],
                [candidate],
                require_internet=True,
                allow_active=False,
                allow_lan=False,
                cleanup_success=False,
            )
            if not result[0]:
                try:
                    result[2]()
                except Exception:
                    pass
            return result

        self.run_async(
            "wifi-connect",
            worker,
            lambda result: self._wifi_connect_finished(ssid, result),
        )

    def _wifi_connect_finished(self, ssid: str, result) -> None:
        ok, message, _cleanup = result
        self._wifi_connection_busy = False
        state = "good" if ok else "bad"
        self._wifi_connected_ssid = ssid if ok else ""
        self._build_refs["wifi_status"].set_text(self._translate_status(message))
        self._set_network_chip(f"{ssid} ✓" if ok else self._t("WLAN-Fehler", "Wi-Fi error", "Chyba Wi-Fi"), state)
        self.set_status(self._translate_status(message), state)
        popover: Gtk.Popover | None = self._build_refs.get("wifi_quick_popover")
        if popover is not None:
            popover.popdown()
        self._wifi_quick_networks = []
        self._refresh_wifi_saved_rows()
        if ok:
            GLib.timeout_add_seconds(2, lambda: self._schedule_auto_update_check(force=True))

    def _delete_wifi(self, ssid: str) -> None:
        if self.core.delete_wifi_network(ssid):
            self.set_status(f"{self._t('WLAN gelöscht', 'Wi-Fi deleted', 'Wi-Fi smazána')}: {ssid}", "good")
        self._wifi_quick_networks = []
        self._refresh_wifi_saved_rows()

    # ---------- printing ----------

    def _build_print_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Drucken", "Print", "Tisk"),
            self._t(
                "Den aktuellen Hardware-Report prüfen, speichern und direkt an den aktiven Drucker senden.",
                "Review, save and send the current hardware report directly to the active printer.",
                "Zkontrolujte, uložte a odešlete aktuální hardwarový report na aktivní tiskárnu.",
            ),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["print_status"] = self._label(self._t("Hardware wird geladen …", "Loading hardware …", "Načítání hardwaru …"), "status-chip")
        toolbar.pack_start(self._build_refs["print_status"], True, True, 0)
        toolbar.pack_end(
            self._button(
                self._t("Jetzt drucken", "Print now", "Vytisknout nyní"),
                self._print_current_report,
                "primary-button",
                "document-print-symbolic",
            ),
            False,
            False,
            0,
        )
        toolbar.pack_end(
            self._button(
                self._t("Report speichern", "Save report", "Uložit report"),
                self._save_current_report,
                "secondary-button",
                "document-save-symbolic",
            ),
            False,
            False,
            0,
        )
        toolbar.pack_end(
            self._button(
                self._t("Drucker auswählen", "Choose printer", "Vybrat tiskárnu"),
                lambda _b: self.show_page("printers"),
                "secondary-button",
                "printer-symbolic",
            ),
            False,
            False,
            0,
        )
        outer.pack_start(toolbar, False, False, 12)

        preview_frame = Gtk.Frame()
        preview_frame.set_shadow_type(Gtk.ShadowType.NONE)
        preview_frame.get_style_context().add_class("card")
        preview_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        preview_frame.add(preview_box)
        preview_box.pack_start(self._label(self._t("Druckvorschau", "Print preview", "Náhled tisku"), "section-title"), False, False, 0)
        preview = Gtk.TextView()
        preview.set_editable(False)
        preview.set_cursor_visible(False)
        preview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        preview_scroll = Gtk.ScrolledWindow()
        preview_scroll.set_min_content_height(430)
        preview_scroll.add(preview)
        preview_box.pack_start(preview_scroll, True, True, 0)
        outer.pack_start(preview_frame, True, True, 0)
        self._build_refs["print_preview"] = preview
        return page

    def _current_report_text(self) -> str:
        if not self.snapshot:
            return self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen.")
        matches = self.core.format_model_match_results(self.match_results, self.language, limit=6)
        return self.core.build_report(self.snapshot, matches, self.language)

    def _refresh_print_page(self) -> None:
        preview: Gtk.TextView | None = self._build_refs.get("print_preview")
        status: Gtk.Label | None = self._build_refs.get("print_status")
        if preview is not None:
            preview.get_buffer().set_text(self._current_report_text())
        task_name = "print-printer-status"
        if status is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        status.set_text(self._t("Aktiver Drucker wird geprüft …", "Checking active printer …", "Kontrola aktivní tiskárny …"))

        def worker():
            try:
                config, _path = self.core.load_printer_config()
                printer_name = str(config.get("printer_name") or config.get("name") or "").strip()
                printer_target = str(config.get("printer_uri") or config.get("raw_host") or config.get("printer_host") or "").strip()
                return printer_name, printer_target
            except Exception:
                return "", ""

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            printer_name, printer_target = result
            if printer_name or printer_target:
                status.set_text(f"{self._t('Aktiver Drucker', 'Active printer', 'Aktivní tiskárna')}: {printer_name or printer_target}")
                self._set_chip_state(status, "good")
            else:
                status.set_text(self._t("Noch kein aktiver Drucker gewählt", "No active printer selected", "Není vybrána aktivní tiskárna"))
                self._set_chip_state(status, "warn")

        self.run_async(task_name, worker, done)

    def _write_current_report(self, print_after: bool) -> None:
        if not self.snapshot:
            self.set_status(self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen."), "warn")
            return

        def worker():
            report = self._current_report_text()
            report_dir = self.core.get_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            target = report_dir / f"{self.core.report_basename(self.snapshot)}.txt"
            self.core.write_text_durable(target, report)
            if not print_after:
                return target, None

            def progress(_state: str, message: str) -> None:
                status: Gtk.Label | None = self._build_refs.get("print_status")
                if status is not None:
                    GLib.idle_add(status.set_text, self._translate_status(message))

            return target, self.core.run_report_print(target, progress)

        def done(result) -> None:
            target, print_result = result
            if print_result is None:
                message = f"{self._t('Report gespeichert', 'Report saved', 'Report uložen')}: {target.name}"
                self.set_status(message, "good")
                self._build_refs["print_status"].set_text(message)
            else:
                ok, message = print_result
                translated = self._translate_status(message)
                self.set_status(f"{translated} · {target.name}", "good" if ok else "bad")
                self._build_refs["print_status"].set_text(translated)

        self.run_async("current-report-print" if print_after else "current-report-save", worker, done)

    def _save_current_report(self, _button=None) -> None:
        self._write_current_report(False)

    def _print_current_report(self, _button=None) -> None:
        self._write_current_report(True)

    # ---------- printers ----------

    def _build_printers_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Drucker-Zentrale", "Printer centre", "Centrum tiskáren"),
            self._t("Gespeicherte Drucker sofort verwenden und neue IPP-/RAW-Drucker live finden.", "Use saved printers immediately and discover new IPP/RAW printers live.", "Okamžitě používejte uložené tiskárny a vyhledávejte nové tiskárny IPP/RAW."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["printer_status"] = self._label(self._t("Bereit", "Ready", "Připraveno"), "status-chip")
        toolbar.pack_start(self._build_refs["printer_status"], True, True, 0)
        toolbar.pack_end(self._button(self._t("Testseite drucken", "Print test page", "Vytisknout testovací stránku"), self._print_test_report, "secondary-button", "document-print-symbolic"), False, False, 0)
        toolbar.pack_end(self._button(self._t("Drucker suchen", "Find printers", "Vyhledat tiskárny"), self._scan_printers, "primary-button", "system-search-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)

        panes = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        panes.set_position(520)
        outer.pack_start(panes, True, True, 4)
        saved_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        saved_box.pack_start(self._label(self._t("Gespeicherte Drucker", "Saved printers", "Uložené tiskárny"), "section-title"), False, False, 0)
        self._build_refs["printer_saved_list"] = Gtk.ListBox()
        self._build_refs["printer_saved_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        saved_scroll = Gtk.ScrolledWindow()
        saved_scroll.add(self._build_refs["printer_saved_list"])
        saved_box.pack_start(saved_scroll, True, True, 0)
        panes.pack1(saved_box, True, False)
        found_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        found_box.pack_start(self._label(self._t("Gefundene Drucker", "Discovered printers", "Nalezené tiskárny"), "section-title"), False, False, 0)
        self._build_refs["printer_found_list"] = Gtk.ListBox()
        self._build_refs["printer_found_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        found_scroll = Gtk.ScrolledWindow()
        found_scroll.add(self._build_refs["printer_found_list"])
        found_box.pack_start(found_scroll, True, True, 0)
        panes.pack2(found_box, True, False)
        return page

    def _refresh_printer_profiles(self) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("printer_saved_list")
        task_name = "printer-profiles"
        if listbox is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["printer_status"].set_text(self._t("Druckerprofile werden geladen …", "Loading printer profiles …", "Načítání profilů tiskáren …"))

        def worker():
            try:
                profiles = self.core.load_printer_profiles()
                active_config, _path = self.core.load_printer_config()
                return profiles, self.core.printer_config_signature(active_config)
            except Exception:
                return [], ()

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_printer_profiles(result)

        self.run_async(task_name, worker, done)

    def _render_printer_profiles(self, result) -> None:
        profiles, active_signature = result
        listbox: Gtk.ListBox = self._build_refs.get("printer_saved_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        if not profiles:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Noch kein Drucker gespeichert.", "No printer saved yet.", "Zatím není uložena žádná tiskárna."), "muted", wrap=True))
            listbox.add(row)
        for profile in profiles:
            config = self.core.printer_profile_config(profile)
            active = self.core.printer_config_signature(config) == active_signature
            row = Gtk.ListBoxRow()
            row.get_style_context().add_class("list-row")
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.add(box)
            box.pack_start(self._icon("printer-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            name = self.core.printer_profile_name(profile)
            text.pack_start(self._label(name, "section-title"), False, False, 0)
            host = config.get("raw_host") or config.get("printer_host") or config.get("printer_uri") or "–"
            text.pack_start(self._label(f"{_short(host, 54)} · {self._t('aktiv', 'active', 'aktivní') if active else self._t('gespeichert', 'saved', 'uloženo')}", "good-text" if active else "muted"), False, False, 0)
            box.pack_start(text, True, True, 0)
            box.pack_end(self._button(self._t("Aktivieren", "Activate", "Aktivovat"), lambda _b, item=profile: self._activate_printer_profile(item), "primary-button"), False, False, 0)
            box.pack_end(self._button(self._t("Löschen", "Delete", "Smazat"), lambda _b, item=profile: self._delete_printer_profile(item), "danger-button"), False, False, 0)
            listbox.add(row)
        listbox.show_all()
        self._build_refs["printer_status"].set_text(
            self._t(f"{len(profiles)} Drucker gespeichert", f"{len(profiles)} printers saved", f"Uloženo tiskáren: {len(profiles)}")
        )

    def _activate_printer_profile(self, profile: dict[str, object]) -> None:
        try:
            self.core.save_active_printer_profile(profile, manual_selected=True)
            name = self.core.printer_profile_name(profile)
            self.set_status(f"{self._t('Aktiver Drucker', 'Active printer', 'Aktivní tiskárna')}: {name}", "good")
            self._build_refs["printer_status"].set_text(name)
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _delete_printer_profile(self, profile: dict[str, object]) -> None:
        profile_id = str(profile.get("id") or "")
        profiles = [item for item in self.core.load_printer_profiles() if str(item.get("id") or "") != profile_id]
        try:
            self.core.save_printer_profiles(profiles)
            self.set_status(self._t("Druckerprofil gelöscht.", "Printer profile deleted.", "Profil tiskárny smazán."), "good")
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _scan_printers(self, _button=None) -> None:
        self._printer_results = []
        found_list: Gtk.ListBox = self._build_refs["printer_found_list"]
        self._clear_listbox(found_list)
        self._build_refs["printer_status"].set_text(self._t("Druckersuche läuft …", "Printer discovery running …", "Probíhá hledání tiskáren …"))

        def status(_state: str, message: str) -> None:
            GLib.idle_add(self._build_refs["printer_status"].set_text, self._translate_status(message))

        def found(printer: dict[str, object]) -> None:
            GLib.idle_add(self._add_found_printer, printer)

        self.run_async("printer-scan", lambda: self.core.discover_network_printers(status, found), self._printer_scan_finished)

    def _add_found_printer(self, printer: dict[str, object]) -> bool:
        if any(str(item.get("host")) == str(printer.get("host")) for item in self._printer_results):
            return False
        self._printer_results.append(printer)
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.add(box)
        box.pack_start(self._icon("printer-network-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(printer.get("name")), "section-title"), False, False, 0)
        text.pack_start(self._label(f"{_clean(printer.get('host'))} · {_clean(printer.get('method'))} · {_clean(printer.get('ports'))}", "muted", wrap=True), False, False, 0)
        box.pack_start(text, True, True, 0)
        box.pack_end(self._button(self._t("Speichern + aktivieren", "Save + activate", "Uložit + aktivovat"), lambda _b, item=printer: self._save_discovered_printer(item), "primary-button"), False, False, 0)
        self._build_refs["printer_found_list"].add(row)
        self._build_refs["printer_found_list"].show_all()
        return False

    def _printer_scan_finished(self, result) -> None:
        found, message = result
        for printer in found:
            self._add_found_printer(printer)
        self._build_refs["printer_status"].set_text(self._translate_status(message))
        self.set_status(self._translate_status(message), "good" if found else "warn")

    def _save_discovered_printer(self, printer: dict[str, object]) -> None:
        try:
            profile = self.core.discovered_printer_profile(printer)
            self.core.upsert_printer_profile(profile)
            self.core.save_active_printer_profile(profile, manual_selected=True)
            self.set_status(f"{self._t('Drucker gespeichert', 'Printer saved', 'Tiskárna uložena')}: {self.core.printer_profile_name(profile)}", "good")
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _print_test_report(self, _button=None) -> None:
        if not self.snapshot:
            self.set_status(self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen."), "warn")
            return

        def worker():
            matches = self.core.format_model_match_results(self.match_results, self.language, limit=6)
            report = self.core.build_report(self.snapshot, matches, self.language)
            report_dir = self.core.get_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            target = report_dir / f"{self.core.report_basename(self.snapshot)}_v5-testprint.txt"
            self.core.write_text_durable(target, report)
            return target, self.core.run_report_print(target, lambda state, message: GLib.idle_add(self._build_refs["printer_status"].set_text, self._translate_status(message)))

        self.run_async("test-print", worker, self._print_finished)

    def _print_finished(self, result) -> None:
        target, (ok, message) = result
        self.set_status(f"{self._translate_status(message)} · {target.name}", "good" if ok else "bad")
        self._build_refs["printer_status"].set_text(self._translate_status(message))

    # ---------- reports ----------

    def _build_reports_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Report-Center", "Report centre", "Centrum reportů"),
            self._t("Modell- und Akku-Reports zentral öffnen, prüfen und drucken.", "Open, inspect and print model and battery reports in one place.", "Otevírejte, kontrolujte a tiskněte reporty modelů a baterie na jednom místě."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        toolbar.pack_end(self._button(self._t("Aktualisieren", "Refresh", "Obnovit"), lambda _b: self._refresh_reports(), "secondary-button", "view-refresh-symbolic"), False, False, 0)
        toolbar.pack_end(self._button(self._t("Ausgewählten Report drucken", "Print selected report", "Vytisknout vybraný report"), self._print_selected_report, "primary-button", "document-print-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 10)
        panes = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        panes.set_position(430)
        outer.pack_start(panes, True, True, 0)
        store = Gtk.ListStore(str, str, str, object)
        tree = Gtk.TreeView(model=store)
        tree.get_selection().connect("changed", self._report_selection_changed)
        for title, index, width in ((self._t("Typ", "Type", "Typ"), 0, 90), (self._t("Datei", "File", "Soubor"), 1, 230), (self._t("Datum", "Date", "Datum"), 2, 130)):
            renderer = Gtk.CellRendererText()
            renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
            column = Gtk.TreeViewColumn(title, renderer, text=index)
            column.set_min_width(width)
            column.set_resizable(True)
            tree.append_column(column)
        report_scroll = Gtk.ScrolledWindow()
        report_scroll.add(tree)
        panes.pack1(report_scroll, True, False)
        preview = Gtk.TextView()
        preview.set_editable(False)
        preview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        preview_scroll = Gtk.ScrolledWindow()
        preview_scroll.add(preview)
        panes.pack2(preview_scroll, True, False)
        self._build_refs["report_store"] = store
        self._build_refs["report_tree"] = tree
        self._build_refs["report_preview"] = preview
        return page

    def _refresh_reports(self) -> None:
        store: Gtk.ListStore = self._build_refs.get("report_store")
        task_name = "reports"
        if store is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        store.clear()
        self.set_status(self._t("Reports werden geladen …", "Loading reports …", "Načítání reportů …"), "info")

        def worker():
            paths: list[tuple[str, pathlib.Path]] = []
            try:
                report_dir = self.core.get_report_dir()
                paths.extend((self._t("Modell", "Model", "Model"), path) for path in report_dir.glob("*.txt"))
            except OSError:
                pass
            try:
                paths.extend((self._t("Akku", "Battery", "Baterie"), path) for path in self.core.list_battery_report_files())
            except OSError:
                pass
            unique: dict[str, tuple[str, pathlib.Path]] = {}
            for report_type, path in paths:
                unique[str(path)] = (report_type, path)
            return sorted(unique.values(), key=lambda pair: pair[1].stat().st_mtime if pair[1].exists() else 0, reverse=True)

        def done(paths) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_reports(paths)

        self.run_async(task_name, worker, done)

    def _render_reports(self, paths: list[tuple[str, pathlib.Path]]) -> None:
        store: Gtk.ListStore = self._build_refs.get("report_store")
        if store is None:
            return
        store.clear()
        for report_type, path in paths:
            try:
                stamp = datetime.datetime.fromtimestamp(path.stat().st_mtime).strftime("%d.%m.%Y %H:%M")
            except OSError:
                stamp = "–"
            store.append([report_type, path.name, stamp, path])
        self.set_status(self._t(f"{len(paths)} Reports geladen.", f"{len(paths)} reports loaded.", f"Načtené reporty: {len(paths)}."), "good")

    def _selected_report_path(self) -> pathlib.Path | None:
        tree: Gtk.TreeView = self._build_refs["report_tree"]
        model, iterator = tree.get_selection().get_selected()
        return model[iterator][3] if iterator is not None else None

    def _report_selection_changed(self, _selection) -> None:
        path = self._selected_report_path()
        if path is None:
            return
        try:
            preview_path = self.core.report_print_source_path(path)
            if preview_path != path:
                text = preview_path.read_text(encoding="utf-8", errors="replace")
            elif path.suffix.lower() == ".html":
                text = self.core.battery_report_preview_text(path, 120)
            else:
                text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            text = str(exc)
        self._build_refs["report_preview"].get_buffer().set_text(text)

    def _print_selected_report(self, _button=None) -> None:
        path = self._selected_report_path()
        if path is None:
            self.set_status(self._t("Bitte einen Report auswählen.", "Please select a report.", "Vyberte report."), "warn")
            return
        self.run_async("report-print", lambda: self.core.run_report_print(path), lambda result: self.set_status(self._translate_status(result[1]), "good" if result[0] else "bad"))

    # ---------- updates ----------

    def _open_update_settings(self, _button=None) -> None:
        self.show_page("settings")

    def _update_widgets(self) -> list[Gtk.Widget]:
        widgets: list[Gtk.Widget] = []
        for candidate in (
            self._build_refs.get("update_alert_button"),
            self.nav_buttons.get("settings"),
            self._build_refs.get("footer_box"),
        ):
            if isinstance(candidate, Gtk.Widget):
                widgets.append(candidate)
        return widgets

    def _clear_update_phase_classes(self) -> None:
        for widget in self._update_widgets():
            context = widget.get_style_context()
            for css_class in self.UPDATE_PHASE_CLASSES:
                context.remove_class(css_class)

    def _update_alert_tick(self) -> bool:
        if not (self._db_update_available or self._program_update_available):
            self._clear_update_phase_classes()
            self._update_alert_timer_id = None
            return False
        self._clear_update_phase_classes()
        css_class = self.UPDATE_PHASE_CLASSES[self._update_alert_phase % len(self.UPDATE_PHASE_CLASSES)]
        self._update_alert_phase += 1
        for widget in self._update_widgets():
            widget.get_style_context().add_class(css_class)
        return True

    def _refresh_update_alert(self) -> None:
        button: Gtk.Button | None = self._build_refs.get("update_alert_button")
        label: Gtk.Label | None = self._build_refs.get("update_alert_label")
        available = self._db_update_available or self._program_update_available
        if not available:
            if self._update_alert_timer_id is not None:
                try:
                    GLib.source_remove(self._update_alert_timer_id)
                except Exception:
                    pass
                self._update_alert_timer_id = None
            self._clear_update_phase_classes()
            if button is not None:
                button.hide()
            return

        parts: list[str] = []
        if self._db_update_available:
            parts.append("DB")
        if self._program_update_available:
            parts.append(self._t("PROGRAMM", "APP", "PROGRAM"))
        if label is not None:
            label.set_text(
                self._t("UPDATE VERFÜGBAR", "UPDATE AVAILABLE", "AKTUALIZACE K DISPOZICI")
                + ": "
                + " + ".join(parts)
            )
        if button is not None:
            child = button.get_child()
            if child is not None:
                child.show_all()
            button.show()
        if self._update_alert_timer_id is None:
            self._update_alert_phase = 0
            self._update_alert_tick()
            self._update_alert_timer_id = GLib.timeout_add(650, self._update_alert_tick)

    def _set_update_availability(self, db_available: bool | None = None, program_available: bool | None = None) -> None:
        if db_available is not None:
            self._db_update_available = bool(db_available)
        if program_available is not None:
            self._program_update_available = bool(program_available)
        self._refresh_update_alert()

    def _set_update_controls_busy(self, busy: bool) -> None:
        for key in ("db_update_button", "program_update_button", "updates_check_button"):
            button: Gtk.Button | None = self._build_refs.get(key)
            if button is not None:
                button.set_sensitive(not busy)

    def _set_update_progress(self, message: str) -> bool:
        if self._update_progress_determinate:
            return False
        translated = self._translate_status(message)
        label: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if label is not None:
            label.set_text(translated)
        return False

    def _set_update_percentage(self, kind: str, percent: int, message: str) -> bool:
        value = max(0, min(100, int(percent)))
        translated = self._translate_status(message)
        progress: Gtk.ProgressBar | None = self._build_refs.get(f"{kind}_update_progress")
        if progress is not None:
            progress.set_fraction(value / 100.0)
            progress.set_text(f"{value}%")
            progress.show()
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if overall is not None:
            overall.set_text(f"{translated} · {value}%")
        footer: Gtk.ProgressBar | None = self._build_refs.get("footer_progress")
        if footer is not None:
            footer.set_fraction(value / 100.0)
            footer.set_text(f"{value}%")
            footer.show()
        return False

    def _begin_update_percentage(self, kind: str, message: str) -> None:
        self._update_progress_determinate = True
        self._set_update_percentage(kind, 0, message)

    def _finish_update_percentage(self, kind: str, ok: bool, message: str) -> None:
        translated = self._translate_status(message)
        progress: Gtk.ProgressBar | None = self._build_refs.get(f"{kind}_update_progress")
        if progress is not None:
            if ok:
                progress.set_fraction(1.0)
                progress.set_text("100%")
            else:
                progress.set_text(self._t("Fehler", "Error", "Chyba"))
            progress.show()
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if overall is not None:
            overall.set_text(translated)
        self._update_progress_determinate = False

    def _schedule_auto_update_check(self, force: bool = False) -> bool:
        if self._auto_update_check_started and not force:
            return False
        if self._update_operation:
            return False
        self._auto_update_check_started = True
        self._check_updates(auto=True)
        return False

    def _manual_check_updates_clicked(self, _button=None) -> None:
        self._auto_update_check_started = True
        self._check_updates(auto=False)

    def _toggle_update_alert_demo(self, _button=None) -> None:
        self._update_alert_demo = not self._update_alert_demo
        if self._update_alert_demo:
            db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
            program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
            overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
            demo_text = self._t("TESTANZEIGE – DB- und Programmupdate verfügbar", "TEST DISPLAY – DB and application update available", "TESTOVACÍ ZOBRAZENÍ – aktualizace DB a programu je k dispozici")
            if db_label is not None:
                db_label.set_text(self._t("TEST: DB-Update verfügbar", "TEST: DB update available", "TEST: aktualizace DB je k dispozici"))
                self._set_chip_state(db_label, "warn")
            if program_label is not None:
                program_label.set_text(self._t("TEST: Programm-Update verfügbar", "TEST: application update available", "TEST: aktualizace programu je k dispozici"))
                self._set_chip_state(program_label, "warn")
            if overall is not None:
                overall.set_text(demo_text)
            self._set_update_availability(True, True)
            self.set_status(demo_text, "warn")
            return
        self._set_update_availability(False, False)
        self._set_update_progress(self._t("Testanzeige beendet. Jetzt erneut prüfen.", "Test display stopped. Check again now.", "Testovací zobrazení ukončeno. Nyní proveďte novou kontrolu."))

    def _check_updates(self, auto: bool) -> None:
        if self._update_operation:
            if not auto:
                self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "check"
        self._set_update_controls_busy(True)
        self._set_update_progress(self._t("DB und Programm werden geprüft …", "Checking DB and application …", "Kontrola DB a programu …"))
        if not auto:
            self.set_status(self._t("Updates werden geprüft …", "Checking for updates …", "Kontrola aktualizací …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def worker():
            db_ok, db_message, db_available = self.core.check_model_database_update_available(progress)
            app_ok, app_message, app_available = self.core.check_hardwarecheck_update_available(progress)
            return db_ok, db_message, db_available, app_ok, app_message, app_available

        self.run_async("updates-check", worker, self._update_check_finished)

    def _update_check_finished(self, result) -> None:
        db_ok, db_message, db_available, app_ok, app_message, app_available = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        self._set_update_availability(db_available, app_available)
        db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
        program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if db_label is not None:
            db_label.set_text(self._translate_status(db_message))
            self._set_chip_state(db_label, "warn" if db_available else "good" if db_ok else "bad")
        if program_label is not None:
            program_label.set_text(self._translate_status(app_message))
            self._set_chip_state(program_label, "warn" if app_available else "good" if app_ok else "bad")
        messages = [message for message, available in ((db_message, db_available), (app_message, app_available)) if available]
        if messages:
            text = " | ".join(self._translate_status(message) for message in messages)
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "warn")
        elif db_ok and app_ok:
            text = self._t("DB und Programm sind aktuell.", "DB and application are current.", "DB a program jsou aktuální.")
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "good")
        else:
            text = f"{self._translate_status(db_message)} | {self._translate_status(app_message)}"
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "bad")

    def _db_update_clicked(self, _button=None) -> None:
        if self._update_operation:
            self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "db"
        self._set_update_controls_busy(True)
        self._begin_update_percentage("db", self._t("DB-Update wird vorbereitet …", "Preparing DB update …", "Příprava aktualizace DB …"))
        self.set_status(self._t("DB-Update: verbinde …", "DB update: connecting …", "Aktualizace DB: připojování …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def percentage(percent: int, message: str) -> None:
            GLib.idle_add(self._set_update_percentage, "db", percent, message)

        def worker():
            ok, message = self.core.run_model_database_update(progress, percentage)
            if not ok:
                return ok, message, None
            models = self.core.load_model_db()
            manifest = self.core.load_local_model_manifest()
            matches = self.core.get_model_match_results(self.snapshot, models) if self.snapshot else []
            relations = self.core.build_model_relation_map(models)
            return ok, message, (models, manifest, matches, relations)

        self.run_async("db-update", worker, self._db_update_finished)

    def _db_update_finished(self, result) -> None:
        ok, message, refreshed = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
        if db_label is not None:
            db_label.set_text(self._translate_status(message))
            self._set_chip_state(db_label, "good" if ok else "bad")
        self._finish_update_percentage("db", ok, message)
        if ok and refreshed is not None:
            self.models, manifest, self.match_results, self._model_relation_map = refreshed
            version = self.core.format_database_version(str(manifest.get("version") or ""))
            count = manifest.get("models_count") or manifest.get("model_count") or len(self.models)
            db_chip: Gtk.Label | None = self._build_refs.get("db_chip")
            if db_chip is not None:
                db_chip.set_text(f"DB {version or '–'} · {count}")
                self._set_chip_state(db_chip, "good")
            self._render_dashboard_model_suggestions()
            self._refresh_model_table()
            self._set_update_availability(db_available=False)
        self.set_status(self._translate_status(message), "good" if ok else "bad")

    def _program_update_clicked(self, _button=None) -> None:
        if self._update_operation:
            self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "program"
        self._set_update_controls_busy(True)
        self._begin_update_percentage("program", self._t("Programm-Update wird vorbereitet …", "Preparing application update …", "Příprava aktualizace programu …"))
        self.set_status(self._t("Programm-Update: verbinde …", "App update: connecting …", "Aktualizace programu: připojování …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def percentage(percent: int, message: str) -> None:
            GLib.idle_add(self._set_update_percentage, "program", percent, message)

        self.run_async(
            "program-update",
            lambda: self.core.run_hardwarecheck_update_check(progress, percentage),
            self._program_update_finished,
        )

    def _program_update_finished(self, result) -> None:
        ok, message, install_request = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
        if program_label is not None:
            program_label.set_text(self._translate_status(message))
            self._set_chip_state(program_label, "warn" if install_request else "good" if ok else "bad")
        self._finish_update_percentage("program", ok, message)
        self._set_update_availability(program_available=bool(install_request))
        self.set_status(self._translate_status(message), "warn" if install_request else "good" if ok else "bad")
        if ok and install_request:
            self._show_program_update_prompt(install_request)

    def _show_program_update_prompt(self, install_request: dict[str, str]) -> None:
        target_version = str(install_request.get("target_version") or "?")
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=self._t("Programm-Update bereit", "Application update ready", "Aktualizace programu je připravena"),
        )
        dialog.format_secondary_text(
            self._t(
                f"Version {target_version} wurde heruntergeladen, per SHA256 geprüft und kann jetzt installiert werden.",
                f"Version {target_version} was downloaded, verified with SHA256 and can now be installed.",
                f"Verze {target_version} byla stažena, ověřena pomocí SHA256 a nyní ji lze nainstalovat.",
            )
        )
        dialog.add_button(self._t("Später", "Later", "Později"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self._t("Jetzt installieren", "Install now", "Nainstalovat nyní"), Gtk.ResponseType.OK)
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.OK:
            self._start_program_update_install(install_request)

    def _start_program_update_install(self, install_request: dict[str, str]) -> None:
        config_path = pathlib.Path(str(install_request.get("config_path") or ""))
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            self.set_status(f"{self._t('Programm-Update: Installer-Konfiguration fehlt', 'App update: installer configuration is missing', 'Aktualizace programu: chybí konfigurace instalátoru')}: {exc}", "bad")
            return
        if not isinstance(config, dict):
            self.set_status(self._t("Programm-Update: ungültige Installer-Konfiguration", "App update: invalid installer configuration", "Aktualizace programu: neplatná konfigurace instalátoru"), "bad")
            return

        dialog = Gtk.Dialog(
            title=self._t("Programm-Update", "Application update", "Aktualizace programu"),
            transient_for=self.window,
            flags=Gtk.DialogFlags.MODAL,
        )
        dialog.set_deletable(False)
        dialog.set_default_size(640, 240)
        content = dialog.get_content_area()
        content.set_spacing(14)
        content.set_margin_start(24)
        content.set_margin_end(24)
        content.set_margin_top(22)
        content.set_margin_bottom(18)
        title = self._label(self._t("HardwareCheck wird aktualisiert", "Updating HardwareCheck", "Aktualizace HardwareCheck"), "hero-title")
        detail = self._label(self._t("Vorbereitung …", "Preparing …", "Příprava …"), wrap=True)
        progress_bar = Gtk.ProgressBar()
        progress_bar.set_show_text(True)
        close_button = dialog.add_button(self._t("Schließen", "Close", "Zavřít"), Gtk.ResponseType.CLOSE)
        close_button.set_no_show_all(True)
        close_button.hide()
        content.pack_start(title, False, False, 0)
        content.pack_start(detail, False, False, 0)
        content.pack_start(progress_bar, False, False, 0)
        dialog.connect("response", lambda current, _response: current.destroy())
        dialog.show_all()
        close_button.hide()

        self._update_operation = "program-install"
        self._set_update_controls_busy(True)
        self._begin_update_percentage(
            "program",
            self._t("Programm-Update wird installiert …", "Installing application update …", "Instalace aktualizace programu …"),
        )

        def progress(percent: int, message: str) -> None:
            GLib.idle_add(self._program_install_progress, progress_bar, detail, percent, message)

        def worker():
            try:
                app_path = self.core.apply_hardwarecheck_update(config, progress)
                return True, str(app_path), ""
            except Exception as exc:
                return False, str(exc), traceback.format_exc()

        self.run_async(
            "program-install",
            worker,
            lambda result: self._program_install_finished(dialog, detail, progress_bar, close_button, result),
        )

    def _program_install_progress(self, progress_bar: Gtk.ProgressBar, detail: Gtk.Label, percent: int, message: str) -> bool:
        value = max(0, min(100, int(percent)))
        detail.set_text(self._translate_status(message))
        progress_bar.set_fraction(value / 100.0)
        progress_bar.set_text(f"{value}%")
        self._set_update_percentage("program", value, message)
        self.set_status(f"{self._t('Programm-Update', 'App update', 'Aktualizace programu')}: {self._translate_status(message)}", "info")
        return False

    def _program_install_finished(
        self,
        dialog: Gtk.Dialog,
        detail: Gtk.Label,
        progress_bar: Gtk.ProgressBar,
        close_button: Gtk.Button,
        result,
    ) -> None:
        ok, value, error_detail = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        if ok:
            detail.set_text(self._t("Update erfolgreich. HardwareCheck wird neu gestartet …", "Update successful. Restarting HardwareCheck …", "Aktualizace byla úspěšná. HardwareCheck se restartuje …"))
            progress_bar.set_fraction(1.0)
            progress_bar.set_text("100%")
            self._finish_update_percentage("program", True, self._t("Programm-Update erfolgreich", "Application update successful", "Aktualizace programu byla úspěšná"))
            self._set_update_availability(program_available=False)
            self.set_status(self._t("Programm-Update erfolgreich – Neustart …", "Application update successful – restarting …", "Aktualizace programu byla úspěšná – restart …"), "good")
            GLib.timeout_add(900, self._restart_after_program_update, value)
            return

        detail.set_text(f"{self._t('Programm-Update fehlgeschlagen', 'Application update failed', 'Aktualizace programu se nezdařila')}: {value}")
        progress_bar.set_fraction(1.0)
        progress_bar.set_text("!")
        self._finish_update_percentage("program", False, str(value))
        close_button.show()
        self.set_status(f"{self._t('Programm-Update fehlgeschlagen', 'Application update failed', 'Aktualizace programu se nezdařila')}: {value}", "bad")
        try:
            debug_root = self.core.find_external_root() or self.core.SCRIPT_DIR
            debug_dir = pathlib.Path(debug_root) / "hardwarecheck-debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            self.core.write_text_durable(debug_dir / "v5-program-install-error.txt", error_detail)
        except Exception:
            pass

    def _restart_after_program_update(self, app_path: str) -> bool:
        self._save_battery_state()
        env = os.environ.copy()
        env.pop("HC_USE_LEGACY_UI", None)
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(app_path).resolve())], env)
        return False

    # ---------- settings ----------

    def _build_settings_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Einstellungen", "Settings", "Nastavení"),
            self._t("Updates, WLAN, Drucker, Sprache, Diagnose und Informationen zu HardwareCheck.", "Updates, Wi-Fi, printers, language, diagnostics and HardwareCheck information.", "Aktualizace, Wi-Fi, tiskárny, jazyk, diagnostika a informace o HardwareCheck."),
        )

        updates = self._section(outer, self._t("Updates", "Updates", "Aktualizace"), 12)
        update_card = Gtk.Frame()
        update_card.set_shadow_type(Gtk.ShadowType.NONE)
        update_card.get_style_context().add_class("card")
        update_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        update_card.add(update_box)
        updates.pack_start(update_card, False, False, 0)
        self._build_refs["updates_overall_status"] = self._label(
            self._t(
                "Automatische Prüfung nach der WLAN-Verbindung.",
                "Automatic check after the Wi-Fi connection.",
                "Automatická kontrola po připojení k Wi-Fi.",
            ),
            "muted",
            wrap=True,
        )
        update_box.pack_start(self._build_refs["updates_overall_status"], False, False, 0)

        db_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        db_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        db_text.pack_start(self._label(self._t("Modelldatenbank", "Model database", "Databáze modelů"), "section-title"), False, False, 0)
        self._build_refs["db_update_status"] = self._label(self._t("Noch nicht geprüft", "Not checked yet", "Dosud nekontrolováno"), "status-chip", wrap=True)
        db_text.pack_start(self._build_refs["db_update_status"], False, False, 0)
        db_progress = Gtk.ProgressBar()
        db_progress.set_show_text(True)
        db_progress.set_no_show_all(True)
        db_progress.hide()
        db_text.pack_start(db_progress, False, False, 4)
        self._build_refs["db_update_progress"] = db_progress
        db_row.pack_start(db_text, True, True, 0)
        db_button = self._button(self._t("DB-Update", "DB update", "Aktualizace DB"), self._db_update_clicked, "primary-button", "view-refresh-symbolic")
        db_row.pack_end(db_button, False, False, 0)
        self._build_refs["db_update_button"] = db_button
        update_box.pack_start(db_row, False, False, 0)

        program_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        program_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        program_text.pack_start(self._label(self._t("HardwareCheck-Programm", "HardwareCheck application", "Program HardwareCheck"), "section-title"), False, False, 0)
        self._build_refs["program_update_status"] = self._label(self._t("Noch nicht geprüft", "Not checked yet", "Dosud nekontrolováno"), "status-chip", wrap=True)
        program_text.pack_start(self._build_refs["program_update_status"], False, False, 0)
        program_progress = Gtk.ProgressBar()
        program_progress.set_show_text(True)
        program_progress.set_no_show_all(True)
        program_progress.hide()
        program_text.pack_start(program_progress, False, False, 4)
        self._build_refs["program_update_progress"] = program_progress
        program_row.pack_start(program_text, True, True, 0)
        program_button = self._button(self._t("Programm-Update", "App update", "Aktualizace programu"), self._program_update_clicked, "primary-button", "software-update-available-symbolic")
        program_row.pack_end(program_button, False, False, 0)
        self._build_refs["program_update_button"] = program_button
        update_box.pack_start(program_row, False, False, 0)

        check_button = self._button(
            self._t("DB und Programm jetzt prüfen", "Check DB and application now", "Zkontrolovat DB a program nyní"),
            self._manual_check_updates_clicked,
            "secondary-button",
            "system-search-symbolic",
        )
        update_box.pack_start(check_button, False, False, 0)
        self._build_refs["updates_check_button"] = check_button
        if any(marker in str(self.core.APP_VERSION).lower() for marker in ("dev", "test")):
            demo_button = self._button(
                self._t("Nur Teststand: Update-Alarm testen", "Test build only: test update alert", "Pouze testovací verze: vyzkoušet upozornění"),
                self._toggle_update_alert_demo,
                "secondary-button",
                "dialog-warning-symbolic",
            )
            update_box.pack_start(demo_button, False, False, 0)

        language_box = self._section(outer, self._t("Sprache", "Language", "Jazyk"), 12)
        languages = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        language_box.pack_start(languages, False, False, 0)
        for language, code in (("CZ", "CZ"), ("DE", "DE"), ("EN", "EN")):
            button = Gtk.Button()
            button.get_style_context().add_class("primary-button" if self.language == language else "secondary-button")
            inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            inner.pack_start(Gtk.Image.new_from_pixbuf(flag_pixbuf(language)), False, False, 0)
            inner.pack_start(self._label(code, "section-title"), False, False, 0)
            button.add(inner)
            button.connect("clicked", lambda _b, target=language: self._select_language(target))
            languages.pack_start(button, False, False, 0)
            self._build_refs[f"language_button_{language}"] = button

        connections = self._section(outer, self._t("Verbindungen & Geräte", "Connections & devices", "Připojení a zařízení"))
        connections.pack_start(
            self._label(
                self._t(
                    "Gespeicherte WLANs und Drucker werden hier verwaltet. Die schnelle WLAN-Auswahl bleibt jederzeit oben erreichbar.",
                    "Manage saved Wi-Fi networks and printers here. Quick Wi-Fi selection remains available at the top.",
                    "Zde můžete spravovat uložené sítě Wi-Fi a tiskárny. Rychlý výběr Wi-Fi zůstává dostupný nahoře.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        connection_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        connection_actions.pack_start(
            self._button(
                self._t("WLANs verwalten", "Manage Wi-Fi", "Spravovat Wi-Fi"),
                lambda _b: self.show_page("wifi"),
                "secondary-button",
                "network-wireless-symbolic",
            ),
            False,
            False,
            0,
        )
        connection_actions.pack_start(
            self._button(
                self._t("Drucker suchen und verwalten", "Find and manage printers", "Vyhledat a spravovat tiskárny"),
                lambda _b: self.show_page("printers"),
                "secondary-button",
                "printer-symbolic",
            ),
            False,
            False,
            0,
        )
        connections.pack_start(connection_actions, False, False, 0)

        service = self._section(outer, self._t("Service", "Service", "Servis"))
        service_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        service.pack_start(service_row, False, False, 0)
        service_row.pack_start(self._button(self._t("Hardware neu scannen", "Rescan hardware", "Znovu skenovat hardware"), self._rescan_clicked, "primary-button", "view-refresh-symbolic"), False, False, 0)
        service_row.pack_start(self._button(self._t("Legacy-Oberfläche starten", "Start legacy interface", "Spustit původní rozhraní"), self._restart_legacy, "secondary-button", "go-previous-symbolic"), False, False, 0)

        about = Gtk.Frame()
        about.set_shadow_type(Gtk.ShadowType.NONE)
        about.get_style_context().add_class("card")
        about_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        about.add(about_box)
        about_box.pack_start(self._label(f"HardwareCheck {self.core.APP_VERSION}", "hero-title"), False, False, 0)
        about_box.pack_start(self._label(f"{self.core.APP_VERSION} · GTK {Gtk.get_major_version()}.{Gtk.get_minor_version()} · Python {sys.version.split()[0]}", "muted"), False, False, 0)
        about_box.pack_start(self._label(self._t("Der bewährte v3-Hardwarekern bleibt unverändert als Rückfall verfügbar. v5 lädt aufwendige Suchen erst bei Bedarf.", "The proven v3 hardware core remains available as a fallback. v5 loads expensive searches only when requested.", "Osvědčené jádro hardwaru v3 zůstává k dispozici jako záloha. v5 spouští náročná vyhledávání pouze na vyžádání."), wrap=True), False, False, 0)
        about_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        about_actions.pack_start(
            self._button(
                self._t("Versionsverlauf anzeigen", "Show version history", "Zobrazit historii verzí"),
                self._show_version_history,
                "secondary-button",
                "help-about-symbolic",
            ),
            False,
            False,
            0,
        )
        about_box.pack_start(about_actions, False, False, 8)
        outer.pack_start(about, False, False, 20)
        return page

    def _show_version_history(self, _button=None) -> None:
        dialog = Gtk.Dialog(
            title=self._t("HardwareCheck – Versionsverlauf", "HardwareCheck – Version history", "HardwareCheck – Historie verzí"),
            transient_for=self.window,
            modal=True,
        )
        dialog.set_default_size(900, 680)
        dialog.add_button(self._t("Schließen", "Close", "Zavřít"), Gtk.ResponseType.CLOSE)

        content = dialog.get_content_area()
        content.set_spacing(10)
        content.set_margin_start(18)
        content.set_margin_end(18)
        content.set_margin_top(14)
        content.set_margin_bottom(10)
        content.pack_start(
            self._label(
                self._t(
                    "Die wichtigsten Entwicklungsschritte von der ersten Grundversion bis zum aktuellen Werkstattstand.",
                    "The most important development milestones from the first basic version to the current workshop release.",
                    "Nejdůležitější vývojové kroky od první základní verze po aktuální dílenské vydání.",
                ),
                "page-subtitle",
                wrap=True,
            ),
            False,
            False,
            0,
        )

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_min_content_height(520)
        history_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        history_box.set_margin_end(8)
        scroll.add(history_box)
        content.pack_start(scroll, True, True, 0)

        for index, entry in enumerate(self.VERSION_HISTORY):
            frame = Gtk.Frame()
            frame.set_shadow_type(Gtk.ShadowType.NONE)
            frame.get_style_context().add_class("card")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            frame.add(box)

            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            version_label = self._label(str(entry["version"]), "section-title")
            header.pack_start(version_label, False, False, 0)
            if index == 0:
                current = self._label(self._t("AKTUELL", "CURRENT", "AKTUÁLNÍ"), "status-chip")
                current.get_style_context().add_class("good")
                header.pack_start(current, False, False, 0)
            header.pack_end(self._label(str(entry["date"]), "muted"), False, False, 0)
            box.pack_start(header, False, False, 0)
            box.pack_start(self._label(self._t(*entry["title"]), "card-value", wrap=True), False, False, 0)
            for item in entry["items"]:
                bullet = self._label(f"• {self._t(*item)}", "card-subtitle", wrap=True)
                bullet.set_margin_start(8)
                box.pack_start(bullet, False, False, 0)
            history_box.pack_start(frame, False, False, 0)

        content.pack_start(
            self._label(
                self._t(
                    "Der Verlauf fasst die sichtbaren Meilensteine zusammen; kleine technische Korrekturen sind bewusst gebündelt.",
                    "This history summarizes visible milestones; minor technical fixes are intentionally grouped.",
                    "Historie shrnuje viditelné milníky; menší technické opravy jsou záměrně sloučeny.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        dialog.show_all()
        dialog.run()
        dialog.destroy()

    def _select_language(self, language: str) -> None:
        if language not in self.core.LANGUAGES:
            return
        self.language = language
        self.core.save_language(language)
        self.set_status(self._t("Sprache gespeichert; Oberfläche wird neu geladen …", "Language saved; reloading the interface …", "Jazyk uložen; rozhraní se znovu načítá …"), "good")
        for key in self.core.LANGUAGES:
            button = self._build_refs.get(f"language_button_{key}")
            if button:
                context = button.get_style_context()
                if key == language:
                    context.add_class("primary-button")
                    context.remove_class("secondary-button")
                else:
                    context.add_class("secondary-button")
                    context.remove_class("primary-button")
        GLib.timeout_add(350, self._restart_v5)

    def _restart_v5(self) -> bool:
        self._save_battery_state()
        env = os.environ.copy()
        env.pop("HC_USE_LEGACY_UI", None)
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(self.core.__file__).resolve())], env)
        return False

    def _restart_legacy(self, _button=None) -> None:
        self._save_battery_state()
        env = os.environ.copy()
        env["HC_USE_LEGACY_UI"] = "1"
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(self.core.__file__).resolve())], env)

    def _power_menu_action(self, action: str, popover: Gtk.Popover | None = None) -> None:
        if popover is not None:
            popover.popdown()
        self._execute_power_action(action)

    def _execute_power_action(self, action: str) -> None:
        restart = action == "reboot"
        self.set_status(
            self._t("Computer wird neu gestartet …", "Restarting computer …", "Počítač se restartuje …")
            if restart
            else self._t("Computer wird heruntergefahren …", "Shutting down computer …", "Počítač se vypíná …"),
            "warn",
        )
        try:
            self.core.subprocess.Popen(["reboot" if restart else "poweroff"])
        except OSError as exc:
            self.set_status(str(exc), "bad")

    def _confirm_power_action(self, action: str) -> None:
        self._execute_power_action(action)

    def _confirm_poweroff(self, _button=None) -> None:
        self._execute_power_action("poweroff")

    # ---------- async lifecycle ----------

    def _start_initial_load(self) -> bool:
        self.set_status(self._t("Hardware wird im Hintergrund erkannt …", "Detecting hardware in the background …", "Rozpoznávání hardwaru na pozadí …"), "info")

        def worker():
            snapshot = self.core.get_system_snapshot()
            models = self.core.load_model_db()
            matches = self.core.get_model_match_results(snapshot, models)
            relations = self.core.build_model_relation_map(models)
            battery = self.core.read_battery_details()
            manifest = self.core.load_local_model_manifest()
            network = self.core.active_local_network_message()
            return snapshot, models, matches, relations, battery, manifest, network

        self.run_async("initial-load", worker, self._initial_load_finished)
        return False

    def _initial_load_finished(self, result) -> None:
        self.snapshot, self.models, self.match_results, self._model_relation_map, battery, manifest, network = result
        vendor = _clean(self.snapshot.get("vendor_short") or self.snapshot.get("vendor"))
        model = _clean(self.snapshot.get("model_name"))
        self._build_refs["hero_title"].set_text(f"{vendor} {model}")
        product = _clean(self.snapshot.get("product_no"), self._t("Keine Produktnummer erkannt", "No product number detected", "Nebylo zjištěno produktové číslo"))
        self._build_refs["hero_subtitle"].set_text(f"{product} · {self._t('Scan abgeschlossen', 'Scan complete', 'Sken dokončen')}")
        self._build_refs["metric_system"].set_text(f"{vendor} {model}")
        self._build_refs["metric_system_sub"].set_text(product)
        self._build_refs["metric_cpu"].set_text(_clean(self.snapshot.get("cpu_short") or self.snapshot.get("cpu")))
        self._build_refs["metric_cpu_sub"].set_text(_short(self.snapshot.get("cpu"), 64))
        ram_total = _clean(self.snapshot.get("ram_total_gb"))
        self._build_refs["metric_ram"].set_text(f"{ram_total} GB {self.snapshot.get('ram_type') or ''}".strip())
        self._build_refs["metric_ram_sub"].set_text(_clean(self.snapshot.get("ram_layout")))
        storage_lines = self.snapshot.get("storage_lines") or []
        self._build_refs["metric_storage"].set_text(_short(storage_lines[0] if storage_lines else "–", 72))
        self._build_refs["metric_storage_sub"].set_text(_short(" · ".join(str(line) for line in storage_lines[1:3]), 72))
        display = f"{_clean(self.snapshot.get('display_inches'))}\" {self.snapshot.get('display_type') or ''}".strip()
        self._build_refs["metric_display"].set_text(display)
        self._build_refs["metric_display_sub"].set_text(_clean(self.snapshot.get("resolution")))
        if self.match_results:
            best = self.match_results[0]
            item = best.get("item") if isinstance(best.get("item"), dict) else {}
            self._build_refs["metric_match"].set_text(f"{_clean(item.get('model_id'))} · {int(best.get('score') or 0)}%")
            self._build_refs["metric_match_sub"].set_text(_short(self.core.model_notebook_summary(item), 72))
        else:
            self._build_refs["metric_match"].set_text(self._t("Kein Treffer", "No match", "Žádná shoda"))
            self._build_refs["metric_match_sub"].set_text("")
        self._render_dashboard_model_suggestions()
        version = self.core.format_database_version(str(manifest.get("version") or ""))
        count = manifest.get("models_count") or manifest.get("model_count") or len(self.models)
        self._build_refs["db_chip"].set_text(f"DB {version or '–'} · {count}")
        if network:
            self._set_network_chip(self._translate_status(network), "good")
        else:
            self._set_network_chip(self._t("Offline", "Offline", "Offline"), "warn")
        self._update_battery_ui(battery)
        self._refresh_model_table()
        if self.current_page == "print":
            self._refresh_print_page()
        self.set_status(self._t("HardwareCheck v5 ist bereit.", "HardwareCheck v5 is ready.", "HardwareCheck v5 je připraven."), "good")
        GLib.idle_add(self._start_wifi_autoconnect)

    def _rescan_clicked(self, _button=None) -> None:
        if self._busy_count:
            self.set_status(self._t("Bitte laufenden Vorgang abwarten.", "Please wait for the current task.", "Počkejte na dokončení aktuální úlohy."), "warn")
            return
        self._start_initial_load()

    def run_async(self, name: str, worker: Callable, done: Callable | None = None) -> None:
        self._busy_count += 1
        self._busy_changed()

        def target() -> None:
            try:
                result = worker()
            except Exception as exc:
                detail = traceback.format_exc()
                GLib.idle_add(self._async_failed, name, exc, detail)
                return
            GLib.idle_add(self._async_finished, done, result)

        threading.Thread(target=target, name=f"hc-v5-{name}", daemon=True).start()

    def _async_finished(self, done: Callable | None, result) -> bool:
        self._busy_count = max(0, self._busy_count - 1)
        self._busy_changed()
        if done is not None:
            done(result)
        return False

    def _async_failed(self, name: str, exc: Exception, detail: str) -> bool:
        self._busy_count = max(0, self._busy_count - 1)
        self._refresh_tasks.discard(name)
        if name in {"updates-check", "db-update", "program-update", "program-install"}:
            self._update_operation = ""
            self._set_update_controls_busy(False)
            if name == "db-update":
                self._finish_update_percentage("db", False, str(exc))
            elif name in {"program-update", "program-install"}:
                self._finish_update_percentage("program", False, str(exc))
        if name in {"wifi-autoconnect", "wifi-connect"}:
            self._wifi_connection_busy = False
            self._set_network_chip(self._t("WLAN-Fehler", "Wi-Fi error", "Chyba Wi-Fi"), "bad")
        self._busy_changed()
        try:
            debug_root = self.core.find_external_root() or self.core.SCRIPT_DIR
            debug_dir = pathlib.Path(debug_root) / "hardwarecheck-debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            self.core.write_text_durable(debug_dir / f"v5-{name}-error.txt", detail)
        except Exception:
            pass
        self.set_status(f"{name}: {exc}", "bad")
        return False

    def _busy_changed(self) -> None:
        spinner: Gtk.Spinner | None = self._build_refs.get("top_spinner")
        progress: Gtk.ProgressBar | None = self._build_refs.get("footer_progress")
        if self._busy_count:
            if spinner is not None:
                spinner.start()
            if progress is not None:
                progress.show()
                if not self._update_progress_determinate:
                    progress.pulse()
        else:
            if spinner is not None:
                spinner.stop()
            if progress is not None:
                progress.hide()

    def _clock_tick(self) -> bool:
        clock: Gtk.Label = self._build_refs.get("clock")
        if clock:
            clock.set_text(datetime.datetime.now().strftime("%H:%M · %d.%m.%Y"))
        if self._busy_count:
            progress: Gtk.ProgressBar = self._build_refs.get("footer_progress")
            if progress and not self._update_progress_determinate:
                progress.pulse()
        return True

    def _translate_status(self, message: object) -> str:
        try:
            return self.core.translate_status_text(str(message or ""), self.language)
        except Exception:
            return str(message or "")

    def _set_chip_state(self, chip: Gtk.Label, state: str) -> None:
        context = chip.get_style_context()
        for name in ("good", "warn", "bad"):
            context.remove_class(name)
        if state in {"good", "warn", "bad"}:
            context.add_class(state)

    def set_status(self, message: str, state: str = "info") -> None:
        label: Gtk.Label = self._build_refs.get("footer_status")
        if label:
            label.set_text(self._translate_status(message))
            context = label.get_style_context()
            for name in ("good-text", "warn-text", "bad-text"):
                context.remove_class(name)
            if state == "good":
                context.add_class("good-text")
            elif state == "warn":
                context.add_class("warn-text")
            elif state == "bad":
                context.add_class("bad-text")


def run(core) -> int:
    """Start the v5 GTK application using an already-loaded core module."""
    app = HardwareCheckV5(core)
    return int(app.run([str(pathlib.Path(core.__file__).resolve())]))
