#!/usr/bin/env python3
"""Native GTK 3 interface for the HardwareCheck v5 line.

The proven HardwareCheck module remains the functional core.  This file only
owns the new navigation, presentation and asynchronous UI orchestration so the
legacy Tk interface remains available as a safe fallback.
"""

from __future__ import annotations

import datetime
import json
import math
import os
import pathlib
import random
import re
import subprocess
import sys
import threading
import traceback
from typing import Callable

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, GLib, Gtk, Pango  # noqa: E402

import magic_image_manager as magic  # noqa: E402
import config_server_sync  # noqa: E402


APP_ID = "de.hardwarecheck.v5"
ACCENT = "#f7b733"
GOOD = "#2ec98f"
WARN = "#f0a83b"
BAD = "#ed5d68"
INFO = "#4aa7ff"

APPEARANCE_LAYOUTS = (
    "original",
    "service-light",
    "workshop-pro",
    "blue-control",
    "service-desk",
    "workshop-console",
    "studio-panels",
)
APPEARANCE_DEFAULT_ACCENTS = {
    "original": "#f7b733",
    "service-light": "#0b9189",
    "workshop-pro": "#ffb000",
    "blue-control": "#4d8dff",
    "service-desk": "#0b9189",
    "workshop-console": "#ffb000",
    "studio-panels": "#ffe07b",
}
APPEARANCE_ACCENTS = (
    ("gold", "#f7b733"),
    ("teal", "#0b9189"),
    ("blue", "#4d8dff"),
    ("violet", "#8b5cf6"),
    ("green", "#2ec98f"),
    ("red", "#e65d68"),
)


CSS = b"""
* {
  font-family: Inter, "Segoe UI", sans-serif;
}
window, .app-root {
  background: #0b1018;
  color: #ecf2f8;
}
.topbar {
  background: #111824;
  border-bottom: 1px solid #283347;
  padding: 10px 18px;
}
.brand {
  color: #ffffff;
  font-size: 22px;
  font-weight: 800;
}
.version {
  color: #8fa2b8;
  font-size: 11px;
  font-weight: 700;
}
.status-chip {
  background: #192334;
  border: 1px solid #30405a;
  border-radius: 18px;
  color: #cfe0ef;
  padding: 7px 12px;
  font-weight: 700;
}
.status-chip.good { color: #74e1b5; border-color: #286b54; }
.status-chip.warn { color: #ffd07b; border-color: #735824; }
.status-chip.bad { color: #ff969e; border-color: #71313a; }
.update-alert {
  border: 2px solid #ffffff;
  border-radius: 10px;
  padding: 8px 14px;
  font-weight: 900;
}
.update-phase-red { background: #b51f32; color: #ffffff; border-color: #ff8a98; }
.update-phase-gold { background: #e6a82e; color: #10151d; border-color: #fff2ad; }
.update-phase-blue { background: #176fc1; color: #ffffff; border-color: #92ccff; }
.update-phase-purple { background: #8138a6; color: #ffffff; border-color: #e4a8ff; }
popover, popover.background, .dark-popover, .dark-popover > contents {
  background: #111824;
  color: #ecf2f8;
  border-color: #34435b;
}
.dark-popover { border: 1px solid #34435b; border-radius: 12px; }
.sidebar {
  background: #0e1520;
  border-right: 1px solid #253146;
  padding: 14px 10px;
}
.nav-button {
  background: transparent;
  color: #aebdcd;
  border: 0;
  border-radius: 10px;
  padding: 12px 14px;
  margin: 2px 0;
  font-size: 14px;
  font-weight: 700;
}
.nav-button:hover { background: #182235; color: #ffffff; }
.nav-button.active {
  background: #253044;
  color: #ffd06a;
  border-left: 4px solid #f7b733;
}
.content { background: #0b1018; padding: 20px; }
.page-title { color: #ffffff; font-size: 26px; font-weight: 800; }
.page-subtitle { color: #8fa2b8; font-size: 13px; }
.hero {
  background: linear-gradient(135deg, #18253a, #172033);
  border: 1px solid #33435e;
  border-radius: 16px;
  padding: 22px;
}
.hero-title { color: #ffffff; font-size: 25px; font-weight: 800; }
.hero-subtitle { color: #aebed0; font-size: 14px; }
.section-title { color: #f5f8fb; font-size: 17px; font-weight: 800; }
.card {
  background: #141c29;
  border: 1px solid #2b374c;
  border-radius: 14px;
  padding: 16px;
}
.card:hover { border-color: #435674; }
.card-icon { color: #f7b733; }
.card-title { color: #92a5ba; font-size: 12px; font-weight: 700; }
.card-value { color: #ffffff; font-size: 19px; font-weight: 800; }
.card-subtitle { color: #7f91a7; font-size: 11px; }
.battery-live-panel {
  background: #102920;
  border: 1px solid #2f755a;
  border-radius: 12px;
  padding: 11px 14px;
}
.battery-live-panel.warn { background: #302510; border-color: #8b6725; }
.battery-live-panel.bad { background: #351920; border-color: #8b3946; }
.battery-live-title { color: #70e2b5; font-size: 14px; font-weight: 800; }
.battery-live-panel.warn .battery-live-title { color: #ffd071; }
.battery-live-panel.bad .battery-live-title { color: #ff969e; }
.battery-live-subtitle { color: #9eb3c2; font-size: 11px; }
.dashboard-battery-value { color: #ffffff; font-size: 15px; font-weight: 900; }
.dashboard-battery-level trough { min-height: 7px; border-radius: 4px; }
.dashboard-battery-level block.filled { min-height: 7px; border-radius: 4px; }
.battery-metric-card {
  background: #101827;
  border: 1px solid #30405a;
  border-radius: 12px;
  padding: 12px 14px;
}
.battery-metric-card .card-value { font-size: 26px; }
.battery-metric-card.compact .card-value { font-size: 20px; }
.battery-history-card {
  background: #0d1522;
  border: 1px solid #30405a;
  border-radius: 12px;
  padding: 12px 14px;
}
.battery-chart { background: #0e151f; }
.battery-mini-panel {
  background: #11222b;
  border: 1px solid #2b6170;
  border-radius: 11px;
  padding: 10px;
  margin: 8px 0;
}
.battery-mini-panel.warn { background: #302510; border-color: #8b6725; }
.battery-mini-panel.bad { background: #351920; border-color: #8b3946; }
.battery-mini-title { color: #65dfae; font-size: 11px; font-weight: 800; }
.battery-mini-panel.warn .battery-mini-title { color: #ffd071; }
.battery-mini-panel.bad .battery-mini-title { color: #ff969e; }
.battery-mini-value { color: #ffffff; font-size: 16px; font-weight: 800; }
.battery-mini-subtitle { color: #8fa2b8; font-size: 10px; }
.battery-mini-panel levelbar trough { min-height: 9px; }
.quick-button {
  background: #162234;
  border: 1px solid #344763;
  border-radius: 13px;
  color: #ffffff;
  padding: 16px;
  font-size: 14px;
  font-weight: 800;
}
.quick-button:hover { background: #21314a; border-color: #f7b733; }
.primary-button {
  background: #e6a82e;
  color: #11151d;
  border: 0;
  border-radius: 9px;
  padding: 9px 16px;
  font-weight: 800;
}
.primary-button:hover { background: #ffc957; }
.secondary-button {
  background: #1b2739;
  color: #e8eef5;
  border: 1px solid #354762;
  border-radius: 9px;
  padding: 9px 14px;
  font-weight: 700;
}
.secondary-button:hover { background: #25354d; }
.danger-button {
  background: #42212a;
  color: #ffabb2;
  border: 1px solid #78343f;
  border-radius: 9px;
  padding: 9px 14px;
  font-weight: 800;
}
entry, searchentry, spinbutton {
  background: #101825;
  color: #f7f9fc;
  border: 1px solid #3b4b64;
  border-radius: 9px;
  padding: 9px 12px;
}
treeview, list, textview, textview text {
  background: #101722;
  color: #eaf0f6;
}
treeview header button {
  background: #d9d6cf;
  color: #121820;
  border: 1px solid #b9b5ad;
  font-weight: 800;
  padding: 8px;
}
treeview:selected, row:selected { background: #a96b00; color: #ffffff; }
.list-row { background: #121b28; border-bottom: 1px solid #29364a; padding: 10px; }
.list-row:hover { background: #192538; }
.muted { color: #8da0b5; }
.good-text { color: #55dca8; font-weight: 800; }
.warn-text { color: #ffc86b; font-weight: 800; }
.bad-text { color: #ff858f; font-weight: 800; }
.match-cell { background: #176b61; color: #ffffff; padding: 8px; }
.mismatch-cell { background: #85242b; color: #ffffff; padding: 8px; }
.reference-cell { background: #18506b; color: #ffffff; padding: 8px; }
.neutral-cell { background: #151e2b; color: #dce6f0; padding: 8px; }
.unavailable-cell { background: #171d27; color: #748397; padding: 8px; }
.comparison-header { background: #d9d6cf; color: #111820; padding: 8px; font-weight: 800; }
.footer {
  background: #101722;
  border-top: 1px solid #263247;
  color: #91a3b8;
  padding: 7px 14px;
}
.footer.update-phase-red, .nav-button.update-phase-red { background: #b51f32; color: #ffffff; border-color: #ff8a98; }
.footer.update-phase-gold, .nav-button.update-phase-gold { background: #e6a82e; color: #10151d; border-color: #fff2ad; }
.footer.update-phase-blue, .nav-button.update-phase-blue { background: #176fc1; color: #ffffff; border-color: #92ccff; }
.footer.update-phase-purple, .nav-button.update-phase-purple { background: #8138a6; color: #ffffff; border-color: #e4a8ff; }
.footer.update-phase-red label, .footer.update-phase-blue label, .footer.update-phase-purple label,
.nav-button.update-phase-red label, .nav-button.update-phase-blue label, .nav-button.update-phase-purple label { color: #ffffff; }
.footer.update-phase-gold label, .nav-button.update-phase-gold label { color: #10151d; }
progressbar trough, levelbar trough {
  background: #253044;
  border: 0;
  border-radius: 6px;
  min-height: 12px;
}
progressbar progress, levelbar block.filled {
  background: #2ec98f;
  border: 0;
  border-radius: 6px;
}
.magic-selector button {
  background: #101825;
  color: #f7f9fc;
  border: 1px solid #3b4b64;
}
.magic-selector menu, .magic-selector menuitem {
  background: #172131;
  color: #f7f9fc;
}
.magic-selector menuitem label { color: #f7f9fc; }
.magic-selector menuitem:hover { background: #365a87; }
.magic-confirm-dialog, .magic-confirm-dialog .dialog-vbox,
.magic-confirm-dialog .content-area {
  background: #141c29;
  color: #f5f8fb;
}
.magic-confirm-dialog label { color: #f5f8fb; }
.magic-confirm-dialog button { color: #f5f8fb; }
.magic-confirm-dialog .primary-button { color: #11151d; }
.magic-confirm-dialog .magic-selector button {
  background: #101825;
  color: #f7f9fc;
}
.magic-config-entry {
  min-height: 54px;
  min-width: 180px;
  font-size: 26px;
  font-weight: 900;
  padding: 7px 16px;
}
.magic-config-warning, .magic-config-warning .dialog-vbox,
.magic-config-warning .content-area {
  background: #301a21;
  color: #fff4f5;
}
.magic-config-warning label { color: #fff4f5; }
.magic-config-warning .warning-title { color: #ff9ca6; font-size: 23px; font-weight: 900; }
.magic-config-warning .config-warning-config { font-size: 19px; font-weight: 900; }
.magic-config-warning .config-warning-list-title { font-size: 18px; font-weight: 900; }
.magic-config-warning .config-warning-details { font-size: 17px; font-weight: 700; }
.magic-config-warning .magic-config-difference-card {
  background: #141923;
  border: 1px solid #64738a;
  border-radius: 8px;
  padding: 9px 12px;
}
.magic-config-warning .magic-config-difference-title { color: #ffffff; font-size: 16px; font-weight: 900; }
.magic-config-warning .magic-config-difference-device { color: #f7f9fc; font-size: 15px; font-weight: 700; }
.magic-config-warning .magic-config-difference-config { color: #ffd84a; font-size: 15px; font-weight: 900; }
.magic-config-warning button { min-height: 44px; font-size: 16px; font-weight: 900; }
.magic-config-status.good { color: #74e1b5; font-weight: 800; }
.magic-config-status.warn { color: #ffd07b; font-weight: 800; }
.magic-config-status.bad { color: #ff969e; font-weight: 900; }
.magic-progress trough { min-height: 34px; border-radius: 17px; }
.magic-progress progress { min-height: 34px; border-radius: 17px; }
.magic-progress text { font-size: 17px; font-weight: 900; color: #ffffff; }
.magic-progress-label { color: #f5f8fb; font-size: 16px; font-weight: 800; }
separator { background: #2a374b; }
"""


RESPONSIVE_CSS = b"""
window.compact-screen .topbar { padding: 6px 10px; }
window.compact-screen .brand { font-size: 18px; }
window.compact-screen .version { font-size: 9px; }
window.compact-screen .status-chip { padding: 5px 8px; font-size: 11px; }
window.compact-screen .update-alert { padding: 5px 8px; font-size: 11px; }
window.compact-screen .content { padding: 10px; }
window.compact-screen .page-title { font-size: 21px; }
window.compact-screen .page-subtitle { font-size: 11px; }
window.compact-screen .hero { padding: 12px; }
window.compact-screen .hero-title { font-size: 20px; }
window.compact-screen .hero-subtitle { font-size: 11px; }
window.compact-screen .section-title { font-size: 14px; }
window.compact-screen .card { padding: 9px 11px; }
window.compact-screen .card-value { font-size: 16px; }
window.compact-screen .card-title { font-size: 10px; }
window.compact-screen .card-subtitle { font-size: 9px; }
window.compact-screen .battery-live-panel { padding: 7px 10px; }
window.compact-screen .primary-button,
window.compact-screen .secondary-button,
window.compact-screen .danger-button { padding: 6px 9px; font-size: 11px; }
window.compact-screen .nav-button { padding: 8px 10px; font-size: 12px; }
window.compact-screen .bottom-navigation,
window.compact-screen.layout-studio-panels .bottom-navigation { padding: 4px 10px; }
window.compact-screen .footer { padding: 4px 9px; font-size: 10px; }
window.compact-screen.layout-studio-panels .studio-panel { padding: 10px 12px; }
window.compact-screen.layout-studio-panels .studio-suggestions-panel,
window.compact-screen.layout-studio-panels .studio-dashboard-battery { padding: 10px 12px; }
window.compact-screen.layout-studio-panels .studio-suggestion-card { padding: 5px 9px; min-height: 29px; }
window.compact-screen.layout-studio-panels .studio-suggestion-title { font-size: 13px; }
window.compact-screen.layout-studio-panels .studio-suggestion-summary { font-size: 10px; }
window.compact-screen.layout-studio-panels .studio-suggestion-score { font-size: 16px; }
window.compact-screen.layout-service-desk .service-device-hero { padding: 12px; }
window.compact-screen.layout-service-desk .service-status-rail { padding: 10px; }
window.compact-screen.layout-service-desk .service-rail-row { padding: 6px 0; }
window.compact-screen.layout-workshop-console .console-summary { padding: 8px 10px; }
window.compact-screen.layout-workshop-console .console-label,
window.compact-screen.layout-workshop-console .console-value,
window.compact-screen.layout-workshop-console .console-state { padding: 6px 8px; }
window.compact-screen.layout-workshop-console .console-actions { padding: 6px; }
window.compact-screen .models-toolbar { padding: 6px; }
window.compact-screen .models-compare-card { padding: 8px 10px; }
window.compact-screen .models-results-header { padding: 6px 9px; }

window.narrow-screen .topbar { padding: 4px 7px; }
window.narrow-screen .brand { font-size: 16px; }
window.narrow-screen .status-chip,
window.narrow-screen .update-alert { padding: 4px 6px; font-size: 10px; }
window.narrow-screen .topbar button,
window.narrow-screen .topbar menubutton,
window.narrow-screen .topbar .status-chip { min-width: 0; }
window.narrow-screen .content { padding: 7px; }
window.narrow-screen .nav-button { padding: 6px 7px; font-size: 11px; }
window.narrow-screen .bottom-navigation .nav-button { min-width: 0; padding: 5px 6px; }
window.narrow-screen .bottom-navigation .nav-button label { font-size: 10px; }
"""


def _valid_hex_color(value: object, fallback: str) -> str:
    text = str(value or "").strip().lower()
    return text if re.fullmatch(r"#[0-9a-f]{6}", text) else fallback


def _hex_rgb(value: str) -> tuple[int, int, int]:
    color = _valid_hex_color(value, "#000000")
    return tuple(int(color[index : index + 2], 16) for index in (1, 3, 5))


def _rgb_float(value: str) -> tuple[float, float, float]:
    return tuple(channel / 255.0 for channel in _hex_rgb(value))


def _mix_hex(first: str, second: str, amount: float) -> str:
    left = _hex_rgb(first)
    right = _hex_rgb(second)
    ratio = max(0.0, min(1.0, float(amount)))
    mixed = tuple(round(left[index] * (1.0 - ratio) + right[index] * ratio) for index in range(3))
    return "#" + "".join(f"{channel:02x}" for channel in mixed)


def _contrast_text(background: str) -> str:
    red, green, blue = _hex_rgb(background)
    luminance = (0.299 * red + 0.587 * green + 0.114 * blue) / 255.0
    return "#10151d" if luminance >= 0.58 else "#ffffff"


def screen_layout_flags(width: object, height: object) -> tuple[bool, bool]:
    """Choose compact UI from usable pixel geometry, never screen inches.

    A 17.3-inch HD+ panel is 1600×900 and has less vertical room than a
    14-inch Full-HD panel.  The content area therefore must react to pixels,
    not to a guessed physical panel size.  The narrow flag also tightens the
    header/navigation when a low-height display has limited horizontal room.
    """

    try:
        screen_width = max(1, int(width))
        screen_height = max(1, int(height))
    except (TypeError, ValueError):
        return True, True
    compact = screen_height <= 900 or screen_width <= 1440
    narrow = screen_width <= 1366 or (screen_height <= 900 and screen_width <= 1680)
    return compact, narrow


def appearance_css(layout: str, accent: str) -> bytes:
    layout = layout if layout in APPEARANCE_LAYOUTS else "original"
    accent = _valid_hex_color(accent, APPEARANCE_DEFAULT_ACCENTS[layout])
    accent_hover = _mix_hex(accent, "#ffffff", 0.18)
    accent_dark = _mix_hex(accent, "#000000", 0.22)
    accent_text = _contrast_text(accent)
    common = f"""
.app-root .primary-button {{ background: {accent}; color: {accent_text}; }}
.app-root .primary-button label {{ color: {accent_text}; }}
.app-root .primary-button:hover {{ background: {accent_hover}; color: {_contrast_text(accent_hover)}; }}
.app-root .primary-button:hover label {{ color: {_contrast_text(accent_hover)}; }}
.app-root .nav-button.active {{ color: {accent}; border-color: {accent}; }}
.app-root .card-icon, .app-root .battery-measure-state {{ color: {accent}; }}
.app-root .quick-button:hover {{ border-color: {accent}; }}
.app-root progressbar progress, .app-root levelbar block.filled {{ background: {accent}; }}
.app-root treeview:selected, .app-root row:selected {{ background: {accent_dark}; color: #ffffff; }}
.app-root .appearance-option.active {{ border: 2px solid {accent}; color: {accent}; }}
.app-root .accent-choice.active {{ border: 3px solid #ffffff; }}
.app-root .top-navigation {{ border-right: 0; padding: 4px 16px; }}
.app-root .top-navigation .nav-button {{ margin: 0 2px; }}
.app-root .top-navigation .nav-button.active {{ border-left: 0; border-bottom: 3px solid {accent}; }}
.app-root .accent-gold {{ background: #f7b733; color: #10151d; }}
.app-root .accent-teal {{ background: #0b9189; color: #ffffff; }}
.app-root .accent-blue {{ background: #4d8dff; color: #ffffff; }}
.app-root .accent-violet {{ background: #8b5cf6; color: #ffffff; }}
.app-root .accent-green {{ background: #2ec98f; color: #10151d; }}
.app-root .accent-red {{ background: #e65d68; color: #ffffff; }}
"""
    if layout == "service-light":
        theme = f"""
window.layout-service-light, .layout-service-light {{ background: #f7f4ec; color: #17324d; }}
.layout-service-light .topbar {{ background: #fffdf8; border-bottom: 1px solid #d8d4c8; padding: 12px 20px; }}
.layout-service-light .brand, .layout-service-light .page-title, .layout-service-light .hero-title,
.layout-service-light .section-title, .layout-service-light .card-value {{ color: #143b5b; }}
.layout-service-light .version, .layout-service-light .page-subtitle, .layout-service-light .hero-subtitle,
.layout-service-light .card-title, .layout-service-light .card-subtitle, .layout-service-light .muted {{ color: #667d90; }}
.layout-service-light .status-chip {{ background: #ffffff; border-color: #cbd5d7; color: #17324d; }}
.layout-service-light .status-chip.good {{ color: #08766f; border-color: #5aa69f; }}
.layout-service-light .status-chip.warn {{ color: #8c5a00; border-color: #c99c47; }}
.layout-service-light .status-chip.bad {{ color: #a62f3e; border-color: #d18891; }}
.layout-service-light .sidebar, .layout-service-light .top-navigation {{ background: #fffdf8; border-color: #d8d4c8; }}
.layout-service-light .nav-button {{ background: transparent; color: #516b80; border-radius: 7px; }}
.layout-service-light .nav-button:hover {{ background: #e8efec; color: #143b5b; }}
.layout-service-light .nav-button.active {{ background: #e3efec; color: {accent_dark}; }}
.layout-service-light .content {{ background: #f7f4ec; }}
.layout-service-light .hero {{ background: #fffdf8; border-color: #d8d4c8; border-radius: 11px; }}
.layout-service-light .card, .layout-service-light .battery-metric-card,
.layout-service-light .battery-history-card, .layout-service-light .battery-mini-panel {{ background: #fffdf8; border-color: #d8d4c8; border-radius: 10px; }}
.layout-service-light .card:hover {{ border-color: #aebdbb; }}
.layout-service-light .battery-chart {{ background: #fffdf8; }}
.layout-service-light .battery-live-panel {{ background: #e4f3ee; border-color: #79b8a4; }}
.layout-service-light .battery-live-title, .layout-service-light .battery-mini-title {{ color: #08766f; }}
.layout-service-light .battery-live-subtitle, .layout-service-light .battery-mini-subtitle {{ color: #667d90; }}
.layout-service-light .quick-button, .layout-service-light .secondary-button {{ background: #ffffff; border-color: #bcc9cc; color: #17324d; }}
.layout-service-light .quick-button:hover, .layout-service-light .secondary-button:hover {{ background: #e8efec; }}
.layout-service-light .danger-button {{ background: #fff0ef; border-color: #d99a9d; color: #a62f3e; }}
.layout-service-light entry, .layout-service-light searchentry, .layout-service-light spinbutton,
.layout-service-light treeview, .layout-service-light list, .layout-service-light textview,
.layout-service-light textview text {{ background: #fffdf8; color: #17324d; border-color: #bcc9cc; }}
.layout-service-light treeview header button {{ background: #e9e5dc; color: #17324d; border-color: #c9c4b8; }}
.layout-service-light .list-row {{ background: #fffdf8; border-color: #dedacf; }}
.layout-service-light .list-row:hover {{ background: #edf2ef; }}
.layout-service-light .neutral-cell {{ background: #edf1ee; color: #17324d; }}
.layout-service-light .unavailable-cell {{ background: #f0eee8; color: #788897; }}
.layout-service-light .comparison-header {{ background: #dedbd2; color: #17324d; }}
.layout-service-light .footer {{ background: #fffdf8; border-color: #d8d4c8; color: #667d90; }}
.layout-service-light popover, .layout-service-light popover.background,
.layout-service-light .dark-popover, .layout-service-light .dark-popover > contents {{ background: #fffdf8; color: #17324d; border-color: #c5ced0; }}
.layout-service-light progressbar trough, .layout-service-light levelbar trough {{ background: #dce3e1; }}
.layout-service-light .dashboard-battery-value {{ color: #153a4b; }}
.layout-service-light separator {{ background: #d8d4c8; }}
"""
    elif layout == "workshop-pro":
        theme = f"""
window.layout-workshop-pro, .layout-workshop-pro {{ background: #191b1d; color: #f2f0e8; font-family: Bahnschrift, "Arial Narrow", sans-serif; }}
.layout-workshop-pro .topbar {{ background: #101214; border-bottom: 2px solid {accent}; padding: 10px 16px; }}
.layout-workshop-pro .brand, .layout-workshop-pro .page-title, .layout-workshop-pro .hero-title,
.layout-workshop-pro .section-title, .layout-workshop-pro .card-value {{ color: #f8f7f1; }}
.layout-workshop-pro .version, .layout-workshop-pro .page-subtitle, .layout-workshop-pro .hero-subtitle,
.layout-workshop-pro .card-title, .layout-workshop-pro .card-subtitle, .layout-workshop-pro .muted {{ color: #9a9ea0; }}
.layout-workshop-pro .status-chip {{ background: #202326; border-color: #515558; border-radius: 0; color: #eeeeea; }}
.layout-workshop-pro .sidebar {{ background: #101214; border-color: #3b3e40; padding: 12px 0; }}
.layout-workshop-pro .nav-button {{ background: transparent; color: #c1c4c5; border-radius: 0; border-bottom: 1px solid #2d3032; margin: 0; }}
.layout-workshop-pro .nav-button:hover {{ background: #242729; color: #ffffff; }}
.layout-workshop-pro .nav-button.active {{ background: {accent}; color: {accent_text}; border-left: 0; }}
.layout-workshop-pro .content {{ background: #191b1d; }}
.layout-workshop-pro .hero {{ background: #25282a; border: 0; border-left: 5px solid {accent}; border-radius: 0; }}
.layout-workshop-pro .card, .layout-workshop-pro .battery-metric-card,
.layout-workshop-pro .battery-history-card, .layout-workshop-pro .battery-mini-panel {{ background: #1d2022; border-color: #3d4143; border-radius: 0; }}
.layout-workshop-pro .card:hover {{ border-color: {accent_dark}; }}
.layout-workshop-pro .battery-chart {{ background: #181b1d; }}
.layout-workshop-pro .battery-live-panel {{ background: #1d2823; border-color: #3b745d; border-radius: 0; }}
.layout-workshop-pro .quick-button, .layout-workshop-pro .secondary-button {{ background: #25282a; border-color: #5a5e60; border-radius: 0; color: #f5f4ee; }}
.layout-workshop-pro .quick-button:hover, .layout-workshop-pro .secondary-button:hover {{ background: #303335; }}
.layout-workshop-pro .primary-button, .layout-workshop-pro .danger-button {{ border-radius: 0; }}
.layout-workshop-pro entry, .layout-workshop-pro searchentry, .layout-workshop-pro spinbutton,
.layout-workshop-pro treeview, .layout-workshop-pro list, .layout-workshop-pro textview,
.layout-workshop-pro textview text {{ background: #151719; color: #f3f1ea; border-color: #4a4e50; border-radius: 0; }}
.layout-workshop-pro treeview header button {{ background: {accent}; color: {accent_text}; border-color: {accent_dark}; }}
.layout-workshop-pro .list-row {{ background: #1b1e20; border-color: #343739; }}
.layout-workshop-pro .list-row:hover {{ background: #282b2d; }}
.layout-workshop-pro .neutral-cell {{ background: #202326; color: #ecebe5; }}
.layout-workshop-pro .unavailable-cell {{ background: #181a1c; color: #777b7d; }}
.layout-workshop-pro .comparison-header {{ background: {accent}; color: {accent_text}; }}
.layout-workshop-pro .footer {{ background: #101214; border-color: #3b3e40; color: #9a9ea0; }}
.layout-workshop-pro popover, .layout-workshop-pro popover.background,
.layout-workshop-pro .dark-popover, .layout-workshop-pro .dark-popover > contents {{ background: #181b1d; color: #f3f1ea; border-color: #515558; border-radius: 0; }}
.layout-workshop-pro progressbar trough, .layout-workshop-pro levelbar trough {{ background: #333638; border-radius: 0; }}
.layout-workshop-pro progressbar progress, .layout-workshop-pro levelbar block.filled {{ border-radius: 0; }}
.layout-workshop-pro separator {{ background: #3b3e40; }}
"""
    elif layout == "blue-control":
        theme = f"""
window.layout-blue-control, .layout-blue-control {{ background: #08142d; color: #f5f8ff; }}
.layout-blue-control .topbar {{ background: linear-gradient(110deg, #07142f, #0d2c55); border-bottom: 1px solid #245f91; padding: 12px 20px; }}
.layout-blue-control .brand, .layout-blue-control .page-title, .layout-blue-control .hero-title,
.layout-blue-control .section-title, .layout-blue-control .card-value {{ color: #f8faff; }}
.layout-blue-control .version, .layout-blue-control .page-subtitle, .layout-blue-control .hero-subtitle,
.layout-blue-control .card-title, .layout-blue-control .card-subtitle, .layout-blue-control .muted {{ color: #9eb7dc; }}
.layout-blue-control .status-chip {{ background: rgba(24, 58, 105, 0.75); border-color: #3e74aa; color: #e5f2ff; }}
.layout-blue-control .sidebar, .layout-blue-control .top-navigation {{ background: #091b3b; border-color: #255286; }}
.layout-blue-control .nav-button {{ background: transparent; color: #adc3e5; border-radius: 11px; }}
.layout-blue-control .nav-button:hover {{ background: #173b6c; color: #ffffff; }}
.layout-blue-control .nav-button.active {{ background: #173f78; color: #ffffff; }}
.layout-blue-control .content {{ background: linear-gradient(145deg, #07132c, #12366c, #24174f); }}
.layout-blue-control .hero {{ background: linear-gradient(125deg, #174a91, #2c2d84); border-color: #4b79c5; border-radius: 18px; }}
.layout-blue-control .card, .layout-blue-control .battery-metric-card,
.layout-blue-control .battery-history-card, .layout-blue-control .battery-mini-panel {{ background: rgba(13, 31, 69, 0.90); border-color: #315b91; border-radius: 16px; }}
.layout-blue-control .card:hover {{ border-color: #5a91d1; }}
.layout-blue-control .battery-chart {{ background: #0a1938; }}
.layout-blue-control .battery-live-panel {{ background: rgba(10, 63, 69, 0.85); border-color: #2ca28d; border-radius: 15px; }}
.layout-blue-control .quick-button, .layout-blue-control .secondary-button {{ background: rgba(25, 59, 110, 0.88); border-color: #467bb6; border-radius: 12px; color: #f2f7ff; }}
.layout-blue-control .quick-button:hover, .layout-blue-control .secondary-button:hover {{ background: #214f8d; }}
.layout-blue-control .danger-button {{ background: #4b244b; border-color: #824d78; border-radius: 12px; color: #ffc4dc; }}
.layout-blue-control entry, .layout-blue-control searchentry, .layout-blue-control spinbutton,
.layout-blue-control treeview, .layout-blue-control list, .layout-blue-control textview,
.layout-blue-control textview text {{ background: #091831; color: #edf5ff; border-color: #37669d; }}
.layout-blue-control treeview header button {{ background: #173b6c; color: #f5f8ff; border-color: #315b91; }}
.layout-blue-control .list-row {{ background: rgba(10, 27, 59, 0.92); border-color: #284d7b; }}
.layout-blue-control .list-row:hover {{ background: #173b6c; }}
.layout-blue-control .neutral-cell {{ background: #10264d; color: #e8f2ff; }}
.layout-blue-control .unavailable-cell {{ background: #0a1830; color: #718db3; }}
.layout-blue-control .comparison-header {{ background: #dfe8f4; color: #0a1830; }}
.layout-blue-control .footer {{ background: #07142f; border-color: #28568a; color: #9eb7dc; }}
.layout-blue-control popover, .layout-blue-control popover.background,
.layout-blue-control .dark-popover, .layout-blue-control .dark-popover > contents {{ background: #0a1b3b; color: #edf5ff; border-color: #3e6d9f; }}
.layout-blue-control progressbar trough, .layout-blue-control levelbar trough {{ background: #1d3c6d; }}
.layout-blue-control separator {{ background: #2a568a; }}
"""
    elif layout == "service-desk":
        theme = f"""
window.layout-service-desk, .layout-service-desk {{ background: #f2efe7; color: #19384a; }}
.layout-service-desk .topbar {{ background: #fffdf7; border-bottom: 1px solid #d8d2c4; padding: 14px 22px; }}
.layout-service-desk .brand {{ color: #153a4b; font-size: 27px; }}
.layout-service-desk .version, .layout-service-desk .page-subtitle, .layout-service-desk .hero-subtitle,
.layout-service-desk .card-title, .layout-service-desk .card-subtitle, .layout-service-desk .muted {{ color: #71828b; }}
.layout-service-desk .page-title, .layout-service-desk .hero-title, .layout-service-desk .section-title,
.layout-service-desk .card-value {{ color: #153a4b; }}
.layout-service-desk .status-chip {{ background: #edf7f3; border-color: #bfcfc9; color: #096e68; }}
.layout-service-desk .top-navigation {{ background: #fffdf7; border-bottom: 1px solid #d8d2c4; padding: 0 16px; }}
.layout-service-desk .top-navigation .nav-button {{ background: transparent; color: #536b75; border-radius: 0; padding: 10px 13px; }}
.layout-service-desk .top-navigation .nav-button:hover {{ background: #edf3ef; color: #153a4b; }}
.layout-service-desk .top-navigation .nav-button.active {{ background: transparent; color: {accent_dark}; border-bottom: 3px solid {accent}; }}
.layout-service-desk .content {{ background: #f2efe7; }}
.layout-service-desk .hero, .layout-service-desk .card, .layout-service-desk .battery-metric-card,
.layout-service-desk .battery-history-card, .layout-service-desk .battery-mini-panel {{ background: #fffdf7; border-color: #d8d2c4; border-radius: 0; }}
.layout-service-desk .service-device-hero {{ background: #fffdf7; border: 1px solid #d8d2c4; padding: 22px; }}
.layout-service-desk .service-fact {{ background: #fffdf7; border-top: 1px solid #ded8cc; padding: 10px 4px; }}
.layout-service-desk .service-status-rail {{ background: #153a4b; border: 0; padding: 18px; }}
.layout-service-desk .service-status-rail .card-title, .layout-service-desk .service-status-rail .card-subtitle {{ color: #b8c9cd; }}
.layout-service-desk .service-status-rail .card-value, .layout-service-desk .service-status-rail .section-title {{ color: #ffffff; }}
.layout-service-desk .service-rail-row {{ border-top: 1px solid rgba(255,255,255,0.16); padding: 12px 0; }}
.layout-service-desk .models-toolbar {{ background: #fffdf7; border: 1px solid #d8d2c4; padding: 10px; }}
.layout-service-desk .models-compare-card {{ background: #fffdf7; border-color: #d8d2c4; border-radius: 0; }}
.layout-service-desk .models-results-header {{ background: #153a4b; padding: 9px 12px; }}
.layout-service-desk .models-results-header .section-title {{ color: #ffffff; }}
.layout-service-desk .models-results-header .muted {{ color: #b8c9cd; }}
.layout-service-desk .battery-page .battery-live-panel {{ background: #153a4b; border-color: #153a4b; }}
.layout-service-desk .battery-page .battery-live-title {{ color: #ffffff; }}
.layout-service-desk .battery-page .battery-live-subtitle {{ color: #b8c9cd; }}
.layout-service-desk .battery-live-panel {{ background: #e3f3ed; border-color: #79b8a4; border-radius: 0; }}
.layout-service-desk .quick-button, .layout-service-desk .secondary-button {{ background: #fffdf7; border-color: #afc3c0; color: #19384a; border-radius: 5px; }}
.layout-service-desk .quick-button:hover, .layout-service-desk .secondary-button:hover {{ background: #e7f0ec; }}
.layout-service-desk .primary-button {{ border-radius: 5px; }}
.layout-service-desk entry, .layout-service-desk searchentry, .layout-service-desk spinbutton,
.layout-service-desk treeview, .layout-service-desk list, .layout-service-desk textview,
.layout-service-desk textview text {{ background: #fffdf7; color: #19384a; border-color: #afc3c0; border-radius: 4px; }}
.layout-service-desk treeview header button {{ background: #e9e5dc; color: #17384b; border-color: #c9c4b8; }}
.layout-service-desk .list-row {{ background: #fffdf7; border-color: #e8e3d9; }}
.layout-service-desk .list-row:hover {{ background: #edf3ef; }}
.layout-service-desk .comparison-header {{ background: #e9e5dc; color: #17384b; }}
.layout-service-desk .neutral-cell {{ background: #edf1ee; color: #17384b; }}
.layout-service-desk .unavailable-cell {{ background: #f0eee8; color: #788897; }}
.layout-service-desk .footer {{ background: #fffdf7; border-color: #d8d2c4; color: #667d90; }}
.layout-service-desk .dark-popover, .layout-service-desk .dark-popover > contents {{ background: #fffdf7; color: #19384a; border-color: #c5ced0; }}
.layout-service-desk progressbar trough, .layout-service-desk levelbar trough {{ background: #dce3e1; }}
.layout-service-desk .dashboard-battery-value {{ color: #153a4b; }}
"""
    elif layout == "workshop-console":
        theme = f"""
window.layout-workshop-console, .layout-workshop-console {{ background: #111315; color: #e9e7de; font-family: Bahnschrift, "Arial Narrow", sans-serif; }}
.layout-workshop-console .topbar {{ background: #08090a; border-bottom: 3px solid {accent}; padding: 10px 16px; }}
.layout-workshop-console .brand, .layout-workshop-console .page-title, .layout-workshop-console .hero-title,
.layout-workshop-console .section-title, .layout-workshop-console .card-value {{ color: #f2f0e8; }}
.layout-workshop-console .version, .layout-workshop-console .page-subtitle, .layout-workshop-console .hero-subtitle,
.layout-workshop-console .card-title, .layout-workshop-console .card-subtitle, .layout-workshop-console .muted {{ color: #999d9f; }}
.layout-workshop-console .status-chip {{ background: #1b1e20; border-color: #45484a; border-radius: 0; color: #e9e7de; }}
.layout-workshop-console .sidebar {{ background: #08090a; border-color: #444648; padding: 8px 0; }}
.layout-workshop-console .sidebar .nav-button {{ background: transparent; color: #b8b8b2; border-radius: 0; border-bottom: 1px solid #292b2d; margin: 0; padding: 13px 14px; }}
.layout-workshop-console .sidebar .nav-button:hover {{ background: #202326; color: #ffffff; }}
.layout-workshop-console .sidebar .nav-button.active {{ background: {accent}; color: {accent_text}; border-left: 0; }}
.layout-workshop-console .content {{ background: #111315; }}
.layout-workshop-console .hero, .layout-workshop-console .card, .layout-workshop-console .battery-metric-card,
.layout-workshop-console .battery-history-card, .layout-workshop-console .battery-mini-panel {{ background: #1b1e20; border-color: #45484a; border-radius: 0; }}
.layout-workshop-console .console-summary {{ background: #202326; border-left: 6px solid {accent}; padding: 14px; }}
.layout-workshop-console .console-table {{ background: #111315; border: 1px solid #45484a; }}
.layout-workshop-console .console-table-row {{ border-bottom: 1px solid #35383a; padding: 0; }}
.layout-workshop-console .console-label {{ background: #202326; color: #999d9f; padding: 11px; }}
.layout-workshop-console .console-value {{ color: #f2f0e8; padding: 11px; }}
.layout-workshop-console .console-state {{ color: #39d68b; padding: 11px; }}
.layout-workshop-console .console-actions {{ background: #1b1e20; border: 1px solid #45484a; padding: 10px; }}
.layout-workshop-console .console-actions .secondary-button {{ margin: 4px 0; }}
.layout-workshop-console .models-toolbar {{ background: #08090a; border: 1px solid #45484a; padding: 8px; }}
.layout-workshop-console .models-compare-card {{ background: #111315; border-color: #45484a; border-radius: 0; }}
.layout-workshop-console .models-results-header {{ background: {accent}; padding: 8px 10px; }}
.layout-workshop-console .models-results-header .section-title,
.layout-workshop-console .models-results-header .muted {{ color: {accent_text}; }}
.layout-workshop-console .battery-page .battery-live-panel {{ background: #08090a; border-color: {accent}; border-radius: 0; }}
.layout-workshop-console .battery-page .battery-live-title {{ color: {accent}; }}
.layout-workshop-console .battery-live-panel {{ background: #162b23; border-color: #32745b; border-radius: 0; }}
.layout-workshop-console .primary-button {{ background: {accent}; color: {accent_text}; border-radius: 0; }}
.layout-workshop-console .secondary-button, .layout-workshop-console .quick-button {{ background: #232628; color: #eeeeea; border-color: #5a5d5f; border-radius: 0; }}
.layout-workshop-console .secondary-button:hover, .layout-workshop-console .quick-button:hover {{ background: #303335; }}
.layout-workshop-console .danger-button {{ border-radius: 0; }}
.layout-workshop-console entry, .layout-workshop-console searchentry, .layout-workshop-console spinbutton,
.layout-workshop-console treeview, .layout-workshop-console list, .layout-workshop-console textview,
.layout-workshop-console textview text {{ background: #090a0b; color: #f2f0e8; border-color: #55595b; border-radius: 0; }}
.layout-workshop-console treeview header button {{ background: {accent}; color: {accent_text}; border-color: {accent_dark}; }}
.layout-workshop-console .list-row {{ background: #17191b; border-color: #35383a; }}
.layout-workshop-console .list-row:hover {{ background: #25282a; }}
.layout-workshop-console .comparison-header {{ background: {accent}; color: {accent_text}; }}
.layout-workshop-console .neutral-cell {{ background: #202326; color: #ecebe5; }}
.layout-workshop-console .unavailable-cell {{ background: #121416; color: #777b7d; }}
.layout-workshop-console .footer {{ background: #08090a; border-color: #3b3e40; color: #999d9f; }}
.layout-workshop-console .dark-popover, .layout-workshop-console .dark-popover > contents {{ background: #181b1d; color: #f3f1ea; border-color: #515558; border-radius: 0; }}
.layout-workshop-console progressbar trough, .layout-workshop-console levelbar trough {{ background: #333638; border-radius: 0; }}
.layout-workshop-console progressbar progress, .layout-workshop-console levelbar block.filled {{ border-radius: 0; }}
"""
    elif layout == "studio-panels":
        theme = f"""
window.layout-studio-panels, .layout-studio-panels {{ background: #321346; color: #fff7ff; }}
.layout-studio-panels .topbar {{ background: linear-gradient(110deg, #321346, #632663); border-bottom: 1px solid rgba(255,255,255,0.20); padding: 13px 20px; }}
.layout-studio-panels .brand, .layout-studio-panels .page-title, .layout-studio-panels .hero-title,
.layout-studio-panels .section-title, .layout-studio-panels .card-value {{ color: #fff7ff; }}
.layout-studio-panels .version, .layout-studio-panels .page-subtitle, .layout-studio-panels .hero-subtitle,
.layout-studio-panels .card-title, .layout-studio-panels .card-subtitle, .layout-studio-panels .muted {{ color: #edcce9; }}
.layout-studio-panels .status-chip {{ background: rgba(255,255,255,0.12); border-color: rgba(255,255,255,0.26); color: #fff7ff; }}
.layout-studio-panels .content {{ background: linear-gradient(145deg, #321346, #632663, #9b385f); }}
.layout-studio-panels .bottom-navigation {{ background: rgba(24,8,39,0.96); border-top: 1px solid rgba(255,255,255,0.22); padding: 7px 18px; }}
.layout-studio-panels .bottom-navigation .nav-button {{ background: transparent; color: #f0d6eb; border: 1px solid transparent; border-radius: 11px; padding: 8px 11px; margin: 0 2px; }}
.layout-studio-panels .bottom-navigation .nav-button:hover {{ background: rgba(255,255,255,0.10); color: #ffffff; }}
.layout-studio-panels .bottom-navigation .nav-button.active {{ background: {accent}; color: {accent_text}; border-color: {accent}; border-left: 1px solid {accent}; }}
.layout-studio-panels .hero {{ background: linear-gradient(125deg, #643194, #201347); border-color: transparent; border-radius: 18px; }}
.layout-studio-panels .card, .layout-studio-panels .battery-metric-card,
.layout-studio-panels .battery-history-card, .layout-studio-panels .battery-mini-panel,
.layout-studio-panels .studio-panel {{ background: rgba(25,9,42,0.82); border: 0; box-shadow: none; border-radius: 18px; }}
.layout-studio-panels .studio-panel {{ padding: 16px; }}
.layout-studio-panels .studio-device-panel {{ background: linear-gradient(125deg, #643194, #201347); }}
.layout-studio-panels .studio-match-panel {{ background: linear-gradient(125deg, #d75369, #801f54); }}
.layout-studio-panels .studio-action-panel {{ background: rgba(25,9,42,0.82); padding: 13px; }}
.layout-studio-panels .studio-rescan-button {{ padding: 7px 11px; min-height: 26px; }}
.layout-studio-panels .studio-suggestions-panel {{ background: rgba(18,6,35,0.90); border: 0; box-shadow: none; border-radius: 18px; padding: 14px 16px; }}
.layout-studio-panels .studio-suggestion-list {{ background: transparent; border: 0; }}
.layout-studio-panels .studio-suggestion-row {{ background: transparent; border: 0; padding: 0; }}
.layout-studio-panels .studio-suggestion-card {{ background: rgba(255,255,255,0.08); border: 0; box-shadow: none; border-radius: 12px; color: #fff7ff; padding: 9px 12px; min-height: 38px; }}
.layout-studio-panels .studio-suggestion-card:hover {{ background: rgba(255,255,255,0.16); }}
.layout-studio-panels .studio-suggestion-card.best {{ background: rgba(255,224,123,0.17); color: #fffbea; }}
.layout-studio-panels .studio-suggestion-title {{ color: #fff7ff; font-weight: 700; font-size: 15px; }}
.layout-studio-panels .studio-suggestion-kind {{ color: #eebfdf; font-size: 10px; font-weight: 700; }}
.layout-studio-panels .studio-suggestion-summary {{ color: #edcce9; font-size: 12px; }}
.layout-studio-panels .studio-suggestion-score {{ color: #ffe07b; font-size: 19px; font-weight: 800; }}
.layout-studio-panels .studio-dashboard-workspace {{ background: transparent; }}
.layout-studio-panels .studio-dashboard-battery {{ background: rgba(18,6,35,0.90); border: 0; box-shadow: none; border-radius: 18px; padding: 14px 16px; }}
.layout-studio-panels .studio-dashboard-battery:hover {{ background: rgba(30,10,47,0.96); }}
.layout-studio-panels .studio-dashboard-battery-state {{ color: #4edca6; font-size: 12px; font-weight: 700; }}
.layout-studio-panels .studio-dashboard-battery-runtime {{ color: #fff7ff; font-size: 20px; font-weight: 800; }}
.layout-studio-panels .studio-dashboard-battery-subtitle {{ color: #edcce9; font-size: 11px; }}
.layout-studio-panels .models-toolbar {{ background: rgba(25,9,42,0.72); border: 0; box-shadow: none; border-radius: 16px; padding: 10px; }}
.layout-studio-panels .models-compare-card {{ background: rgba(25,9,42,0.82); border: 0; box-shadow: none; border-radius: 18px; }}
.layout-studio-panels .models-results-header {{ background: linear-gradient(110deg, #d75369, #801f54); border-radius: 12px; padding: 9px 12px; }}
.layout-studio-panels .models-results-header .section-title,
.layout-studio-panels .models-results-header .muted {{ color: #fff7ff; }}
.layout-studio-panels .battery-page .battery-live-panel {{ background: linear-gradient(110deg, #643194, #201347); border: 0; box-shadow: none; padding: 15px 18px; }}
.layout-studio-panels .battery-studio-grid {{ background: transparent; }}
.layout-studio-panels .battery-metric-card {{ border: 0; box-shadow: none; border-radius: 18px; padding: 15px 17px; }}
.layout-studio-panels .battery-metric-level {{ background: linear-gradient(145deg, #13a6a0, #3152bc); }}
.layout-studio-panels .battery-metric-level .card-title,
.layout-studio-panels .battery-metric-level .card-subtitle {{ color: #d7ffff; }}
.layout-studio-panels .battery-metric-level .card-value {{ font-size: 42px; color: #ffffff; }}
.layout-studio-panels .battery-metric-runtime {{ background: linear-gradient(135deg, #d75369, #8a245a); }}
.layout-studio-panels .battery-metric-power {{ background: linear-gradient(135deg, #4b2b89, #262258); }}
.layout-studio-panels .battery-metric-health {{ background: linear-gradient(135deg, #147c70, #224f63); }}
.layout-studio-panels .battery-metric-capacity {{ background: linear-gradient(135deg, #3d1d64, #6e276b); }}
.layout-studio-panels .battery-metric-voltage_cycles {{ background: linear-gradient(135deg, #7d315f, #39214e); }}
.layout-studio-panels .battery-controls {{ background: rgba(25,9,42,0.72); border-radius: 15px; padding: 10px; }}
.layout-studio-panels .battery-studio-history {{ background: rgba(18,6,35,0.88); border: 0; box-shadow: none; border-radius: 20px; padding: 15px; }}
.layout-studio-panels .battery-live-panel {{ background: rgba(18,87,75,0.80); border-color: #43c49b; border-radius: 15px; }}
.layout-studio-panels .quick-button, .layout-studio-panels .secondary-button {{ background: rgba(255,255,255,0.10); border-color: rgba(255,255,255,0.24); color: #fff7ff; border-radius: 11px; }}
.layout-studio-panels .quick-button:hover, .layout-studio-panels .secondary-button:hover {{ background: rgba(255,255,255,0.17); }}
.layout-studio-panels .primary-button {{ background: {accent}; color: {accent_text}; border-radius: 11px; }}
.layout-studio-panels .danger-button {{ background: rgba(93,29,67,0.92); border-color: #a95887; color: #ffd8eb; border-radius: 11px; }}
.layout-studio-panels entry, .layout-studio-panels searchentry, .layout-studio-panels spinbutton,
.layout-studio-panels treeview, .layout-studio-panels list, .layout-studio-panels textview,
.layout-studio-panels textview text {{ background: rgba(18,6,35,0.90); color: #fff7ff; border-color: transparent; border-radius: 12px; }}
.layout-studio-panels treeview header button {{ background: #4a215b; color: #fff7ff; border: 0; box-shadow: none; }}
.layout-studio-panels .list-row {{ background: rgba(30,10,47,0.86); border-color: transparent; border-radius: 9px; }}
.layout-studio-panels .list-row:hover {{ background: rgba(255,255,255,0.12); }}
.layout-studio-panels .comparison-header {{ background: #4a215b; color: #fff7ff; }}
.layout-studio-panels .neutral-cell {{ background: #432150; color: #fff7ff; }}
.layout-studio-panels .unavailable-cell {{ background: #291332; color: #a985aa; }}
.layout-studio-panels .footer {{ background: #250d32; border-color: rgba(255,255,255,0.17); color: #edcce9; }}
.layout-studio-panels .dark-popover, .layout-studio-panels .dark-popover > contents {{ background: #351442; color: #fff7ff; border-color: #8b5d91; border-radius: 12px; }}
.layout-studio-panels progressbar trough, .layout-studio-panels levelbar trough {{ background: rgba(255,255,255,0.16); }}
"""
    else:
        theme = ""
    return (common + theme).encode("utf-8")


def _clean(value: object, fallback: str = "–") -> str:
    text = str(value or "").strip()
    return text if text else fallback


def _short(value: object, maximum: int = 80) -> str:
    text = " ".join(str(value or "").split())
    return text if len(text) <= maximum else text[: maximum - 1].rstrip() + "…"


def _flag_rgb(language: str, width: int = 42, height: int = 26) -> bytes:
    language = str(language or "DE").upper()
    data = bytearray()
    for y in range(height):
        for x in range(width):
            nx = x / max(1, width - 1)
            ny = y / max(1, height - 1)
            if language == "CZ":
                color = (248, 248, 248) if ny < 0.5 else (215, 20, 26)
                if nx <= 0.5 * (1.0 - abs(2.0 * ny - 1.0)):
                    color = (17, 69, 126)
            elif language == "EN":
                color = (33, 70, 139)
                if abs(ny - nx) <= 0.13 or abs(ny - (1.0 - nx)) <= 0.13:
                    color = (247, 247, 247)
                if abs(ny - nx) <= 0.05 or abs(ny - (1.0 - nx)) <= 0.05:
                    color = (207, 20, 43)
                if abs(nx - 0.5) <= 0.13 or abs(ny - 0.5) <= 0.20:
                    color = (247, 247, 247)
                if abs(nx - 0.5) <= 0.06 or abs(ny - 0.5) <= 0.09:
                    color = (207, 20, 43)
            else:
                color = (20, 20, 20) if ny < 1 / 3 else (221, 30, 47) if ny < 2 / 3 else (245, 202, 40)
            data.extend(color)
    return bytes(data)


def flag_pixbuf(language: str, width: int = 42, height: int = 26) -> GdkPixbuf.Pixbuf:
    raw = GLib.Bytes.new(_flag_rgb(language, width, height))
    return GdkPixbuf.Pixbuf.new_from_bytes(raw, GdkPixbuf.Colorspace.RGB, False, 8, width, height, width * 3)


class BatteryHistoryArea(Gtk.DrawingArea):
    """Drawing widget that owns its render pass on all supported GTK 3 builds."""

    def __init__(self, draw_callback: Callable[[Gtk.DrawingArea, object], bool]) -> None:
        super().__init__()
        self._draw_callback = draw_callback
        self.set_app_paintable(True)
        self.get_style_context().add_class("battery-chart")

    def do_draw(self, context) -> bool:
        self._draw_callback(self, context)
        # The chart paints its full allocation. Stopping propagation prevents
        # some live-system themes from painting their background over it.
        return True


class HardwareCheckV5(Gtk.Application):
    """GTK shell using the proven v3 core functions without blocking startup."""

    UPDATE_PHASE_CLASSES = (
        "update-phase-red",
        "update-phase-gold",
        "update-phase-blue",
        "update-phase-purple",
    )

    NAV_ITEMS = (
        ("dashboard", "view-grid-symbolic", ("Übersicht", "Overview", "Přehled")),
        ("models", "system-search-symbolic", ("ModelFinder", "Model finder", "Vyhledávač modelů")),
        ("magic", "drive-harddisk-symbolic", ("Magic Image", "Magic Image", "Magic Image")),
        ("battery", "battery-symbolic", ("Akku-Test", "Battery test", "Test baterie")),
        ("print", "document-print-symbolic", ("Drucken", "Print", "Tisk")),
        ("reports", "folder-documents-symbolic", ("Reports", "Reports", "Reporty")),
        ("settings", "preferences-system-symbolic", ("Einstellungen", "Settings", "Nastavení")),
    )

    # User-facing milestones rather than a technical commit log. Keep this
    # list current whenever a stable HardwareCheck version is published.
    VERSION_HISTORY = (
        {
            "version": "V5.4.5",
            "date": "02.09.2026",
            "title": (
                "Acronis – verlässlicher Einmalstart",
                "Acronis – reliable one-time boot",
                "Acronis – spolehlivé jednorázové spuštění",
            ),
            "items": (
                (
                    "Acronis wird nur auf der tatsächlich gestarteten GRUB-Partition einmalig markiert. Alte Marker auf der anderen Bootpartition werden sicher entfernt.",
                    "Acronis is marked once only on the GRUB partition that actually booted. Stale markers on the other boot partition are safely removed.",
                    "Acronis se jednorázově označí pouze na skutečně spuštěném oddílu GRUB. Staré značky na druhém spouštěcím oddílu se bezpečně odstraní.",
                ),
                (
                    "Die Acronis-Startdatei wird bei Bedarf kurz schreibgeschützt geprüft, auch wenn die kleine Acronis-Partition nicht automatisch eingehängt wurde.",
                    "When needed, the Acronis boot file is checked briefly read-only even if the small Acronis partition was not mounted automatically.",
                    "V případě potřeby se spouštěcí soubor Acronis krátce ověří pouze pro čtení, i když malý oddíl Acronis nebyl automaticky připojen.",
                ),
            ),
        },
        {
            "version": "V5.4",
            "date": "17.08.2026",
            "title": ("Magic Image – sicherer Abgleich und universelles Layout", "Magic Image – safer validation and universal layout", "Magic Image – bezpečnější ověření a univerzální rozvržení"),
            "items": (
                (
                    "Config und tatsächliche Hardware werden vor einer Installation klar verglichen. Abweichungen bei Prozessor, Arbeitsspeicher, Speicherart/-größe oder Display bleiben sichtbar und müssen bewusst bestätigt werden.",
                    "Selected configuration and actual hardware are clearly compared before installation. Differences in processor, memory, storage type/size or display remain visible and require explicit confirmation.",
                    "Zvolená konfigurace a skutečný hardware se před instalací jasně porovnají. Odchylky procesoru, paměti, typu/velikosti úložiště nebo displeje zůstávají viditelné a vyžadují vědomé potvrzení.",
                ),
                (
                    "Fehlt eine moderne Magic-Config, wird ein vorhandenes klassisches Acronis-Image deutlich angezeigt, ohne die Magic-Image-Installation freizugeben.",
                    "If a modern Magic configuration is missing, an available classic Acronis image is clearly shown without enabling a Magic Image installation.",
                    "Pokud chybí moderní konfigurace Magic, dostupný klasický obraz Acronis se jasně zobrazí, aniž by se povolila instalace Magic Image.",
                ),
                (
                    "Die Oberfläche passt sich wieder an unterschiedliche Displaygrößen und Auflösungen an; Akku-Übersicht und Akku-Test bleiben dabei gut lesbar.",
                    "The interface again adapts to different display sizes and resolutions while keeping the battery overview and battery test readable.",
                    "Rozhraní se znovu přizpůsobuje různým velikostem a rozlišením displeje a přitom zachovává čitelnost přehledu a testu baterie.",
                ),
            ),
        },
        {
            "version": "V5.3",
            "date": "12.08.2026",
            "title": ("Magic Image – geprüfter Installationsablauf", "Magic Image – verified installation flow", "Magic Image – ověřený instalační postup"),
            "items": (
                (
                    "Magic Image verbindet die bewusst gewählte Config, das Clonezilla-Image und die interne Ziel-SSD in einem geprüften Ablauf.",
                    "Magic Image combines the deliberately selected config, Clonezilla image and internal target SSD in one verified workflow.",
                    "Magic Image spojuje vědomě vybranou konfiguraci, obraz Clonezilla a interní cílový SSD do jednoho ověřeného postupu.",
                ),
                (
                    "Clonezilla wird beim Öffnen der Seite automatisch nur lesend geprüft; die Ziel-SSD wird unmittelbar vor dem Restore erneut validiert.",
                    "Clonezilla is checked read-only automatically when the page opens; the target SSD is validated again directly before restore.",
                    "Clonezilla se při otevření stránky automaticky kontroluje pouze pro čtení; cílový SSD se ověří znovu bezprostředně před obnovením.",
                ),
                (
                    "Nach dem Restore wird die gewählte Config als einzeilige Übergabe an Windows übergeben, damit der vorhandene Treiber- und Abschlussablauf automatisch weiterläuft.",
                    "After restore, the selected config is handed to Windows as a single line so the existing driver and finishing workflow continues automatically.",
                    "Po obnovení se vybraná konfigurace předá Windows jako jeden řádek, aby stávající postup ovladačů a dokončení pokračoval automaticky.",
                ),
            ),
        },
        {
            "version": "V5.2",
            "date": "07.08.2026",
            "title": ("Sieben wählbare Oberflächen", "Seven selectable interfaces", "Sedm volitelných rozhraní"),
            "items": (
                (
                    "Original, Service Light, Werkstatt Pro und Blue Control bleiben erhalten.",
                    "Original, Service Light, Workshop Pro and Blue Control remain available.",
                    "Original, Service Light, Workshop Pro a Blue Control zůstávají k dispozici.",
                ),
                (
                    "Service Desk, Werkstatt-Konsole und Studio Panels ergänzen drei eigenständige Bedienstrukturen.",
                    "Service Desk, Workshop Console and Studio Panels add three independent interaction structures.",
                    "Service Desk, Workshop Console a Studio Panels přidávají tři samostatné struktury ovládání.",
                ),
                (
                    "Akzentfarben sind je Oberfläche speicherbar; ModelFinder, Akku-Test und alle Serviceseiten passen sich an.",
                    "Accent colours are stored per interface; ModelFinder, battery test and all service pages adapt.",
                    "Barvy zvýraznění se ukládají pro každé rozhraní; ModelFinder, test baterie i servisní stránky se přizpůsobí.",
                ),
                (
                    "Studio Panels besitzt eigene Modell-, Akku- und Ergebnisflächen ohne helle Standardrahmen.",
                    "Studio Panels has dedicated model, battery and result surfaces without bright default borders.",
                    "Studio Panels má vlastní plochy modelů, baterie a výsledků bez světlých výchozích rámečků.",
                ),
                (
                    "Abweichende Prozessoren werden klar erkannt und können nicht mehr als 100-%-Treffer erscheinen.",
                    "Different processors are clearly detected and can no longer appear as a 100% match.",
                    "Odlišné procesory jsou jasně rozpoznány a již se nemohou zobrazit jako 100% shoda.",
                ),
                (
                    "Studio Panels zeigt kompakte Modellkarten und einen animierten Akku-Ring mit Live-Verlauf.",
                    "Studio Panels shows compact model cards and an animated battery ring with live history.",
                    "Studio Panels zobrazuje kompaktní karty modelů a animovaný kruh baterie s živým průběhem.",
                ),
            ),
        },
        {
            "version": "V5.1",
            "date": "06.08.2026",
            "title": ("Akku-Werkstatttest", "Battery workshop test", "Dílenský test baterie"),
            "items": (
                (
                    "Adaptiver Lade-/Entladetest: mindestens 30 Minuten und 5 % Änderung, maximal 60 Minuten.",
                    "Adaptive charge/discharge test: at least 30 minutes and 5% change, maximum 60 minutes.",
                    "Adaptivní test nabíjení/vybíjení: nejméně 30 minut a změna 5 %, maximálně 60 minut.",
                ),
                (
                    "Klare Gesamtbewertung mit Handlungsempfehlung und automatischem Abbruch bei kritischen Auffälligkeiten.",
                    "Clear overall result with recommendation and automatic stop for critical anomalies.",
                    "Jasné celkové hodnocení s doporučením a automatickým ukončením při kritických odchylkách.",
                ),
                (
                    "Live-Akkuanzeige, Verlaufsgrafik, Restlaufzeit sowie verständlicher kompakter Druckbericht.",
                    "Live battery display, history chart, runtime estimate and a concise readable print report.",
                    "Živý stav baterie, graf průběhu, odhad výdrže a stručný srozumitelný tiskový report.",
                ),
                (
                    "Versionsverlauf direkt in den Einstellungen nachlesbar.",
                    "Version history can be read directly in Settings.",
                    "Historie verzí je dostupná přímo v nastavení.",
                ),
            ),
        },
        {
            "version": "V5.0",
            "date": "05.08.2026",
            "title": ("Neue native GTK-Oberfläche", "New native GTK interface", "Nové nativní rozhraní GTK"),
            "items": (
                (
                    "Modernes Werkstatt-Dashboard mit schneller Navigation und weiterhin schnellem Programmstart.",
                    "Modern workshop dashboard with quick navigation and fast application startup.",
                    "Moderní dílenský panel s rychlou navigací a rychlým spuštěním aplikace.",
                ),
                (
                    "Erweiterter ModelFinder: aktuelles Gerät, Familienvorschläge, Refurbished-Modelle und Mehrfachvergleich.",
                    "Expanded ModelFinder: current device, family suggestions, refurbished models and multi-model comparison.",
                    "Rozšířený ModelFinder: aktuální zařízení, návrhy řady, repasované modely a vícenásobné porovnání.",
                ),
                (
                    "WLAN-Schnellauswahl, automatische Wiederverbindung, Drucken, Reports und sichtbarer Updatefortschritt.",
                    "Quick Wi-Fi selection, automatic reconnect, printing, reports and visible update progress.",
                    "Rychlý výběr Wi-Fi, automatické opětovné připojení, tisk, reporty a viditelný průběh aktualizace.",
                ),
                (
                    "Die bewährte Legacy-Oberfläche bleibt als sicherer Rückfall verfügbar.",
                    "The proven legacy interface remains available as a safe fallback.",
                    "Osvědčené původní rozhraní zůstává k dispozici jako bezpečná záloha.",
                ),
            ),
        },
        {
            "version": "V4",
            "date": "2026",
            "title": ("Linux- und Update-Brückengeneration", "Linux and update bridge generation", "Generace Linuxu a aktualizačního mostu"),
            "items": (
                (
                    "Vierte interne Linux-/Stick-Generation als stabile technische Basis für HardwareCheck V5.",
                    "Fourth internal Linux/USB generation as the stable technical foundation for HardwareCheck V5.",
                    "Čtvrtá interní generace Linuxu/USB jako stabilní technický základ pro HardwareCheck V5.",
                ),
                (
                    "Sichere Updatebrücke von V3.78 zu V5; WLANs, Drucker, Datenbank, Reports und Geräteidentität bleiben erhalten.",
                    "Safe update bridge from V3.78 to V5 while preserving Wi-Fi, printers, database, reports and device identity.",
                    "Bezpečný aktualizační most z V3.78 na V5 se zachováním Wi-Fi, tiskáren, databáze, reportů a identity zařízení.",
                ),
            ),
        },
        {
            "version": "V3",
            "date": "2026",
            "title": ("Bewährte Werkstatt- und Legacy-Linie", "Proven workshop and legacy line", "Osvědčená dílenská a původní řada"),
            "items": (
                (
                    "Modelldatenbank, Modellvorschläge, Gerätestatus sowie sichere DB- und Programmupdates.",
                    "Model database, model suggestions, device status and safe database/application updates.",
                    "Databáze modelů, návrhy modelů, stav zařízení a bezpečné aktualizace databáze i programu.",
                ),
                (
                    "Gespeicherte WLAN-Profile mit automatischer Verbindung sowie Druckersuche und Druckerprofile.",
                    "Saved Wi-Fi profiles with automatic connection plus printer discovery and printer profiles.",
                    "Uložené profily Wi-Fi s automatickým připojením, vyhledávání tiskáren a profily tiskáren.",
                ),
                (
                    "Robustere Hardwareerkennung, beschreibbare USB-Pfade, Reports und Bedienung in DE/EN/CZ.",
                    "More robust hardware detection, writable USB paths, reports and DE/EN/CZ operation.",
                    "Robustnější detekce hardwaru, zapisovatelné cesty USB, reporty a ovládání v DE/EN/CZ.",
                ),
                (
                    "V3.78 ist die letzte stabile klassische Oberfläche und bleibt in V5 weiterhin aufrufbar.",
                    "V3.78 is the final stable classic interface and remains accessible from V5.",
                    "V3.78 je poslední stabilní klasické rozhraní a zůstává dostupné z V5.",
                ),
            ),
        },
        {
            "version": "V2",
            "date": "Grundgeneration",
            "title": ("Ausbau zum Werkstattwerkzeug", "Expansion into a workshop tool", "Rozšíření na dílenský nástroj"),
            "items": (
                (
                    "Erweiterte Erkennung von CPU, RAM, Speicher, Anzeige und Geräteidentifikation.",
                    "Expanded detection of CPU, RAM, storage, display and device identity.",
                    "Rozšířená detekce CPU, RAM, úložiště, displeje a identity zařízení.",
                ),
                (
                    "Übersichtlichere Ergebnisse und speicherbare Werkstattberichte.",
                    "Clearer results and savable workshop reports.",
                    "Přehlednější výsledky a ukládatelné dílenské reporty.",
                ),
            ),
        },
        {
            "version": "V1",
            "date": "Start",
            "title": ("Erste HardwareCheck-Version", "First HardwareCheck version", "První verze HardwareCheck"),
            "items": (
                (
                    "Automatischer Hardware-Scan für den schnellen Notebook- und PC-Eingangstest.",
                    "Automatic hardware scan for quick incoming notebook and PC checks.",
                    "Automatické skenování hardwaru pro rychlou vstupní kontrolu notebooků a PC.",
                ),
                (
                    "Grundlegende Systemübersicht als Basis für alle späteren Werkstattfunktionen.",
                    "Basic system overview as the foundation for all later workshop functions.",
                    "Základní přehled systému jako základ všech pozdějších dílenských funkcí.",
                ),
            ),
        },
    )

    def __init__(self, core) -> None:
        super().__init__(application_id=APP_ID, flags=0)
        self.core = core
        try:
            self.language = core.LANGUAGES[core.load_language_index()]
        except Exception:
            self.language = "DE"
        try:
            appearance_settings = core.load_settings()
        except Exception:
            appearance_settings = {}
        self.appearance_layout = str(appearance_settings.get("v5_layout") or "original").strip().lower()
        if self.appearance_layout not in APPEARANCE_LAYOUTS:
            self.appearance_layout = "original"
        saved_colors = appearance_settings.get("v5_layout_colors")
        if not isinstance(saved_colors, dict):
            saved_colors = {}
        self.appearance_colors = {
            name: _valid_hex_color(saved_colors.get(name), APPEARANCE_DEFAULT_ACCENTS[name])
            for name in APPEARANCE_LAYOUTS
        }
        self.appearance_accent = self.appearance_colors[self.appearance_layout]
        if self.appearance_layout == "studio-panels":
            self.appearance_navigation = "bottom"
        elif self.appearance_layout in {"service-light", "blue-control", "service-desk"}:
            self.appearance_navigation = "top"
        else:
            self.appearance_navigation = "left"
        self.screen_width = 1366
        self.screen_height = 768
        self.compact_screen = False
        self.narrow_screen = False
        self.window: Gtk.ApplicationWindow | None = None
        self.stack: Gtk.Stack | None = None
        self.nav_buttons: dict[str, Gtk.Button] = {}
        self.pages: dict[str, Gtk.Widget] = {}
        self.current_page = "dashboard"
        self.snapshot: dict[str, object] = {}
        self.models: list[dict[str, object]] = []
        self.match_results: list[dict[str, object]] = []
        self._model_relation_map: dict[str, tuple[list[str], list[str]]] = {}
        self._model_selected_ids: list[str] = []
        self._model_visible_results: list[tuple[int, dict[str, object]]] = []
        self._model_option_bindings: list[dict[str, object]] = []
        self._model_selection_syncing = False
        self._busy_count = 0
        self._refresh_tasks: set[str] = set()
        self._battery_samples: list[dict[str, object]] = []
        self._battery_mode = ""
        self._battery_csv_path: pathlib.Path | None = None
        self._battery_timer_id: int | None = None
        self._battery_display_details: dict[str, object] = {}
        self._battery_last_metrics: dict[str, object] = {}
        self._battery_last_result: dict[str, object] = {}
        self._battery_last_report_path: pathlib.Path | None = None
        self._battery_chart_signature = ""
        self._dashboard_battery_animation_timer_id: int | None = None
        self._printer_results: list[dict[str, object]] = []
        self._report_paths: list[pathlib.Path] = []
        self._wifi_autoconnect_started = False
        self._wifi_connection_busy = False
        self._wifi_connected_ssid = ""
        self._wifi_quick_networks: list[dict[str, str]] = []
        self._auto_update_check_started = False
        self._update_operation = ""
        self._db_update_available = False
        self._program_update_available = False
        self._update_alert_demo = False
        self._update_alert_timer_id: int | None = None
        self._update_alert_phase = 0
        self._update_progress_determinate = False
        self._build_refs: dict[str, object] = {}
        self._magic_inspection = magic.MediaInspection()
        self._magic_images_by_id: dict[str, magic.MagicImage] = {}
        self._magic_targets_by_path: dict[str, magic.BlockDevice] = {}
        self._magic_data_disks_by_path: dict[str, magic.BlockDevice] = {}
        self._magic_config_validation: magic.ConfigValidation | None = None
        self._magic_classic_acronis_by_config: dict[str, tuple[magic.ClassicAcronisImage, ...]] = {}
        self._magic_scan_pending = False
        self._magic_engine_pending = False
        self._magic_restore_plan: magic.RestoreProofPlan | None = None
        self._magic_data_disk_plan: magic.DataDiskPreparePlan | None = None
        self._magic_restore_pending = False
        self._magic_restore_completed = False
        self._magic_post_restore_action = "reboot"
        self._magic_last_warning_config = ""
        self._magic_config_warning_acknowledged = ""
        self._magic_config_validate_timer_id: int | None = None
        self._magic_config_server_pending = ""
        self._magic_config_server_checked: set[str] = set()

    def _t(self, de: str, en: str, cz: str) -> str:
        return {"DE": de, "EN": en, "CZ": cz}.get(self.language, de)

    def do_activate(self) -> None:
        if self.window is not None:
            self.window.present()
            return
        screen = Gdk.Screen.get_default()
        try:
            display = Gdk.Display.get_default()
            monitor = display.get_primary_monitor() if display is not None else None
            geometry = monitor.get_geometry() if monitor is not None else None
            if geometry is not None:
                self.screen_width = int(geometry.width)
                self.screen_height = int(geometry.height)
            elif screen is not None:
                self.screen_width = int(screen.get_width())
                self.screen_height = int(screen.get_height())
        except Exception:
            if screen is not None:
                self.screen_width = int(screen.get_width())
                self.screen_height = int(screen.get_height())
        self.compact_screen, self.narrow_screen = screen_layout_flags(self.screen_width, self.screen_height)

        provider = Gtk.CssProvider()
        provider.load_from_data(CSS + appearance_css(self.appearance_layout, self.appearance_accent) + RESPONSIVE_CSS)
        Gtk.StyleContext.add_provider_for_screen(screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        self.window = Gtk.ApplicationWindow(application=self)
        self.window.set_title(f"HardwareCheck {self.core.APP_VERSION}")
        self.window.set_default_size(1366, 820)
        self.window.set_size_request(900, 600)
        self.window.get_style_context().add_class("app-root")
        self.window.get_style_context().add_class(f"layout-{self.appearance_layout}")
        if self.compact_screen:
            self.window.get_style_context().add_class("compact-screen")
        if self.narrow_screen:
            self.window.get_style_context().add_class("narrow-screen")
        if os.environ.get("HC_V5_WINDOWED") == "1":
            self.window.set_position(Gtk.WindowPosition.CENTER)
        else:
            self.window.fullscreen()

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.window.add(root)
        root.pack_start(self._build_topbar(), False, False, 0)

        middle = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        middle.set_hexpand(True)
        middle.set_vexpand(True)
        navigation = self._build_sidebar(horizontal=self.appearance_navigation != "left")
        if self.appearance_navigation == "top":
            root.pack_start(navigation, False, False, 0)
        root.pack_start(middle, True, True, 0)
        if self.appearance_navigation == "left":
            middle.pack_start(navigation, False, False, 0)

        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE, transition_duration=180)
        self.stack.set_hexpand(True)
        self.stack.set_vexpand(True)
        # Dashboard pages are adaptive and used to have no scroll container.
        # Wrapping the complete stack keeps every page reachable on HD/HD+
        # monitors while preserving its responsive layout on larger displays.
        # Some complex views still have a legitimate minimum width (for
        # example comparison tables).  An automatic horizontal scrollbar is
        # the safety net: no layout may ever be silently clipped at the right
        # edge just because it is wider than the current panel.
        stack_scroll = Gtk.ScrolledWindow()
        stack_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        stack_scroll.set_overlay_scrolling(False)
        stack_scroll.set_hexpand(True)
        stack_scroll.set_vexpand(True)
        stack_scroll.add(self.stack)
        middle.pack_start(stack_scroll, True, True, 0)
        self._build_pages()
        if self.appearance_navigation == "bottom":
            root.pack_start(navigation, False, False, 0)
        root.pack_end(self._build_footer(), False, False, 0)

        self.window.show_all()
        self._restore_battery_test()
        self.show_page("dashboard")
        GLib.timeout_add_seconds(1, self._clock_tick)
        GLib.timeout_add_seconds(2, self._battery_refresh_tick)
        if self._dashboard_battery_animation_timer_id is None:
            self._dashboard_battery_animation_timer_id = GLib.timeout_add(140, self._dashboard_battery_animation_tick)
        GLib.idle_add(self._start_initial_load)

    # ---------- shared widgets ----------

    def _icon(self, name: str, size: Gtk.IconSize = Gtk.IconSize.BUTTON) -> Gtk.Image:
        return Gtk.Image.new_from_icon_name(name, size)

    def _label(self, text: str = "", css: str = "", xalign: float = 0.0, wrap: bool = False) -> Gtk.Label:
        label = Gtk.Label(label=text, xalign=xalign)
        if css:
            label.get_style_context().add_class(css)
        label.set_line_wrap(wrap)
        label.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
        label.set_selectable(False)
        return label

    def _button(self, text: str, callback: Callable, css: str = "secondary-button", icon: str = "") -> Gtk.Button:
        button = Gtk.Button()
        button.get_style_context().add_class(css)
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        box.set_halign(Gtk.Align.CENTER)
        if icon:
            box.pack_start(self._icon(icon), False, False, 0)
        box.pack_start(self._label(text), False, False, 0)
        button.add(box)
        button.connect("clicked", callback)
        return button

    def _page_shell(self, title: str, subtitle: str, adaptive: bool = False) -> tuple[Gtk.Widget, Gtk.Box]:
        if self.appearance_layout == "studio-panels":
            subtitle = ""
        page: Gtk.Widget
        if adaptive:
            page_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            page_box.set_hexpand(True)
            page_box.set_vexpand(True)
            page_box.get_style_context().add_class("content")
            page = page_box
        else:
            scroll = Gtk.ScrolledWindow()
            scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            scroll.get_style_context().add_class("content")
            page = scroll
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        outer.set_hexpand(True)
        outer.set_vexpand(True)
        outer.set_margin_start(16 if adaptive else 22)
        outer.set_margin_end(16 if adaptive else 22)
        outer.set_margin_top(10 if adaptive else 18)
        outer.set_margin_bottom(8 if adaptive else 22)
        outer.pack_start(self._label(title, "page-title"), False, False, 0)
        if subtitle:
            outer.pack_start(self._label(subtitle, "page-subtitle", wrap=True), False, False, 2)
        if adaptive:
            page_box.pack_start(outer, True, True, 0)
        else:
            scroll.add(outer)
        return page, outer

    def _card(self, title: str, value: str = "–", subtitle: str = "", icon: str = "computer-symbolic") -> tuple[Gtk.Frame, Gtk.Label, Gtk.Label]:
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.NONE)
        frame.set_size_request(205 if self.compact_screen else 245, 94 if self.compact_screen else 128)
        frame.get_style_context().add_class("card")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        frame.add(box)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        image = self._icon(icon, Gtk.IconSize.LARGE_TOOLBAR)
        image.get_style_context().add_class("card-icon")
        top.pack_start(image, False, False, 0)
        top.pack_start(self._label(title, "card-title"), True, True, 0)
        box.pack_start(top, False, False, 0)
        value_label = self._label(value, "card-value", wrap=True)
        value_label.set_ellipsize(Pango.EllipsizeMode.END)
        box.pack_start(value_label, True, True, 0)
        subtitle_label = self._label(subtitle, "card-subtitle", wrap=True)
        box.pack_start(subtitle_label, False, False, 0)
        return frame, value_label, subtitle_label

    def _section(self, parent: Gtk.Box, title: str, margin_top: int = 16, expand: bool = False) -> Gtk.Box:
        title_label = self._label(title, "section-title")
        title_label.set_margin_top(margin_top)
        parent.pack_start(title_label, False, False, 4)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_vexpand(expand)
        parent.pack_start(box, expand, expand, 0)
        return box

    def _flow(self) -> Gtk.FlowBox:
        flow = Gtk.FlowBox()
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_row_spacing(8 if self.compact_screen else 12)
        flow.set_column_spacing(8 if self.compact_screen else 12)
        flow.set_homogeneous(True)
        flow.set_max_children_per_line(6 if self.compact_screen else 4)
        flow.set_min_children_per_line(1)
        return flow

    # ---------- application chrome ----------

    def _build_topbar(self) -> Gtk.Widget:
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4 if self.narrow_screen else 8 if self.compact_screen else 16)
        bar.get_style_context().add_class("topbar")
        brand_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        brand_box.pack_start(self._label("HardwareCheck", "brand"), False, False, 0)
        brand_box.pack_start(self._label(f"VERSION {self.core.APP_VERSION.upper()} · LIVE", "version"), False, False, 0)
        bar.pack_start(brand_box, False, False, 0)

        self._build_refs["top_spinner"] = Gtk.Spinner()
        bar.pack_start(self._build_refs["top_spinner"], False, False, 0)
        bar.pack_start(Gtk.Box(), True, True, 0)

        network_button = self._build_wifi_quick_menu()
        update_button = self._build_update_alert_button()
        self._build_refs["db_chip"] = self._label("DB: –", "status-chip")
        self._build_refs["battery_chip"] = self._label(self._t("Akku: –", "Battery: –", "Baterie: –"), "status-chip")
        self._build_refs["clock"] = self._label("", "status-chip")
        if self.compact_screen:
            limits = (("db_chip", 16), ("battery_chip", 18), ("clock", 13))
            if self.narrow_screen:
                limits = (("db_chip", 12), ("battery_chip", 14), ("clock", 10))
            for key, maximum in limits:
                self._build_refs[key].set_max_width_chars(maximum)
                self._build_refs[key].set_ellipsize(Pango.EllipsizeMode.END)
        if self.narrow_screen:
            # GTK otherwise keeps natural minimum widths for these header
            # controls and can push the last control beyond a small monitor.
            # Their labels already ellipsize, so allowing shrink is safe.
            for widget in (network_button, update_button, self._build_refs["db_chip"], self._build_refs["battery_chip"], self._build_refs["clock"]):
                widget.set_size_request(0, -1)
        bar.pack_start(network_button, False, False, 0)
        bar.pack_start(update_button, False, False, 0)
        for key in ("db_chip", "battery_chip", "clock"):
            bar.pack_start(self._build_refs[key], False, False, 0)
        if self.appearance_navigation != "left":
            bar.pack_start(self._build_power_menu(), False, False, 0)
        return bar

    def _build_update_alert_button(self) -> Gtk.Button:
        button = Gtk.Button()
        button.get_style_context().add_class("update-alert")
        button.set_no_show_all(True)
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=3 if self.narrow_screen else 7)
        inner.pack_start(self._icon("software-update-available-symbolic"), False, False, 0)
        label = self._label(self._t("UPDATE VERFÜGBAR", "UPDATE AVAILABLE", "AKTUALIZACE K DISPOZICI"))
        if self.compact_screen:
            label.set_max_width_chars(14 if self.narrow_screen else 18)
            label.set_ellipsize(Pango.EllipsizeMode.END)
        inner.pack_start(label, False, False, 0)
        button.add(inner)
        button.connect("clicked", self._open_update_settings)
        self._build_refs["update_alert_button"] = button
        self._build_refs["update_alert_label"] = label
        return button

    def _build_wifi_quick_menu(self) -> Gtk.MenuButton:
        button = Gtk.MenuButton()
        button.get_style_context().add_class("status-chip")
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=3 if self.narrow_screen else 7)
        inner.pack_start(self._icon("network-wireless-symbolic"), False, False, 0)
        label = self._label(self._t("WLAN wird geprüft", "Checking Wi-Fi", "Kontrola Wi-Fi"))
        if self.compact_screen:
            label.set_max_width_chars(12 if self.narrow_screen else 16)
            label.set_ellipsize(Pango.EllipsizeMode.END)
        inner.pack_start(label, False, False, 0)
        button.add(inner)

        popover = Gtk.Popover.new(button)
        popover.get_style_context().add_class("dark-popover")
        popover.get_style_context().add_class(f"layout-{self.appearance_layout}")
        popover.set_size_request(440, 430)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        content.set_margin_start(12)
        content.set_margin_end(12)
        content.set_margin_top(12)
        content.set_margin_bottom(12)

        heading = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        heading.pack_start(self._label("WLAN", "section-title"), True, True, 0)
        heading.pack_end(
            self._button(
                self._t("Aktualisieren", "Refresh", "Obnovit"),
                lambda _b: self._refresh_wifi_quick_menu(force=True),
                "secondary-button",
                "view-refresh-symbolic",
            ),
            False,
            False,
            0,
        )
        content.pack_start(heading, False, False, 0)
        quick_status = self._label(self._t("Verbindung wird geprüft …", "Checking connection …", "Kontrola připojení …"), "muted", wrap=True)
        content.pack_start(quick_status, False, False, 0)

        quick_list = Gtk.ListBox()
        quick_list.set_selection_mode(Gtk.SelectionMode.NONE)
        quick_scroll = Gtk.ScrolledWindow()
        quick_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        quick_scroll.set_min_content_height(270)
        quick_scroll.add(quick_list)
        content.pack_start(quick_scroll, True, True, 0)
        content.pack_start(
            self._button(
                self._t("Gespeicherte WLANs verwalten", "Manage saved Wi-Fi", "Spravovat uložené Wi-Fi"),
                lambda _b: self._open_settings_tool("wifi", popover),
                "secondary-button",
                "preferences-system-symbolic",
            ),
            False,
            False,
            0,
        )
        popover.add(content)
        content.show_all()
        button.set_popover(popover)
        button.connect("toggled", self._wifi_quick_toggled)
        self._build_refs["network_chip_button"] = button
        self._build_refs["network_chip"] = label
        self._build_refs["wifi_quick_popover"] = popover
        self._build_refs["wifi_quick_status"] = quick_status
        self._build_refs["wifi_quick_list"] = quick_list
        return button

    def _build_sidebar(self, horizontal: bool = False) -> Gtk.Widget:
        orientation = Gtk.Orientation.HORIZONTAL if horizontal else Gtk.Orientation.VERTICAL
        side = Gtk.Box(orientation=orientation, spacing=2)
        side.set_size_request(-1 if horizontal else 225, -1)
        side.get_style_context().add_class("sidebar")
        if horizontal:
            side.get_style_context().add_class(
                "bottom-navigation" if self.appearance_navigation == "bottom" else "top-navigation"
            )
        for name, icon, texts in self.NAV_ITEMS:
            button = Gtk.Button()
            button.get_style_context().add_class("nav-button")
            inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            inner.pack_start(self._icon(icon, Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            label = self._label(self._t(*texts))
            if horizontal and self.narrow_screen:
                button.set_size_request(0, -1)
                label.set_max_width_chars(10)
                label.set_ellipsize(Pango.EllipsizeMode.END)
            inner.pack_start(label, True, True, 0)
            button.add(inner)
            button.connect("clicked", lambda _button, page=name: self.show_page(page))
            side.pack_start(button, horizontal, horizontal, 0)
            self.nav_buttons[name] = button
            self._build_refs[f"nav_label_{name}"] = label
        if not horizontal:
            side.pack_start(Gtk.Box(), True, True, 0)
        battery_monitor = Gtk.Frame()
        battery_monitor.set_shadow_type(Gtk.ShadowType.NONE)
        battery_monitor.get_style_context().add_class("battery-mini-panel")
        battery_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        battery_monitor.add(battery_box)
        battery_head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        battery_head.pack_start(self._icon("battery-symbolic"), False, False, 0)
        battery_title = self._label(self._t("Akku-Test bereit", "Battery test ready", "Test baterie připraven"), "battery-mini-title", wrap=True)
        battery_head.pack_start(battery_title, True, True, 0)
        battery_value = self._label("–", "battery-mini-value")
        battery_head.pack_end(battery_value, False, False, 0)
        battery_box.pack_start(battery_head, False, False, 0)
        battery_level = Gtk.LevelBar.new_for_interval(0, 100)
        battery_box.pack_start(battery_level, False, False, 0)
        battery_subtitle = self._label("", "battery-mini-subtitle", wrap=True)
        battery_box.pack_start(battery_subtitle, False, False, 0)
        battery_monitor.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        battery_monitor.connect("button-press-event", lambda *_args: self.show_page("battery"))
        if not horizontal:
            side.pack_start(battery_monitor, False, False, 0)
        self._build_refs["battery_mini_panel"] = battery_monitor
        self._build_refs["battery_mini_title"] = battery_title
        self._build_refs["battery_mini_value"] = battery_value
        self._build_refs["battery_mini_level"] = battery_level
        self._build_refs["battery_mini_subtitle"] = battery_subtitle
        if not horizontal:
            side.pack_start(self._label(self._t("Native GTK-Oberfläche", "Native GTK interface", "Nativní rozhraní GTK"), "version", wrap=True), False, False, 8)
            side.pack_start(self._build_power_menu(), False, False, 0)
        return side

    def _build_power_menu(self) -> Gtk.MenuButton:
        button = Gtk.MenuButton()
        button.get_style_context().add_class("danger-button")
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=3 if self.narrow_screen else 7)
        inner.set_halign(Gtk.Align.CENTER)
        inner.pack_start(self._icon("system-shutdown-symbolic"), False, False, 0)
        power_label = self._t("Ein/Aus", "Power", "Napájení")
        inner.pack_start(self._label("" if self.narrow_screen else power_label), False, False, 0)
        button.add(inner)
        button.set_tooltip_text(power_label)
        if self.narrow_screen:
            button.set_size_request(0, -1)

        popover = Gtk.Popover.new(button)
        popover.get_style_context().add_class("dark-popover")
        popover.get_style_context().add_class(f"layout-{self.appearance_layout}")
        actions = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        actions.set_margin_start(6)
        actions.set_margin_end(6)
        actions.set_margin_top(6)
        actions.set_margin_bottom(6)
        actions.pack_start(
            self._button(
                self._t("Herunterfahren", "Shut down", "Vypnout"),
                lambda _b: self._power_menu_action("poweroff", popover),
                "secondary-button",
                "system-shutdown-symbolic",
            ),
            False,
            False,
            0,
        )
        actions.pack_start(
            self._button(
                self._t("Neu starten", "Restart", "Restartovat"),
                lambda _b: self._power_menu_action("reboot", popover),
                "secondary-button",
                "view-refresh-symbolic",
            ),
            False,
            False,
            0,
        )
        popover.add(actions)
        actions.show_all()
        button.set_popover(popover)
        self._build_refs["power_menu"] = popover
        return button

    def _build_footer(self) -> Gtk.Widget:
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        footer.get_style_context().add_class("footer")
        self._build_refs["footer_box"] = footer
        self._build_refs["footer_icon"] = self._icon("emblem-system-symbolic")
        self._build_refs["footer_status"] = self._label(self._t("v5 wird gestartet …", "Starting v5 …", "Spouštění v5 …"), wrap=True)
        footer.pack_start(self._build_refs["footer_icon"], False, False, 0)
        footer.pack_start(self._build_refs["footer_status"], True, True, 0)
        self._build_refs["footer_progress"] = Gtk.ProgressBar()
        self._build_refs["footer_progress"].set_size_request(170, -1)
        self._build_refs["footer_progress"].set_no_show_all(True)
        footer.pack_end(self._build_refs["footer_progress"], False, False, 0)
        return footer

    def _build_pages(self) -> None:
        builders = {
            "dashboard": self._build_dashboard,
            "models": self._build_models_page,
            "magic": self._build_magic_image_page,
            "battery": self._build_battery_page,
            "wifi": self._build_wifi_page,
            "printers": self._build_printers_page,
            "print": self._build_print_page,
            "reports": self._build_reports_page,
            "settings": self._build_settings_page,
        }
        for name, builder in builders.items():
            page = builder()
            self.pages[name] = page
            self.stack.add_named(page, name)

    def show_page(self, name: str) -> None:
        if self.stack is None or name not in self.pages:
            return
        self.current_page = name
        self.stack.set_visible_child_name(name)
        active_nav = "settings" if name in {"wifi", "printers"} else name
        for key, button in self.nav_buttons.items():
            context = button.get_style_context()
            if key == active_nav:
                context.add_class("active")
            else:
                context.remove_class("active")
        if name == "wifi":
            self._refresh_wifi_saved_rows()
        elif name == "printers":
            self._refresh_printer_profiles()
        elif name == "print":
            self._refresh_print_page()
        elif name == "reports":
            self._refresh_reports()
        elif name == "models":
            self._refresh_model_table()
        elif name == "magic" and not self._magic_scan_pending:
            self._magic_refresh_clicked()

    # ---------- dashboard ----------

    def _studio_greeting(self) -> str:
        greetings = (
            self._t("Guten Tag, schön, dass du da bist.", "Hello, nice to have you here.", "Dobrý den, jsme rádi, že jste tady."),
            self._t("Guten Tag, wird Zeit, dass du mal was machst.", "Hello, time to get something done.", "Dobrý den, je čas něco udělat."),
            self._t("Guten Tag, der nächste Laptop wartet schon.", "Hello, the next laptop is already waiting.", "Dobrý den, další notebook už čeká."),
            self._t("Guten Tag, Kaffee bereit? Dann kann es losgehen.", "Hello, coffee ready? Then let's get started.", "Dobrý den, káva připravena? Můžeme začít."),
            self._t("Guten Tag, heute finden wir jeden Fehler.", "Hello, today we will find every fault.", "Dobrý den, dnes najdeme každou závadu."),
            self._t("Guten Tag, die Werkstatt zählt auf dich.", "Hello, the workshop is counting on you.", "Dobrý den, dílna na vás spoléhá."),
        )
        return random.choice(greetings)

    def _build_dashboard(self) -> Gtk.Widget:
        if self.appearance_layout == "service-desk":
            return self._build_dashboard_service_desk()
        if self.appearance_layout == "workshop-console":
            return self._build_dashboard_workshop_console()
        if self.appearance_layout == "studio-panels":
            return self._build_dashboard_studio_panels()
        return self._build_dashboard_classic()

    def _build_dashboard_classic(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Werkstatt-Dashboard", "Workshop dashboard", "Dílenský přehled"),
            "",
            adaptive=True,
        )
        outer.get_style_context().add_class("dashboard-page")
        hero = Gtk.Frame()
        hero.set_shadow_type(Gtk.ShadowType.NONE)
        hero.get_style_context().add_class("hero")
        hero_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hero.add(hero_box)
        hero_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self._build_refs["hero_title"] = self._label(self._t("Gerät wird erkannt …", "Detecting device …", "Rozpoznávání zařízení …"), "hero-title", wrap=True)
        self._build_refs["hero_subtitle"] = self._label(self._t("Die Oberfläche ist bereits bereit; der Hardware-Scan läuft im Hintergrund.", "The interface is ready while hardware scanning continues in the background.", "Rozhraní je připraveno, sken hardwaru probíhá na pozadí."), "hero-subtitle", wrap=True)
        hero_text.pack_start(self._build_refs["hero_title"], False, False, 0)
        hero_text.pack_start(self._build_refs["hero_subtitle"], False, False, 0)
        hero_box.pack_start(hero_text, True, True, 0)
        hero_box.pack_end(self._button(self._t("Neu scannen", "Scan again", "Skenovat znovu"), self._rescan_clicked, "primary-button", "view-refresh-symbolic"), False, False, 0)
        outer.pack_start(hero, False, False, 12)

        metrics = self._section(outer, self._t("Systemübersicht", "System overview", "Přehled systému"))
        flow = self._flow()
        metrics.pack_start(flow, False, False, 0)
        card_specs = (
            ("system", self._t("Gerät", "Device", "Zařízení"), "computer-symbolic"),
            ("cpu", "CPU", "cpu-symbolic"),
            ("ram", "RAM", "drive-harddisk-symbolic"),
            ("storage", self._t("Speicher", "Storage", "Úložiště"), "drive-harddisk-symbolic"),
            ("display", self._t("Anzeige", "Display", "Displej"), "video-display-symbolic"),
            ("match", self._t("Bester Modelltreffer", "Best model match", "Nejlepší shoda modelu"), "system-search-symbolic"),
        )
        for key, title, icon in card_specs:
            card, value, subtitle = self._card(title, icon=icon)
            flow.add(card)
            self._build_refs[f"metric_{key}"] = value
            self._build_refs[f"metric_{key}_sub"] = subtitle

        battery_live = Gtk.Frame()
        battery_live.set_shadow_type(Gtk.ShadowType.NONE)
        battery_live.get_style_context().add_class("battery-live-panel")
        battery_live.set_no_show_all(True)
        battery_live.hide()
        battery_live_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        battery_live.add(battery_live_row)
        battery_live_row.pack_start(self._icon("battery-good-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        battery_live_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        dashboard_battery_title = self._label("", "battery-live-title", wrap=True)
        dashboard_battery_subtitle = self._label("", "battery-live-subtitle", wrap=True)
        battery_live_text.pack_start(dashboard_battery_title, False, False, 0)
        battery_live_text.pack_start(dashboard_battery_subtitle, False, False, 0)
        battery_live_row.pack_start(battery_live_text, True, True, 0)
        dashboard_battery_level = Gtk.LevelBar.new_for_interval(0, 100)
        dashboard_battery_level.get_style_context().add_class("dashboard-battery-level")
        dashboard_battery_level.set_size_request(120, 10)
        dashboard_battery_value = self._label("–", "dashboard-battery-value", xalign=1.0)
        battery_live_row.pack_start(dashboard_battery_value, False, False, 0)
        battery_live_row.pack_start(dashboard_battery_level, False, False, 0)
        battery_live_row.pack_end(
            self._button(self._t("Akku-Test öffnen", "Open battery test", "Otevřít test baterie"), lambda _b: self.show_page("battery"), "secondary-button", "go-next-symbolic"),
            False,
            False,
            0,
        )
        outer.pack_start(battery_live, False, False, 12)
        self._build_refs["dashboard_battery_live"] = battery_live
        self._build_refs["dashboard_battery_title"] = dashboard_battery_title
        self._build_refs["dashboard_battery_subtitle"] = dashboard_battery_subtitle
        self._build_refs["dashboard_battery_level"] = dashboard_battery_level
        self._build_refs["dashboard_battery_value"] = dashboard_battery_value

        suggestions = self._section(outer, self._t("Modellvorschläge", "Model suggestions", "Návrhy modelů"))
        self._build_refs["dashboard_model_count"] = self._label(
            self._t("Hardware wird ausgewertet …", "Evaluating hardware …", "Vyhodnocování hardwaru …"),
            "muted",
        )
        suggestions.pack_start(self._build_refs["dashboard_model_count"], False, False, 0)
        self._build_refs["dashboard_model_list"] = Gtk.ListBox()
        self._build_refs["dashboard_model_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        suggestion_scroll = Gtk.ScrolledWindow()
        suggestion_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        suggestion_scroll.set_min_content_height(125 if self.compact_screen else 220)
        suggestion_scroll.set_vexpand(True)
        suggestion_scroll.add(self._build_refs["dashboard_model_list"])
        suggestions.pack_start(suggestion_scroll, True, True, 0)
        return page

    def _dashboard_value_block(self, key: str, title: str, icon: str = "") -> Gtk.Widget:
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.NONE)
        frame.get_style_context().add_class("studio-panel")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        frame.add(box)
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
        if icon:
            image = self._icon(icon, Gtk.IconSize.LARGE_TOOLBAR)
            image.get_style_context().add_class("card-icon")
            head.pack_start(image, False, False, 0)
        head.pack_start(self._label(title, "card-title"), True, True, 0)
        box.pack_start(head, False, False, 0)
        value = self._label("–", "card-value", wrap=True)
        subtitle = self._label("", "card-subtitle", wrap=True)
        box.pack_start(value, True, True, 0)
        box.pack_start(subtitle, False, False, 0)
        self._build_refs[f"metric_{key}"] = value
        self._build_refs[f"metric_{key}_sub"] = subtitle
        return frame

    def _build_dashboard_live_panel(self, outer: Gtk.Box) -> None:
        battery_live = Gtk.Frame()
        battery_live.set_shadow_type(Gtk.ShadowType.NONE)
        battery_live.get_style_context().add_class("battery-live-panel")
        battery_live.set_no_show_all(True)
        battery_live.hide()
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        battery_live.add(row)
        row.pack_start(self._icon("battery-good-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title = self._label("", "battery-live-title", wrap=True)
        subtitle = self._label("", "battery-live-subtitle", wrap=True)
        text.pack_start(title, False, False, 0)
        text.pack_start(subtitle, False, False, 0)
        row.pack_start(text, True, True, 0)
        level = Gtk.LevelBar.new_for_interval(0, 100)
        level.get_style_context().add_class("dashboard-battery-level")
        level.set_size_request(120, 10)
        level_value = self._label("–", "dashboard-battery-value", xalign=1.0)
        row.pack_start(level_value, False, False, 0)
        row.pack_start(level, False, False, 0)
        row.pack_end(
            self._button(
                self._t("Akku-Test öffnen", "Open battery test", "Otevřít test baterie"),
                lambda _button: self.show_page("battery"),
                "secondary-button",
                "go-next-symbolic",
            ),
            False,
            False,
            0,
        )
        outer.pack_start(battery_live, False, False, 12)
        self._build_refs["dashboard_battery_live"] = battery_live
        self._build_refs["dashboard_battery_title"] = title
        self._build_refs["dashboard_battery_subtitle"] = subtitle
        self._build_refs["dashboard_battery_level"] = level
        self._build_refs["dashboard_battery_value"] = level_value

    def _build_dashboard_suggestions(self, outer: Gtk.Box, minimum_height: int = 220, adaptive: bool = False) -> None:
        studio_cards = adaptive and self.appearance_layout == "studio-panels"
        if studio_cards:
            panel = Gtk.Frame()
            panel.set_shadow_type(Gtk.ShadowType.NONE)
            panel.set_vexpand(True)
            panel.get_style_context().add_class("studio-suggestions-panel")
            suggestions = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            panel.add(suggestions)
            suggestions.pack_start(
                self._label(self._t("MODELLVORSCHLÄGE", "MODEL SUGGESTIONS", "NÁVRHY MODELŮ"), "section-title"),
                False,
                False,
                0,
            )
            outer.pack_start(panel, True, True, 0)
        else:
            suggestions = self._section(
                outer,
                self._t("Modellvorschläge", "Model suggestions", "Návrhy modelů"),
                margin_top=8 if self.compact_screen else 16,
                expand=adaptive,
            )
        count = self._label(
            self._t("Hardware wird ausgewertet …", "Evaluating hardware …", "Vyhodnocování hardwaru …"),
            "muted",
        )
        if studio_cards:
            count.set_no_show_all(True)
            count.hide()
        suggestions.pack_start(count, False, False, 0)
        listbox = Gtk.ListBox()
        listbox.set_selection_mode(Gtk.SelectionMode.NONE)
        if studio_cards:
            listbox.get_style_context().add_class("studio-suggestion-list")
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(
            Gtk.PolicyType.NEVER,
            Gtk.PolicyType.AUTOMATIC,
        )
        if adaptive:
            scroll.set_overlay_scrolling(False)
        scroll.set_min_content_height(minimum_height)
        scroll.set_vexpand(True)
        scroll.add(listbox)
        suggestions.pack_start(scroll, True, True, 0)
        self._build_refs["dashboard_model_count"] = count
        self._build_refs["dashboard_model_list"] = listbox

    def _build_dashboard_studio_battery(self, outer: Gtk.Box) -> None:
        event_box = Gtk.EventBox()
        event_box.set_visible_window(False)
        event_box.connect("button-release-event", lambda _widget, _event: self.show_page("battery"))
        panel = Gtk.Frame()
        panel.set_shadow_type(Gtk.ShadowType.NONE)
        panel.set_hexpand(True)
        panel.set_vexpand(True)
        panel.get_style_context().add_class("studio-dashboard-battery")
        event_box.add(panel)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        panel.add(box)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        header.pack_start(
            self._label(self._t("AKKU-TEST", "BATTERY TEST", "TEST BATERIE"), "section-title"),
            True,
            True,
            0,
        )
        state = self._label(self._t("● bereit", "● ready", "● připraveno"), "studio-dashboard-battery-state", xalign=1.0)
        header.pack_end(state, False, False, 0)
        box.pack_start(header, False, False, 0)

        runtime = self._label("–", "studio-dashboard-battery-runtime", xalign=0.0)
        subtitle = self._label(self._t("Restlaufzeit", "Remaining time", "Zbývající čas"), "studio-dashboard-battery-subtitle")
        box.pack_start(runtime, False, False, 0)
        box.pack_start(subtitle, False, False, 0)

        visual = Gtk.Overlay()
        visual.set_hexpand(True)
        visual.set_vexpand(True)
        # The SVG itself has no useful natural size until its first render.
        # Reserve a responsive workshop-sized canvas so it cannot remain a
        # tiny 240 px image in an otherwise large dashboard card.
        dashboard_visual_width = max(320, min(520, self.screen_width // 3))
        visual.set_size_request(dashboard_visual_width, int(dashboard_visual_width * 290 / 520))
        image = Gtk.Image()
        image.set_hexpand(True)
        image.set_vexpand(True)
        image.set_halign(Gtk.Align.CENTER)
        image.set_valign(Gtk.Align.CENTER)
        visual.add(image)
        box.pack_start(visual, True, True, 0)
        outer.pack_start(event_box, True, True, 0)

        self._build_refs["dashboard_studio_battery"] = panel
        self._build_refs["dashboard_studio_battery_state"] = state
        self._build_refs["dashboard_studio_battery_runtime"] = runtime
        self._build_refs["dashboard_studio_battery_subtitle"] = subtitle
        self._build_refs["dashboard_studio_battery_image"] = image

    def _build_dashboard_service_desk(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Werkstatt-Übersicht", "Workshop overview", "Přehled dílny"),
            "",
            adaptive=True,
        )
        outer.get_style_context().add_class("dashboard-page")
        outer.get_style_context().add_class("service-dashboard")
        grid = Gtk.Grid(column_spacing=16, row_spacing=16)
        grid.set_column_homogeneous(False)
        outer.pack_start(grid, False, False, 12)

        device = Gtk.Frame()
        device.set_shadow_type(Gtk.ShadowType.NONE)
        device.get_style_context().add_class("service-device-hero")
        device_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        device.add(device_box)
        device_box.pack_start(self._label(self._t("AKTUELLES GERÄT", "CURRENT DEVICE", "AKTUÁLNÍ ZAŘÍZENÍ"), "card-title"), False, False, 0)
        hero_title = self._label(self._t("Gerät wird erkannt …", "Detecting device …", "Rozpoznávání zařízení …"), "hero-title", wrap=True)
        hero_subtitle = self._label("", "hero-subtitle", wrap=True)
        device_box.pack_start(hero_title, False, False, 0)
        device_box.pack_start(hero_subtitle, False, False, 0)
        self._build_refs["hero_title"] = hero_title
        self._build_refs["hero_subtitle"] = hero_subtitle
        self._build_refs["metric_system"] = hero_title
        self._build_refs["metric_system_sub"] = hero_subtitle
        facts = Gtk.Grid(column_spacing=12, row_spacing=8)
        facts.set_column_homogeneous(True)
        for index, (key, title, icon) in enumerate((
            ("cpu", "CPU", "cpu-symbolic"),
            ("ram", "RAM", "drive-harddisk-symbolic"),
            ("storage", self._t("Speicher", "Storage", "Úložiště"), "drive-harddisk-symbolic"),
            ("display", self._t("Anzeige", "Display", "Displej"), "video-display-symbolic"),
        )):
            block = self._dashboard_value_block(key, title, icon)
            block.get_style_context().add_class("service-fact")
            facts.attach(block, index % 2, index // 2, 1, 1)
        device_box.pack_start(facts, False, False, 12)
        grid.attach(device, 0, 0, 2, 1)

        rail = Gtk.Frame()
        rail.set_shadow_type(Gtk.ShadowType.NONE)
        rail.get_style_context().add_class("service-status-rail")
        rail_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        rail.add(rail_box)
        rail_box.pack_start(self._label(self._t("Werkstattstatus", "Workshop status", "Stav dílny"), "section-title"), False, False, 0)
        match = self._dashboard_value_block("match", self._t("Bester Modelltreffer", "Best model match", "Nejlepší shoda"), "system-search-symbolic")
        match.get_style_context().add_class("service-rail-row")
        rail_box.pack_start(match, False, False, 5)
        rail_box.pack_start(self._button(self._t("ModelFinder öffnen", "Open ModelFinder", "Otevřít ModelFinder"), lambda _b: self.show_page("models"), "secondary-button", "system-search-symbolic"), False, False, 5)
        rail_box.pack_start(self._button(self._t("Drucken", "Print", "Tisk"), lambda _b: self.show_page("print"), "secondary-button", "document-print-symbolic"), False, False, 0)
        grid.attach(rail, 2, 0, 1, 1)
        grid.set_hexpand(True)

        self._build_dashboard_live_panel(outer)
        self._build_dashboard_suggestions(outer, 125 if self.compact_screen else 220, adaptive=True)
        return page

    def _build_dashboard_workshop_console(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("SYSTEMÜBERSICHT / EINGANGSTEST", "SYSTEM OVERVIEW / INTAKE TEST", "PŘEHLED SYSTÉMU / VSTUPNÍ TEST"),
            "",
            adaptive=True,
        )
        outer.get_style_context().add_class("dashboard-page")
        outer.get_style_context().add_class("console-dashboard")
        summary = Gtk.Frame()
        summary.set_shadow_type(Gtk.ShadowType.NONE)
        summary.get_style_context().add_class("console-summary")
        summary_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        summary.add(summary_row)
        summary_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        hero_title = self._label(self._t("GERÄT WIRD ERKANNT …", "DETECTING DEVICE …", "ROZPOZNÁVÁNÍ ZAŘÍZENÍ …"), "hero-title", wrap=True)
        hero_subtitle = self._label("", "hero-subtitle", wrap=True)
        summary_text.pack_start(hero_title, False, False, 0)
        summary_text.pack_start(hero_subtitle, False, False, 0)
        summary_row.pack_start(summary_text, True, True, 0)
        summary_row.pack_end(self._button(self._t("DRUCKEN", "PRINT", "TISK"), lambda _b: self.show_page("print"), "primary-button", "document-print-symbolic"), False, False, 0)
        outer.pack_start(summary, False, False, 12)
        self._build_refs["hero_title"] = hero_title
        self._build_refs["hero_subtitle"] = hero_subtitle
        self._build_refs["metric_system"] = hero_title
        self._build_refs["metric_system_sub"] = hero_subtitle

        grid = Gtk.Grid(column_spacing=12, row_spacing=12)
        grid.set_hexpand(True)
        table = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        table.get_style_context().add_class("console-table")
        for key, title in (
            ("cpu", "CPU"),
            ("ram", "RAM"),
            ("storage", self._t("SPEICHER", "STORAGE", "ÚLOŽIŠTĚ")),
            ("display", self._t("ANZEIGE", "DISPLAY", "DISPLEJ")),
            ("match", self._t("MODELL", "MODEL", "MODEL")),
        ):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
            row.get_style_context().add_class("console-table-row")
            label = self._label(title, "console-label")
            label.set_size_request(145, -1)
            row.pack_start(label, False, False, 0)
            value_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            value_box.get_style_context().add_class("console-value")
            value = self._label("–", "card-value", wrap=True)
            subtitle = self._label("", "card-subtitle", wrap=True)
            value_box.pack_start(value, False, False, 0)
            value_box.pack_start(subtitle, False, False, 0)
            row.pack_start(value_box, True, True, 0)
            row.pack_end(self._label(self._t("OK", "OK", "OK"), "console-state"), False, False, 0)
            table.pack_start(row, False, False, 0)
            self._build_refs[f"metric_{key}"] = value
            self._build_refs[f"metric_{key}_sub"] = subtitle
        grid.attach(table, 0, 0, 3, 1)

        actions = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        actions.get_style_context().add_class("console-actions")
        actions.pack_start(self._label(self._t("BEFEHLE", "COMMANDS", "PŘÍKAZY"), "section-title"), False, False, 0)
        for text, icon, target in (
            (self._t("MODELLFINDER ÖFFNEN", "OPEN MODELFINDER", "OTEVŘÍT MODELFINDER"), "system-search-symbolic", "models"),
            (self._t("AKKU-TEST STARTEN", "START BATTERY TEST", "SPUSTIT TEST BATERIE"), "battery-symbolic", "battery"),
            (self._t("REPORT DRUCKEN", "PRINT REPORT", "TISKNOUT REPORT"), "document-print-symbolic", "print"),
        ):
            actions.pack_start(self._button(text, lambda _b, page_name=target: self.show_page(page_name), "secondary-button", icon), False, False, 0)
        actions.pack_start(self._button(self._t("HARDWARE NEU SCANNEN", "RESCAN HARDWARE", "ZNOVU SKENOVAT HARDWARE"), self._rescan_clicked, "secondary-button", "view-refresh-symbolic"), False, False, 0)
        grid.attach(actions, 3, 0, 1, 1)
        outer.pack_start(grid, False, False, 0)
        self._build_dashboard_live_panel(outer)
        self._build_dashboard_suggestions(outer, 125 if self.compact_screen else 220, adaptive=True)
        return page

    def _build_dashboard_studio_panels(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._studio_greeting(),
            "",
            adaptive=True,
        )
        outer.get_style_context().add_class("dashboard-page")
        outer.get_style_context().add_class("studio-dashboard")
        grid = Gtk.Grid(column_spacing=12, row_spacing=12)
        grid.set_column_homogeneous(True)
        outer.pack_start(grid, False, False, 12)

        device = Gtk.Frame()
        device.set_shadow_type(Gtk.ShadowType.NONE)
        device.get_style_context().add_class("studio-panel")
        device.get_style_context().add_class("studio-device-panel")
        device_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        device.add(device_box)
        device_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        device_header.pack_start(self._label(self._t("AKTUELLES GERÄT", "CURRENT DEVICE", "AKTUÁLNÍ ZAŘÍZENÍ"), "card-title"), True, True, 0)
        rescan_button = self._button(
            self._t("Neu scannen", "Rescan", "Znovu skenovat"),
            self._rescan_clicked,
            "secondary-button",
            "view-refresh-symbolic",
        )
        rescan_button.get_style_context().add_class("studio-rescan-button")
        device_header.pack_end(rescan_button, False, False, 0)
        device_box.pack_start(device_header, False, False, 0)
        hero_title = self._label(self._t("Gerät wird erkannt …", "Detecting device …", "Rozpoznávání zařízení …"), "hero-title", wrap=True)
        hero_subtitle = self._label("", "hero-subtitle", wrap=True)
        device_box.pack_start(hero_title, True, True, 4)
        device_box.pack_start(hero_subtitle, False, False, 0)
        grid.attach(device, 0, 0, 3, 1)
        self._build_refs["hero_title"] = hero_title
        self._build_refs["hero_subtitle"] = hero_subtitle
        self._build_refs["metric_system"] = hero_title
        self._build_refs["metric_system_sub"] = hero_subtitle

        match = self._dashboard_value_block("match", self._t("BESTER MODELLTREFFER", "BEST MODEL MATCH", "NEJLEPŠÍ SHODA"), "system-search-symbolic")
        match.get_style_context().add_class("studio-match-panel")
        grid.attach(match, 3, 0, 1, 1)
        for index, (key, title, icon) in enumerate((
            ("cpu", "CPU", "cpu-symbolic"),
            ("ram", "RAM", "drive-harddisk-symbolic"),
            ("storage", self._t("SPEICHER", "STORAGE", "ÚLOŽIŠTĚ"), "drive-harddisk-symbolic"),
            ("display", self._t("ANZEIGE", "DISPLAY", "DISPLEJ"), "video-display-symbolic"),
        )):
            grid.attach(self._dashboard_value_block(key, title, icon), index, 1, 1, 1)

        workspace = Gtk.Grid(column_spacing=12, row_spacing=0)
        workspace.set_column_homogeneous(True)
        workspace.set_hexpand(True)
        workspace.set_vexpand(True)
        workspace.get_style_context().add_class("studio-dashboard-workspace")
        suggestions_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        suggestions_box.set_hexpand(True)
        suggestions_box.set_vexpand(True)
        self._build_dashboard_suggestions(suggestions_box, 125 if self.compact_screen else 210, adaptive=True)
        battery_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        battery_box.set_hexpand(True)
        battery_box.set_vexpand(True)
        self._build_dashboard_studio_battery(battery_box)
        workspace.attach(suggestions_box, 0, 0, 3, 1)
        workspace.attach(battery_box, 3, 0, 2, 1)
        outer.pack_start(workspace, True, True, 0)
        return page

    def _render_dashboard_model_suggestions(self) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("dashboard_model_list")
        count_label: Gtk.Label | None = self._build_refs.get("dashboard_model_count")
        if listbox is None or count_label is None:
            return
        self._clear_listbox(listbox)
        studio_cards = self.appearance_layout == "studio-panels"
        shown = self.match_results[:5 if studio_cards else 6]
        count_label.set_text(
            self._t(
                f"{len(self.match_results)} passende Geräte · die besten {len(shown)} werden angezeigt",
                f"{len(self.match_results)} matching devices · showing the best {len(shown)}",
                f"Odpovídající zařízení: {len(self.match_results)} · zobrazeno nejlepších {len(shown)}",
            )
        )
        if not shown:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Kein passendes Modell gefunden.", "No matching model found.", "Nebyl nalezen odpovídající model."), "muted", wrap=True))
            listbox.add(row)
        if studio_cards and shown:
            for index, result in enumerate(shown):
                row = Gtk.ListBoxRow()
                row.set_activatable(False)
                row.set_selectable(False)
                row.get_style_context().add_class("studio-suggestion-row")
                item = result.get("item") if isinstance(result.get("item"), dict) else {}
                model_id = _clean(item.get("model_id"))
                score = int(result.get("score") or 0)
                kind = self._t("REFURBISHED", "REFURBISHED", "REPASOVANÉ") if self.core.model_is_refurbished(item) else self._t("BASIS", "BASE", "ZÁKLAD")
                summary_parts = (
                    self._model_item_value(item, "vendor"),
                    self._model_item_value(item, "cpu"),
                    _clean(item.get("ram_total") or item.get("total_ram_gb") or self._model_item_value(item, "ram")),
                    self._model_item_value(item, "storage"),
                )
                summary = " · ".join(value for value in summary_parts if value and value != "–")
                button = Gtk.Button()
                button.set_hexpand(True)
                button.set_relief(Gtk.ReliefStyle.NONE)
                button.get_style_context().add_class("studio-suggestion-card")
                if index == 0:
                    button.get_style_context().add_class("best")
                content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
                identity = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
                identity.set_size_request(96, -1)
                identity.pack_start(self._label(model_id, "studio-suggestion-title"), False, False, 0)
                identity.pack_start(self._label(kind, "studio-suggestion-kind"), False, False, 0)
                content.pack_start(identity, False, False, 0)
                content.pack_start(self._label(_short(summary, 86), "studio-suggestion-summary", wrap=True), True, True, 0)
                content.pack_end(self._label(f"{score}%", "studio-suggestion-score", xalign=1.0), False, False, 0)
                button.add(content)
                button.set_tooltip_text(self.core.model_notebook_summary(item))
                button.connect("clicked", lambda _button, value=model_id: self._open_dashboard_model(value))
                row.add(button)
                listbox.add(row)
            listbox.show_all()
            count_label.hide()
            return
        for index, result in enumerate(shown):
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            model_id = _clean(item.get("model_id"))
            score = int(result.get("score") or 0)
            row = Gtk.ListBoxRow()
            row.get_style_context().add_class("list-row")
            content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            row.add(content)
            rank = self._label("★" if index == 0 else str(index + 1), "good-text" if index == 0 else "muted", xalign=0.5)
            rank.set_size_request(32, -1)
            content.pack_start(rank, False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            title = f"{model_id} · {score}%"
            if index == 0:
                title = f"{self._t('Bester Treffer', 'Best match', 'Nejlepší shoda')}: {title}"
            text.pack_start(self._label(title, "section-title"), False, False, 0)
            text.pack_start(self._label(_short(self.core.model_notebook_summary(item), 100), "muted", wrap=True), False, False, 0)
            content.pack_start(text, True, True, 0)
            content.pack_end(
                self._button(
                    self._t("Vergleichen", "Compare", "Porovnat"),
                    lambda _b, value=model_id: self._open_dashboard_model(value),
                    "secondary-button",
                    "system-search-symbolic",
                ),
                False,
                False,
                0,
            )
            listbox.add(row)
        listbox.show_all()

    def _open_dashboard_model(self, model_id: str) -> None:
        search: Gtk.SearchEntry | None = self._build_refs.get("model_search")
        if search is not None:
            search.set_text(model_id)
            self._model_search_changed(search)
        self.show_page("models")

    # ---------- model finder ----------

    def _build_models_page(self) -> Gtk.Widget:
        studio_layout = self.appearance_layout == "studio-panels"
        page, outer = self._page_shell(
            "ModelFinder",
            "",
            adaptive=True,
        )
        outer.get_style_context().add_class("models-page")
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        toolbar.get_style_context().add_class("models-toolbar")
        self._build_refs["model_search"] = Gtk.SearchEntry()
        self._build_refs["model_search"].set_placeholder_text(self._t("Modell-ID, Hersteller, CPU oder Produktnummer", "Model ID, manufacturer, CPU or product number", "ID modelu, výrobce, CPU nebo produktové číslo"))
        self._build_refs["model_search"].connect("search-changed", self._model_search_changed)
        toolbar.pack_start(self._build_refs["model_search"], True, True, 0)
        self._build_refs["model_use_device"] = Gtk.CheckButton(label=self._t("Aktuelles Gerät anzeigen", "Show current device", "Zobrazit aktuální zařízení"))
        self._build_refs["model_use_device"].set_active(True)
        self._build_refs["model_use_device"].connect("toggled", self._model_device_toggled)
        toolbar.pack_start(self._build_refs["model_use_device"], False, False, 0)
        self._build_refs["model_selection_count"] = self._label(self._t("0/3 gewählt", "0/3 selected", "Vybráno 0/3"), "muted")
        toolbar.pack_start(self._build_refs["model_selection_count"], False, False, 0)
        toolbar.pack_start(self._button(self._t("Auswahl leeren", "Clear selection", "Zrušit výběr"), self._clear_model_selection, "secondary-button", "edit-clear-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)

        compare_frame = Gtk.Frame()
        compare_frame.set_shadow_type(Gtk.ShadowType.NONE)
        compare_frame.get_style_context().add_class("card")
        compare_frame.get_style_context().add_class("models-compare-card")
        compare_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        compare_frame.add(compare_outer)
        compare_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["model_compare_title"] = self._label(self._t("Modellvergleich mit aktuellem Gerät", "Model comparison with current device", "Porovnání modelů s aktuálním zařízením"), "section-title")
        compare_header.pack_start(self._build_refs["model_compare_title"], True, True, 0)
        compare_header.pack_end(self._button(self._t("Mit gewählten Optionen suchen", "Search selected options", "Hledat vybrané možnosti"), self._search_selected_model_options, "primary-button", "system-search-symbolic"), False, False, 0)
        compare_outer.pack_start(compare_header, False, False, 0)
        compare_scroll = Gtk.ScrolledWindow()
        compare_scroll.set_policy(
            Gtk.PolicyType.AUTOMATIC,
            Gtk.PolicyType.ALWAYS if self.compact_screen or studio_layout else Gtk.PolicyType.AUTOMATIC,
        )
        if self.compact_screen or studio_layout:
            compare_scroll.set_overlay_scrolling(False)
        compare_scroll.set_min_content_height(205 if self.compact_screen else 282 if studio_layout else 250)
        self._build_refs["compare_box"] = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        compare_scroll.add(self._build_refs["compare_box"])
        compare_outer.pack_start(compare_scroll, True, True, 0)
        outer.pack_start(compare_frame, False, False, 4)

        result_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        result_header.get_style_context().add_class("models-results-header")
        result_header.pack_start(self._label(self._t("Modellvorschläge", "Model suggestions", "Návrhy modelů"), "section-title"), False, False, 0)
        self._build_refs["model_result_count"] = self._label(self._t("Datenbank wird geladen …", "Loading database …", "Načítání databáze …"), "muted")
        if studio_layout:
            self._build_refs["model_result_count"].set_no_show_all(True)
            self._build_refs["model_result_count"].hide()
        result_header.pack_start(self._build_refs["model_result_count"], True, True, 0)
        outer.pack_start(result_header, False, False, 8)

        lower = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        lower.set_position(115 if self.compact_screen else 180 if studio_layout else 250)
        lower.set_wide_handle(self.compact_screen or studio_layout)
        outer.pack_start(lower, True, True, 0)
        store = Gtk.ListStore(str, str, str, str, str, str, str, str, object)
        self._build_refs["model_store"] = store
        tree = Gtk.TreeView(model=store)
        tree.set_headers_clickable(True)
        tree.set_grid_lines(
            Gtk.TreeViewGridLines.BOTH
            if self.appearance_layout == "original"
            else Gtk.TreeViewGridLines.NONE
        )
        tree.get_selection().set_mode(Gtk.SelectionMode.NONE)
        tree.connect("button-press-event", self._model_tree_clicked)
        columns = (
            ("%", 0, 58),
            (self._t("Basis-ID", "Base ID", "Základní ID"), 1, 105),
            (self._t("Refurbished", "Refurbished", "Repasované"), 2, 110),
            (self._t("Hersteller", "Manufacturer", "Výrobce"), 3, 110),
            ("CPU", 4, 210),
            ("RAM", 5, 70),
            (self._t("Speicher", "Storage", "Úložiště"), 6, 170),
            (self._t("Anzeige", "Display", "Displej"), 7, 170),
        )
        for title, index, width in columns:
            renderer = Gtk.CellRendererText()
            renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
            column = Gtk.TreeViewColumn(title, renderer)
            column.add_attribute(renderer, "markup" if index in {1, 2} else "text", index)
            column.set_min_width(width)
            column.set_resizable(True)
            column.set_sort_column_id(index)
            tree.append_column(column)
            if index == 0:
                self._build_refs["model_score_column"] = column
        model_scroll = Gtk.ScrolledWindow()
        model_scroll.set_policy(
            Gtk.PolicyType.AUTOMATIC,
            Gtk.PolicyType.ALWAYS if self.compact_screen or studio_layout else Gtk.PolicyType.AUTOMATIC,
        )
        if self.compact_screen or studio_layout:
            model_scroll.set_overlay_scrolling(False)
            model_scroll.set_min_content_height(90 if self.compact_screen else 110)
        model_scroll.add(tree)
        lower.pack1(model_scroll, True, False)
        self._build_refs["model_tree"] = tree

        self._build_refs["model_detail"] = Gtk.TextView()
        self._build_refs["model_detail"].set_editable(False)
        self._build_refs["model_detail"].set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        detail_scroll = Gtk.ScrolledWindow()
        detail_scroll.set_min_content_height(58 if self.compact_screen else 72 if studio_layout else 100)
        detail_scroll.add(self._build_refs["model_detail"])
        lower.pack2(detail_scroll, True, False)
        return page

    def _model_item_value(self, item: dict[str, object], key: str) -> str:
        if key == "ram":
            return _clean(self.core.model_ram_summary(item))
        if key == "storage":
            return _clean(self.core.model_storage_summary(item))
        if key == "display":
            return _clean(self.core.model_display_summary(item))
        if key == "notebook":
            return _clean(self.core.model_notebook_summary(item))
        if key == "condition":
            return _clean(self.core.model_condition_summary(item))
        aliases = {
            "os": ("operating_system", "os"),
            "software": ("software",),
            "vendor": ("vendor", "manufacturer"),
            "cpu": ("cpu",),
        }
        for alias in aliases.get(key, (key,)):
            value = str(item.get(alias) or "").strip()
            if value:
                return value
        return "–"

    def _model_relation_values(self, item: dict[str, object], selected_ids: set[str] | None = None) -> tuple[str, str]:
        model_id = _clean(item.get("model_id"))
        base_ids, refurbished_ids = self._model_relation_map.get(model_id, ([], []))
        selected_ids = selected_ids or set()

        def marked(values: list[str]) -> str:
            return ", ".join(f"{value} ★" if value in selected_ids else value for value in values)

        if self.core.model_is_refurbished(item):
            base_text = marked(base_ids[:2]) or "–"
            refurbished_text = marked([model_id])
        else:
            base_text = marked([model_id])
            refurbished_text = marked(refurbished_ids[:3]) or "–"
        return base_text, refurbished_text

    def _model_relation_markup(self, item: dict[str, object], selected_ids: set[str] | None = None) -> tuple[str, str]:
        model_id = _clean(item.get("model_id"))
        base_ids, refurbished_ids = self._model_relation_map.get(model_id, ([], []))
        selected_ids = selected_ids or set()
        highlight = "#d7539a" if self.appearance_layout == "studio-panels" else self.appearance_accent
        foreground = "#fff7ff" if self.appearance_layout == "studio-panels" else "#111820"

        def marked(values: list[str]) -> str:
            rendered: list[str] = []
            for value in values:
                escaped = GLib.markup_escape_text(value)
                if value in selected_ids:
                    rendered.append(
                        f'<span background="{highlight}" foreground="{foreground}" weight="bold"> {escaped} ★ </span>'
                    )
                else:
                    rendered.append(escaped)
            return ", ".join(rendered)

        if self.core.model_is_refurbished(item):
            base_text = marked(base_ids[:2]) or "–"
            refurbished_text = marked([model_id])
        else:
            base_text = marked([model_id])
            refurbished_text = marked(refurbished_ids[:3]) or "–"
        return base_text, refurbished_text

    @staticmethod
    def _model_family_tokens_match(first: str, second: str) -> bool:
        first = str(first or "").strip().casefold()
        second = str(second or "").strip().casefold()
        if not first or not second:
            return False
        if first == second:
            return True
        common = 0
        for left, right in zip(first, second):
            if left != right:
                break
            common += 1
        return common >= 6 and any(character.isdigit() for character in first[:common])

    def _model_belongs_to_current_family(self, item: dict[str, object]) -> bool:
        if not self.snapshot:
            return False
        snapshot_vendor = self.core.normalize_generic_token(
            str(self.snapshot.get("vendor_short") or self.snapshot.get("vendor") or "")
        )
        item_vendor = self.core.normalize_generic_token(str(item.get("vendor") or ""))
        if not snapshot_vendor or snapshot_vendor != item_vendor:
            return False

        snapshot_products = self.core.snapshot_product_numbers(self.snapshot)
        item_products = self.core.row_product_numbers(item)
        if snapshot_products and item_products:
            return any(
                self._model_family_tokens_match(snapshot_product, item_product)
                for snapshot_product in snapshot_products
                for item_product in item_products
            )

        snapshot_cpu = self.core.normalize_cpu_token(
            str(self.snapshot.get("cpu_short") or self.snapshot.get("cpu") or "")
        )
        item_cpu = self.core.normalize_cpu_token(str(item.get("cpu") or ""))
        if not snapshot_cpu or snapshot_cpu != item_cpu:
            return False
        snapshot_inches = self.core.display_inches_number(self.snapshot.get("display_inches"))
        item_inches = self.core.display_inches_number(item.get("inch"))
        return snapshot_inches is None or item_inches is None or self.core.compare_inches(snapshot_inches, item_inches)

    def _current_family_models(self) -> list[dict[str, object]]:
        hardware_matches = [
            result["item"]
            for result in self.match_results
            if isinstance(result.get("item"), dict)
        ]
        family_matches = [item for item in self.models if self._model_belongs_to_current_family(item)]
        combined: list[dict[str, object]] = []
        combined_ids: set[str] = set()
        for item in hardware_matches + family_matches:
            model_id = str(item.get("model_id") or "")
            if model_id and model_id not in combined_ids:
                combined_ids.add(model_id)
                combined.append(item)
        if combined:
            compact: list[dict[str, object]] = []
            for item in combined:
                model_id = str(item.get("model_id") or "")
                base_ids, _refurbished_ids = self._model_relation_map.get(model_id, ([], []))
                if self.core.model_is_refurbished(item) and any(base_id in combined_ids for base_id in base_ids):
                    continue
                compact.append(item)
            return compact
        return []

    def _refresh_model_table(self) -> None:
        if not self.models:
            self._populate_model_results([])
            self._render_model_comparison()
            return
        query = self._build_refs["model_search"].get_text().strip()
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        if query:
            # An explicit search is deliberately unrestricted: it must also allow
            # comparing unrelated database models with the current device.
            items = self.core.find_model_db_items(query, limit=250, entries=self.models)
        elif use_device:
            items = self._current_family_models()
        else:
            # With the current device disabled the ModelFinder remains a free,
            # independent database comparison tool.
            items = self.models
        results = [(self._model_display_score(item), item) for item in items]
        if self._model_has_score_reference():
            results.sort(key=lambda pair: (-pair[0], self.core.model_value_int(pair[1].get("model_id"))))
        self._populate_model_results(results[:250])
        self._render_model_comparison()

    def _model_has_score_reference(self) -> bool:
        return bool(
            self._build_refs.get("model_use_device")
            and self._build_refs["model_use_device"].get_active()
            and self.snapshot
        ) or bool(self._model_selected_ids)

    def _model_display_score(self, item: dict[str, object]) -> int:
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        if use_device:
            model_id = str(item.get("model_id") or "")
            for result in self.match_results:
                result_item = result.get("item") if isinstance(result.get("item"), dict) else {}
                if str(result_item.get("model_id") or "") == model_id:
                    return int(result.get("score") or 0)
            result = self.core.score_snapshot_model_for_finder(self.snapshot, item)
            return int(result.get("score") or 0)
        selected = self._selected_model_items()
        if selected:
            return int(self.core.model_similarity_score(selected[0], item))
        return 0

    def _populate_model_results(self, results: list[tuple[int, dict[str, object]]]) -> None:
        store: Gtk.ListStore | None = self._build_refs.get("model_store")
        tree: Gtk.TreeView | None = self._build_refs.get("model_tree")
        if store is None or tree is None:
            return
        self._model_visible_results = [(score, item) for score, item in results if isinstance(item, dict)]
        self._model_selection_syncing = True
        try:
            store.clear()
            show_score = self._model_has_score_reference()
            score_column: Gtk.TreeViewColumn | None = self._build_refs.get("model_score_column")
            if score_column is not None:
                score_column.set_title(self._t("% Gerät", "% Device", "% Zařízení") if self._build_refs["model_use_device"].get_active() and self.snapshot else self._t("% Ähnl.", "% Similar", "% Podob."))
            selected_ids = set(self._model_selected_ids)
            for score, item in self._model_visible_results:
                base_id, refurbished = self._model_relation_markup(item, selected_ids)
                store.append([
                    f"{score}%" if show_score else "–",
                    base_id,
                    refurbished,
                    _short(self._model_item_value(item, "vendor"), 24),
                    _short(self._model_item_value(item, "cpu"), 42),
                    _short(item.get("ram_total") or item.get("total_ram_gb") or self._model_item_value(item, "ram"), 18),
                    _short(self._model_item_value(item, "storage"), 38),
                    _short(self._model_item_value(item, "display"), 38),
                    item,
                ])
        finally:
            self._model_selection_syncing = False
        count = len(self._model_visible_results)
        family_mode = bool(
            self._build_refs["model_use_device"].get_active()
            and self.snapshot
            and not self._build_refs["model_search"].get_text().strip()
        )
        self._build_refs["model_result_count"].set_text(
            self._t(
                f"{count} Geräte-/Familienvorschläge" if family_mode else f"{count} Vorschläge",
                f"{count} device/family suggestions" if family_mode else f"{count} suggestions",
                f"{count} návrhů zařízení/řady" if family_mode else f"{count} návrhů",
            )
        )
        self._update_model_selection_count()

    def _model_search_changed(self, _entry) -> None:
        query = self._build_refs["model_search"].get_text().strip()
        exact_ids = re.findall(r"\b\d{4,6}\b", query)
        if exact_ids:
            available = {str(item.get("model_id") or ""): item for item in self.models}
            maximum = self._model_selection_limit()
            selected: list[str] = []
            for model_id in exact_ids:
                if model_id in available and model_id not in selected:
                    selected.append(model_id)
            self._model_selected_ids = selected[:maximum]
        self._refresh_model_table()

    def _model_device_toggled(self, _button) -> None:
        maximum = self._model_selection_limit()
        self._model_selected_ids = self._model_selected_ids[:maximum]
        self._refresh_model_table()

    def _model_selection_limit(self) -> int:
        use_device = bool(
            self._build_refs.get("model_use_device")
            and self._build_refs["model_use_device"].get_active()
            and self.snapshot
        )
        return 3 if use_device else 4

    def _update_model_selection_count(self) -> None:
        maximum = self._model_selection_limit()
        count = len(self._model_selected_ids)
        self._build_refs["model_selection_count"].set_text(
            self._t(f"{count}/{maximum} gewählt", f"{count}/{maximum} selected", f"Vybráno {count}/{maximum}")
        )

    def _selected_model_rows(self) -> list[tuple[int, dict[str, object]]]:
        return [(self._model_display_score(item), item) for item in self._selected_model_items()]

    def _selected_model_items(self) -> list[dict[str, object]]:
        by_id = {str(item.get("model_id") or ""): item for item in self.models}
        return [by_id[model_id] for model_id in self._model_selected_ids if model_id in by_id]

    def _toggle_model_selection_id(self, target_id: str) -> bool:
        if target_id in self._model_selected_ids:
            self._model_selected_ids = [value for value in self._model_selected_ids if value != target_id]
            self._refresh_model_table()
            return True
        if len(self._model_selected_ids) >= self._model_selection_limit():
            self.set_status(
                self._t(
                    "Der Vergleich ist voll. Bitte zuerst ein Modell abwählen.",
                    "The comparison is full. Deselect a model first.",
                    "Porovnání je plné. Nejprve zrušte výběr jednoho modelu.",
                ),
                "warn",
            )
            return False
        self._model_selected_ids.append(target_id)
        self._refresh_model_table()
        return True

    def _model_tree_clicked(self, tree: Gtk.TreeView, event) -> bool:
        if event.button != 1:
            return False
        path_info = tree.get_path_at_pos(int(event.x), int(event.y))
        if not path_info:
            return False
        path, column, cell_x, _cell_y = path_info
        model = tree.get_model()
        iterator = model.get_iter(path) if model is not None else None
        item = model.get_value(iterator, 8) if model is not None and iterator is not None else None
        column_index = tree.get_columns().index(column) if column in tree.get_columns() else -1
        if isinstance(item, dict) and column_index in {1, 2}:
            model_id = _clean(item.get("model_id"))
            base_ids, refurbished_ids = self._model_relation_map.get(model_id, ([], []))
            if column_index == 1:
                relation_ids = base_ids[:2] if self.core.model_is_refurbished(item) else [model_id]
            else:
                relation_ids = [model_id] if self.core.model_is_refurbished(item) else refurbished_ids[:3]
            if relation_ids:
                slot = min(len(relation_ids) - 1, max(0, int(max(0, cell_x) * len(relation_ids) / max(1, column.get_width()))))
                target_id = relation_ids[slot]
                self._toggle_model_selection_id(target_id)
                return True
        if isinstance(item, dict):
            self._toggle_model_selection_id(_clean(item.get("model_id")))
        return True

    def _model_selection_changed(self, _selection) -> None:
        if self._model_selection_syncing:
            return
        model, paths = _selection.get_selected_rows()
        visible_ids = {
            str(item.get("model_id") or "")
            for _score, item in self._model_visible_results
            if isinstance(item, dict)
        }
        hidden_ids = [model_id for model_id in self._model_selected_ids if model_id not in visible_ids]
        visible_selected: list[str] = []
        for path in paths:
            row = model[model.get_iter(path)]
            item = row[8]
            if isinstance(item, dict):
                model_id = str(item.get("model_id") or "").strip()
                if model_id and model_id not in visible_selected:
                    visible_selected.append(model_id)
        self._model_selected_ids = (hidden_ids + visible_selected)[: self._model_selection_limit()]
        self._refresh_model_selection_markers()
        self._update_model_selection_count()
        self._render_model_comparison()
        selected = self._selected_model_rows()
        if not selected:
            self._build_refs["model_detail"].get_buffer().set_text("")
            return
        score, item = selected[-1]
        try:
            detail = self.core.format_model_database_detail(item, self.language, percent=score)
        except Exception:
            detail = "\n".join(f"{key}: {value}" for key, value in item.items())
        self._build_refs["model_detail"].get_buffer().set_text(detail)

    def _refresh_model_selection_markers(self) -> None:
        store: Gtk.ListStore | None = self._build_refs.get("model_store")
        if store is None:
            return
        selected_ids = set(self._model_selected_ids)
        iterator = store.get_iter_first()
        while iterator is not None:
            item = store.get_value(iterator, 8)
            if isinstance(item, dict):
                base_id, refurbished = self._model_relation_markup(item, selected_ids)
                store.set_value(iterator, 1, base_id)
                store.set_value(iterator, 2, refurbished)
            iterator = store.iter_next(iterator)

    def _clear_model_selection(self, _button=None) -> None:
        self._model_selected_ids = []
        tree: Gtk.TreeView | None = self._build_refs.get("model_tree")
        if tree is not None:
            self._model_selection_syncing = True
            try:
                tree.get_selection().unselect_all()
            finally:
                self._model_selection_syncing = False
        self._refresh_model_selection_markers()
        self._update_model_selection_count()
        self._render_model_comparison()
        self._build_refs["model_detail"].get_buffer().set_text("")

    def _remove_model_from_comparison(self, model_id: str) -> None:
        self._model_selected_ids = [value for value in self._model_selected_ids if value != model_id]
        self._refresh_model_table()

    def _compare_selected_models(self, _button=None) -> None:
        self._render_model_comparison()

    def _render_model_comparison(self) -> None:
        box: Gtk.Box = self._build_refs["compare_box"]
        saved_states = {
            (str(binding.get("source_id") or ""), str(binding.get("key") or "")): bool(binding["check"].get_active())
            for binding in self._model_option_bindings
            if isinstance(binding.get("check"), Gtk.CheckButton)
        }
        self._model_option_bindings = []
        for child in box.get_children():
            box.remove(child)
        selected = self._selected_model_items()
        use_device = self._build_refs["model_use_device"].get_active() and bool(self.snapshot)
        sources: list[tuple[str, dict[str, object] | None]] = []
        if use_device:
            sources.append(("device", None))
        sources.extend((str(item.get("model_id") or ""), item) for item in selected)

        if use_device and selected:
            scores = [self._model_display_score(item) for item in selected]
            title = f"{self._t('Modellvergleich mit aktuellem Gerät', 'Model comparison with current device', 'Porovnání modelů s aktuálním zařízením')} · {self._t('Bester Match', 'Best match', 'Nejlepší shoda')}: {max(scores)}%"
        elif use_device:
            title = self._t("Modellvergleich mit aktuellem Gerät", "Model comparison with current device", "Porovnání modelů s aktuálním zařízením")
        elif len(selected) > 1:
            scores = [int(self.core.model_similarity_score(selected[0], item)) for item in selected[1:]]
            title = f"{self._t('Modellvergleich', 'Model comparison', 'Porovnání modelů')} · Match: {min(scores)}%"
        elif selected:
            title = self._t("Vergleichsmodell gewählt – weitere Vorschläge anklicken", "Comparison model selected – click more suggestions", "Vybrán srovnávací model – klikněte na další návrhy")
        else:
            title = self._t("Modelle aus der Vorschlagsliste auswählen", "Select models from the suggestion list", "Vyberte modely ze seznamu návrhů")
        self._build_refs["model_compare_title"].set_text(title)

        if not sources:
            box.pack_start(self._label(self._t("Aktuelles Gerät einschalten oder unten Modelle auswählen.", "Enable the current device or select models below.", "Zapněte aktuální zařízení nebo níže vyberte modely."), "muted", wrap=True), False, False, 12)
            box.show_all()
            return

        grid = Gtk.Grid(column_spacing=2, row_spacing=2)
        grid.attach(self._label("#", "comparison-header", xalign=0.5), 0, 0, 1, 1)
        grid.attach(self._label(self._t("Kategorie", "Category", "Kategorie"), "comparison-header"), 1, 0, 1, 1)
        snapshot_rows = self.core.snapshot_compare_entries(self.snapshot, self.language)
        categories = [(key, label) for key, label, _value, _available in snapshot_rows]
        if not use_device and selected:
            categories = [(key, label) for key, label, _value in self.core.model_compare_entries(selected[0], self.language)]
        snapshot_map = {key: (value, available) for key, _label, value, available in snapshot_rows}
        model_maps = {
            str(item.get("model_id") or ""): {key: value for key, _label, value in self.core.model_compare_entries(item, self.language)}
            for item in selected
        }
        base_model = selected[0] if selected else None

        for column, (source_id, item) in enumerate(sources, start=2):
            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
            header.get_style_context().add_class("comparison-header")
            if source_id == "device":
                header_text = self._t("Aktuelles Gerät", "Current device", "Aktuální zařízení")
            elif use_device and item:
                header_text = f"{self._t('Modell', 'Model', 'Model')} {source_id} ★ · {self._model_display_score(item)}%"
            elif item is base_model:
                header_text = f"{self._t('Basis', 'Base', 'Základ')} · {self._t('Modell', 'Model', 'Model')} {source_id} ★"
            else:
                header_text = f"{self._t('Modell', 'Model', 'Model')} {source_id} ★ · {int(self.core.model_similarity_score(base_model or item, item))}%"
            header.pack_start(self._label(header_text, xalign=0.5), True, True, 0)
            if source_id != "device":
                remove_button = Gtk.Button(label="×")
                remove_button.set_relief(Gtk.ReliefStyle.NONE)
                remove_button.set_tooltip_text(self._t("Aus Vergleich entfernen", "Remove from comparison", "Odebrat z porovnání"))
                remove_button.connect("clicked", lambda _b, model_id=source_id: self._remove_model_from_comparison(model_id))
                header.pack_end(remove_button, False, False, 0)
            header.set_size_request(268 if self.appearance_layout == "studio-panels" else 285, 34 if self.appearance_layout == "studio-panels" else 42)
            grid.attach(header, column, 0, 1, 1)

        for row_index, (key, category_title) in enumerate(categories, start=1):
            grid.attach(self._label(str(row_index), "card-subtitle", xalign=0.5), 0, row_index, 1, 1)
            category = self._label(category_title, "card-title")
            category.set_size_request(138 if self.appearance_layout == "studio-panels" else 145, 31 if self.appearance_layout == "studio-panels" else 38)
            grid.attach(category, 1, row_index, 1, 1)
            for column, (source_id, item) in enumerate(sources, start=2):
                if source_id == "device":
                    value, available = snapshot_map.get(key, ("–", False))
                    same: bool | None = None
                    css = "reference-cell" if available else "unavailable-cell"
                else:
                    value = model_maps.get(source_id, {}).get(key, "–")
                    available = value not in {"", "–", "-"}
                    if use_device and item:
                        same = self.core.model_matches_snapshot_option(item, self.snapshot, key)
                    elif item is base_model:
                        same = None
                    elif item and base_model:
                        same = self.core.model_option_matches(item, base_model, key)
                    else:
                        same = None
                    if not available:
                        css = "unavailable-cell"
                    elif item is base_model and not use_device:
                        css = "reference-cell"
                    elif same is True:
                        css = "match-cell"
                    elif same is False:
                        css = "mismatch-cell"
                    else:
                        css = "neutral-cell"
                state_key = (source_id, key)
                default_active = bool(available and (source_id == "device" or same is True or (item is base_model and not use_device)))
                active = saved_states.get(state_key, default_active)
                check = Gtk.CheckButton(label=str(value))
                check.set_active(active)
                check.set_sensitive(bool(available))
                check.set_size_request(268 if self.appearance_layout == "studio-panels" else 285, 31 if self.appearance_layout == "studio-panels" else 38)
                check.get_style_context().add_class(css)
                child = check.get_child()
                if isinstance(child, Gtk.Label):
                    child.set_line_wrap(True)
                    child.set_max_width_chars(42)
                grid.attach(check, column, row_index, 1, 1)
                self._model_option_bindings.append({
                    "check": check,
                    "key": key,
                    "source_id": source_id,
                    "source": "device" if source_id == "device" else "model",
                    "item": item,
                    "available": available,
                })
        box.pack_start(grid, False, False, 0)
        box.show_all()

    def _search_selected_model_options(self, _button=None) -> None:
        filters: dict[str, list[dict[str, object]]] = {}
        for binding in self._model_option_bindings:
            check = binding.get("check")
            if not isinstance(check, Gtk.CheckButton) or not check.get_active() or not binding.get("available"):
                continue
            filters.setdefault(str(binding.get("key") or ""), []).append(binding)
        filters.pop("", None)
        if not filters:
            self.set_status(self._t("Bitte mindestens eine Vergleichsoption markieren.", "Select at least one comparison option.", "Vyberte alespoň jednu možnost porovnání."), "warn")
            return
        matched: list[dict[str, object]] = []
        for candidate in self.models:
            matches_all = True
            for key, bindings in filters.items():
                category_match = False
                for binding in bindings:
                    if binding.get("source") == "device":
                        category_match = self.core.model_matches_snapshot_option(candidate, self.snapshot, key) is True
                    else:
                        source_item = binding.get("item")
                        category_match = isinstance(source_item, dict) and self.core.model_option_matches(candidate, source_item, key)
                    if category_match:
                        break
                if not category_match:
                    matches_all = False
                    break
            if matches_all:
                matched.append(candidate)
        results = [(self._model_display_score(item), item) for item in matched]
        if self._model_has_score_reference():
            results.sort(key=lambda pair: pair[0], reverse=True)
        self._populate_model_results(results[:250])
        self.set_status(
            self._t(f"{len(matched)} Modelle passen zu den gewählten Optionen.", f"{len(matched)} models match the selected options.", f"Vybraným možnostem odpovídá {len(matched)} modelů."),
            "good" if matched else "warn",
        )

    # ---------- battery ----------

    # ---------- Magic Image ----------

    def _build_magic_image_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Magic Image", "Magic Image", "Magic Image"),
            self._t(
                "Config, Image und Ziel bewusst wählen. Clonezilla wird beim Öffnen dieser Seite automatisch nur lesend geprüft.",
                "Choose config, image and target deliberately. Clonezilla is checked read-only automatically when this page opens.",
                "Vědomě vyberte konfiguraci, obraz a cíl. Clonezilla se při otevření této stránky automaticky kontroluje pouze pro čtení.",
            ),
        )

        notice = Gtk.Frame()
        notice.set_shadow_type(Gtk.ShadowType.NONE)
        notice.get_style_context().add_class("card")
        notice_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        notice.add(notice_box)
        notice_box.pack_start(
            self._label(
                self._t("SICHERER INSTALLATIONSLAUF · geschrieben wird erst nach der finalen Bestätigung", "SAFE INSTALLATION FLOW · writing starts only after final confirmation", "BEZPEČNÝ INSTALAČNÍ POSTUP · zápis začne až po konečném potvrzení"),
                "section-title",
            ),
            False,
            False,
            0,
        )
        notice_box.pack_start(
            self._label(
                self._t(
                    "Das Ziel wird vor dem Restore erneut über Seriennummer, Modell und Größe geprüft.",
                    "The target is rechecked by serial number, model and size before restore.",
                    "Cíl se před obnovením znovu ověří podle sériového čísla, modelu a velikosti.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        outer.pack_start(notice, False, False, 10)

        workspace = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        workspace.set_homogeneous(False)
        outer.pack_start(workspace, True, True, 4)

        selection_card = Gtk.Frame()
        selection_card.set_shadow_type(Gtk.ShadowType.NONE)
        selection_card.get_style_context().add_class("card")
        selection_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=9)
        selection_box.set_margin_start(12)
        selection_box.set_margin_end(12)
        selection_box.set_margin_top(10)
        selection_box.set_margin_bottom(12)
        selection_card.add(selection_box)
        selection_card.set_size_request(520, -1)
        workspace.pack_start(selection_card, True, True, 0)

        media_head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        media_head.pack_start(self._label(self._t("Clonezilla-Engine", "Clonezilla engine", "Modul Clonezilla"), "section-title"), False, False, 0)
        media_head.pack_end(
            self._button(self._t("Aktualisieren", "Refresh", "Obnovit"), self._magic_refresh_clicked, "secondary-button", "view-refresh-symbolic"),
            False,
            False,
            0,
        )
        selection_box.pack_start(media_head, False, False, 0)
        media_status = self._label(self._t("Prüfung wird beim Öffnen automatisch gestartet …", "Check starts automatically when opening …", "Kontrola se při otevření spustí automaticky …"), "muted", wrap=True)
        selection_box.pack_start(media_status, False, False, 0)
        self._build_refs["magic_media_status"] = media_status

        selection_box.pack_start(self._label(self._t("Config", "Config", "Konfigurace"), "section-title"), False, False, 8)
        config_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        config_entry = Gtk.Entry()
        config_entry.set_max_length(4)
        config_entry.set_width_chars(9)
        config_entry.set_size_request(210, 64)
        config_entry.set_input_purpose(Gtk.InputPurpose.DIGITS)
        config_entry.get_style_context().add_class("magic-config-entry")
        config_entry.connect("changed", self._magic_config_changed)
        config_entry.connect("activate", self._magic_validate_config)
        config_row.pack_start(config_entry, False, False, 0)
        config_row.pack_start(self._label(self._t("vierstellig", "four digits", "čtyři číslice"), "muted"), False, False, 0)
        selection_box.pack_start(config_row, False, False, 0)
        config_hint = self._label("", "muted", wrap=True)
        config_status = self._label(self._t("Nummer eingeben – Config oder Komplettimage wird gesucht.", "Enter number – searching for a config or complete image.", "Zadejte číslo – vyhledá se konfigurace nebo kompletní obraz."), "muted", wrap=True)
        config_status.get_style_context().add_class("magic-config-status")
        selection_box.pack_start(config_hint, False, False, 0)
        selection_box.pack_start(config_status, False, False, 0)
        self._build_refs["magic_config_entry"] = config_entry
        self._build_refs["magic_config_hint"] = config_hint
        self._build_refs["magic_config_status"] = config_status

        selection_box.pack_start(self._label(self._t("Image und Ziel", "Image and target", "Obraz a cíl"), "section-title"), False, False, 8)
        image_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        image_row.pack_start(self._label(self._t("Magic Image", "Magic image", "Magic Image")), False, False, 0)
        image_combo = Gtk.ComboBoxText()
        image_combo.set_hexpand(True)
        image_combo.get_style_context().add_class("magic-selector")
        image_combo.append("", self._t("Image auswählen", "Select image", "Vybrat obraz"))
        image_combo.set_active(0)
        image_combo.connect("changed", self._magic_selection_changed)
        image_row.pack_start(image_combo, True, True, 0)
        selection_box.pack_start(image_row, False, False, 0)

        target_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        target_row.pack_start(self._label(self._t("Ziel-SSD", "Target SSD", "Cílové SSD")), False, False, 0)
        target_combo = Gtk.ComboBoxText()
        target_combo.set_hexpand(True)
        target_combo.get_style_context().add_class("magic-selector")
        target_combo.append("", self._t("Interne SSD auswählen", "Select internal SSD", "Vybrat interní SSD"))
        target_combo.set_active(0)
        target_combo.connect("changed", self._magic_selection_changed)
        target_row.pack_start(target_combo, True, True, 0)
        selection_box.pack_start(target_row, False, False, 0)

        data_disk_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        data_disk_row.pack_start(
            self._label(self._t("Daten-HDD (optional)", "Data HDD (optional)", "Datový HDD (volitelné)")),
            False,
            False,
            0,
        )
        data_disk_combo = Gtk.ComboBoxText()
        data_disk_combo.set_hexpand(True)
        data_disk_combo.get_style_context().add_class("magic-selector")
        data_disk_combo.append(
            "",
            self._t(
                "Keine Daten-HDD vorbereiten",
                "Do not prepare a data HDD",
                "Nepřipravovat datový HDD",
            ),
        )
        data_disk_combo.set_active(0)
        data_disk_combo.connect("changed", self._magic_selection_changed)
        data_disk_row.pack_start(data_disk_combo, True, True, 0)
        selection_box.pack_start(data_disk_row, False, False, 5)
        selection_box.pack_start(
            self._label(
                self._t(
                    "Optional: zweite interne HDD vollständig leeren und nach erfolgreichem Restore als NTFS-Datenplatte vorbereiten.",
                    "Optional: erase a second internal HDD completely and prepare it as an NTFS data disk after the successful restore.",
                    "Volitelné: druhý interní HDD úplně vymazat a po úspěšném obnovení jej připravit jako datový disk NTFS.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        self._build_refs["magic_image_combo"] = image_combo
        self._build_refs["magic_target_combo"] = target_combo
        self._build_refs["magic_data_disk_combo"] = data_disk_combo

        summary_card = Gtk.Frame()
        summary_card.set_shadow_type(Gtk.ShadowType.NONE)
        summary_card.get_style_context().add_class("card")
        summary_section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        summary_section.set_margin_start(12)
        summary_section.set_margin_end(12)
        summary_section.set_margin_top(10)
        summary_section.set_margin_bottom(12)
        summary_card.add(summary_section)
        workspace.pack_start(summary_card, True, True, 0)
        summary_section.pack_start(self._label(self._t("Sicherheitsstatus", "Safety status", "Stav bezpečnosti"), "section-title"), False, False, 0)
        summary_view = Gtk.TextView()
        summary_view.set_editable(False)
        summary_view.set_cursor_visible(False)
        summary_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        summary_view.set_left_margin(10)
        summary_view.set_right_margin(10)
        summary_view.set_top_margin(8)
        summary_view.set_bottom_margin(8)
        summary_view.get_style_context().add_class("card")
        summary_view.get_buffer().set_text(
            self._t("Noch keine gültige Installationsprüfung vorbereitet.", "No valid installation check has been prepared yet.", "Zatím nebyla připravena platná kontrola instalace.")
        )
        summary_view.set_size_request(420, 220)
        summary_section.pack_start(summary_view, True, True, 0)
        self._build_refs["magic_summary"] = summary_view

        progress_label = self._label("", "muted", wrap=True)
        progress_label.get_style_context().add_class("magic-progress-label")
        progress = Gtk.ProgressBar()
        progress.set_show_text(True)
        progress.set_size_request(-1, 42)
        progress.get_style_context().add_class("magic-progress")
        progress.set_no_show_all(True)
        progress_label.set_no_show_all(True)
        progress.hide()
        progress_label.hide()
        summary_section.pack_start(progress_label, False, False, 0)
        summary_section.pack_start(progress, False, False, 0)
        self._build_refs["magic_restore_progress"] = progress
        self._build_refs["magic_restore_progress_label"] = progress_label

        restore_action = self._button(
            self._t("Jetzt installieren …", "Install now …", "Nainstalovat nyní …"),
            self._magic_restore_clicked,
            "primary-button",
            "system-run-symbolic",
        )
        restore_action.set_sensitive(False)
        summary_section.pack_start(restore_action, False, False, 2)
        self._build_refs["magic_restore_action"] = restore_action
        return page

    def _magic_config_value(self) -> str:
        entry: Gtk.Entry | None = self._build_refs.get("magic_config_entry")
        return entry.get_text().strip() if entry is not None else ""

    def _populate_magic_configs(self) -> None:
        hint: Gtk.Label | None = self._build_refs.get("magic_config_hint")
        if hint is None:
            return
        if self._magic_config_validation and self._magic_config_validation.deployment_mode == "complete":
            hint.set_text("")
            return
        suggestions: list[str] = []
        for result in self.match_results[:3]:
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            model_id = str(item.get("model_id") or "").strip()
            if re.fullmatch(r"\d{4}", model_id):
                suggestions.append(f"{model_id} ({int(result.get('score') or 0)} %)" )
        if suggestions:
            hint.set_text(
                self._t(
                    "Hardware-Vorschlag: " + ", ".join(suggestions),
                    "Hardware suggestion: " + ", ".join(suggestions),
                    "Návrh hardwaru: " + ", ".join(suggestions),
                )
            )
        else:
            hint.set_text("")

    def _magic_config_changed(self, _widget=None) -> None:
        value = self._magic_config_value()
        if self._magic_config_validate_timer_id is not None:
            GLib.source_remove(self._magic_config_validate_timer_id)
            self._magic_config_validate_timer_id = None
        if self._magic_last_warning_config and value != self._magic_last_warning_config:
            self._magic_last_warning_config = ""
        if self._magic_config_warning_acknowledged and value != self._magic_config_warning_acknowledged:
            self._magic_config_warning_acknowledged = ""
        if value and not re.fullmatch(r"\d{0,4}", value):
            entry: Gtk.Entry | None = self._build_refs.get("magic_config_entry")
            if entry is not None:
                entry.set_text("".join(character for character in value if character.isdigit())[:4])
            return
        self._magic_config_validation = None
        self._magic_set_config_status(None)
        self._magic_filter_images()
        self._magic_update_summary()
        status: Gtk.Label | None = self._build_refs.get("magic_config_status")
        if len(value) == 4:
            # Let barcode scanners and normal typing finish before opening a
            # modal dialog. The explicit Enter key stays available below.
            self._magic_config_validate_timer_id = GLib.timeout_add(650, self._magic_validate_config_after_pause)
            return
        if status is not None:
            status.set_text(self._t("Vier Ziffern eingeben.", "Enter four digits.", "Zadejte čtyři číslice.")) if value else status.set_text(self._t("Nummer eingeben – Config oder Komplettimage wird gesucht.", "Enter number – searching for a config or complete image.", "Zadejte číslo – vyhledá se konfigurace nebo kompletní obraz."))
        self._magic_update_summary()

    def _magic_validate_config_after_pause(self) -> bool:
        self._magic_config_validate_timer_id = None
        if len(self._magic_config_value()) == 4:
            self._magic_validate_config()
        return False

    def _magic_set_config_status(self, validation: magic.ConfigValidation | None) -> None:
        status: Gtk.Label | None = self._build_refs.get("magic_config_status")
        if status is None:
            return
        context = status.get_style_context()
        for css_class in ("good", "warn", "bad"):
            context.remove_class(css_class)
        if validation is None:
            return
        if not validation.valid or validation.requires_confirmation:
            context.add_class("bad")
        elif validation.strict_match:
            context.add_class("good")
        else:
            context.add_class("warn")
        status.set_text(self._magic_config_status_text(validation))
        self._populate_magic_configs()

    def _magic_validate_config(self, _widget=None) -> None:
        value = self._magic_config_value()
        status: Gtk.Label | None = self._build_refs.get("magic_config_status")
        if len(value) != 4:
            self._magic_config_validation = None
            self._magic_set_config_status(None)
            self._magic_filter_images()
            if status is not None:
                status.set_text(
                    self._t(
                        "Config muss genau vier Ziffern enthalten.",
                        "Config must contain exactly four digits.",
                        "Konfigurace musí obsahovat přesně čtyři číslice.",
                    )
                    if value
                    else self._t("Nummer eingeben – Config oder Komplettimage wird gesucht.", "Enter number – searching for a config or complete image.", "Zadejte číslo – vyhledá se konfigurace nebo kompletní obraz.")
                )
            self._magic_update_summary()
            return
        if self._magic_scan_pending:
            self._magic_config_validation = None
            self._magic_set_config_status(None)
            self._magic_filter_images()
            if status is not None:
                status.set_text(
                    self._t(
                        "Image-Medium wird noch geprüft …",
                        "Image medium is still being checked …",
                        "Médium s obrazy se ještě kontroluje …",
                    )
                )
            self._magic_update_summary()
            return
        # The normal Magic config directory is a tiny, direct lookup.  Only
        # if it is absent do we inspect the matching *single* legacy Acronis
        # folder.  Scanning every legacy image here made opening the embedded
        # HardwareCheck page unnecessarily slow on production media.
        classic_acronis_images: tuple[magic.ClassicAcronisImage, ...] = ()
        has_complete_image = any(
            image.deployment_mode == "complete" and value in image.model_configs
            for image in self._magic_inspection.images
        )
        complete_fallback = value not in self._magic_inspection.available_configs and has_complete_image
        if not self.snapshot and not complete_fallback:
            self._magic_config_validation = None
            self._magic_set_config_status(None)
            self._magic_filter_images()
            if status is not None:
                status.set_text(self._t(
                    "Hardware-Scan noch nicht bereit. Bitte warten.",
                    "Hardware scan is not ready yet. Please wait.",
                    "Sken hardwaru ještě není připraven. Vyčkejte prosím.",
                ))
            self._magic_update_summary()
            return
        if value not in self._magic_inspection.available_configs and not has_complete_image:
            classic_acronis_images = self._magic_classic_acronis_for_config(value)
        self._magic_config_validation = magic.validate_config(
            value,
            self.models or [],
            self.snapshot or {},
            self.core.score_model_candidate,
            self._magic_inspection.available_configs,
            classic_acronis_images,
            self._magic_inspection.config_profiles,
            complete_images=self._magic_inspection.images,
        )
        if (
            self._magic_config_validation.requires_confirmation
            and self._magic_config_validation.config == self._magic_config_warning_acknowledged
        ):
            self._magic_config_validation = magic.confirm_config_override(self._magic_config_validation)
        validation = self._magic_config_validation
        checking_server = self._magic_start_config_server_check(value)
        self._magic_set_config_status(validation)
        self._magic_filter_images()
        self._magic_update_summary()
        if checking_server and not validation.valid:
            if status is not None:
                status.set_text(self._t(
                    "Config wird lokal geprüft · Server-Version wird geprüft …",
                    "Checking config locally · checking server version …",
                    "Konfigurace se ověřuje místně · kontroluje se verze na serveru …",
                ))
            return
        if validation.config == self._magic_last_warning_config:
            return
        if validation.valid and validation.requires_confirmation and not validation.override_confirmed:
            self._magic_last_warning_config = validation.config
            self._show_magic_config_warning(validation)
        elif not validation.valid:
            self._magic_last_warning_config = validation.config
            self._show_magic_config_unavailable(validation)

    def _magic_classic_acronis_for_config(self, config: str) -> tuple[magic.ClassicAcronisImage, ...]:
        """Find an optional Acronis fallback only for the entered config."""

        cached = self._magic_classic_acronis_by_config.get(config)
        if cached is not None:
            return cached
        found = tuple(
            magic.discover_classic_acronis_images(
                self._magic_inspection.config_repository_paths,
                config_filter=config,
            )
        )
        self._magic_classic_acronis_by_config[config] = found
        return found

    def _magic_config_server_root(self) -> pathlib.Path:
        return pathlib.Path(self.core.SCRIPT_DIR).resolve()

    def _magic_config_server_active(self) -> bool:
        settings = config_server_sync.load_settings(self._magic_config_server_root())
        return bool(settings.enabled and settings.endpoint)

    def _magic_start_config_server_check(self, config: str) -> bool:
        if (
            not self._magic_config_server_active()
            or self._magic_config_server_pending == config
            or config in self._magic_config_server_checked
        ):
            return False
        self._magic_config_server_pending = config
        repositories = tuple(self._magic_inspection.config_repository_paths)

        def worker():
            return config_server_sync.sync_requested_config(
                config,
                repositories,
                self._magic_config_server_root(),
            )

        self.run_async("magic-config-server", worker, self._magic_config_server_finished)
        return True

    def _magic_config_server_finished(self, result: config_server_sync.ConfigSyncResult) -> None:
        if self._magic_config_server_pending == result.config:
            self._magic_config_server_pending = ""
        self._magic_config_server_checked.add(result.config)
        if result.changed:
            self._magic_inspection.available_configs = magic.discover_config_ids(
                self._magic_inspection.config_repository_paths
            )
            self._magic_inspection.config_profiles = magic.discover_config_profiles(
                self._magic_inspection.config_repository_paths
            )
            self.models = config_server_sync.merge_model_overrides(
                self.models, self._magic_config_server_root()
            )
            self._magic_last_warning_config = ""
        if self._magic_config_value() != result.config:
            return
        self._magic_validate_config()
        if result.error and self._magic_config_validation and not self._magic_config_validation.valid:
            status: Gtk.Label | None = self._build_refs.get("magic_config_status")
            if status is not None:
                status.set_text(
                    self._t(
                        "Config-Server konnte nicht abgefragt werden. Die lokale Config bleibt aktiv.",
                        "The config server could not be reached. The local config remains active.",
                        "Server konfigurací nelze kontaktovat. Místní konfigurace zůstává aktivní.",
                    )
                )

    def _show_magic_config_warning(self, validation: magic.ConfigValidation) -> None:
        """Make a wrong four-digit config unmistakable before any restore exists."""

        dialog = Gtk.Dialog(
            title=self._t("Config passt nicht zum Gerät", "Config does not match this device", "Konfigurace neodpovídá zařízení"),
            transient_for=self.window,
            flags=Gtk.DialogFlags.MODAL,
        )
        dialog.get_style_context().add_class("magic-config-warning")
        dialog.set_default_size(760, -1)
        close = dialog.add_button(self._t("Config ändern", "Change config", "Změnit konfiguraci"), Gtk.ResponseType.CANCEL)
        close.get_style_context().add_class("primary-button")
        continue_button = dialog.add_button(
            self._t("Abweichung bewusst bestätigen", "Confirm mismatch deliberately", "Vědomě potvrdit odchylku"),
            Gtk.ResponseType.ACCEPT,
        )
        continue_button.get_style_context().add_class("secondary-button")
        content = dialog.get_content_area()
        content.set_spacing(12)
        content.set_margin_start(24)
        content.set_margin_end(24)
        content.set_margin_top(20)
        content.set_margin_bottom(20)
        content.pack_start(
            self._label(
                self._t("ACHTUNG: Config bitte prüfen", "WARNING: Check config", "VAROVÁNÍ: Zkontrolujte konfiguraci"),
                "warning-title",
            ),
            False,
            False,
            0,
        )
        content.pack_start(
            self._label(
                f"{self._t('Config', 'Config', 'Konfigurace')}: {validation.config}",
                "config-warning-config",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        details = self._magic_config_difference_lines(validation)
        if details:
            content.pack_start(
                self._label(
                    self._t("Erkannte Abweichungen:", "Detected mismatches:", "Zjištěné odchylky:"),
                    "config-warning-list-title",
                ),
                False,
                False,
                2,
            )
            differences = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            for detail in details:
                differences.pack_start(self._magic_config_difference_card(detail), False, False, 0)
            content.pack_start(differences, False, False, 0)
        dialog.show_all()
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.ACCEPT:
            self._magic_config_validation = magic.confirm_config_override(validation)
            self._magic_config_warning_acknowledged = validation.config
            self._magic_set_config_status(self._magic_config_validation)
            self._magic_update_summary()

    def _magic_config_difference_card(self, detail: str) -> Gtk.Box:
        """Render one device/config mismatch as the readable Solo-style card."""

        metric, separator, comparison = detail.partition(":")
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        card.get_style_context().add_class("magic-config-difference-card")
        if not separator:
            card.pack_start(self._label(detail, "magic-config-difference-device", wrap=True), False, False, 0)
            return card

        translated_metric = {
            "Hersteller": self._t("Hersteller", "Manufacturer", "Výrobce"),
            "CPU": "CPU",
            "RAM gesamt": self._t("RAM gesamt", "Total RAM", "RAM celkem"),
            "RAM-Bestückung": self._t("RAM-Bestückung", "RAM layout", "Osazení RAM"),
            "SSD-Typ": self._t("SSD-Typ", "SSD type", "Typ SSD"),
            "SSD-Größe": self._t("SSD-Größe", "SSD size", "Velikost SSD"),
            "Display-Auflösung": self._t("Display-Auflösung", "Display resolution", "Rozlišení displeje"),
            "Display-Größe": self._t("Display-Größe", "Display size", "Velikost displeje"),
        }.get(metric.strip(), metric.strip())
        card.pack_start(self._label(translated_metric, "magic-config-difference-title"), False, False, 0)

        unknown = re.fullmatch(
            r"Gerät unbekannt – Config ([^:]+): (.+) kann nicht sicher geprüft werden\.",
            comparison.strip(),
        )
        if unknown:
            card.pack_start(
                self._label(
                    self._t(
                        "Gerät unbekannt – Vergleich nicht sicher möglich.",
                        "Device unknown – comparison is not safely possible.",
                        "Zařízení není rozpoznáno – porovnání nelze bezpečně provést.",
                    ),
                    "magic-config-difference-device",
                    wrap=True,
                ),
                False,
                False,
                0,
            )
            card.pack_start(
                self._label(
                    f"{self._t('Config', 'Config', 'Konfigurace')} {unknown.group(1)}: {unknown.group(2)}",
                    "magic-config-difference-config",
                    wrap=True,
                ),
                False,
                False,
                0,
            )
            return card

        actual, marker, expected = comparison.strip().partition(" ≠ ")
        if not marker:
            actual, marker, expected = comparison.strip().partition(" ↔ ")
        device_prefix = self._t("Gerät", "Device", "Zařízení")
        config_prefix = self._t("Config", "Config", "Konfigurace")
        actual = actual.strip()
        if actual.startswith("Gerät "):
            actual = f"{device_prefix} {actual[7:]}"
        elif actual:
            actual = f"{device_prefix} {actual}"
        card.pack_start(self._label(actual or detail, "magic-config-difference-device", wrap=True), False, False, 0)

        expected = expected.strip()
        config_match = re.fullmatch(r"Config\s+(\d{4})\s*:\s*(.*)", expected)
        if config_match:
            expected = f"{config_prefix} {config_match.group(1)}: {config_match.group(2)}"
        elif expected:
            expected = f"{config_prefix}: {expected}"
        if expected:
            card.pack_start(self._label(expected, "magic-config-difference-config", wrap=True), False, False, 0)
        return card

    def _show_magic_config_unavailable(self, validation: magic.ConfigValidation) -> None:
        """Show a red, non-bypassable warning for unavailable configurations."""

        dialog = Gtk.Dialog(
            title=self._t("Config nicht verfügbar", "Config unavailable", "Konfigurace není k dispozici"),
            transient_for=self.window,
            flags=Gtk.DialogFlags.MODAL,
        )
        dialog.get_style_context().add_class("magic-config-warning")
        dialog.set_default_size(640, -1)
        close = dialog.add_button(self._t("Config ändern", "Change config", "Změnit konfiguraci"), Gtk.ResponseType.CLOSE)
        close.get_style_context().add_class("primary-button")
        content = dialog.get_content_area()
        content.set_spacing(12)
        content.set_margin_start(24)
        content.set_margin_end(24)
        content.set_margin_top(20)
        content.set_margin_bottom(20)
        content.pack_start(
            self._label(
                self._t(
                    "WARNUNG: Installation nicht verfügbar",
                    "WARNING: Installation unavailable",
                    "VAROVÁNÍ: Instalace není k dispozici",
                ),
                "warning-title",
            ),
            False,
            False,
            0,
        )
        content.pack_start(
            self._label(
                f"{self._t('Config', 'Config', 'Konfigurace')}: {validation.config}",
                "config-warning-config",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        if validation.classic_acronis_images:
            detail = self._t(
                "Keine moderne Magic-Config gefunden. Klassisches Acronis-Image vorhanden.",
                "No modern Magic config found. A classical Acronis image is available.",
                "Nebyla nalezena moderní konfigurace Magic. Je k dispozici klasický obraz Acronis.",
            )
        else:
            detail = self._t(
                "Keine moderne Magic-Config und kein klassisches Acronis-Image gefunden.",
                "No modern Magic config and no classical Acronis image found.",
                "Nebyla nalezena moderní konfigurace Magic ani klasický obraz Acronis.",
        )
        content.pack_start(self._label(detail, "config-warning-details", wrap=True), False, False, 2)
        if validation.classic_acronis_images:
            start_acronis = dialog.add_button(
                self._t("Acronis starten", "Start Acronis", "Spustit Acronis"),
                Gtk.ResponseType.ACCEPT,
            )
            start_acronis.get_style_context().add_class("secondary-button")
        dialog.show_all()
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.ACCEPT and validation.classic_acronis_images:
            self._magic_start_acronis()

    def _magic_start_acronis(self) -> None:
        """Ask once, then select verified Acronis in the next GRUB boot."""

        dialog = Gtk.Dialog(
            title=self._t("Acronis starten", "Start Acronis", "Spustit Acronis"),
            transient_for=self.window,
            flags=Gtk.DialogFlags.MODAL,
        )
        dialog.get_style_context().add_class("magic-config-warning")
        dialog.set_default_size(610, -1)
        cancel = dialog.add_button(self._t("Zurück", "Back", "Zpět"), Gtk.ResponseType.CANCEL)
        cancel.get_style_context().add_class("primary-button")
        start = dialog.add_button(
            self._t("Jetzt neu starten", "Restart now", "Restartovat"),
            Gtk.ResponseType.ACCEPT,
        )
        start.get_style_context().add_class("secondary-button")
        content = dialog.get_content_area()
        content.set_spacing(12)
        content.set_margin_start(24)
        content.set_margin_end(24)
        content.set_margin_top(20)
        content.set_margin_bottom(20)
        content.pack_start(
            self._label(
                self._t("Acronis manuell öffnen", "Open Acronis manually", "Otevřít Acronis ručně"),
                "warning-title",
            ),
            False,
            False,
            0,
        )
        content.pack_start(
            self._label(
                self._t(
                    "Das Gerät startet einmalig in Acronis neu. Dort wählen Sie Image und Ziel wie gewohnt selbst aus. Es wird kein Image automatisch wiederhergestellt.",
                    "The device restarts once into Acronis. There you select image and target manually as usual. No image is restored automatically.",
                    "Zařízení se jednou restartuje do Acronis. Obraz a cíl zde vyberete ručně jako obvykle. Žádný obraz se automaticky neobnoví.",
                ),
                "config-warning-details",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        dialog.show_all()
        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.ACCEPT:
            return
        result = magic.schedule_acronis_boot(self._magic_inspection)
        if not result.ready:
            headline = self._t(
                "Acronis konnte nicht sicher für den nächsten Neustart vorbereitet werden.",
                "Acronis could not be prepared safely for the next restart.",
                "Acronis se nepodařilo bezpečně připravit pro příští restart.",
            )
            # The core returns the concrete safe-stop reason (for example a
            # missing EFI variable or an inaccessible GRUB partition).  Keep
            # it visible: a generic dialog made field diagnosis impossible.
            detail_label = self._t("Technische Details:", "Technical details:", "Technické podrobnosti:")
            display_message = f"{headline}\n\n{detail_label}\n{result.message}"
            self.set_status(display_message, "bad")
            error = Gtk.MessageDialog(
                transient_for=self.window,
                flags=Gtk.DialogFlags.MODAL,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.CLOSE,
                text=self._t("Acronis konnte nicht gestartet werden", "Acronis could not be started", "Acronis nelze spustit"),
            )
            error.format_secondary_text(display_message)
            error.run()
            error.destroy()
            return
        self.set_status(
            self._t(
                "Acronis ist für den nächsten Neustart vorbereitet.",
                "Acronis is prepared for the next restart.",
                "Acronis je připraven pro příští restart.",
            ),
            "good",
        )
        GLib.timeout_add(450, self._magic_reboot_to_acronis)

    def _magic_reboot_to_acronis(self) -> bool:
        """The one-time GRUB marker has been written; this only restarts Debian."""

        try:
            os.sync()
            subprocess.Popen(["systemctl", "reboot"], start_new_session=True)
        except OSError as exc:
            self.set_status(
                self._t(
                    f"Acronis wurde vorbereitet, aber der Neustart konnte nicht ausgelöst werden: {exc}",
                    f"Acronis was prepared, but the restart could not be triggered: {exc}",
                    f"Acronis byl připraven, ale restart nelze spustit: {exc}",
                ),
                "bad",
            )
        return False

    def _magic_config_difference_lines(self, validation: magic.ConfigValidation) -> list[str]:
        """Present the concrete device-versus-config differences to an operator."""

        if validation.legacy_config_without_model:
            return [self._t(
                f"#configs\\{validation.config} ist vorhanden, aber model.json enthält keine Hardwaredaten. Ein automatischer Hardwarevergleich ist nicht möglich.",
                f"#configs\\{validation.config} exists, but model.json contains no hardware data. An automatic hardware comparison is not possible.",
                f"#configs\\{validation.config} existuje, ale model.json neobsahuje údaje o hardwaru. Automatické porovnání hardwaru není možné.",
            )]
        if validation.details:
            return list(validation.details)
        model = validation.model or {}
        reason_text = " ".join(validation.details).lower()
        lines = [detail for detail in validation.details if "passend" not in detail.lower() and "deckel:" not in detail.lower()]

        def add_comparison(label: str, device_value: object, config_value: object) -> None:
            device_text = str(device_value or "unbekannt").strip()
            config_text = str(config_value or "unbekannt").strip()
            candidate = f"{label}: Gerät {device_text}  ↔  Config {config_text}"
            if candidate not in lines:
                lines.append(candidate)

        if "hersteller" in reason_text:
            add_comparison("Hersteller", self.snapshot.get("vendor_short"), model.get("vendor"))
        if "cpu" in reason_text:
            add_comparison("CPU", self.snapshot.get("cpu_short") or self.snapshot.get("cpu"), model.get("cpu"))
        if "ram" in reason_text:
            actual_ram = self.snapshot.get("ram_total_gb")
            expected_ram = model.get("ram_total")
            add_comparison("RAM", f"{actual_ram} GB" if actual_ram not in (None, "") else "", f"{expected_ram} GB" if expected_ram not in (None, "") else "")
        if "speicher" in reason_text or "ssd" in reason_text:
            actual_ssd = self.snapshot.get("primary_disk_gb")
            expected_ssd = model.get("ssd")
            add_comparison("SSD", f"{actual_ssd} GB" if actual_ssd not in (None, "") else "", f"{expected_ssd} GB" if expected_ssd not in (None, "") else "")
        if "display" in reason_text:
            add_comparison("Display", self.snapshot.get("display_inches"), model.get("inch"))
        return lines

    def _magic_refresh_clicked(self, _button=None) -> None:
        if self._magic_scan_pending:
            return
        self._magic_scan_pending = True
        media_status: Gtk.Label | None = self._build_refs.get("magic_media_status")
        if media_status is not None:
            media_status.set_text(self._t("Analysiere angeschlossene Medien …", "Analysing connected media …", "Analyzuji připojená média …"))
        self.run_async(
            "magic-media",
            lambda: magic.inspect_media(include_classic_acronis=False),
            self._magic_refresh_finished,
        )

    def _magic_refresh_finished(self, inspection: magic.MediaInspection) -> None:
        self._magic_scan_pending = False
        self._magic_inspection = inspection
        self._magic_classic_acronis_by_config.clear()
        self._magic_config_validation = None
        self._magic_filter_images()
        self._magic_targets_by_path = {target.path: target for target in inspection.safe_targets}
        self._magic_data_disks_by_path = {
            disk.path: disk
            for disk in magic.safe_data_disk_targets(inspection.devices, inspection.protected_disks)
        }
        media_status: Gtk.Label | None = self._build_refs.get("magic_media_status")
        if media_status is not None:
            roles = ", ".join(f"{role.role}: {role.parent_disk}" for role in inspection.roles) or self._t("keine Rollen erkannt", "no roles detected", "nebyly rozpoznány žádné role")
            warning_note = ""
            if inspection.warnings:
                warning_note = " " + self._t(
                    "Bei der Medienprüfung liegen Hinweise vor; die Installation bleibt bis zur vollständigen Sicherheitsprüfung gesperrt.",
                    "The media check returned notices; installation remains locked until the safety check is complete.",
                    "Kontrola média zobrazila upozornění; instalace zůstává uzamčena až do dokončení bezpečnostní kontroly.",
                )
            media_status.set_text(
                f"{self._t('Geschützte Medien', 'Protected media', 'Chráněná média')}: {roles}. "
                f"{self._magic_clonezilla_message(inspection.clonezilla)}{warning_note}".strip()
            )
        target_combo: Gtk.ComboBoxText | None = self._build_refs.get("magic_target_combo")
        if target_combo is not None:
            target_combo.remove_all()
            target_combo.append("", self._t("Interne Ziel-SSD bewusst auswählen", "Explicitly select internal target SSD", "Vědomě vyberte interní cílové SSD"))
            for target in inspection.safe_targets:
                target_combo.append(target.path, self._magic_disk_display_text(target))
            target_combo.set_active(0)
        data_disk_combo: Gtk.ComboBoxText | None = self._build_refs.get("magic_data_disk_combo")
        if data_disk_combo is not None:
            data_disk_combo.remove_all()
            data_disk_combo.append(
                "",
                self._t(
                    "Keine Daten-HDD vorbereiten",
                    "Do not prepare a data HDD",
                    "Nepřipravovat datový HDD",
                ),
            )
            for disk in self._magic_data_disks_by_path.values():
                data_disk_combo.append(disk.path, self._magic_disk_display_text(disk))
            data_disk_combo.set_active(0)
        self._magic_validate_config()
        self._magic_update_summary()
        self._magic_engine_check_clicked()

    def _magic_engine_check_clicked(self, _button=None) -> None:
        if self._magic_engine_pending:
            return
        if not self._magic_inspection.clonezilla.source_path:
            self.set_status(
                self._t(
                    "Keine geprüfte Clonezilla-Quelle erkannt. Zuerst Medien prüfen.",
                    "No verified Clonezilla source detected. Check media first.",
                    "Nebyl rozpoznán žádný ověřený zdroj Clonezilly. Nejdříve zkontrolujte média.",
                ),
                "warn",
            )
            return
        self._magic_engine_pending = True
        media_status: Gtk.Label | None = self._build_refs.get("magic_media_status")
        if media_status is not None:
            media_status.set_text(
                self._t(
                    "Prüfe Clonezilla nur lesend mit ocs-sr --help … Kein Restore wird gestartet.",
                    "Checking Clonezilla read-only with ocs-sr --help … No restore will start.",
                    "Clonezilla se kontroluje pouze pro čtení pomocí ocs-sr --help … Obnovení se nespustí.",
                )
            )
        self.run_async(
            "magic-clonezilla-engine",
            lambda: magic.diagnose_clonezilla_runtime(self._magic_inspection),
            self._magic_engine_check_finished,
        )

    def _magic_engine_check_finished(self, probe: magic.ClonezillaProbe) -> None:
        self._magic_engine_pending = False
        self._magic_inspection.clonezilla = probe
        media_status: Gtk.Label | None = self._build_refs.get("magic_media_status")
        if media_status is not None:
            media_status.set_text(self._magic_clonezilla_message(probe))
        self._magic_update_summary()
        self.set_status(
            self._t(
                "Clonezilla-Engine geprüft. Kein Restore und kein Schreibvorgang.",
                "Clonezilla engine checked. No restore and no write operation.",
                "Clonezilla engine byla ověřena. Žádné obnovení ani zápis.",
            )
            if probe.usage_verified
            else self._magic_clonezilla_message(probe),
            "good" if probe.usage_verified else "warn",
        )

    def _magic_selection_changed(self, _widget=None) -> None:
        if not getattr(self, "_magic_image_choices_pending", False):
            self._magic_update_summary()

    def _magic_filter_images(self) -> None:
        """Keep the image choice tied to the currently validated number."""

        combo: Gtk.ComboBoxText | None = self._build_refs.get("magic_image_combo")
        validation = self._magic_config_validation
        if validation and validation.config != self._magic_config_value():
            validation = None
        images = magic.install_images_for_config(validation, self._magic_inspection.images)
        selected_id = combo.get_active_id() if combo is not None else None
        self._magic_images_by_id = {image.image_id: image for image in images}
        if combo is None:
            return
        self._magic_image_choices_pending = True
        try:
            combo.remove_all()
            combo.append("", self._t("Image auswählen", "Select image", "Vybrat obraz"))
            for image in images:
                combo.append(image.image_id, self._magic_image_display_text(image))
            checking_server = validation and self._magic_config_server_pending == validation.config
            if selected_id in self._magic_images_by_id and not checking_server:
                combo.set_active_id(selected_id)
            elif validation and validation.deployment_mode == "complete" and len(images) == 1 and not checking_server:
                combo.set_active_id(images[0].image_id)
            else:
                combo.set_active(0)
        finally:
            self._magic_image_choices_pending = False

    def _magic_selected_image(self) -> magic.MagicImage | None:
        combo: Gtk.ComboBoxText | None = self._build_refs.get("magic_image_combo")
        image = self._magic_images_by_id.get(combo.get_active_id() or "") if combo is not None else None
        validation = self._magic_config_validation
        if image and image.deployment_mode == "complete" and (
            validation is None
            or validation.deployment_mode != "complete"
            or validation.config != self._magic_config_value()
            or validation.config not in image.model_configs
        ):
            return None
        return image

    def _magic_selected_target(self) -> magic.BlockDevice | None:
        combo: Gtk.ComboBoxText | None = self._build_refs.get("magic_target_combo")
        return self._magic_targets_by_path.get(combo.get_active_id() or "") if combo is not None else None

    def _magic_selected_data_disk(self) -> magic.BlockDevice | None:
        combo: Gtk.ComboBoxText | None = self._build_refs.get("magic_data_disk_combo")
        return self._magic_data_disks_by_path.get(combo.get_active_id() or "") if combo is not None else None

    def _magic_config_status_text(self, validation: magic.ConfigValidation) -> str:
        """Keep the operator-facing config state independent from German core logs."""

        if validation.valid and validation.deployment_mode == "complete":
            return self._t(
                f"Clonezilla-Komplettimage für {validation.config} gefunden. Die Modellprüfung übernimmt das vorhandene Skript nach dem Windows-Start.",
                f"Complete Clonezilla image found for {validation.config}. The existing script checks the model after Windows starts.",
                f"Nalezen kompletní obraz Clonezilla pro {validation.config}. Model ověří stávající skript po spuštění Windows.",
            )
        if validation.strict_match:
            return self._t(
                f"Config {validation.config} passt zum Gerät.",
                f"Config {validation.config} matches this device.",
                f"Konfigurace {validation.config} odpovídá zařízení.",
            )
        if validation.legacy_config_without_model:
            return self._t(
                f"ACHTUNG: #configs\\{validation.config} ist vorhanden, aber model.json hat keine Hardwaredaten. Nur nach bewusster Bestätigung fortfahren.",
                f"ATTENTION: #configs\\{validation.config} exists, but model.json has no hardware data. Continue only after deliberate confirmation.",
                f"POZOR: #configs\\{validation.config} existuje, ale model.json nemá údaje o hardwaru. Pokračujte pouze po vědomém potvrzení.",
            )
        if validation.valid and validation.requires_confirmation:
            if validation.details:
                return self._t(
                    f"ROTE WARNUNG: {len(validation.details)} Hardware-Abweichung(en) zur Config {validation.config}. Bitte erst bewusst bestätigen.",
                    f"RED WARNING: {len(validation.details)} hardware mismatch(es) for config {validation.config}. Confirm deliberately first.",
                    f"ČERVENÉ VAROVÁNÍ: {len(validation.details)} hardwarových odchylek pro konfiguraci {validation.config}. Nejprve je vědomě potvrďte.",
                )
            return self._t(
                f"ACHTUNG: Hardwarevergleich für Config {validation.config} ist unvollständig. Bitte bewusst bestätigen.",
                f"ATTENTION: The hardware comparison for config {validation.config} is incomplete. Confirm deliberately.",
                f"POZOR: Porovnání hardwaru pro konfiguraci {validation.config} není úplné. Vědomě je potvrďte.",
            )
        if validation.classic_acronis_images:
            return self._t(
                "Keine moderne Magic-Config gefunden. Klassisches Acronis-Image vorhanden.",
                "No modern Magic config was found. A classic Acronis image is available.",
                "Nebyla nalezena moderní konfigurace Magic. Je k dispozici klasický obraz Acronis.",
            )
        return self._t(
            "Keine passende moderne Magic-Config verfügbar.",
            "No matching modern Magic config is available.",
            "Není k dispozici odpovídající moderní konfigurace Magic.",
        )

    def _magic_clonezilla_message(self, probe: magic.ClonezillaProbe) -> str:
        """Show a translated, safe state; detailed German diagnostics remain in logs."""

        if probe.usage_verified:
            return self._t(
                "Clonezilla-Engine vom geschützten Medium erfolgreich geprüft; kein Restore wurde ausgeführt.",
                "Clonezilla engine on the protected medium was verified successfully; no restore was performed.",
                "Engine Clonezilly na chráněném médiu byla úspěšně ověřena; nebylo provedeno žádné obnovení.",
            )
        if probe.source_path:
            return self._t(
                "Clonezilla-Engine wurde erkannt, die sichere Prüfung war jedoch nicht erfolgreich.",
                "The Clonezilla engine was detected, but the safe verification was not successful.",
                "Engine Clonezilly byla rozpoznána, ale bezpečné ověření nebylo úspěšné.",
            )
        return self._t(
            "Keine geprüfte Clonezilla-Engine erkannt.",
            "No verified Clonezilla engine was detected.",
            "Nebyla rozpoznána žádná ověřená engine Clonezilly.",
        )

    def _magic_image_display_text(self, image: magic.MagicImage) -> str:
        version = f" · {image.version}" if image.version else ""
        if image.deployment_mode == "complete":
            return f"{image.display_name}{version} · " + self._t(
                "Clonezilla-Komplettimage", "Complete Clonezilla image", "Kompletní obraz Clonezilla"
            )
        source = self._t("Manifest", "Manifest", "Manifest") if image.managed else self._t(
            "Image ohne Manifest", "Image without manifest", "Image bez manifestu"
        )
        return f"{image.display_name}{version} ({source})"

    def _magic_disk_display_text(self, disk: magic.BlockDevice) -> str:
        return disk.description.replace(
            "unbekanntes Modell", self._t("unbekanntes Modell", "unknown model", "neznámý model")
        ).replace(
            "unbekannter Bus", self._t("unbekannter Bus", "unknown bus", "neznámá sběrnice")
        )

    def _magic_plan_message(self, plan: magic.RestoreProofPlan) -> str:
        if plan.ready:
            return self._t(
                "Restore ist vorbereitet. Die Ziel-SSD wird erst nach der expliziten Bestätigung gelöscht.",
                "Restore is prepared. The target SSD is erased only after the explicit confirmation.",
                "Obnovení je připraveno. Cílové SSD bude vymazáno až po výslovném potvrzení.",
            )
        return self._t(
            "Die Installation ist aus Sicherheitsgründen noch nicht vollständig vorbereitet.",
            "The installation is not yet fully prepared for safety reasons.",
            "Instalace z bezpečnostních důvodů ještě není plně připravena.",
        )

    def _magic_data_disk_plan_message(self, plan: magic.DataDiskPreparePlan) -> str:
        if plan.ready:
            return self._t(
                "Die Daten-HDD wird nach erfolgreicher Windows-Installation als leere NTFS-Datenplatte vorbereitet.",
                "The data HDD will be prepared as an empty NTFS data disk after the successful Windows installation.",
                "Datový HDD bude po úspěšné instalaci systému Windows připraven jako prázdný datový disk NTFS.",
            )
        return self._t(
            "Die ausgewählte Daten-HDD kann aus Sicherheitsgründen nicht vorbereitet werden.",
            "The selected data HDD cannot be prepared for safety reasons.",
            "Vybraný datový HDD nelze z bezpečnostních důvodů připravit.",
        )

    def _magic_progress_text(self, text: str) -> str:
        progress = {
            "Clonezilla startet …": self._t("Clonezilla startet …", "Starting Clonezilla …", "Spouští se Clonezilla …"),
            "Clonezilla schreibt das Image …": self._t("Clonezilla schreibt das Image …", "Clonezilla is writing the image …", "Clonezilla zapisuje image …"),
            "Clonezilla-Umgebung wird vorbereitet …": self._t("Clonezilla-Umgebung wird vorbereitet …", "Preparing the Clonezilla environment …", "Připravuje se prostředí Clonezilly …"),
            "Daten-HDD wird vorbereitet …": self._t("Daten-HDD wird vorbereitet …", "Preparing the data HDD …", "Připravuje se datový HDD …"),
            "Daten-HDD als NTFS vorbereitet …": self._t("Daten-HDD wurde als NTFS vorbereitet …", "Data HDD was prepared as NTFS …", "Datový HDD byl připraven jako NTFS …"),
            "Windows-Handoff wird geschrieben …": self._t("Windows-Handoff wird geschrieben …", "Writing Windows handoff …", "Zapisuje se předání systému Windows …"),
            "Komplettimage wiederhergestellt; Windows-Modellprüfung bleibt unverändert.": self._t(
                "Komplettimage wiederhergestellt; Windows-Modellprüfung bleibt unverändert.",
                "Complete image restored; the existing Windows model check is preserved.",
                "Kompletní obraz obnoven; stávající kontrola modelu ve Windows zůstává zachována.",
            ),
        }
        if text in progress:
            return progress[text]
        return text if self.language == "DE" else self._t("Restore läuft …", "Restore is running …", "Probíhá obnovení …")

    def _magic_result_message(self, result: magic.RestoreProofResult) -> str:
        if result.success:
            if result.deployment_mode == "complete":
                return self._t(
                    "Clonezilla-Komplettimage erfolgreich installiert. Die Modellprüfung startet mit dem vorhandenen Windows-Skript.",
                    "Complete Clonezilla image installed successfully. The existing Windows script will start the model check.",
                    "Kompletní obraz Clonezilla byl úspěšně nainstalován. Kontrolu modelu spustí stávající skript Windows.",
                )
            return self._t(
                "Restore und Windows-Handoff wurden erfolgreich abgeschlossen.",
                "Restore and Windows handoff completed successfully.",
                "Obnovení a předání systému Windows bylo úspěšně dokončeno.",
            )
        return self._t(
            "Restore wurde aus Sicherheitsgründen abgebrochen. Details stehen im Protokoll.",
            "Restore was stopped for safety. Details are in the log.",
            "Obnovení bylo z bezpečnostních důvodů zastaveno. Podrobnosti jsou v protokolu.",
        )

    def _magic_update_summary(self) -> None:
        view: Gtk.TextView | None = self._build_refs.get("magic_summary")
        restore_action: Gtk.Button | None = self._build_refs.get("magic_restore_action")
        if view is None or restore_action is None:
            return
        config = self._magic_config_validation
        checking_server = bool(config and self._magic_config_server_pending == config.config)
        image = self._magic_selected_image()
        target = self._magic_selected_target()
        data_disk = self._magic_selected_data_disk()
        capacity_problem = bool(
            image and target and image.minimum_target_bytes and target.size_bytes < image.minimum_target_bytes
        )
        lines = [self._t("Bereit zur Installation – erst die letzte Bestätigung startet Clonezilla.", "Ready to install – Clonezilla starts only after final confirmation.", "Připraveno k instalaci – Clonezilla se spustí až po posledním potvrzení.")]
        lines.append(f"{self._t('Config', 'Config', 'Konfigurace')}: {config.config if config else self._t('noch nicht geprüft', 'not validated yet', 'zatím neověřeno')}")
        if config:
            lines.append(self._magic_config_status_text(config))
        lines.append(f"{self._t('Image', 'Image', 'Obraz')}: {self._magic_image_display_text(image) if image else self._t('noch nicht gewählt', 'not selected yet', 'zatím nevybráno')}")
        lines.append(f"{self._t('Ziel', 'Target', 'Cíl')}: {self._magic_disk_display_text(target) if target else self._t('noch nicht gewählt', 'not selected yet', 'zatím nevybráno')}")
        lines.append(
            f"{self._t('Daten-HDD', 'Data HDD', 'Datový HDD')}: "
            f"{self._magic_disk_display_text(data_disk) if data_disk else self._t('nicht ausgewählt (bleibt unverändert)', 'not selected (unchanged)', 'nevybráno (zůstane beze změny)')}"
        )
        lines.append(
            f"{self._t('Clonezilla-Backend', 'Clonezilla backend', 'Backend Clonezilly')}: "
            f"{self._magic_clonezilla_message(self._magic_inspection.clonezilla)}"
        )
        if config and config.deployment_mode == "complete":
            lines.append(self._t(
                "Windows-Abschluss: Das Komplettimage verwendet sein vorhandenes ModelCheck-Skript.",
                "Windows completion: The complete image uses its existing ModelCheck script.",
                "Dokončení ve Windows: Kompletní obraz použije svůj stávající skript ModelCheck.",
            ))
        elif config:
            lines.append(
                f"{self._t('Geplanter Windows-Handoff', 'Planned Windows handoff', 'Plánované předání systému Windows')}: "
                f"{magic.HANDOFF_WINDOWS_PATH} ← {config.config}"
            )
        if checking_server:
            lines.append(self._t(
                "Config-Server wird geprüft. Die Image-Auswahl wird anschließend aktualisiert.",
                "Checking the config server. The image selection will be updated afterwards.",
                "Kontroluje se server konfigurací. Poté se aktualizuje výběr obrazu.",
            ))
        if capacity_problem:
            lines.append(self._t("Installation gesperrt: Ziel-SSD ist kleiner als die Manifest-Mindestgröße.", "Installation blocked: target SSD is smaller than the manifest minimum size.", "Instalace zablokována: cílové SSD je menší než minimální velikost v manifestu."))
        if self._magic_inspection.protected_disks:
            lines.append(
                self._t("Geschützt", "Protected", "Chráněno")
                + ": "
                + ", ".join(sorted(self._magic_inspection.protected_disks))
            )
        else:
            lines.append(self._t("Warnung: Noch kein geschütztes HardwareCheck-/Image-Medium erkannt.", "Warning: no protected HardwareCheck/image medium detected yet.", "Varování: dosud nebylo rozpoznáno žádné chráněné médium HardwareCheck/obrazu."))
        plan: magic.RestoreProofPlan | None = None
        data_disk_plan: magic.DataDiskPreparePlan | None = None
        if config and image and target:
            plan = magic.build_restore_proof_plan(config, image, target, self._magic_inspection)
            lines.append(
                f"{self._t('Installation', 'Installation', 'Instalace')}: {self._magic_plan_message(plan)}"
            )
            if data_disk is not None:
                data_label = self._t("Daten", "Data", "Data")
                data_disk_plan = magic.build_data_disk_prepare_plan(
                    data_disk,
                    target,
                    self._magic_inspection,
                    label=data_label,
                )
                lines.append(
                    f"{self._t('Daten-HDD', 'Data HDD', 'Datový HDD')}: {self._magic_data_disk_plan_message(data_disk_plan)}"
                )
            if plan.ready:
                lines.append(
                    f"{self._t('Clonezilla-Zielbindung', 'Clonezilla target binding', 'Vazba cíle Clonezilly')}: {plan.target_selector}"
                )
                lines.append(
                    self._t(
                        "Mit „Jetzt installieren“ bestätigen; danach wird die Ziel-SSD vollständig gelöscht.",
                        "Confirm with “Install now”; the target SSD is then erased completely.",
                        "Potvrďte tlačítkem „Nainstalovat nyní“; cílové SSD bude poté zcela vymazáno.",
                    )
                )
        self._magic_restore_plan = plan
        self._magic_data_disk_plan = data_disk_plan
        view.get_buffer().set_text("\n".join(lines))
        restore_action.set_sensitive(
            bool(
                plan
                and plan.ready
                and (data_disk_plan is None or data_disk_plan.ready)
                and not checking_server
                and not capacity_problem
                and not self._magic_scan_pending
                and not self._magic_restore_pending
                and not self._magic_restore_completed
            )
        )

    def _magic_simulate_clicked(self, _button=None) -> None:
        config = self._magic_config_validation
        image = self._magic_selected_image()
        target = self._magic_selected_target()
        if not config or not config.valid or not image or not target:
            self.set_status(self._t("Installationsprüfung unvollständig: Config, Image und Ziel prüfen.", "Installation check is incomplete: validate config, image and target.", "Kontrola instalace je neúplná: ověřte konfiguraci, obraz a cíl."), "warn")
            return
        view: Gtk.TextView | None = self._build_refs.get("magic_summary")
        if view is not None:
            self._magic_update_summary()
        self.set_status(self._t("Installationsprüfung erstellt. Noch kein Clonezilla-Aufruf und kein Schreibvorgang.", "Installation check created. Clonezilla has not been called and nothing has been written yet.", "Kontrola instalace vytvořena. Clonezilla zatím nebyla spuštěna a nic nebylo zapsáno."), "good")

    def _magic_restore_clicked(self, _button=None) -> None:
        self._magic_update_summary()
        plan = self._magic_restore_plan
        data_disk_plan = self._magic_data_disk_plan
        if self._magic_restore_pending:
            return
        if (
            plan is None
            or not plan.ready
            or plan.config != self._magic_config_value()
            or self._magic_scan_pending
            or self._magic_config_server_pending == plan.config
            or (data_disk_plan is not None and not data_disk_plan.ready)
        ):
            self.set_status(self._t("Restore ist noch nicht vollständig geprüft.", "Restore is not fully validated yet.", "Obnovení ještě není plně ověřeno."), "warn")
            return
        dialog = Gtk.Dialog(
            title=self._t("Installation endgültig bestätigen", "Confirm installation", "Konečně potvrdit instalaci"),
            transient_for=self.window,
            flags=Gtk.DialogFlags.MODAL,
        )
        dialog.get_style_context().add_class("magic-confirm-dialog")
        cancel = dialog.add_button(self._t("Abbrechen", "Cancel", "Zrušit"), Gtk.ResponseType.CANCEL)
        cancel.get_style_context().add_class("secondary-button")
        start = dialog.add_button(self._t("Jetzt installieren", "Install now", "Nainstalovat nyní"), Gtk.ResponseType.ACCEPT)
        start.get_style_context().add_class("primary-button")
        content = dialog.get_content_area()
        content.set_spacing(8)
        content.set_margin_start(18)
        content.set_margin_end(18)
        content.set_margin_top(14)
        content.set_margin_bottom(14)
        content.pack_start(
            self._label(
                self._t(
                    "ACHTUNG: Die unten genannte Ziel-SSD wird vollständig gelöscht. Clonezilla erhält keine zweite Image- oder Zielauswahl.",
                    "WARNING: The target SSD below will be completely erased. Clonezilla receives no second image or target selection.",
                    "VAROVÁNÍ: Níže uvedený cílový SSD bude zcela vymazán. Clonezilla neobdrží druhý výběr obrazu ani cíle.",
                ),
                "section-title",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        content.pack_start(
            self._label(f"{self._t('Config', 'Config', 'Konfigurace')}: {plan.config}", "muted"),
            False,
            False,
            0,
        )
        content.pack_start(
            self._label(
                f"{self._t('Image', 'Image', 'Obraz')}: "
                f"{plan.image_path if plan.deployment_mode == 'complete' else plan.image_name}",
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        if plan.deployment_mode == "complete":
            content.pack_start(
                self._label(self._t(
                    "Clonezilla-Komplettimage: Die Modellprüfung erfolgt nach dem Windows-Start durch das vorhandene ModelCheck-Skript im Image.",
                    "Complete Clonezilla image: The existing ModelCheck script inside the image checks the model after Windows starts.",
                    "Kompletní obraz Clonezilla: Model ověří po spuštění Windows stávající skript ModelCheck obsažený v obrazu.",
                ), "warn", wrap=True),
                False,
                False,
                0,
            )
        content.pack_start(
            self._label(
                f"{self._t('Zielbindung', 'Target binding', 'Vazba cíle')}: {plan.target_selector}",
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        if data_disk_plan is not None:
            content.pack_start(
                self._label(
                    self._t(
                        f"Zusätzliche Daten-HDD: {data_disk_plan.disk_selector}\nSie wird vollständig gelöscht und als leere NTFS-Datenplatte „{data_disk_plan.label}“ vorbereitet.",
                        f"Additional data HDD: {data_disk_plan.disk_selector}\nIt will be completely erased and prepared as an empty NTFS data disk named “{data_disk_plan.label}”.",
                        f"Další datový HDD: {data_disk_plan.disk_selector}\nBude zcela vymazán a připraven jako prázdný datový disk NTFS s názvem „{data_disk_plan.label}“.",
                    ),
                    "section-title",
                    wrap=True,
                ),
                False,
                False,
                0,
            )
        content.pack_start(
            self._label(
                self._t(
                    "Die Auswahl wurde bewusst getroffen. HardwareCheck prüft die Ziel-SSD unmittelbar vor dem Start erneut.",
                    "The selection was made deliberately. HardwareCheck rechecks the target SSD immediately before starting.",
                    "Výběr byl proveden vědomě. HardwareCheck znovu ověří cílové SSD bezprostředně před spuštěním.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        completion_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        completion_row.pack_start(self._label(self._t("Nach erfolgreichem Restore:", "After successful restore:", "Po úspěšném obnovení:"), "muted"), False, False, 0)
        completion_choice = Gtk.ComboBoxText()
        completion_choice.get_style_context().add_class("magic-selector")
        completion_choice.append("reboot", self._t("Windows automatisch starten", "Start Windows automatically", "Automaticky spustit Windows"))
        completion_choice.append("poweroff", self._t("Gerät ausschalten", "Shut down device", "Vypnout zařízení"))
        completion_choice.set_active_id("reboot")
        completion_row.pack_start(completion_choice, True, True, 0)
        content.pack_start(completion_row, False, False, 2)
        dialog.show_all()
        response = dialog.run()
        post_restore_action = completion_choice.get_active_id() or "reboot"
        dialog.destroy()
        if response != Gtk.ResponseType.ACCEPT:
            self.set_status(self._t("Restore abgebrochen.", "Restore cancelled.", "Obnovení zrušeno."), "warn")
            return
        self._magic_update_summary()
        if plan != self._magic_restore_plan or data_disk_plan != self._magic_data_disk_plan:
            self.set_status(self._t(
                "Die Installationsauswahl hat sich geändert. Bitte erneut prüfen und bestätigen.",
                "The installation selection changed. Review it and confirm again.",
                "Výběr instalace se změnil. Zkontrolujte jej a znovu potvrďte.",
            ), "warn")
            return
        self._magic_post_restore_action = post_restore_action
        self._magic_restore_pending = True
        progress: Gtk.ProgressBar | None = self._build_refs.get("magic_restore_progress")
        progress_label: Gtk.Label | None = self._build_refs.get("magic_restore_progress_label")
        if progress is not None:
            progress.set_fraction(0.0)
            progress.set_text("0 %")
            progress.show()
        if progress_label is not None:
            progress_label.set_text(self._t("Restore wird vorbereitet …", "Preparing restore …", "Obnovení se připravuje …"))
            progress_label.show()
        self._magic_update_summary()
        self.set_status(self._t("Restore läuft. Ziel-SSD wird erneut geprüft.", "Restore is running. Target SSD is rechecked.", "Obnovení běží. Cílový SSD se znovu ověřuje."), "warn")
        self.run_async(
            "magic-restore-proof",
            lambda: magic.execute_restore_proof(
                plan,
                self._magic_inspection,
                progress_callback=lambda percent, text: GLib.idle_add(self._magic_restore_progress, percent, text),
                data_disk_plan=data_disk_plan,
            ),
            self._magic_restore_finished,
        )

    def _magic_restore_progress(self, percent: int, text: str) -> bool:
        progress: Gtk.ProgressBar | None = self._build_refs.get("magic_restore_progress")
        progress_label: Gtk.Label | None = self._build_refs.get("magic_restore_progress_label")
        bounded = max(0, min(100, int(percent)))
        if progress is not None:
            progress.set_fraction(bounded / 100)
            progress.set_text(f"{bounded} %")
        if progress_label is not None and text:
            progress_label.set_text(self._magic_progress_text(text))
        return False

    def _magic_restore_finished(self, result: magic.RestoreProofResult) -> None:
        self._magic_restore_pending = False
        self._magic_restore_completed = result.success
        result_message = self._magic_result_message(result)
        self._magic_restore_progress(100 if result.success else 0, result_message)
        self._magic_update_summary()
        view: Gtk.TextView | None = self._build_refs.get("magic_summary")
        if view is not None:
            lines = [result_message, f"{self._t('Phase', 'Phase', 'Fáze')}: {result.phase}"]
            if result.clonezilla_exit_code is not None:
                lines.append(f"{self._t('Clonezilla Exit-Code', 'Clonezilla exit code', 'Návratový kód Clonezilly')}: {result.clonezilla_exit_code}")
            if result.handoff_path:
                lines.append(f"{self._t('Windows-Handoff', 'Windows handoff', 'Předání systému Windows')}: {result.handoff_path}")
            if result.log_path:
                lines.append(f"{self._t('Protokoll', 'Log', 'Protokol')}: {result.log_path}")
            if result.output_excerpt:
                lines.append(
                    self._t(
                        "Die technische Clonezilla-Ausgabe steht im Protokoll.",
                        "The technical Clonezilla output is available in the log.",
                        "Technický výstup Clonezilly je k dispozici v protokolu.",
                    )
                )
            view.get_buffer().set_text("\n".join(lines))
        self.set_status(result_message, "good" if result.success else "bad")
        if result.success:
            action_text = self._t("Windows wird automatisch gestartet …", "Windows will start automatically …", "Windows se automaticky spustí …") if self._magic_post_restore_action == "reboot" else self._t("Gerät wird automatisch ausgeschaltet …", "Device will shut down automatically …", "Zařízení se automaticky vypne …")
            self.set_status(action_text, "good")
            GLib.timeout_add(1200, self._magic_apply_post_restore_action)

    def _magic_apply_post_restore_action(self) -> bool:
        self._execute_power_action(self._magic_post_restore_action)
        return False

    def _build_battery_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Akku-Test", "Battery test", "Test baterie"),
            "",
        )
        outer.get_style_context().add_class("battery-page")
        live_panel = Gtk.Frame()
        live_panel.set_shadow_type(Gtk.ShadowType.NONE)
        live_panel.get_style_context().add_class("battery-live-panel")
        live_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        live_panel.add(live_row)
        live_row.pack_start(self._icon("battery-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        live_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self._build_refs["battery_live_title"] = self._label(self._t("Akku-Test bereit", "Battery test ready", "Test baterie připraven"), "battery-live-title", wrap=True)
        self._build_refs["battery_live_subtitle"] = self._label("", "battery-live-subtitle", wrap=True)
        live_text.pack_start(self._build_refs["battery_live_title"], False, False, 0)
        live_text.pack_start(self._build_refs["battery_live_subtitle"], False, False, 0)
        live_row.pack_start(live_text, True, True, 0)
        self._build_refs["battery_live_panel"] = live_panel
        outer.pack_start(live_panel, False, False, 8)

        metric_specs = (
            ("level", self._t("Akkustand", "Battery level", "Stav baterie"), "battery-symbolic"),
            ("runtime", self._t("Restlaufzeit", "Remaining runtime", "Zbývající výdrž"), "alarm-symbolic"),
            ("power", self._t("Leistung", "Power", "Výkon"), "preferences-system-power-symbolic"),
            ("capacity", self._t("Kapazität", "Capacity", "Kapacita"), "battery-symbolic"),
            ("health", self._t("Kapazitätsgesundheit", "Capacity health", "Zdraví kapacity"), "emblem-ok-symbolic"),
            ("voltage_cycles", self._t("Spannung · Ladezyklen", "Voltage · charge cycles", "Napětí · nabíjecí cykly"), "view-refresh-symbolic"),
        )
        metric_cards: dict[str, Gtk.Widget] = {}
        for key, title, icon in metric_specs:
            card, value, subtitle = self._card(title, icon=icon)
            card.set_size_request(245, 102)
            card.get_style_context().add_class("battery-metric-card")
            card.get_style_context().add_class(f"battery-metric-{key}")
            if key in {"capacity", "voltage_cycles"}:
                card.get_style_context().add_class("compact")
            metric_cards[key] = card
            self._build_refs[f"battery_{key}"] = value
            self._build_refs[f"battery_{key}_sub"] = subtitle

        if self.appearance_layout == "studio-panels":
            studio_grid = Gtk.Grid(column_spacing=12, row_spacing=12)
            studio_grid.set_column_homogeneous(True)
            studio_grid.set_row_homogeneous(True)
            studio_grid.get_style_context().add_class("battery-studio-grid")
            metric_cards["level"].set_size_request(-1, 216)
            studio_grid.attach(metric_cards["level"], 0, 0, 1, 2)
            studio_grid.attach(metric_cards["runtime"], 1, 0, 1, 1)
            studio_grid.attach(metric_cards["power"], 2, 0, 1, 1)
            studio_grid.attach(metric_cards["health"], 3, 0, 1, 1)
            studio_grid.attach(metric_cards["capacity"], 1, 1, 2, 1)
            studio_grid.attach(metric_cards["voltage_cycles"], 3, 1, 1, 1)
            outer.pack_start(studio_grid, False, False, 12)
        else:
            flow = self._flow()
            flow.set_min_children_per_line(3)
            flow.set_max_children_per_line(3)
            for key, _title, _icon in metric_specs:
                flow.add(metric_cards[key])
            outer.pack_start(flow, False, False, 12)

        controls = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        controls.get_style_context().add_class("battery-controls")
        controls.pack_start(self._button(self._t("Entladen starten", "Start discharge", "Spustit vybíjení"), lambda _b: self._start_battery_test("discharge"), "primary-button", "battery-caution-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Laden starten", "Start charge", "Spustit nabíjení"), lambda _b: self._start_battery_test("charge"), "primary-button", "battery-good-charging-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Stop + Report", "Stop + report", "Stop + report"), self._stop_battery_test, "secondary-button", "media-playback-stop-symbolic"), False, False, 0)
        controls.pack_start(self._button(self._t("Sofort-Report", "Instant report", "Okamžitý report"), self._instant_battery_report, "secondary-button", "document-save-symbolic"), False, False, 0)
        outer.pack_start(controls, False, False, 8)

        history = Gtk.Frame()
        history.set_shadow_type(Gtk.ShadowType.NONE)
        history.get_style_context().add_class("battery-history-card")
        if self.appearance_layout == "studio-panels":
            history.get_style_context().add_class("battery-studio-history")
        history_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        history.add(history_box)
        history_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        history_header.pack_start(self._label(self._t("Akku-Verlauf · Live-Messung", "Battery history · live measurement", "Průběh baterie · živé měření"), "section-title"), True, True, 0)
        self._build_refs["battery_measure_state"] = self._label("", "good-text")
        history_header.pack_end(self._build_refs["battery_measure_state"], False, False, 0)
        history_box.pack_start(history_header, False, False, 0)
        chart = Gtk.Overlay()
        chart.set_hexpand(True)
        chart.set_vexpand(True)
        chart.set_size_request(-1, 300)
        chart_image = Gtk.Image()
        chart_image.set_halign(Gtk.Align.CENTER)
        chart_image.set_valign(Gtk.Align.CENTER)
        chart.add(chart_image)
        chart_error = self._label("", "bad-text", xalign=0.5, wrap=True)
        chart_error.set_no_show_all(True)
        chart_error.hide()
        chart.add_overlay(chart_error)
        self._build_refs["battery_chart"] = chart
        self._build_refs["battery_chart_image"] = chart_image
        self._build_refs["battery_chart_error"] = chart_error
        history_box.pack_start(chart, True, True, 0)
        outer.pack_start(history, False, False, 8)

        return page

    def _battery_refresh_tick(self) -> bool:
        if self.window is None:
            return False
        try:
            details = self.core.read_battery_details()
            self._update_battery_ui(details)
        except Exception:
            pass
        return True

    def _battery_display_samples_for(self, details: dict[str, object]) -> list[dict[str, object]]:
        samples = list(self._battery_samples)
        if details.get("present"):
            current_stamp = str(details.get("timestamp") or "")
            last_stamp = str(samples[-1].get("timestamp") or "") if samples else ""
            if current_stamp != last_stamp:
                samples.append(details)
        return samples or ([details] if details.get("present") else [])

    def _battery_estimate_display(self, metrics: dict[str, object]) -> tuple[str, str]:
        estimate = metrics.get("estimate_seconds")
        if not isinstance(estimate, (float, int)) or estimate <= 0:
            return (
                self._t("wird berechnet", "calculating", "počítá se"),
                self._t("nach messbarer Änderung", "after a measurable change", "po měřitelné změně"),
            )
        duration = self.core.battery_elapsed_text(float(estimate), self.language)
        kind = str(metrics.get("estimate_kind") or "")
        value = (
            self._t(f"voll in {duration}", f"full in {duration}", f"plná za {duration}")
            if kind == "to_full"
            else self._t(f"ca. {duration}", f"approx. {duration}", f"cca {duration}")
        )
        source = str(metrics.get("estimate_source") or "")
        subtitle = {
            "measured": self._t("aus dem Testverlauf", "from the measured test trend", "z průběhu testu"),
            "controller": self._t("Controller-Prognose", "controller estimate", "odhad řadiče"),
            "power": self._t("bei aktueller Leistung", "at current power draw", "při aktuálním odběru"),
        }.get(source, self._t("Schätzwert", "estimate", "odhad"))
        return value, subtitle

    @staticmethod
    def _battery_panel_state(widget: Gtk.Widget | None, state: str) -> None:
        if widget is None:
            return
        context = widget.get_style_context()
        for name in ("warn", "bad"):
            context.remove_class(name)
        if state in {"warn", "bad"}:
            context.add_class(state)

    def _battery_next_sample_seconds(self) -> int:
        if not self._battery_mode or not self._battery_samples:
            return 0
        last = self.core.parse_battery_timestamp(self._battery_samples[-1].get("timestamp"))
        if last is None:
            return 60
        now = datetime.datetime.now(last.tzinfo) if last.tzinfo is not None else datetime.datetime.now()
        return max(0, min(60, 60 - int(max(0.0, (now - last).total_seconds()))))

    def _update_battery_ui(self, details: dict[str, object]) -> None:
        self._battery_display_details = dict(details)
        if not details.get("present"):
            text = self._t("Kein Akku erkannt", "No battery detected", "Baterie nebyla nalezena")
            for key in ("level", "runtime", "power", "capacity", "health", "voltage_cycles"):
                if f"battery_{key}" in self._build_refs:
                    self._build_refs[f"battery_{key}"].set_text(text if key == "level" else "–")
                    self._build_refs[f"battery_{key}_sub"].set_text("")
            self._build_refs["battery_chip"].set_text(self._t("Kein Akku", "No battery", "Bez baterie"))
            self._set_chip_state(self._build_refs.get("battery_chip"), "bad")
            self._build_refs["battery_mini_title"].set_text(text)
            self._build_refs["battery_mini_value"].set_text("–")
            self._build_refs["battery_mini_level"].set_value(0)
            self._build_refs["battery_mini_subtitle"].set_text("")
            self._battery_panel_state(self._build_refs.get("battery_mini_panel"), "bad")
            dashboard_panel: Gtk.Frame | None = self._build_refs.get("dashboard_battery_live")
            if dashboard_panel is not None:
                dashboard_panel.hide()
                dashboard_panel.set_no_show_all(True)
            self._build_refs["battery_measure_state"].set_text("")
            self._battery_chart_signature = ""
            self._update_battery_history_image()
            self._update_dashboard_studio_battery("–")
            return
        capacity = details.get("capacity_percent")
        health = self.core.battery_health_assessment(details, self.language)
        display_samples = self._battery_display_samples_for(details)
        metrics = self.core.battery_dashboard_metrics(self._battery_mode, display_samples)
        self._battery_last_metrics = metrics
        function = self.core.battery_function_assessment(self._battery_mode, display_samples, self.language)
        try:
            level = max(0.0, min(100.0, float(capacity)))
        except (TypeError, ValueError):
            level = 0.0
        status = self.core.battery_status_label(details.get("status"), self.language)
        self._build_refs["battery_level"].set_text(f"{_clean(capacity)} %")
        self._build_refs["battery_level_sub"].set_text(status)
        runtime_value, runtime_subtitle = self._battery_estimate_display(metrics)
        self._build_refs["battery_runtime"].set_text(runtime_value)
        self._build_refs["battery_runtime_sub"].set_text(runtime_subtitle)
        power = details.get("power_w")
        self._build_refs["battery_power"].set_text(f"{float(power):.2f} W" if isinstance(power, (float, int)) else "–")
        self._build_refs["battery_power_sub"].set_text(self.core.battery_source_text(details.get("status"), self.language))
        capacity_now = self.core.battery_capacity_text(details.get("energy_now"), details.get("capacity_unit"), self.language)
        capacity_full = self.core.battery_capacity_text(details.get("energy_full"), details.get("capacity_unit"), self.language)
        capacity_unit = self.core.battery_capacity_unit_label(details.get("capacity_unit"))
        if capacity_unit and capacity_now.endswith(f" {capacity_unit}") and capacity_full.endswith(f" {capacity_unit}"):
            capacity_now = capacity_now[: -(len(capacity_unit) + 1)]
        self._build_refs["battery_capacity"].set_text(f"{capacity_now} / {capacity_full}")
        self._build_refs["battery_capacity_sub"].set_text(self._t("aktuell / volle Kapazität", "current / full capacity", "aktuální / plná kapacita"))
        self._build_refs["battery_health"].set_text(str(health.get("display") or "–"))
        self._build_refs["battery_health_sub"].set_text(str(health.get("note") or ""))
        voltage = details.get("voltage_v")
        try:
            voltage_text = f"{float(voltage):.2f} V"
        except (TypeError, ValueError):
            voltage_text = "–"
        cycles_text = _clean(details.get("cycle_count"))
        self._build_refs["battery_voltage_cycles"].set_text(f"{voltage_text} · {cycles_text}")
        self._build_refs["battery_voltage_cycles_sub"].set_text(self._t("aktuelle Spannung · Zyklen", "current voltage · cycles", "aktuální napětí · cykly"))
        estimate_short = runtime_value.replace("ca. ", "").replace("approx. ", "").replace("cca ", "")
        drop_state = str(metrics.get("drop_state") or "")
        panel_state = "bad" if drop_state == "critical" else "warn" if drop_state == "warn" else ""
        function_problem = self._battery_mode and str(function.get("class_name") or "") == "bad"
        if function_problem and not panel_state:
            panel_state = "bad"
        delta = metrics.get("delta_percent")
        try:
            delta_text = f"{float(delta):+g} %"
        except (TypeError, ValueError):
            delta_text = "±0 %"
        if self._battery_mode:
            mode_text = self._t("entlädt", "discharging", "vybíjí se") if self._battery_mode == "discharge" else self._t("lädt", "charging", "nabíjí se")
            test_title = self._t("Entlade-Test läuft", "Discharge test running", "Probíhá test vybíjení") if self._battery_mode == "discharge" else self._t("Lade-Test läuft", "Charge test running", "Probíhá test nabíjení")
            count = int(metrics.get("sample_count") or len(display_samples))
            elapsed_text = self.core.battery_elapsed_text(float(metrics.get("elapsed_seconds") or 0.0), self.language)
            if drop_state:
                live_title = self._t("Achtung: ungewöhnlich schneller Akkuabfall", "Warning: unusually rapid battery drop", "Pozor: neobvykle rychlý pokles baterie")
                rate = float(metrics.get("rate_percent_per_hour") or 0.0)
                live_subtitle = self._t(
                    f"{delta_text} · hochgerechnet {rate:.0f} % pro Stunde · {count} Messpunkte",
                    f"{delta_text} · projected {rate:.0f} % per hour · {count} samples",
                    f"{delta_text} · odhad {rate:.0f} % za hodinu · {count} měření",
                )
            elif function_problem:
                live_title = f"{self._t('Achtung', 'Warning', 'Pozor')}: {function.get('display')}"
                live_subtitle = str(function.get("note") or "")
            else:
                live_title = f"{test_title} · {delta_text} · {count} {self._t('Messpunkte', 'samples', 'měření')} · {elapsed_text}"
                live_subtitle = ""
            chip_text = f"{self._t('Akku-Test', 'Battery test', 'Test baterie')}: {mode_text} · {_clean(capacity)}% · {estimate_short}"
            mini_title = test_title
            mini_subtitle = f"{delta_text} · {count} {self._t('Messpunkte', 'samples', 'měření')} · {elapsed_text}"
        elif self._battery_last_result:
            verdict = str(self._battery_last_result.get("verdict") or self._t("abgeschlossen", "completed", "dokončeno"))
            result_class = str(self._battery_last_result.get("class_name") or "warn")
            panel_state = "bad" if result_class == "bad" else "warn" if result_class == "warn" else ""
            live_title = f"{self._t('Akku-Test abgeschlossen', 'Battery test completed', 'Test baterie dokončen')}: {verdict}"
            live_subtitle = str(self._battery_last_result.get("summary") or "")
            chip_text = f"{self._t('Akku-Test', 'Battery test', 'Test baterie')}: {verdict}"
            mini_title = live_title
            mini_subtitle = str(self._battery_last_result.get("completion_text") or runtime_value)
        else:
            live_title = self._t("Akku-Test bereit", "Battery test ready", "Test baterie připraven")
            live_subtitle = ""
            chip_text = f"{self._t('Akku', 'Battery', 'Baterie')}: {_clean(capacity)}%"
            mini_title = live_title
            mini_subtitle = runtime_value
        self._build_refs["battery_chip"].set_text(chip_text)
        self._set_chip_state(self._build_refs.get("battery_chip"), panel_state or ("good" if self._battery_mode else ""))
        self._build_refs["battery_live_title"].set_text(live_title)
        self._build_refs["battery_live_subtitle"].set_text(live_subtitle)
        if live_subtitle:
            self._build_refs["battery_live_subtitle"].set_no_show_all(False)
            self._build_refs["battery_live_subtitle"].show()
        else:
            self._build_refs["battery_live_subtitle"].hide()
            self._build_refs["battery_live_subtitle"].set_no_show_all(True)
        self._battery_panel_state(self._build_refs.get("battery_live_panel"), panel_state)
        self._build_refs["battery_mini_title"].set_text(mini_title)
        self._build_refs["battery_mini_value"].set_text(f"{_clean(capacity)}%")
        self._build_refs["battery_mini_level"].set_value(level)
        self._build_refs["battery_mini_subtitle"].set_text(mini_subtitle)
        self._battery_panel_state(self._build_refs.get("battery_mini_panel"), panel_state)
        dashboard_panel: Gtk.Frame | None = self._build_refs.get("dashboard_battery_live")
        if (self._battery_mode or self._battery_last_result) and dashboard_panel is not None:
            self._build_refs["dashboard_battery_title"].set_text(live_title)
            self._build_refs["dashboard_battery_subtitle"].set_text(f"{_clean(capacity)} % · {mini_subtitle}")
            self._build_refs["dashboard_battery_level"].set_value(level)
            dashboard_value = self._build_refs.get("dashboard_battery_value")
            if dashboard_value is not None:
                dashboard_value.set_text(f"{_clean(capacity)} %")
            self._battery_panel_state(dashboard_panel, panel_state)
            dashboard_panel.set_no_show_all(False)
            dashboard_panel.show_all()
        elif dashboard_panel is not None:
            dashboard_panel.hide()
            dashboard_panel.set_no_show_all(True)
        next_sample = self._battery_next_sample_seconds()
        measure_state = self._build_refs.get("battery_measure_state")
        if measure_state is not None:
            if self._battery_mode:
                completion = self.core.battery_test_completion(self._battery_mode, display_samples)
                elapsed_minutes = int(float(completion.get("elapsed_seconds") or 0.0) // 60)
                change = float(completion.get("directional_change_percent") or 0.0)
                time_progress = f"{elapsed_minutes}/30" if elapsed_minutes <= 30 else f"{elapsed_minutes}/60"
                measure_state.set_text(
                    self._t(
                        f"● aktiv · {time_progress} Min. · {change:.0f}/5 % · nächster Messpunkt in {next_sample} Sek.",
                        f"● active · {time_progress} min · {change:.0f}/5 % · next sample in {next_sample} sec",
                        f"● aktivní · {time_progress} min · {change:.0f}/5 % · další měření za {next_sample} s",
                    )
                )
            elif self._battery_last_result:
                measure_state.set_text(str(self._battery_last_result.get("recommendation") or ""))
            else:
                measure_state.set_text("")
        self._update_battery_history_image()
        self._update_dashboard_studio_battery(runtime_value)

    def _battery_chart_palette(self) -> dict[str, str]:
        if self.appearance_layout in {"service-light", "service-desk"}:
            return {
                "background": "#fffdf8",
                "battery": "#f0f3ef",
                "outline": "#76909b",
                "muted": "#667d90",
                "grid": "#d5ddd9",
                "text": "#17324d",
                "line": self.appearance_accent,
            }
        if self.appearance_layout in {"workshop-pro", "workshop-console"}:
            return {
                "background": "#181b1d",
                "battery": "#25282a",
                "outline": "#a0a4a5",
                "muted": "#9a9ea0",
                "grid": "#3b3e40",
                "text": "#f3f1ea",
                "line": self.appearance_accent,
            }
        if self.appearance_layout == "blue-control":
            return {
                "background": "#0a1938",
                "battery": "#132d5c",
                "outline": "#8bb9e8",
                "muted": "#9eb7dc",
                "grid": "#284d7b",
                "text": "#edf5ff",
                "line": self.appearance_accent,
            }
        if self.appearance_layout == "studio-panels":
            return {
                "background": "#2a103b",
                "battery": "#4a215b",
                "outline": "#f3cdea",
                "muted": "#d7aed5",
                "grid": "#784d7e",
                "text": "#fff7ff",
                "line": self.appearance_accent,
            }
        return {
            "background": "#0e151f",
            "battery": "#111a27",
            "outline": "#91a5b8",
            "muted": "#8fa7bd",
            "grid": "#334156",
            "text": "#dce8f2",
            "line": self.appearance_accent,
        }

    def _studio_battery_history_svg(
        self,
        width: int,
        height: int,
        points: list[tuple[datetime.datetime | None, float]],
        current_level: float,
        palette: dict[str, str],
    ) -> str:
        details = self._battery_display_details
        power = details.get("power_w")
        power_text = f"{float(power):.2f} W" if isinstance(power, (float, int)) else "–"
        health = self.core.battery_health_assessment(details, self.language)
        health_text = str(health.get("display") or "–")
        cycles_text = _clean(details.get("cycle_count")) or "–"
        status_text = self.core.battery_status_label(details.get("status"), self.language)

        def escaped(value: object) -> str:
            return GLib.markup_escape_text(str(value or "–"))

        panel_gap = 12.0
        left_x, panel_y = 8.0, 8.0
        left_width = 248.0
        panel_height = float(height - 16)
        right_x = left_x + left_width + panel_gap
        right_width = max(360.0, float(width) - right_x - 8.0)
        graph_left = right_x + 18.0
        graph_right = right_x + right_width - 18.0
        graph_top = 50.0
        graph_bottom = 166.0

        values = [value for _stamp, value in points]
        if values:
            y_min = max(0.0, min(values) - 5.0)
            y_max = min(100.0, max(values) + 5.0)
            if y_max - y_min < 10.0:
                middle = (y_min + y_max) / 2.0
                y_min = max(0.0, middle - 5.0)
                y_max = min(100.0, y_min + 10.0)
                y_min = max(0.0, y_max - 10.0)
        else:
            y_min, y_max = 0.0, 100.0

        valid_times = [stamp for stamp, _value in points if stamp is not None]
        start_time = valid_times[0] if valid_times else None
        end_time = valid_times[-1] if valid_times else None
        elapsed = (end_time - start_time).total_seconds() if start_time is not None and end_time is not None else 0.0

        coordinates: list[tuple[float, float]] = []
        for index, (stamp, value) in enumerate(points):
            if elapsed > 0 and stamp is not None and start_time is not None:
                fraction = max(0.0, min(1.0, (stamp - start_time).total_seconds() / elapsed))
            else:
                fraction = index / max(1, len(points) - 1)
            x = graph_left + (graph_right - graph_left) * fraction
            y_fraction = (value - y_min) / max(1.0, y_max - y_min)
            y = graph_bottom - (graph_bottom - graph_top) * y_fraction
            coordinates.append((x, y))

        ring_x = left_x + left_width / 2.0
        ring_y = panel_y + panel_height / 2.0 - 2.0
        ring_radius = 73.0
        circumference = 2.0 * 3.141592653589793 * ring_radius
        ring_fill = circumference * max(0.0, min(100.0, current_level)) / 100.0
        ring_gap = max(0.1, circumference - ring_fill)
        parts = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
            f'<defs><linearGradient id="studio-area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{palette["line"]}" stop-opacity="0.26"/><stop offset="1" stop-color="{palette["line"]}" stop-opacity="0.03"/></linearGradient></defs>',
            f'<rect width="{width}" height="{height}" rx="12" fill="{palette["background"]}"/>',
            f'<rect x="{left_x:.1f}" y="{panel_y:.1f}" width="{left_width:.1f}" height="{panel_height:.1f}" rx="18" fill="{palette["battery"]}"/>',
            f'<rect x="{right_x:.1f}" y="{panel_y:.1f}" width="{right_width:.1f}" height="{panel_height:.1f}" rx="18" fill="{palette["battery"]}"/>',
            f'<circle cx="{ring_x:.1f}" cy="{ring_y:.1f}" r="{ring_radius:.1f}" fill="none" stroke="{palette["grid"]}" stroke-width="23"/>',
            f'<circle cx="{ring_x:.1f}" cy="{ring_y:.1f}" r="{ring_radius:.1f}" fill="none" stroke="{palette["line"]}" stroke-width="23" stroke-linecap="round" stroke-dasharray="{ring_fill:.1f} {ring_gap:.1f}" transform="rotate(-90 {ring_x:.1f} {ring_y:.1f})"/>',
            f'<text x="{ring_x:.1f}" y="{ring_y - 2:.1f}" text-anchor="middle" fill="{palette["text"]}" font-family="Sans" font-size="31" font-weight="700">{current_level:.0f}%</text>',
            f'<text x="{ring_x:.1f}" y="{ring_y + 23:.1f}" text-anchor="middle" fill="{palette["muted"]}" font-family="Sans" font-size="12">{escaped(status_text)}</text>',
            f'<text x="{graph_left:.1f}" y="34" fill="{palette["line"]}" font-family="Sans" font-size="12" font-weight="700">{escaped(self._t("LIVE-VERLAUF", "LIVE HISTORY", "ŽIVÝ PRŮBĚH"))}</text>',
        ]

        for index in range(3):
            fraction = index / 2.0
            y = graph_bottom - (graph_bottom - graph_top) * fraction
            parts.append(f'<line x1="{graph_left:.1f}" y1="{y:.1f}" x2="{graph_right:.1f}" y2="{y:.1f}" stroke="{palette["grid"]}" stroke-width="1"/>')

        if coordinates:
            if len(coordinates) > 1:
                line_path = " ".join(("M" if index == 0 else "L") + f" {x:.1f} {y:.1f}" for index, (x, y) in enumerate(coordinates))
                area_path = line_path + f" L {coordinates[-1][0]:.1f} {graph_bottom:.1f} L {coordinates[0][0]:.1f} {graph_bottom:.1f} Z"
                parts.append(f'<path d="{area_path}" fill="url(#studio-area)"/>')
                parts.append(f'<path d="{line_path}" fill="none" stroke="{palette["line"]}" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>')
            for index, (x, y) in enumerate(coordinates):
                radius = 6 if index == len(coordinates) - 1 else 4
                parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{radius}" fill="{palette["text"]}" stroke="{palette["line"]}" stroke-width="2"/>')
        else:
            parts.append(f'<text x="{(graph_left + graph_right) / 2:.1f}" y="112" text-anchor="middle" fill="{palette["muted"]}" font-family="Sans" font-size="14">{escaped(self._t("Akku-Test starten", "Start battery test", "Spustit test baterie"))}</text>')

        card_y = 190.0
        card_height = max(64.0, float(height) - card_y - 18.0)
        card_gap = 8.0
        card_width = (right_width - 36.0 - card_gap * 2.0) / 3.0
        metrics = (
            (self._t("Leistung", "Power", "Výkon"), power_text),
            (self._t("Gesundheit", "Health", "Zdraví"), health_text),
            (self._t("Zyklen", "Cycles", "Cykly"), cycles_text),
        )
        for index, (label, value) in enumerate(metrics):
            x = right_x + 18.0 + index * (card_width + card_gap)
            parts.extend((
                f'<rect x="{x:.1f}" y="{card_y:.1f}" width="{card_width:.1f}" height="{card_height:.1f}" rx="10" fill="{palette["background"]}"/>',
                f'<text x="{x + 12:.1f}" y="{card_y + 24:.1f}" fill="{palette["muted"]}" font-family="Sans" font-size="11">{escaped(label)}</text>',
                f'<text x="{x + 12:.1f}" y="{card_y + 50:.1f}" fill="{palette["text"]}" font-family="Sans" font-size="16" font-weight="700">{escaped(value)}</text>',
            ))
        parts.append('</svg>')
        return "".join(parts)

    def _studio_dashboard_battery_svg(
        self,
        points: list[tuple[datetime.datetime | None, float]],
        current_level: float,
        palette: dict[str, str],
    ) -> str:
        width, height = 520, 290
        details = self._battery_display_details
        power = details.get("power_w")
        power_text = f"{float(power):.2f} W" if isinstance(power, (float, int)) else "–"
        health = str(self.core.battery_health_assessment(details, self.language).get("display") or "–")
        cycles = _clean(details.get("cycle_count")) or "–"
        status = self.core.battery_status_label(details.get("status"), self.language)

        values = [value for _stamp, value in points]
        y_min = max(0.0, min(values) - 4.0) if values else 0.0
        y_max = min(100.0, max(values) + 4.0) if values else 100.0
        if y_max - y_min < 8.0:
            middle = (y_min + y_max) / 2.0
            y_min = max(0.0, middle - 4.0)
            y_max = min(100.0, y_min + 8.0)
            y_min = max(0.0, y_max - 8.0)
        valid_times = [stamp for stamp, _value in points if stamp is not None]
        start_time = valid_times[0] if valid_times else None
        end_time = valid_times[-1] if valid_times else None
        elapsed = (end_time - start_time).total_seconds() if start_time is not None and end_time is not None else 0.0
        graph_left, graph_right = 225.0, 500.0
        graph_top, graph_bottom = 38.0, 174.0
        coordinates: list[tuple[float, float]] = []
        for index, (stamp, value) in enumerate(points):
            fraction = (
                max(0.0, min(1.0, (stamp - start_time).total_seconds() / elapsed))
                if elapsed > 0 and stamp is not None and start_time is not None
                else index / max(1, len(points) - 1)
            )
            x = graph_left + (graph_right - graph_left) * fraction
            y = graph_bottom - (graph_bottom - graph_top) * ((value - y_min) / max(1.0, y_max - y_min))
            coordinates.append((x, y))

        escaped_status = GLib.markup_escape_text(str(status or "–"))
        circumference = 2.0 * 3.141592653589793 * 73.0
        ring_fill = circumference * max(0.0, min(100.0, current_level)) / 100.0
        motion_time = GLib.get_monotonic_time() / 1_000_000.0
        parts = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
            f'<defs><linearGradient id="dash-area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{palette["line"]}" stop-opacity="0.30"/><stop offset="1" stop-color="{palette["line"]}" stop-opacity="0.03"/></linearGradient></defs>',
            f'<rect width="{width}" height="{height}" rx="16" fill="{palette["background"]}"/>',
            f'<circle cx="102" cy="113" r="73" fill="none" stroke="{palette["grid"]}" stroke-width="22"/>',
            f'<circle cx="102" cy="113" r="73" fill="none" stroke="{palette["line"]}" stroke-width="22" stroke-linecap="round" stroke-dasharray="{ring_fill:.1f} {max(0.1, circumference-ring_fill):.1f}" transform="rotate(-90 102 113)"/>',
            f'<text x="102" y="114" text-anchor="middle" fill="{palette["text"]}" font-family="Sans" font-size="31" font-weight="700">{current_level:.0f}%</text>',
            f'<text x="102" y="138" text-anchor="middle" fill="{palette["muted"]}" font-family="Sans" font-size="12">{escaped_status}</text>',
            f'<text x="{graph_left:.0f}" y="23" fill="{palette["line"]}" font-family="Sans" font-size="12" font-weight="700">LIVE-VERLAUF</text>',
        ]
        if self._battery_mode:
            motion_direction = 1.0 if self._battery_mode == "charge" else -1.0
            motion_color = "#ffe15c" if self._battery_mode == "charge" else "#41f5c5"
            orbit_radius = 91.0
            orbit_circumference = 2.0 * math.pi * orbit_radius
            trail_fraction = 0.22
            trail_length = orbit_circumference * trail_fraction
            trail_gap = max(0.1, orbit_circumference - trail_length)
            phase_degrees = (-90.0 + motion_direction * motion_time * 210.0) % 360.0
            leading_angle = math.radians(phase_degrees) + 2.0 * math.pi * trail_fraction
            dot_x = 102.0 + orbit_radius * math.cos(leading_angle)
            dot_y = 113.0 + orbit_radius * math.sin(leading_angle)
            pulse = 1.0 + 0.18 * math.sin(motion_time * 7.0)
            parts.extend((
                f'<circle cx="102" cy="113" r="{orbit_radius:.0f}" fill="none" stroke="{motion_color}" stroke-opacity="0.18" stroke-width="2"/>',
                f'<circle cx="102" cy="113" r="{orbit_radius:.0f}" fill="none" stroke="{motion_color}" stroke-opacity="0.25" stroke-width="11" stroke-linecap="round" stroke-dasharray="{trail_length:.1f} {trail_gap:.1f}" transform="rotate({phase_degrees:.1f} 102 113)"/>',
                f'<circle cx="102" cy="113" r="{orbit_radius:.0f}" fill="none" stroke="{motion_color}" stroke-opacity="0.96" stroke-width="4" stroke-linecap="round" stroke-dasharray="{trail_length * 0.55:.1f} {orbit_circumference - trail_length * 0.55:.1f}" transform="rotate({phase_degrees + 360.0 * trail_fraction * 0.45:.1f} 102 113)"/>',
                f'<circle cx="{dot_x:.1f}" cy="{dot_y:.1f}" r="{9.0 * pulse:.1f}" fill="{motion_color}" fill-opacity="0.24"/>',
                f'<circle cx="{dot_x:.1f}" cy="{dot_y:.1f}" r="{5.0 * pulse:.1f}" fill="{motion_color}"/>',
                f'<circle cx="{dot_x:.1f}" cy="{dot_y:.1f}" r="2.0" fill="#ffffff"/>',
            ))
        for index in range(3):
            y = graph_bottom - (graph_bottom - graph_top) * index / 2.0
            parts.append(f'<line x1="{graph_left:.1f}" y1="{y:.1f}" x2="{graph_right:.1f}" y2="{y:.1f}" stroke="{palette["grid"]}" stroke-width="1"/>')
        if coordinates:
            if len(coordinates) > 1:
                line_path = " ".join(("M" if index == 0 else "L") + f" {x:.1f} {y:.1f}" for index, (x, y) in enumerate(coordinates))
                area_path = line_path + f" L {coordinates[-1][0]:.1f} {graph_bottom:.1f} L {coordinates[0][0]:.1f} {graph_bottom:.1f} Z"
                parts.append(f'<path d="{area_path}" fill="url(#dash-area)"/>')
                parts.append(f'<path d="{line_path}" fill="none" stroke="{palette["line"]}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>')
            for index, (x, y) in enumerate(coordinates):
                parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{5 if index == len(coordinates)-1 else 3}" fill="{palette["text"]}" stroke="{palette["line"]}" stroke-width="2"/>')
        else:
            parts.append(f'<text x="362" y="108" text-anchor="middle" fill="{palette["muted"]}" font-family="Sans" font-size="13">{GLib.markup_escape_text(self._t("Test starten", "Start test", "Spustit test"))}</text>')

        metrics = ((self._t("Leistung", "Power", "Výkon"), power_text), (self._t("Gesundheit", "Health", "Zdraví"), health), (self._t("Zyklen", "Cycles", "Cykly"), cycles))
        card_y, card_w = 228.0, 158.0
        for index, (label, value) in enumerate(metrics):
            x = 14.0 + index * (card_w + 9.0)
            parts.extend((
                f'<rect x="{x:.1f}" y="{card_y:.1f}" width="{card_w:.1f}" height="50" rx="10" fill="{palette["battery"]}"/>',
                f'<text x="{x+10:.1f}" y="{card_y+17:.1f}" fill="{palette["muted"]}" font-family="Sans" font-size="10">{GLib.markup_escape_text(label)}</text>',
                f'<text x="{x+10:.1f}" y="{card_y+39:.1f}" fill="{palette["text"]}" font-family="Sans" font-size="15" font-weight="700">{GLib.markup_escape_text(value)}</text>',
            ))
        parts.append('</svg>')
        return "".join(parts)

    def _update_dashboard_studio_battery(self, runtime_value: str = "–") -> None:
        image: Gtk.Image | None = self._build_refs.get("dashboard_studio_battery_image")
        state: Gtk.Label | None = self._build_refs.get("dashboard_studio_battery_state")
        runtime: Gtk.Label | None = self._build_refs.get("dashboard_studio_battery_runtime")
        if image is None or state is None or runtime is None:
            return
        details = self._battery_display_details
        runtime.set_text(runtime_value or "–")
        if not details.get("present"):
            state.set_text(self._t("● kein Akku", "● no battery", "● bez baterie"))
        elif self._battery_mode:
            state.set_text(self._t("● Messung aktiv", "● measurement active", "● měření aktivní"))
        elif self._battery_last_result:
            state.set_text(self._t("● Test abgeschlossen", "● test completed", "● test dokončen"))
        else:
            state.set_text(self._t("● bereit", "● ready", "● připraveno"))
        samples = list(self._battery_samples) if self._battery_samples else []
        if not samples and details.get("present"):
            samples = [details]
        points: list[tuple[datetime.datetime | None, float]] = []
        for sample in samples:
            try:
                level = max(0.0, min(100.0, float(sample.get("capacity_percent"))))
            except (TypeError, ValueError):
                continue
            points.append((self.core.parse_battery_timestamp(sample.get("timestamp")), level))
        current_level = points[-1][1] if points else 0.0
        try:
            svg = self._studio_dashboard_battery_svg(points, current_level, self._battery_chart_palette())
            loader = GdkPixbuf.PixbufLoader.new_with_type("svg")
            loader.write(svg.encode("utf-8"))
            loader.close()
            pixbuf = loader.get_pixbuf()
            if pixbuf is None:
                return
            allocated_width = int(image.get_allocated_width())
            # Never let the initial image size dictate the minimum width of
            # the complete dashboard.  Before GTK has assigned an allocation,
            # derive a conservative width from the actual monitor; afterwards
            # always follow the available space.  This applies independently
            # of the chosen visual layout and prevents any right-edge crop.
            initial_width = max(320, min(520, self.screen_width // 3))
            available_width = allocated_width if allocated_width >= 300 else initial_width
            target_width = max(320, min(520, available_width))
            target_height = max(1, int(target_width * 290 / 520))
            scaled = pixbuf.scale_simple(target_width, target_height, GdkPixbuf.InterpType.BILINEAR)
            image.set_from_pixbuf((scaled or pixbuf).copy())
            activity: Gtk.DrawingArea | None = self._build_refs.get("dashboard_studio_battery_activity")
            if activity is not None:
                activity.queue_draw()
        except Exception:
            image.clear()

    def _dashboard_battery_animation_tick(self) -> bool:
        if self._battery_mode and self._build_refs.get("dashboard_studio_battery_image") is not None:
            runtime: Gtk.Label | None = self._build_refs.get("dashboard_studio_battery_runtime")
            self._update_dashboard_studio_battery(runtime.get_text() if runtime is not None else "â€“")
        return True

    def _draw_dashboard_studio_battery_activity(self, widget: Gtk.DrawingArea, context) -> bool:
        if not self._battery_mode:
            return False
        image: Gtk.Image | None = self._build_refs.get("dashboard_studio_battery_image")
        pixbuf = image.get_pixbuf() if image is not None else None
        if pixbuf is None:
            return False
        allocation = widget.get_allocation()
        pixbuf_width = float(pixbuf.get_width())
        pixbuf_height = float(pixbuf.get_height())
        offset_x = max(0.0, (float(allocation.width) - pixbuf_width) / 2.0)
        offset_y = max(0.0, (float(allocation.height) - pixbuf_height) / 2.0)
        scale = min(pixbuf_width / 520.0, pixbuf_height / 290.0)
        center_x = offset_x + 102.0 * pixbuf_width / 520.0
        center_y = offset_y + 113.0 * pixbuf_height / 290.0
        radius = 91.0 * scale
        direction = 1.0 if self._battery_mode == "charge" else -1.0
        time_seconds = GLib.get_monotonic_time() / 1_000_000.0
        phase = -math.pi / 2.0 + direction * time_seconds * 2.35
        if self._battery_mode == "charge":
            red, green, blue = (1.0, 0.88, 0.34)
        else:
            red, green, blue = (0.25, 0.96, 0.78)
        context.save()
        context.set_line_cap(1)

        # Ein umlaufender, asymmetrischer Kometenring macht Laden/Entladen
        # auch aus Werkstattentfernung eindeutig als aktive Messung sichtbar.
        context.set_source_rgba(red, green, blue, 0.18)
        context.set_line_width(max(2.0, 2.4 * scale))
        context.arc(center_x, center_y, radius, 0.0, 2.0 * math.pi)
        context.stroke()

        tail_lengths = (1.18, 0.78, 0.42)
        tail_alpha = (0.20, 0.42, 0.92)
        tail_width = (9.0, 6.0, 3.5)
        for length, alpha, line_width in zip(tail_lengths, tail_alpha, tail_width):
            context.set_source_rgba(red, green, blue, alpha)
            context.set_line_width(max(2.5, line_width * scale))
            if direction > 0:
                context.arc(center_x, center_y, radius, phase - length, phase)
            else:
                context.arc_negative(center_x, center_y, radius, phase + length, phase)
            context.stroke()

        dot_x = center_x + radius * math.cos(phase)
        dot_y = center_y + radius * math.sin(phase)
        pulse = 1.0 + 0.18 * math.sin(time_seconds * 7.0)
        context.set_source_rgba(red, green, blue, 0.24)
        context.arc(dot_x, dot_y, max(8.0, 10.0 * scale) * pulse, 0.0, 2.0 * math.pi)
        context.fill()
        context.set_source_rgba(red, green, blue, 1.0)
        context.arc(dot_x, dot_y, max(4.0, 5.2 * scale) * pulse, 0.0, 2.0 * math.pi)
        context.fill()
        context.set_source_rgba(1.0, 1.0, 1.0, 0.96)
        context.arc(dot_x, dot_y, max(1.5, 2.0 * scale), 0.0, 2.0 * math.pi)
        context.fill()
        context.restore()
        return False

    def _update_battery_history_image(self) -> None:
        image: Gtk.Image | None = self._build_refs.get("battery_chart_image")
        error: Gtk.Label | None = self._build_refs.get("battery_chart_error")
        if image is None or error is None:
            return
        try:
            chart_widget: Gtk.Widget | None = self._build_refs.get("battery_chart")
            allocated_width = chart_widget.get_allocated_width() if chart_widget is not None else image.get_allocated_width()
            width = allocated_width if allocated_width >= 760 else 1040
            width = max(760, min(1280, width))
            height = 285
            samples = list(self._battery_samples) if self._battery_samples else []
            if not samples and self._battery_display_details.get("present"):
                samples = [self._battery_display_details]
            points: list[tuple[datetime.datetime | None, float]] = []
            for sample in samples:
                try:
                    value = max(0.0, min(100.0, float(sample.get("capacity_percent"))))
                except (TypeError, ValueError):
                    continue
                points.append((self.core.parse_battery_timestamp(sample.get("timestamp")), value))

            palette = self._battery_chart_palette()
            studio_metrics = ()
            if self.appearance_layout == "studio-panels":
                studio_metrics = (
                    self._battery_display_details.get("power_w"),
                    self._battery_display_details.get("energy_full"),
                    self._battery_display_details.get("energy_full_design"),
                    self._battery_display_details.get("health_percent"),
                    self._battery_display_details.get("cycle_count"),
                    self._battery_display_details.get("status"),
                )
            signature = repr((width, self.appearance_layout, self.appearance_accent, self._battery_mode, studio_metrics, [(str(stamp), value) for stamp, value in points]))
            if signature == self._battery_chart_signature:
                return

            current_level = points[-1][1] if points else 0.0
            level_color = "#ef5c68" if current_level < 20 else "#efaa3b" if current_level < 50 else "#4edca6"
            graph_left = 188.0
            graph_right = float(width - 28)
            graph_top = 42.0
            graph_bottom = float(height - 42)
            values = [value for _stamp, value in points]
            if values:
                y_min = max(0.0, min(values) - 5.0)
                y_max = min(100.0, max(values) + 5.0)
                if y_max - y_min < 10.0:
                    middle = (y_min + y_max) / 2.0
                    y_min = max(0.0, middle - 5.0)
                    y_max = min(100.0, y_min + 10.0)
                    y_min = max(0.0, y_max - 10.0)
            else:
                y_min, y_max = 0.0, 100.0

            valid_times = [stamp for stamp, _value in points if stamp is not None]
            start_time = valid_times[0] if valid_times else None
            end_time = valid_times[-1] if valid_times else None
            elapsed = (end_time - start_time).total_seconds() if start_time is not None and end_time is not None else 0.0

            def point_xy(index: int, stamp: datetime.datetime | None, value: float) -> tuple[float, float]:
                if elapsed > 0 and stamp is not None and start_time is not None:
                    fraction = max(0.0, min(1.0, (stamp - start_time).total_seconds() / elapsed))
                else:
                    fraction = index / max(1, len(points) - 1)
                x = graph_left + (graph_right - graph_left) * fraction
                y_fraction = (value - y_min) / max(1.0, y_max - y_min)
                y = graph_bottom - (graph_bottom - graph_top) * y_fraction
                return x, y

            coordinates = [point_xy(index, stamp, value) for index, (stamp, value) in enumerate(points)]
            if self.appearance_layout == "studio-panels":
                svg = self._studio_battery_history_svg(width, height, points, current_level, palette)
                loader = GdkPixbuf.PixbufLoader.new_with_type("svg")
                loader.write(svg.encode("utf-8"))
                loader.close()
                pixbuf = loader.get_pixbuf()
                if pixbuf is None:
                    raise RuntimeError("SVG konnte nicht geladen werden")
                image.set_from_pixbuf(pixbuf.copy())
                error.hide()
                error.set_no_show_all(True)
                self._battery_chart_signature = signature
                return
            parts = [
                f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
                f'<defs><linearGradient id="area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{palette["line"]}" stop-opacity="0.30"/><stop offset="1" stop-color="{palette["line"]}" stop-opacity="0.03"/></linearGradient></defs>',
                f'<rect width="{width}" height="{height}" rx="10" fill="{palette["background"]}"/>',
                f'<text x="42" y="31" fill="{palette["muted"]}" font-family="Sans" font-size="11">Akkustand</text>',
                f'<rect x="48" y="53" width="82" height="188" rx="10" fill="{palette["battery"]}" stroke="{palette["outline"]}" stroke-width="4"/>',
                f'<rect x="75" y="43" width="28" height="10" rx="3" fill="{palette["outline"]}"/>',
            ]
            inner_height = 168.0
            fill_height = inner_height * current_level / 100.0
            fill_y = 63.0 + inner_height - fill_height
            parts.append(f'<rect x="57" y="{fill_y:.1f}" width="64" height="{fill_height:.1f}" rx="5" fill="{level_color}"/>')
            parts.append(f'<text x="89" y="158" text-anchor="middle" fill="#07131c" font-family="Sans" font-size="22" font-weight="700">{current_level:.0f}%</text>')

            for index in range(5):
                fraction = index / 4.0
                y = graph_bottom - (graph_bottom - graph_top) * fraction
                value = y_min + (y_max - y_min) * fraction
                parts.append(f'<line x1="{graph_left:.1f}" y1="{y:.1f}" x2="{graph_right:.1f}" y2="{y:.1f}" stroke="{palette["grid"]}" stroke-width="1"/>')
                parts.append(f'<text x="{graph_left - 10:.1f}" y="{y + 4:.1f}" text-anchor="end" fill="{palette["muted"]}" font-family="Sans" font-size="10">{value:.0f}%</text>')

            if coordinates:
                if len(coordinates) > 1:
                    line_path = " ".join(("M" if index == 0 else "L") + f" {x:.1f} {y:.1f}" for index, (x, y) in enumerate(coordinates))
                    area_path = line_path + f" L {coordinates[-1][0]:.1f} {graph_bottom:.1f} L {coordinates[0][0]:.1f} {graph_bottom:.1f} Z"
                    parts.append(f'<path d="{area_path}" fill="url(#area)"/>')
                    parts.append(f'<path d="{line_path}" fill="none" stroke="{palette["line"]}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>')
                for index, (x, y) in enumerate(coordinates):
                    radius = 6 if index == len(coordinates) - 1 else 4
                    fill = level_color if index == len(coordinates) - 1 else palette["background"]
                    parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{radius}" fill="{fill}" stroke="{palette["line"]}" stroke-width="3"/>')
                last_x, last_y = coordinates[-1]
                parts.append(f'<text x="{max(graph_left, last_x - 10):.1f}" y="{max(graph_top + 14, last_y - 12):.1f}" text-anchor="end" fill="{palette["text"]}" font-family="Sans" font-size="11">{points[-1][1]:.0f}%</text>')
            else:
                parts.append(f'<text x="{(graph_left + graph_right) / 2:.1f}" y="145" text-anchor="middle" fill="{palette["muted"]}" font-family="Sans" font-size="14">Akku-Test starten</text>')

            for index in range(4):
                fraction = index / 3.0
                x = graph_left + (graph_right - graph_left) * fraction
                if index == 0:
                    label = "Start"
                else:
                    label = self.core.battery_elapsed_text(elapsed * fraction, self.language) if elapsed > 0 else ""
                parts.append(f'<text x="{x:.1f}" y="{height - 17}" text-anchor="middle" fill="{palette["muted"]}" font-family="Sans" font-size="10">{GLib.markup_escape_text(label)}</text>')
            parts.append('</svg>')

            loader = GdkPixbuf.PixbufLoader.new_with_type("svg")
            loader.write("".join(parts).encode("utf-8"))
            loader.close()
            pixbuf = loader.get_pixbuf()
            if pixbuf is None:
                raise RuntimeError("SVG konnte nicht geladen werden")
            image.set_from_pixbuf(pixbuf.copy())
            error.hide()
            error.set_no_show_all(True)
            self._battery_chart_signature = signature
        except Exception as exc:
            image.set_from_icon_name("dialog-error-symbolic", Gtk.IconSize.DIALOG)
            error.set_text(f"{self._t('Akku-Diagramm konnte nicht geladen werden', 'Battery chart could not be loaded', 'Graf baterie nelze načíst')}: {exc}")
            error.set_no_show_all(False)
            error.show()

    def _draw_battery_history(self, widget: Gtk.DrawingArea, context) -> bool:
        try:
            return self._draw_battery_history_content(widget, context)
        except Exception as exc:
            palette = self._battery_chart_palette()
            context.set_source_rgb(*_rgb_float(palette["background"]))
            context.paint()
            context.set_source_rgb(0.94, 0.36, 0.41)
            context.set_font_size(14)
            context.move_to(24, 38)
            context.show_text(self._t("Akku-Diagramm konnte nicht gezeichnet werden", "Battery chart could not be drawn", "Graf baterie se nepodařilo vykreslit"))
            context.set_source_rgb(*_rgb_float(palette["muted"]))
            context.set_font_size(10)
            context.move_to(24, 58)
            context.show_text(_short(str(exc), 120))
            return False

    def _draw_battery_history_content(self, widget: Gtk.DrawingArea, context) -> bool:
        width = widget.get_allocated_width()
        height = widget.get_allocated_height()
        palette = self._battery_chart_palette()
        context.set_source_rgb(*_rgb_float(palette["background"]))
        context.paint()
        samples = self._battery_display_samples_for(self._battery_display_details)
        points: list[tuple[datetime.datetime | None, float]] = []
        for sample in samples:
            try:
                value = max(0.0, min(100.0, float(sample.get("capacity_percent"))))
            except (TypeError, ValueError):
                continue
            points.append((self.core.parse_battery_timestamp(sample.get("timestamp")), value))

        context.select_font_face("Sans", 0, 0)

        def text_size(text: str) -> tuple[float, float]:
            extent = context.text_extents(text)
            width_value = getattr(extent, "width", None)
            height_value = getattr(extent, "height", None)
            if width_value is None:
                width_value = extent[2]
            if height_value is None:
                height_value = extent[3]
            return float(width_value), float(height_value)

        current_level = points[-1][1] if points else 0.0
        battery_x, battery_y, battery_w, battery_h = 38.0, 48.0, 78.0, max(120.0, height - 92.0)
        context.set_line_width(3)
        context.set_source_rgb(*_rgb_float(palette["outline"]))
        context.rectangle(battery_x, battery_y, battery_w, battery_h)
        context.stroke()
        context.rectangle(battery_x + 24, battery_y - 9, 30, 7)
        context.fill()
        inner_margin = 6.0
        fill_height = max(0.0, (battery_h - inner_margin * 2) * current_level / 100.0)
        if current_level < 20:
            context.set_source_rgb(0.94, 0.36, 0.41)
        elif current_level < 50:
            context.set_source_rgb(0.94, 0.66, 0.23)
        else:
            context.set_source_rgb(0.18, 0.79, 0.56)
        context.rectangle(battery_x + inner_margin, battery_y + battery_h - inner_margin - fill_height, battery_w - inner_margin * 2, fill_height)
        context.fill()
        context.set_source_rgb(*_rgb_float(palette["text"]))
        context.set_font_size(19)
        level_text = f"{current_level:.0f}%" if points else "–"
        text_width, text_height = text_size(level_text)
        context.move_to(battery_x + (battery_w - text_width) / 2, battery_y + battery_h / 2 + text_height / 2)
        context.show_text(level_text)

        graph_left = 168.0
        graph_right = max(graph_left + 80.0, width - 34.0)
        graph_top = 30.0
        graph_bottom = max(graph_top + 80.0, height - 42.0)
        values = [value for _stamp, value in points]
        if values:
            y_min = max(0.0, min(values) - 5.0)
            y_max = min(100.0, max(values) + 5.0)
            if y_max - y_min < 10.0:
                middle = (y_min + y_max) / 2.0
                y_min = max(0.0, middle - 5.0)
                y_max = min(100.0, y_min + 10.0)
                y_min = max(0.0, y_max - 10.0)
        else:
            y_min, y_max = 0.0, 100.0
        context.set_font_size(10)
        context.set_line_width(1)
        for index in range(5):
            fraction = index / 4.0
            y = graph_bottom - (graph_bottom - graph_top) * fraction
            value = y_min + (y_max - y_min) * fraction
            grid_red, grid_green, grid_blue = _rgb_float(palette["grid"])
            context.set_source_rgba(grid_red, grid_green, grid_blue, 0.65)
            context.move_to(graph_left, y)
            context.line_to(graph_right, y)
            context.stroke()
            context.set_source_rgb(*_rgb_float(palette["muted"]))
            context.move_to(graph_left - 34, y + 4)
            context.show_text(f"{value:.0f}%")

        if not points:
            context.set_source_rgb(*_rgb_float(palette["muted"]))
            context.set_font_size(14)
            context.move_to(graph_left + 20, graph_top + 45)
            context.show_text(self._t("Akku-Test starten", "Start a battery test", "Spusťte test baterie"))
            return False

        valid_times = [stamp for stamp, _value in points if stamp is not None]
        start_time = valid_times[0] if valid_times else None
        end_time = valid_times[-1] if valid_times else None
        elapsed = (end_time - start_time).total_seconds() if start_time is not None and end_time is not None else 0.0

        def point_xy(index: int, stamp: datetime.datetime | None, value: float) -> tuple[float, float]:
            if elapsed > 0 and stamp is not None and start_time is not None:
                x_fraction = max(0.0, min(1.0, (stamp - start_time).total_seconds() / elapsed))
            else:
                x_fraction = index / max(1, len(points) - 1)
            x = graph_left + (graph_right - graph_left) * x_fraction
            y_fraction = (value - y_min) / max(1.0, y_max - y_min)
            y = graph_bottom - (graph_bottom - graph_top) * y_fraction
            return x, y

        coordinates = [point_xy(index, stamp, value) for index, (stamp, value) in enumerate(points)]
        if len(coordinates) > 1:
            context.move_to(*coordinates[0])
            for x, y in coordinates[1:]:
                context.line_to(x, y)
            context.line_to(coordinates[-1][0], graph_bottom)
            context.line_to(coordinates[0][0], graph_bottom)
            context.close_path()
            line_red, line_green, line_blue = _rgb_float(palette["line"])
            context.set_source_rgba(line_red, line_green, line_blue, 0.13)
            context.fill()
            context.move_to(*coordinates[0])
            for x, y in coordinates[1:]:
                context.line_to(x, y)
            context.set_source_rgb(*_rgb_float(palette["line"]))
            context.set_line_width(3)
            context.stroke()
        for index, (x, y) in enumerate(coordinates):
            context.arc(x, y, 5 if index == len(coordinates) - 1 else 3, 0, 6.28318)
            if index == len(coordinates) - 1:
                context.set_source_rgb(0.32, 0.89, 0.69)
            else:
                context.set_source_rgb(*_rgb_float(palette["line"]))
            context.fill()
        context.set_source_rgb(*_rgb_float(palette["text"]))
        context.set_font_size(12)
        last_x, last_y = coordinates[-1]
        context.move_to(max(graph_left, last_x - 24), max(graph_top + 12, last_y - 10))
        context.show_text(f"{points[-1][1]:.0f}%")
        context.set_source_rgb(*_rgb_float(palette["muted"]))
        context.set_font_size(10)
        context.move_to(graph_left, height - 16)
        context.show_text(self._t("Start", "Start", "Start"))
        if elapsed > 0:
            elapsed_text = self.core.battery_elapsed_text(elapsed, self.language)
            text_width, _text_height = text_size(elapsed_text)
            context.move_to(graph_right - text_width, height - 16)
            context.show_text(elapsed_text)
        return False

    def _battery_state_path(self) -> pathlib.Path:
        return pathlib.Path(self.core.tempfile.gettempdir()) / "hardwarecheck-v5-active-battery-test.json"

    def _save_battery_state(self) -> None:
        if self._battery_mode not in {"charge", "discharge"}:
            return
        path = self._battery_state_path()
        payload = {
            "mode": self._battery_mode,
            "csv_path": str(self._battery_csv_path or ""),
            "saved_at": datetime.datetime.now().astimezone().replace(microsecond=0).isoformat(),
            "samples": self._battery_samples[-720:],
        }
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(path.suffix + ".tmp")
            temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            temporary.replace(path)
        except OSError:
            pass

    def _clear_battery_state(self) -> None:
        try:
            self._battery_state_path().unlink(missing_ok=True)
        except OSError:
            pass

    def _restore_battery_test(self) -> None:
        path = self._battery_state_path()
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            mode = str(payload.get("mode") or "")
            saved_at = self.core.parse_battery_timestamp(payload.get("saved_at"))
            samples = payload.get("samples")
            if mode not in {"charge", "discharge"} or saved_at is None or not isinstance(samples, list) or not samples:
                raise ValueError("invalid active battery state")
            now = datetime.datetime.now(saved_at.tzinfo) if saved_at.tzinfo is not None else datetime.datetime.now()
            if (now - saved_at).total_seconds() > 30 * 60 or (now - saved_at).total_seconds() < -60:
                raise ValueError("stale active battery state")
            self._battery_mode = mode
            self._battery_samples = [sample for sample in samples if isinstance(sample, dict)]
            csv_value = str(payload.get("csv_path") or "").strip()
            self._battery_csv_path = pathlib.Path(csv_value) if csv_value else None
            if self._battery_timer_id is not None:
                GLib.source_remove(self._battery_timer_id)
            self._battery_timer_id = GLib.timeout_add_seconds(60, self._battery_sample_tick)
            details = self.core.read_battery_details()
            self._update_battery_ui(details)
            self.set_status(self._t("Laufender Akku-Test wurde fortgesetzt.", "Running battery test resumed.", "Probíhající test baterie byl obnoven."), "good")
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            self._battery_mode = ""
            self._battery_samples = []
            self._battery_csv_path = None
            self._clear_battery_state()

    def _start_battery_test(self, mode: str) -> None:
        if self._battery_mode:
            self.set_status(self._t("Ein Akku-Test läuft bereits.", "A battery test is already running.", "Test baterie již probíhá."), "warn")
            return
        details = self.core.read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Kein Akku erkannt.", "No battery detected.", "Baterie nebyla nalezena."), "bad")
            return
        try:
            start_percent = float(details.get("capacity_percent"))
        except (TypeError, ValueError):
            start_percent = None
        if mode == "discharge" and details.get("ac_online") is True:
            self.set_status(self._t("Für den Entlade-Test bitte das Netzteil entfernen.", "Disconnect the adapter for the discharge test.", "Pro test vybíjení odpojte napájecí adaptér."), "warn")
            return
        if mode == "charge" and details.get("ac_online") is False:
            self.set_status(self._t("Für den Lade-Test bitte das Netzteil anschließen.", "Connect the adapter for the charge test.", "Pro test nabíjení připojte napájecí adaptér."), "warn")
            return
        if mode == "discharge" and start_percent is not None and start_percent <= self.core.BATTERY_TEST_LOW_LEVEL_PERCENT:
            self.set_status(self._t("Akkustand zu niedrig: Entlade-Test erst oberhalb von 15 % starten.", "Battery level too low: start the discharge test above 15 %.", "Stav baterie je příliš nízký: test vybíjení spusťte nad 15 %."), "warn")
            return
        if mode == "charge" and start_percent is not None and start_percent >= self.core.BATTERY_TEST_CHARGE_STOP_PERCENT:
            self.set_status(self._t("Akku bereits nahezu voll; Lade-Test unter 95 % starten.", "Battery already nearly full; start the charge test below 95 %.", "Baterie je téměř plná; test nabíjení spusťte pod 95 %."), "warn")
            return
        try:
            report_dir = self.core.get_battery_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            basename = self.core.battery_report_basename(self.snapshot or None, mode)
            self._battery_csv_path = report_dir / f"{basename}.csv"
            self.core.append_battery_csv(self._battery_csv_path, mode, details, include_header=True)
        except OSError as exc:
            self.set_status(f"{self._t('Akku-Test konnte nicht gestartet werden', 'Battery test could not be started', 'Test baterie nelze spustit')}: {exc}", "bad")
            return
        self._battery_mode = mode
        self._battery_samples = [details]
        self._battery_last_result = {}
        self._battery_last_report_path = None
        if self._battery_timer_id is not None:
            GLib.source_remove(self._battery_timer_id)
        self._battery_timer_id = GLib.timeout_add_seconds(60, self._battery_sample_tick)
        self._save_battery_state()
        self._update_battery_ui(details)
        self.set_status(self._t("Standardtest gestartet: mindestens 30 Minuten und 5 % Veränderung, maximal 60 Minuten.", "Standard test started: at least 30 minutes and 5 % change, maximum 60 minutes.", "Standardní test spuštěn: nejméně 30 minut a změna 5 %, maximálně 60 minut."), "good")

    def _battery_sample_tick(self) -> bool:
        if not self._battery_mode:
            return False
        details = self.core.read_battery_details()
        self._battery_samples.append(details)
        if self._battery_csv_path is not None:
            try:
                self.core.append_battery_csv(self._battery_csv_path, self._battery_mode, details)
            except OSError:
                pass
        self._save_battery_state()
        self._update_battery_ui(details)
        completion = self.core.battery_test_completion(self._battery_mode, self._battery_samples)
        if completion.get("should_finish"):
            self._battery_timer_id = None
            self._finish_battery_test(str(completion.get("reason") or "max_duration"), automatic=True)
            return False
        return True

    def _stop_battery_test(self, _button=None) -> None:
        if not self._battery_mode:
            self.set_status(self._t("Kein Akku-Test aktiv.", "No battery test active.", "Není aktivní žádný test baterie."), "warn")
            return
        details = self.core.read_battery_details()
        last_stamp = str(self._battery_samples[-1].get("timestamp") or "") if self._battery_samples else ""
        if str(details.get("timestamp") or "") != last_stamp:
            self._battery_samples.append(details)
            if self._battery_csv_path is not None:
                try:
                    self.core.append_battery_csv(self._battery_csv_path, self._battery_mode, details)
                except OSError:
                    pass
        self._finish_battery_test("manual", automatic=False)

    def _finish_battery_test(self, reason: str, automatic: bool) -> None:
        if not self._battery_mode:
            return
        mode = self._battery_mode
        samples = list(self._battery_samples)
        csv_path = self._battery_csv_path
        self._battery_last_result = self.core.battery_test_result(mode, samples, self.language, reason)
        self._battery_mode = ""
        if self._battery_timer_id is not None:
            GLib.source_remove(self._battery_timer_id)
            self._battery_timer_id = None
        self._clear_battery_state()
        self._update_battery_ui(samples[-1])
        if automatic:
            self.set_status(
                f"{self._t('Akku-Test automatisch abgeschlossen', 'Battery test completed automatically', 'Test baterie byl automaticky dokončen')}: {self._battery_last_result.get('verdict')}",
                "good" if self._battery_last_result.get("class_name") == "ok" else "warn" if self._battery_last_result.get("class_name") == "warn" else "bad",
            )
        self._write_battery_report(mode, samples, csv_path, reason)

    def _instant_battery_report(self, _button=None) -> None:
        details = self.core.read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Kein Akku erkannt.", "No battery detected.", "Baterie nebyla nalezena."), "bad")
            return
        self._write_battery_report("instant", [details], None, "instant")

    def _write_battery_report(self, mode: str, samples: list[dict[str, object]], csv_path: pathlib.Path | None, completion_reason: str = "manual") -> None:
        snapshot = dict(self.snapshot)

        def worker():
            report_dir = self.core.get_battery_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            basename = self.core.battery_report_basename(snapshot or None, mode)
            local_csv = csv_path or report_dir / f"{basename}.csv"
            if csv_path is None:
                self.core.append_battery_csv(local_csv, mode, samples[-1], include_header=True)
            txt_path = report_dir / f"{basename}.txt"
            html_path = report_dir / f"{basename}.html"
            report = self.core.build_battery_workshop_report(mode, samples, snapshot, local_csv, self.language, completion_reason)
            html_report = self.core.build_battery_test_html_report(mode, samples, snapshot, local_csv, txt_path, self.language, completion_reason)
            self.core.write_text_durable(txt_path, report)
            self.core.write_text_durable(html_path, html_report)
            return html_path, txt_path

        def done(paths) -> None:
            html_path, txt_path = paths
            self._battery_last_report_path = txt_path
            self.set_status(f"{self._t('Akku-Ergebnis gespeichert', 'Battery result saved', 'Výsledek testu baterie uložen')}: {txt_path.name}", "good")
            if self._battery_display_details:
                self._update_battery_ui(self._battery_display_details)
            self._refresh_reports()

        self.run_async("battery-report", worker, done)

    # ---------- Wi-Fi ----------

    def _open_settings_tool(self, page: str, popover: Gtk.Popover | None = None) -> None:
        if popover is not None:
            popover.popdown()
        self.show_page(page)

    def _set_network_chip(self, text: str, state: str) -> None:
        label: Gtk.Label | None = self._build_refs.get("network_chip")
        button: Gtk.MenuButton | None = self._build_refs.get("network_chip_button")
        if label is not None:
            label.set_text(text)
        if button is not None:
            self._set_chip_state(button, state)

    def _current_wifi_connection(self) -> tuple[str, str]:
        try:
            for iface in self.core.list_network_interfaces(wifi=True):
                ssid = str(self.core.current_wifi_ssid(iface) or "").strip()
                if ssid and self.core.interface_has_ipv4(iface):
                    self._wifi_connected_ssid = ssid
                    return iface, ssid
        except Exception:
            pass
        return "", ""

    def _wifi_quick_toggled(self, button: Gtk.MenuButton) -> None:
        if button.get_active():
            self._refresh_wifi_quick_menu(force=True)

    def _scan_wifi_live_preserving_connection(self) -> tuple[list[dict[str, str]], str]:
        """Scan visible WLANs without resetting an existing association."""
        if not sys.platform.startswith("linux"):
            return [], "WLAN-Scan nur unter Linux verfügbar"
        try:
            ifaces = self.core.list_network_interfaces(wifi=True)
            iw = self.core.find_executable("iw")
            iwlist = self.core.find_executable("iwlist")
            ip_cmd = self.core.find_executable("ip")
        except Exception as exc:
            return [], str(exc)
        if not ifaces:
            return [], self._t("Kein WLAN-Adapter gefunden", "No Wi-Fi adapter found", "Nebyl nalezen adaptér Wi-Fi")

        debug_lines: list[str] = []
        try:
            self.core.unblock_wifi_radios(debug_lines)
            self.core.set_wifi_country(debug_lines)
        except Exception:
            pass
        found: dict[str, dict[str, str]] = {}
        for iface in ifaces:
            if ip_cmd:
                self.core.run_quiet_timeout([ip_cmd, "link", "set", iface, "up"], timeout=3)
            networks: list[dict[str, str]] = []
            if iw:
                output = self.core.run_debug_command([iw, "dev", iface, "scan"], timeout=12)
                networks = self.core.parse_iw_scan(output, iface)
                if not networks:
                    cached = self.core.run_debug_command([iw, "dev", iface, "scan", "dump"], timeout=4)
                    networks = self.core.parse_iw_scan(cached, iface)
            if not networks and iwlist:
                output = self.core.run_debug_command([iwlist, iface, "scan"], timeout=12)
                networks = self.core.parse_iwlist_scan(output, iface)
            for network in networks:
                ssid = str(network.get("ssid") or "").strip()
                if not ssid:
                    continue
                previous = found.get(ssid)
                if previous is None or self.core.wifi_signal_sort_value(network.get("signal", "")) > self.core.wifi_signal_sort_value(previous.get("signal", "")):
                    found[ssid] = network
        networks = sorted(found.values(), key=lambda item: self.core.wifi_signal_sort_value(item.get("signal", "")), reverse=True)
        return networks, self._t(
            f"{len(networks)} sichtbare WLAN-Netze",
            f"{len(networks)} visible Wi-Fi networks",
            f"Viditelné sítě Wi-Fi: {len(networks)}",
        ) if networks else self._t("Keine sichtbaren WLAN-Netze gefunden", "No visible Wi-Fi networks found", "Nebyly nalezeny žádné viditelné sítě Wi-Fi")

    def _refresh_wifi_quick_menu(self, force: bool = False) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("wifi_quick_list")
        status: Gtk.Label | None = self._build_refs.get("wifi_quick_status")
        task_name = "wifi-live-scan"
        if listbox is None or status is None or task_name in self._refresh_tasks:
            return
        if self._wifi_connection_busy:
            status.set_text(self._t("WLAN wird gerade verbunden …", "Wi-Fi is connecting …", "Wi-Fi se právě připojuje …"))
            return
        if self._wifi_quick_networks and not force:
            _iface, connected_ssid = self._current_wifi_connection()
            self._render_wifi_quick_rows(self._wifi_quick_networks, self.core.load_wifi_networks(), connected_ssid)
            return
        status.set_text(self._t("Live-Suche läuft …", "Live scan running …", "Probíhá živé hledání …"))
        if self._wifi_connected_ssid:
            try:
                saved_now = self.core.load_wifi_networks()
            except Exception:
                saved_now = []
            cached = list(self._wifi_quick_networks)
            if not any(str(item.get("ssid") or "") == self._wifi_connected_ssid for item in cached):
                cached.insert(0, {"ssid": self._wifi_connected_ssid, "signal": "–"})
            self._render_wifi_quick_rows(cached, saved_now, self._wifi_connected_ssid)
        else:
            self._clear_listbox(listbox)
            waiting = Gtk.ListBoxRow()
            waiting.add(self._label(self._t("Verfügbare WLANs werden gesucht …", "Searching for available Wi-Fi …", "Vyhledávání dostupných sítí Wi-Fi …"), "muted", wrap=True))
            listbox.add(waiting)
            listbox.show_all()
        self._refresh_tasks.add(task_name)

        def worker():
            iface, connected_ssid = self._current_wifi_connection()
            saved = self.core.load_wifi_networks()
            networks, message = self._scan_wifi_live_preserving_connection()
            return iface, connected_ssid, saved, networks, message

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            _iface, connected_ssid, saved, networks, message = result
            self._wifi_quick_networks = networks
            self._render_wifi_quick_rows(networks, saved, connected_ssid)
            status.set_text(message)

        self.run_async(task_name, worker, done)

    def _render_wifi_quick_rows(self, networks: list[dict[str, str]], saved: list[dict[str, str]], connected_ssid: str) -> None:
        listbox: Gtk.ListBox | None = self._build_refs.get("wifi_quick_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        saved_by_ssid = {str(item.get("ssid") or ""): item for item in saved}
        visible = {str(item.get("ssid") or ""): dict(item) for item in networks if str(item.get("ssid") or "")}
        if connected_ssid and connected_ssid not in visible:
            visible[connected_ssid] = {"ssid": connected_ssid, "signal": "–"}
        ordered = sorted(
            visible.values(),
            key=lambda item: (
                str(item.get("ssid") or "") == connected_ssid,
                self.core.wifi_signal_sort_value(item.get("signal", "")),
            ),
            reverse=True,
        )
        if not ordered:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Keine WLAN-Netze sichtbar.", "No Wi-Fi networks visible.", "Nejsou viditelné žádné sítě Wi-Fi."), "muted", wrap=True))
            listbox.add(row)
        for network in ordered:
            ssid = str(network.get("ssid") or "")
            saved_profile = saved_by_ssid.get(ssid)
            if saved_profile:
                merged = dict(saved_profile)
                merged.update({key: value for key, value in network.items() if value})
            else:
                merged = network
            listbox.add(self._wifi_quick_row(merged, bool(saved_profile), ssid == connected_ssid))
        listbox.show_all()

    def _wifi_quick_row(self, network: dict[str, str], saved: bool, connected: bool) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.add(box)
        box.pack_start(self._icon("network-wireless-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(network.get("ssid")), "section-title"), False, False, 0)
        if connected:
            detail = self._t("Verbunden", "Connected", "Připojeno")
        else:
            security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security")) or self._t("Sicherheit unbekannt", "Security unknown", "Neznámé zabezpečení")
            signal = _clean(network.get("signal"), self._t("Signal unbekannt", "Signal unknown", "Signál neznámý"))
            detail = f"{security} · {signal}"
        if saved:
            detail += f" · {self._t('gespeichert', 'saved', 'uloženo')}"
        text.pack_start(self._label(detail, "good-text" if connected else "muted", wrap=True), False, False, 0)
        box.pack_start(text, True, True, 0)
        if not connected:
            box.pack_end(
                self._button(
                    self._t("Verbinden", "Connect", "Připojit"),
                    lambda _b, item=dict(network), is_saved=saved: self._connect_wifi(item, is_saved),
                    "primary-button",
                ),
                False,
                False,
                0,
            )
        return row

    def _start_wifi_autoconnect(self) -> bool:
        if self._wifi_autoconnect_started:
            return False
        self._wifi_autoconnect_started = True
        self._set_network_chip(self._t("WLAN verbindet …", "Connecting Wi-Fi …", "Připojování Wi-Fi …"), "warn")
        self._wifi_connection_busy = True

        def progress(state: str, message: str) -> None:
            GLib.idle_add(self._wifi_autoconnect_progress, state, message)

        def worker():
            try:
                saved = self.core.load_wifi_networks()
            except Exception:
                saved = []
            result = self.core.connect_temporary_network(
                progress,
                [],
                networks_override=saved,
                require_internet=True,
                allow_active=True,
                allow_lan=False,
                cleanup_success=False,
            )
            if not result[0]:
                try:
                    result[2]()
                except Exception:
                    pass
            _iface, connected_ssid = self._current_wifi_connection() if result[0] else ("", "")
            return result[0], result[1], connected_ssid, bool(saved)

        self.run_async("wifi-autoconnect", worker, self._wifi_autoconnect_finished)
        return False

    def _wifi_autoconnect_progress(self, state: str, message: str) -> bool:
        translated = self._translate_status(message)
        quick_status: Gtk.Label | None = self._build_refs.get("wifi_quick_status")
        if quick_status is not None:
            quick_status.set_text(translated)
        if state == "online":
            self._set_network_chip(self._t("Netzwerk aktiv", "Network active", "Síť aktivní"), "good")
        else:
            self._set_network_chip(self._t("WLAN verbindet …", "Connecting Wi-Fi …", "Připojování Wi-Fi …"), "warn")
        return False

    def _wifi_autoconnect_finished(self, result) -> None:
        ok, message, ssid, had_saved_profiles = result
        self._wifi_connection_busy = False
        if ok:
            self._wifi_connected_ssid = ssid
            self._set_network_chip(f"{ssid} ✓" if ssid else self._translate_status(message), "good")
            self.set_status(self._translate_status(message), "good")
        else:
            self._wifi_connected_ssid = ""
            self._set_network_chip(self._t("Offline", "Offline", "Offline"), "warn")
            self.set_status(
                self._t("Kein gespeichertes WLAN erreichbar.", "No saved Wi-Fi is reachable.", "Žádná uložená Wi-Fi není dostupná.")
                if had_saved_profiles
                else self._t("Noch kein WLAN gespeichert.", "No Wi-Fi has been saved yet.", "Zatím není uložena žádná Wi-Fi."),
                "warn",
            )
        self._wifi_quick_networks = []
        popover: Gtk.Popover | None = self._build_refs.get("wifi_quick_popover")
        if popover is not None and popover.get_visible():
            self._refresh_wifi_quick_menu(force=True)
        GLib.timeout_add_seconds(2, self._schedule_auto_update_check)

    def _build_wifi_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("WLAN-Zentrale", "Wi-Fi centre", "Centrum Wi-Fi"),
            self._t("Gespeicherte und sichtbare Netzwerke gemeinsam anzeigen, prüfen und verbinden.", "Show, check and connect saved and visible networks together.", "Zobrazujte, kontrolujte a připojujte uložené i viditelné sítě."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["wifi_status"] = self._label(self._t("Bereit zur Suche", "Ready to scan", "Připraveno ke skenování"), "status-chip")
        toolbar.pack_start(self._build_refs["wifi_status"], True, True, 0)
        toolbar.pack_end(self._button(self._t("Netze suchen", "Scan networks", "Vyhledat sítě"), self._scan_wifi, "primary-button", "view-refresh-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)
        self._build_refs["wifi_list"] = Gtk.ListBox()
        self._build_refs["wifi_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        wifi_scroll = Gtk.ScrolledWindow()
        wifi_scroll.set_min_content_height(430)
        wifi_scroll.add(self._build_refs["wifi_list"])
        outer.pack_start(wifi_scroll, True, True, 4)
        return page

    def _clear_listbox(self, widget: Gtk.ListBox) -> None:
        for child in widget.get_children():
            widget.remove(child)

    def _refresh_wifi_saved_rows(self, scanned: list[dict[str, str]] | None = None) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("wifi_list")
        task_name = "wifi-profiles"
        if listbox is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["wifi_status"].set_text(self._t("WLAN-Profile werden geladen …", "Loading Wi-Fi profiles …", "Načítání profilů Wi-Fi …"))

        def worker():
            try:
                return self.core.load_wifi_networks()
            except Exception:
                return []

        def done(saved) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_wifi_rows(saved, scanned)

        self.run_async(task_name, worker, done)

    def _render_wifi_rows(self, saved: list[dict[str, str]], scanned: list[dict[str, str]] | None = None) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("wifi_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        saved_by_ssid = {str(item.get("ssid") or ""): item for item in saved}
        merged: dict[str, dict[str, str]] = {ssid: dict(item) for ssid, item in saved_by_ssid.items() if ssid}
        for item in scanned or []:
            ssid = str(item.get("ssid") or "")
            if not ssid:
                continue
            existing = merged.setdefault(ssid, {})
            existing.update(item)
            if ssid in saved_by_ssid:
                existing["password"] = str(saved_by_ssid[ssid].get("password") or "")
                existing["saved"] = "1"
        if not merged:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Noch keine gespeicherten oder sichtbaren WLAN-Netze.", "No saved or visible Wi-Fi networks yet.", "Zatím žádné uložené ani viditelné sítě Wi-Fi."), "muted", wrap=True))
            listbox.add(row)
        for network in sorted(merged.values(), key=lambda item: self.core.wifi_signal_sort_value(item.get("signal", "")), reverse=True):
            listbox.add(self._wifi_row(network, str(network.get("ssid") or "") in saved_by_ssid))
        listbox.show_all()
        self._build_refs["wifi_status"].set_text(
            self._t(f"{len(merged)} WLAN-Netze", f"{len(merged)} Wi-Fi networks", f"Sítě Wi-Fi: {len(merged)}")
        )

    def _wifi_row(self, network: dict[str, str], saved: bool) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        row.add(box)
        box.pack_start(self._icon("network-wireless-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(network.get("ssid")), "section-title"), False, False, 0)
        security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security"))
        signal = _clean(network.get("signal"), self._t("Signal unbekannt", "Signal unknown", "Signál neznámý"))
        saved_text = self._t("gespeichert", "saved", "uloženo") if saved else self._t("nicht gespeichert", "not saved", "neuloženo")
        text.pack_start(self._label(f"{security} · {signal} · {saved_text}", "muted"), False, False, 0)
        box.pack_start(text, True, True, 0)
        box.pack_end(self._button(self._t("Verbinden", "Connect", "Připojit"), lambda _b, item=dict(network), is_saved=saved: self._connect_wifi(item, is_saved), "primary-button", "network-wireless-symbolic"), False, False, 0)
        if saved:
            box.pack_end(self._button(self._t("Löschen", "Delete", "Smazat"), lambda _b, ssid=str(network.get("ssid") or ""): self._delete_wifi(ssid), "danger-button", "edit-delete-symbolic"), False, False, 0)
        return row

    def _scan_wifi(self, _button=None) -> None:
        task_name = "wifi-settings-scan"
        if self._wifi_connection_busy:
            self._build_refs["wifi_status"].set_text(self._t("Bitte laufende WLAN-Verbindung abwarten …", "Please wait for the Wi-Fi connection …", "Počkejte na dokončení připojení Wi-Fi …"))
            return
        if task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["wifi_status"].set_text(self._t("WLAN-Suche läuft …", "Scanning Wi-Fi …", "Probíhá hledání Wi-Fi …"))
        self.run_async(task_name, self._scan_wifi_live_preserving_connection, self._wifi_scan_finished)

    def _wifi_scan_finished(self, result) -> None:
        self._refresh_tasks.discard("wifi-settings-scan")
        networks, message = result
        self._build_refs["wifi_status"].set_text(self._translate_status(message))
        self._refresh_wifi_saved_rows(networks)
        self.set_status(self._translate_status(message), "good" if networks else "warn")

    def _touch_keyboard(self, entry: Gtk.Entry) -> Gtk.Widget:
        revealer = Gtk.Revealer()
        grid = Gtk.Grid(row_spacing=3, column_spacing=3)
        keys = ("1234567890", "qwertzuiop", "asdfghjkl", "yxcvbnm")
        for row_index, row_keys in enumerate(keys):
            for column, key in enumerate(row_keys):
                button = Gtk.Button(label=key)
                button.set_size_request(42, 34)
                button.connect("clicked", lambda _b, value=key: self._entry_insert(entry, value))
                grid.attach(button, column, row_index, 1, 1)
        back = Gtk.Button(label="⌫")
        back.connect("clicked", lambda _b: self._entry_backspace(entry))
        grid.attach(back, 10, 0, 1, 2)
        specials = ("-", "_", ".", "@", "!", "?", "#", "+")
        for column, key in enumerate(specials):
            button = Gtk.Button(label=key)
            button.connect("clicked", lambda _b, value=key: self._entry_insert(entry, value))
            grid.attach(button, column, 4, 1, 1)
        revealer.add(grid)
        return revealer

    def _entry_backspace(self, entry: Gtk.Entry) -> None:
        position = entry.get_position()
        if position > 0:
            entry.delete_text(position - 1, position)

    def _entry_insert(self, entry: Gtk.Entry, value: str) -> None:
        position = entry.get_position()
        entry.insert_text(value, position)
        entry.set_position(position + len(value))

    def _password_dialog(self, ssid: str) -> str | None:
        dialog = Gtk.Dialog(title=self._t("WLAN verbinden", "Connect Wi-Fi", "Připojit Wi-Fi"), transient_for=self.window, modal=True)
        dialog.add_button(self._t("Abbrechen", "Cancel", "Zrušit"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self._t("Speichern + verbinden", "Save + connect", "Uložit + připojit"), Gtk.ResponseType.OK)
        content = dialog.get_content_area()
        content.set_spacing(8)
        content.set_margin_start(16)
        content.set_margin_end(16)
        content.pack_start(self._label(f"{self._t('Passwort für', 'Password for', 'Heslo pro')} {ssid}", "section-title"), False, False, 4)
        entry = Gtk.Entry()
        entry.set_visibility(False)
        entry.set_activates_default(True)
        content.pack_start(entry, False, False, 0)
        reveal_password = Gtk.CheckButton(label=self._t("Passwort anzeigen", "Show password", "Zobrazit heslo"))
        reveal_password.connect("toggled", lambda button: entry.set_visibility(button.get_active()))
        content.pack_start(reveal_password, False, False, 0)
        keyboard = self._touch_keyboard(entry)
        toggle = Gtk.ToggleButton(label=self._t("Bildschirmtastatur", "On-screen keyboard", "Klávesnice na obrazovce"))
        toggle.connect("toggled", lambda button: keyboard.set_reveal_child(button.get_active()))
        content.pack_start(toggle, False, False, 0)
        content.pack_start(keyboard, False, False, 0)
        dialog.set_default_response(Gtk.ResponseType.OK)
        dialog.show_all()
        keyboard.set_reveal_child(False)
        response = dialog.run()
        value = entry.get_text() if response == Gtk.ResponseType.OK else None
        dialog.destroy()
        return value

    def _connect_wifi(self, network: dict[str, str], saved: bool) -> None:
        if self._wifi_connection_busy:
            self.set_status(self._t("Bitte laufende WLAN-Verbindung abwarten.", "Please wait for the Wi-Fi connection.", "Počkejte na dokončení připojení Wi-Fi."), "warn")
            return
        ssid = str(network.get("ssid") or "").strip()
        security = self.core.normalize_wifi_security(network.get("security_mode") or network.get("security"))
        if not ssid:
            return
        if security == "OPEN":
            self.set_status(
                self._t(
                    "Offene WLANs werden in diesem Teststand noch nicht unterstützt.",
                    "Open Wi-Fi networks are not supported by this test build yet.",
                    "Otevřené sítě Wi-Fi zatím tato testovací verze nepodporuje.",
                ),
                "warn",
            )
            return
        saved_networks = {str(item.get("ssid") or ""): item for item in self.core.load_wifi_networks()}
        candidate = dict(saved_networks.get(ssid) or network)
        candidate.update({key: value for key, value in network.items() if value})
        if security != "OPEN" and not str(candidate.get("password") or ""):
            password = self._password_dialog(ssid)
            if password is None:
                return
            candidate["password"] = password
            self.core.save_wifi_network(ssid, password, security)
        elif not saved:
            self.core.save_wifi_network(ssid, "", security)
        self._build_refs["wifi_status"].set_text(f"{self._t('Verbinde', 'Connecting', 'Připojování')} {ssid} …")
        self._wifi_connection_busy = True

        def status(_state: str, message: str) -> None:
            GLib.idle_add(self._build_refs["wifi_status"].set_text, self._translate_status(message))

        def worker():
            result = self.core.connect_temporary_network(
                status,
                [],
                [candidate],
                require_internet=True,
                allow_active=False,
                allow_lan=False,
                cleanup_success=False,
            )
            if not result[0]:
                try:
                    result[2]()
                except Exception:
                    pass
            return result

        self.run_async(
            "wifi-connect",
            worker,
            lambda result: self._wifi_connect_finished(ssid, result),
        )

    def _wifi_connect_finished(self, ssid: str, result) -> None:
        ok, message, _cleanup = result
        self._wifi_connection_busy = False
        state = "good" if ok else "bad"
        self._wifi_connected_ssid = ssid if ok else ""
        self._build_refs["wifi_status"].set_text(self._translate_status(message))
        self._set_network_chip(f"{ssid} ✓" if ok else self._t("WLAN-Fehler", "Wi-Fi error", "Chyba Wi-Fi"), state)
        self.set_status(self._translate_status(message), state)
        popover: Gtk.Popover | None = self._build_refs.get("wifi_quick_popover")
        if popover is not None:
            popover.popdown()
        self._wifi_quick_networks = []
        self._refresh_wifi_saved_rows()
        if ok:
            GLib.timeout_add_seconds(2, lambda: self._schedule_auto_update_check(force=True))

    def _delete_wifi(self, ssid: str) -> None:
        if self.core.delete_wifi_network(ssid):
            self.set_status(f"{self._t('WLAN gelöscht', 'Wi-Fi deleted', 'Wi-Fi smazána')}: {ssid}", "good")
        self._wifi_quick_networks = []
        self._refresh_wifi_saved_rows()

    # ---------- printing ----------

    def _build_print_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Drucken", "Print", "Tisk"),
            self._t(
                "Den aktuellen Hardware-Report prüfen, speichern und direkt an den aktiven Drucker senden.",
                "Review, save and send the current hardware report directly to the active printer.",
                "Zkontrolujte, uložte a odešlete aktuální hardwarový report na aktivní tiskárnu.",
            ),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["print_status"] = self._label(self._t("Hardware wird geladen …", "Loading hardware …", "Načítání hardwaru …"), "status-chip")
        toolbar.pack_start(self._build_refs["print_status"], True, True, 0)
        toolbar.pack_end(
            self._button(
                self._t("Jetzt drucken", "Print now", "Vytisknout nyní"),
                self._print_current_report,
                "primary-button",
                "document-print-symbolic",
            ),
            False,
            False,
            0,
        )
        toolbar.pack_end(
            self._button(
                self._t("Report speichern", "Save report", "Uložit report"),
                self._save_current_report,
                "secondary-button",
                "document-save-symbolic",
            ),
            False,
            False,
            0,
        )
        toolbar.pack_end(
            self._button(
                self._t("Drucker auswählen", "Choose printer", "Vybrat tiskárnu"),
                lambda _b: self.show_page("printers"),
                "secondary-button",
                "printer-symbolic",
            ),
            False,
            False,
            0,
        )
        outer.pack_start(toolbar, False, False, 12)

        preview_frame = Gtk.Frame()
        preview_frame.set_shadow_type(Gtk.ShadowType.NONE)
        preview_frame.get_style_context().add_class("card")
        preview_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        preview_frame.add(preview_box)
        preview_box.pack_start(self._label(self._t("Druckvorschau", "Print preview", "Náhled tisku"), "section-title"), False, False, 0)
        preview = Gtk.TextView()
        preview.set_editable(False)
        preview.set_cursor_visible(False)
        preview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        preview_scroll = Gtk.ScrolledWindow()
        preview_scroll.set_min_content_height(430)
        preview_scroll.add(preview)
        preview_box.pack_start(preview_scroll, True, True, 0)
        outer.pack_start(preview_frame, True, True, 0)
        self._build_refs["print_preview"] = preview
        return page

    def _current_report_text(self) -> str:
        if not self.snapshot:
            return self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen.")
        matches = self.core.format_model_match_results(self.match_results, self.language, limit=6)
        return self.core.build_report(self.snapshot, matches, self.language)

    def _refresh_print_page(self) -> None:
        preview: Gtk.TextView | None = self._build_refs.get("print_preview")
        status: Gtk.Label | None = self._build_refs.get("print_status")
        if preview is not None:
            preview.get_buffer().set_text(self._current_report_text())
        task_name = "print-printer-status"
        if status is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        status.set_text(self._t("Aktiver Drucker wird geprüft …", "Checking active printer …", "Kontrola aktivní tiskárny …"))

        def worker():
            try:
                config, _path = self.core.load_printer_config()
                printer_name = str(config.get("printer_name") or config.get("name") or "").strip()
                printer_target = str(config.get("printer_uri") or config.get("raw_host") or config.get("printer_host") or "").strip()
                return printer_name, printer_target
            except Exception:
                return "", ""

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            printer_name, printer_target = result
            if printer_name or printer_target:
                status.set_text(f"{self._t('Aktiver Drucker', 'Active printer', 'Aktivní tiskárna')}: {printer_name or printer_target}")
                self._set_chip_state(status, "good")
            else:
                status.set_text(self._t("Noch kein aktiver Drucker gewählt", "No active printer selected", "Není vybrána aktivní tiskárna"))
                self._set_chip_state(status, "warn")

        self.run_async(task_name, worker, done)

    def _write_current_report(self, print_after: bool) -> None:
        if not self.snapshot:
            self.set_status(self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen."), "warn")
            return

        def worker():
            report = self._current_report_text()
            report_dir = self.core.get_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            target = report_dir / f"{self.core.report_basename(self.snapshot)}.txt"
            self.core.write_text_durable(target, report)
            if not print_after:
                return target, None

            def progress(_state: str, message: str) -> None:
                status: Gtk.Label | None = self._build_refs.get("print_status")
                if status is not None:
                    GLib.idle_add(status.set_text, self._translate_status(message))

            return target, self.core.run_report_print(target, progress)

        def done(result) -> None:
            target, print_result = result
            if print_result is None:
                message = f"{self._t('Report gespeichert', 'Report saved', 'Report uložen')}: {target.name}"
                self.set_status(message, "good")
                self._build_refs["print_status"].set_text(message)
            else:
                ok, message = print_result
                translated = self._translate_status(message)
                self.set_status(f"{translated} · {target.name}", "good" if ok else "bad")
                self._build_refs["print_status"].set_text(translated)

        self.run_async("current-report-print" if print_after else "current-report-save", worker, done)

    def _save_current_report(self, _button=None) -> None:
        self._write_current_report(False)

    def _print_current_report(self, _button=None) -> None:
        self._write_current_report(True)

    # ---------- printers ----------

    def _build_printers_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Drucker-Zentrale", "Printer centre", "Centrum tiskáren"),
            self._t("Gespeicherte Drucker sofort verwenden und neue IPP-/RAW-Drucker live finden.", "Use saved printers immediately and discover new IPP/RAW printers live.", "Okamžitě používejte uložené tiskárny a vyhledávejte nové tiskárny IPP/RAW."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._build_refs["printer_status"] = self._label(self._t("Bereit", "Ready", "Připraveno"), "status-chip")
        toolbar.pack_start(self._build_refs["printer_status"], True, True, 0)
        toolbar.pack_end(self._button(self._t("Testseite drucken", "Print test page", "Vytisknout testovací stránku"), self._print_test_report, "secondary-button", "document-print-symbolic"), False, False, 0)
        toolbar.pack_end(self._button(self._t("Drucker suchen", "Find printers", "Vyhledat tiskárny"), self._scan_printers, "primary-button", "system-search-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 12)

        panes = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        panes.set_position(520)
        outer.pack_start(panes, True, True, 4)
        saved_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        saved_box.pack_start(self._label(self._t("Gespeicherte Drucker", "Saved printers", "Uložené tiskárny"), "section-title"), False, False, 0)
        self._build_refs["printer_saved_list"] = Gtk.ListBox()
        self._build_refs["printer_saved_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        saved_scroll = Gtk.ScrolledWindow()
        saved_scroll.add(self._build_refs["printer_saved_list"])
        saved_box.pack_start(saved_scroll, True, True, 0)
        panes.pack1(saved_box, True, False)
        found_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        found_box.pack_start(self._label(self._t("Gefundene Drucker", "Discovered printers", "Nalezené tiskárny"), "section-title"), False, False, 0)
        self._build_refs["printer_found_list"] = Gtk.ListBox()
        self._build_refs["printer_found_list"].set_selection_mode(Gtk.SelectionMode.NONE)
        found_scroll = Gtk.ScrolledWindow()
        found_scroll.add(self._build_refs["printer_found_list"])
        found_box.pack_start(found_scroll, True, True, 0)
        panes.pack2(found_box, True, False)
        return page

    def _refresh_printer_profiles(self) -> None:
        listbox: Gtk.ListBox = self._build_refs.get("printer_saved_list")
        task_name = "printer-profiles"
        if listbox is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        self._build_refs["printer_status"].set_text(self._t("Druckerprofile werden geladen …", "Loading printer profiles …", "Načítání profilů tiskáren …"))

        def worker():
            try:
                profiles = self.core.load_printer_profiles()
                active_config, _path = self.core.load_printer_config()
                return profiles, self.core.printer_config_signature(active_config)
            except Exception:
                return [], ()

        def done(result) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_printer_profiles(result)

        self.run_async(task_name, worker, done)

    def _render_printer_profiles(self, result) -> None:
        profiles, active_signature = result
        listbox: Gtk.ListBox = self._build_refs.get("printer_saved_list")
        if listbox is None:
            return
        self._clear_listbox(listbox)
        if not profiles:
            row = Gtk.ListBoxRow()
            row.add(self._label(self._t("Noch kein Drucker gespeichert.", "No printer saved yet.", "Zatím není uložena žádná tiskárna."), "muted", wrap=True))
            listbox.add(row)
        for profile in profiles:
            config = self.core.printer_profile_config(profile)
            active = self.core.printer_config_signature(config) == active_signature
            row = Gtk.ListBoxRow()
            row.get_style_context().add_class("list-row")
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.add(box)
            box.pack_start(self._icon("printer-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
            text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            name = self.core.printer_profile_name(profile)
            text.pack_start(self._label(name, "section-title"), False, False, 0)
            host = config.get("raw_host") or config.get("printer_host") or config.get("printer_uri") or "–"
            text.pack_start(self._label(f"{_short(host, 54)} · {self._t('aktiv', 'active', 'aktivní') if active else self._t('gespeichert', 'saved', 'uloženo')}", "good-text" if active else "muted"), False, False, 0)
            box.pack_start(text, True, True, 0)
            box.pack_end(self._button(self._t("Aktivieren", "Activate", "Aktivovat"), lambda _b, item=profile: self._activate_printer_profile(item), "primary-button"), False, False, 0)
            box.pack_end(self._button(self._t("Löschen", "Delete", "Smazat"), lambda _b, item=profile: self._delete_printer_profile(item), "danger-button"), False, False, 0)
            listbox.add(row)
        listbox.show_all()
        self._build_refs["printer_status"].set_text(
            self._t(f"{len(profiles)} Drucker gespeichert", f"{len(profiles)} printers saved", f"Uloženo tiskáren: {len(profiles)}")
        )

    def _activate_printer_profile(self, profile: dict[str, object]) -> None:
        try:
            self.core.save_active_printer_profile(profile, manual_selected=True)
            name = self.core.printer_profile_name(profile)
            self.set_status(f"{self._t('Aktiver Drucker', 'Active printer', 'Aktivní tiskárna')}: {name}", "good")
            self._build_refs["printer_status"].set_text(name)
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _delete_printer_profile(self, profile: dict[str, object]) -> None:
        profile_id = str(profile.get("id") or "")
        profiles = [item for item in self.core.load_printer_profiles() if str(item.get("id") or "") != profile_id]
        try:
            self.core.save_printer_profiles(profiles)
            self.set_status(self._t("Druckerprofil gelöscht.", "Printer profile deleted.", "Profil tiskárny smazán."), "good")
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _scan_printers(self, _button=None) -> None:
        self._printer_results = []
        found_list: Gtk.ListBox = self._build_refs["printer_found_list"]
        self._clear_listbox(found_list)
        self._build_refs["printer_status"].set_text(self._t("Druckersuche läuft …", "Printer discovery running …", "Probíhá hledání tiskáren …"))

        def status(_state: str, message: str) -> None:
            GLib.idle_add(self._build_refs["printer_status"].set_text, self._translate_status(message))

        def found(printer: dict[str, object]) -> None:
            GLib.idle_add(self._add_found_printer, printer)

        self.run_async("printer-scan", lambda: self.core.discover_network_printers(status, found), self._printer_scan_finished)

    def _add_found_printer(self, printer: dict[str, object]) -> bool:
        if any(str(item.get("host")) == str(printer.get("host")) for item in self._printer_results):
            return False
        self._printer_results.append(printer)
        row = Gtk.ListBoxRow()
        row.get_style_context().add_class("list-row")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.add(box)
        box.pack_start(self._icon("printer-network-symbolic", Gtk.IconSize.LARGE_TOOLBAR), False, False, 0)
        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.pack_start(self._label(_clean(printer.get("name")), "section-title"), False, False, 0)
        text.pack_start(self._label(f"{_clean(printer.get('host'))} · {_clean(printer.get('method'))} · {_clean(printer.get('ports'))}", "muted", wrap=True), False, False, 0)
        box.pack_start(text, True, True, 0)
        box.pack_end(self._button(self._t("Speichern + aktivieren", "Save + activate", "Uložit + aktivovat"), lambda _b, item=printer: self._save_discovered_printer(item), "primary-button"), False, False, 0)
        self._build_refs["printer_found_list"].add(row)
        self._build_refs["printer_found_list"].show_all()
        return False

    def _printer_scan_finished(self, result) -> None:
        found, message = result
        for printer in found:
            self._add_found_printer(printer)
        self._build_refs["printer_status"].set_text(self._translate_status(message))
        self.set_status(self._translate_status(message), "good" if found else "warn")

    def _save_discovered_printer(self, printer: dict[str, object]) -> None:
        try:
            profile = self.core.discovered_printer_profile(printer)
            self.core.upsert_printer_profile(profile)
            self.core.save_active_printer_profile(profile, manual_selected=True)
            self.set_status(f"{self._t('Drucker gespeichert', 'Printer saved', 'Tiskárna uložena')}: {self.core.printer_profile_name(profile)}", "good")
        except OSError as exc:
            self.set_status(str(exc), "bad")
        self._refresh_printer_profiles()

    def _print_test_report(self, _button=None) -> None:
        if not self.snapshot:
            self.set_status(self._t("Hardware-Scan noch nicht abgeschlossen.", "Hardware scan has not finished yet.", "Sken hardwaru ještě není dokončen."), "warn")
            return

        def worker():
            matches = self.core.format_model_match_results(self.match_results, self.language, limit=6)
            report = self.core.build_report(self.snapshot, matches, self.language)
            report_dir = self.core.get_report_dir()
            report_dir.mkdir(parents=True, exist_ok=True)
            target = report_dir / f"{self.core.report_basename(self.snapshot)}_v5-testprint.txt"
            self.core.write_text_durable(target, report)
            return target, self.core.run_report_print(target, lambda state, message: GLib.idle_add(self._build_refs["printer_status"].set_text, self._translate_status(message)))

        self.run_async("test-print", worker, self._print_finished)

    def _print_finished(self, result) -> None:
        target, (ok, message) = result
        self.set_status(f"{self._translate_status(message)} · {target.name}", "good" if ok else "bad")
        self._build_refs["printer_status"].set_text(self._translate_status(message))

    # ---------- reports ----------

    def _build_reports_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Report-Center", "Report centre", "Centrum reportů"),
            self._t("Modell- und Akku-Reports zentral öffnen, prüfen und drucken.", "Open, inspect and print model and battery reports in one place.", "Otevírejte, kontrolujte a tiskněte reporty modelů a baterie na jednom místě."),
        )
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        toolbar.pack_end(self._button(self._t("Aktualisieren", "Refresh", "Obnovit"), lambda _b: self._refresh_reports(), "secondary-button", "view-refresh-symbolic"), False, False, 0)
        toolbar.pack_end(self._button(self._t("Ausgewählten Report drucken", "Print selected report", "Vytisknout vybraný report"), self._print_selected_report, "primary-button", "document-print-symbolic"), False, False, 0)
        outer.pack_start(toolbar, False, False, 10)
        panes = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        panes.set_position(430)
        outer.pack_start(panes, True, True, 0)
        store = Gtk.ListStore(str, str, str, object)
        tree = Gtk.TreeView(model=store)
        tree.get_selection().connect("changed", self._report_selection_changed)
        for title, index, width in ((self._t("Typ", "Type", "Typ"), 0, 90), (self._t("Datei", "File", "Soubor"), 1, 230), (self._t("Datum", "Date", "Datum"), 2, 130)):
            renderer = Gtk.CellRendererText()
            renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
            column = Gtk.TreeViewColumn(title, renderer, text=index)
            column.set_min_width(width)
            column.set_resizable(True)
            tree.append_column(column)
        report_scroll = Gtk.ScrolledWindow()
        report_scroll.add(tree)
        panes.pack1(report_scroll, True, False)
        preview = Gtk.TextView()
        preview.set_editable(False)
        preview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        preview_scroll = Gtk.ScrolledWindow()
        preview_scroll.add(preview)
        panes.pack2(preview_scroll, True, False)
        self._build_refs["report_store"] = store
        self._build_refs["report_tree"] = tree
        self._build_refs["report_preview"] = preview
        return page

    def _refresh_reports(self) -> None:
        store: Gtk.ListStore = self._build_refs.get("report_store")
        task_name = "reports"
        if store is None or task_name in self._refresh_tasks:
            return
        self._refresh_tasks.add(task_name)
        store.clear()
        self.set_status(self._t("Reports werden geladen …", "Loading reports …", "Načítání reportů …"), "info")

        def worker():
            paths: list[tuple[str, pathlib.Path]] = []
            try:
                report_dir = self.core.get_report_dir()
                paths.extend((self._t("Modell", "Model", "Model"), path) for path in report_dir.glob("*.txt"))
            except OSError:
                pass
            try:
                paths.extend((self._t("Akku", "Battery", "Baterie"), path) for path in self.core.list_battery_report_files())
            except OSError:
                pass
            unique: dict[str, tuple[str, pathlib.Path]] = {}
            for report_type, path in paths:
                unique[str(path)] = (report_type, path)
            return sorted(unique.values(), key=lambda pair: pair[1].stat().st_mtime if pair[1].exists() else 0, reverse=True)

        def done(paths) -> None:
            self._refresh_tasks.discard(task_name)
            self._render_reports(paths)

        self.run_async(task_name, worker, done)

    def _render_reports(self, paths: list[tuple[str, pathlib.Path]]) -> None:
        store: Gtk.ListStore = self._build_refs.get("report_store")
        if store is None:
            return
        store.clear()
        for report_type, path in paths:
            try:
                stamp = datetime.datetime.fromtimestamp(path.stat().st_mtime).strftime("%d.%m.%Y %H:%M")
            except OSError:
                stamp = "–"
            store.append([report_type, path.name, stamp, path])
        self.set_status(self._t(f"{len(paths)} Reports geladen.", f"{len(paths)} reports loaded.", f"Načtené reporty: {len(paths)}."), "good")

    def _selected_report_path(self) -> pathlib.Path | None:
        tree: Gtk.TreeView = self._build_refs["report_tree"]
        model, iterator = tree.get_selection().get_selected()
        return model[iterator][3] if iterator is not None else None

    def _report_selection_changed(self, _selection) -> None:
        path = self._selected_report_path()
        if path is None:
            return
        try:
            preview_path = self.core.report_print_source_path(path)
            if preview_path != path:
                text = preview_path.read_text(encoding="utf-8", errors="replace")
            elif path.suffix.lower() == ".html":
                text = self.core.battery_report_preview_text(path, 120)
            else:
                text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            text = str(exc)
        self._build_refs["report_preview"].get_buffer().set_text(text)

    def _print_selected_report(self, _button=None) -> None:
        path = self._selected_report_path()
        if path is None:
            self.set_status(self._t("Bitte einen Report auswählen.", "Please select a report.", "Vyberte report."), "warn")
            return
        self.run_async("report-print", lambda: self.core.run_report_print(path), lambda result: self.set_status(self._translate_status(result[1]), "good" if result[0] else "bad"))

    # ---------- updates ----------

    def _open_update_settings(self, _button=None) -> None:
        self.show_page("settings")

    def _update_widgets(self) -> list[Gtk.Widget]:
        widgets: list[Gtk.Widget] = []
        for candidate in (
            self._build_refs.get("update_alert_button"),
        ):
            if isinstance(candidate, Gtk.Widget):
                widgets.append(candidate)
        return widgets

    def _clear_update_phase_classes(self) -> None:
        for widget in self._update_widgets():
            context = widget.get_style_context()
            for css_class in self.UPDATE_PHASE_CLASSES:
                context.remove_class(css_class)

    def _update_alert_tick(self) -> bool:
        if not (self._db_update_available or self._program_update_available):
            self._clear_update_phase_classes()
            self._update_alert_timer_id = None
            return False
        self._clear_update_phase_classes()
        css_class = self.UPDATE_PHASE_CLASSES[self._update_alert_phase % len(self.UPDATE_PHASE_CLASSES)]
        self._update_alert_phase += 1
        for widget in self._update_widgets():
            widget.get_style_context().add_class(css_class)
        return True

    def _refresh_update_alert(self) -> None:
        button: Gtk.Button | None = self._build_refs.get("update_alert_button")
        label: Gtk.Label | None = self._build_refs.get("update_alert_label")
        available = self._db_update_available or self._program_update_available
        if not available:
            if self._update_alert_timer_id is not None:
                try:
                    GLib.source_remove(self._update_alert_timer_id)
                except Exception:
                    pass
                self._update_alert_timer_id = None
            self._clear_update_phase_classes()
            if button is not None:
                button.hide()
            return

        parts: list[str] = []
        if self._db_update_available:
            parts.append("DB")
        if self._program_update_available:
            parts.append(self._t("PROGRAMM", "APP", "PROGRAM"))
        if label is not None:
            label.set_text(
                self._t("UPDATE VERFÜGBAR", "UPDATE AVAILABLE", "AKTUALIZACE K DISPOZICI")
                + ": "
                + " + ".join(parts)
            )
        if button is not None:
            child = button.get_child()
            if child is not None:
                child.show_all()
            button.show()
        if self._update_alert_timer_id is None:
            self._update_alert_phase = 0
            self._update_alert_tick()
            self._update_alert_timer_id = GLib.timeout_add(650, self._update_alert_tick)

    def _set_update_availability(self, db_available: bool | None = None, program_available: bool | None = None) -> None:
        if db_available is not None:
            self._db_update_available = bool(db_available)
        if program_available is not None:
            self._program_update_available = bool(program_available)
        self._refresh_update_alert()

    def _set_update_controls_busy(self, busy: bool) -> None:
        for key in ("db_update_button", "program_update_button", "updates_check_button"):
            button: Gtk.Button | None = self._build_refs.get(key)
            if button is not None:
                button.set_sensitive(not busy)

    def _set_update_progress(self, message: str) -> bool:
        if self._update_progress_determinate:
            return False
        translated = self._translate_status(message)
        label: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if label is not None:
            label.set_text(translated)
        return False

    def _set_update_percentage(self, kind: str, percent: int, message: str) -> bool:
        value = max(0, min(100, int(percent)))
        translated = self._translate_status(message)
        progress: Gtk.ProgressBar | None = self._build_refs.get(f"{kind}_update_progress")
        if progress is not None:
            progress.set_fraction(value / 100.0)
            progress.set_text(f"{value}%")
            progress.show()
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if overall is not None:
            overall.set_text(f"{translated} · {value}%")
        footer: Gtk.ProgressBar | None = self._build_refs.get("footer_progress")
        if footer is not None:
            footer.set_fraction(value / 100.0)
            footer.set_text(f"{value}%")
            footer.show()
        return False

    def _begin_update_percentage(self, kind: str, message: str) -> None:
        self._update_progress_determinate = True
        self._set_update_percentage(kind, 0, message)

    def _finish_update_percentage(self, kind: str, ok: bool, message: str) -> None:
        translated = self._translate_status(message)
        progress: Gtk.ProgressBar | None = self._build_refs.get(f"{kind}_update_progress")
        if progress is not None:
            if ok:
                progress.set_fraction(1.0)
                progress.set_text("100%")
            else:
                progress.set_text(self._t("Fehler", "Error", "Chyba"))
            progress.show()
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if overall is not None:
            overall.set_text(translated)
        self._update_progress_determinate = False

    def _schedule_auto_update_check(self, force: bool = False) -> bool:
        if self._auto_update_check_started and not force:
            return False
        if self._update_operation:
            return False
        self._auto_update_check_started = True
        self._check_updates(auto=True)
        return False

    def _manual_check_updates_clicked(self, _button=None) -> None:
        self._auto_update_check_started = True
        self._check_updates(auto=False)

    def _toggle_update_alert_demo(self, _button=None) -> None:
        self._update_alert_demo = not self._update_alert_demo
        if self._update_alert_demo:
            db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
            program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
            overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
            demo_text = self._t("TESTANZEIGE – DB- und Programmupdate verfügbar", "TEST DISPLAY – DB and application update available", "TESTOVACÍ ZOBRAZENÍ – aktualizace DB a programu je k dispozici")
            if db_label is not None:
                db_label.set_text(self._t("TEST: DB-Update verfügbar", "TEST: DB update available", "TEST: aktualizace DB je k dispozici"))
                self._set_chip_state(db_label, "warn")
            if program_label is not None:
                program_label.set_text(self._t("TEST: Programm-Update verfügbar", "TEST: application update available", "TEST: aktualizace programu je k dispozici"))
                self._set_chip_state(program_label, "warn")
            if overall is not None:
                overall.set_text(demo_text)
            self._set_update_availability(True, True)
            self.set_status(demo_text, "warn")
            return
        self._set_update_availability(False, False)
        self._set_update_progress(self._t("Testanzeige beendet. Jetzt erneut prüfen.", "Test display stopped. Check again now.", "Testovací zobrazení ukončeno. Nyní proveďte novou kontrolu."))

    def _check_updates(self, auto: bool) -> None:
        if self._update_operation:
            if not auto:
                self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "check"
        self._set_update_controls_busy(True)
        self._set_update_progress(self._t("DB und Programm werden geprüft …", "Checking DB and application …", "Kontrola DB a programu …"))
        if not auto:
            self.set_status(self._t("Updates werden geprüft …", "Checking for updates …", "Kontrola aktualizací …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def worker():
            db_ok, db_message, db_available = self.core.check_model_database_update_available(progress)
            app_ok, app_message, app_available = self.core.check_hardwarecheck_update_available(progress)
            return db_ok, db_message, db_available, app_ok, app_message, app_available

        self.run_async("updates-check", worker, self._update_check_finished)

    def _update_check_finished(self, result) -> None:
        db_ok, db_message, db_available, app_ok, app_message, app_available = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        self._set_update_availability(db_available, app_available)
        db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
        program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
        overall: Gtk.Label | None = self._build_refs.get("updates_overall_status")
        if db_label is not None:
            db_label.set_text(self._translate_status(db_message))
            self._set_chip_state(db_label, "warn" if db_available else "good" if db_ok else "bad")
        if program_label is not None:
            program_label.set_text(self._translate_status(app_message))
            self._set_chip_state(program_label, "warn" if app_available else "good" if app_ok else "bad")
        messages = [message for message, available in ((db_message, db_available), (app_message, app_available)) if available]
        if messages:
            text = " | ".join(self._translate_status(message) for message in messages)
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "warn")
        elif db_ok and app_ok:
            text = self._t("DB und Programm sind aktuell.", "DB and application are current.", "DB a program jsou aktuální.")
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "good")
        else:
            text = f"{self._translate_status(db_message)} | {self._translate_status(app_message)}"
            if overall is not None:
                overall.set_text(text)
            self.set_status(text, "bad")

    def _db_update_clicked(self, _button=None) -> None:
        if self._update_operation:
            self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "db"
        self._set_update_controls_busy(True)
        self._begin_update_percentage("db", self._t("DB-Update wird vorbereitet …", "Preparing DB update …", "Příprava aktualizace DB …"))
        self.set_status(self._t("DB-Update: verbinde …", "DB update: connecting …", "Aktualizace DB: připojování …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def percentage(percent: int, message: str) -> None:
            GLib.idle_add(self._set_update_percentage, "db", percent, message)

        def worker():
            ok, message = self.core.run_model_database_update(progress, percentage)
            if not ok:
                return ok, message, None
            models = config_server_sync.merge_model_overrides(
                self.core.load_model_db(), self._magic_config_server_root()
            )
            manifest = self.core.load_local_model_manifest()
            matches = self.core.get_model_match_results(self.snapshot, models) if self.snapshot else []
            relations = self.core.build_model_relation_map(models)
            return ok, message, (models, manifest, matches, relations)

        self.run_async("db-update", worker, self._db_update_finished)

    def _db_update_finished(self, result) -> None:
        ok, message, refreshed = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        db_label: Gtk.Label | None = self._build_refs.get("db_update_status")
        if db_label is not None:
            db_label.set_text(self._translate_status(message))
            self._set_chip_state(db_label, "good" if ok else "bad")
        self._finish_update_percentage("db", ok, message)
        if ok and refreshed is not None:
            self.models, manifest, self.match_results, self._model_relation_map = refreshed
            version = self.core.format_database_version(str(manifest.get("version") or ""))
            count = manifest.get("models_count") or manifest.get("model_count") or len(self.models)
            db_chip: Gtk.Label | None = self._build_refs.get("db_chip")
            if db_chip is not None:
                db_chip.set_text(f"DB {version or '–'} · {count}")
                self._set_chip_state(db_chip, "good")
            self._render_dashboard_model_suggestions()
            self._refresh_model_table()
            self._set_update_availability(db_available=False)
        self.set_status(self._translate_status(message), "good" if ok else "bad")

    def _program_update_clicked(self, _button=None) -> None:
        if self._update_operation:
            self.set_status(self._t("Ein Update-Vorgang läuft bereits.", "An update operation is already running.", "Aktualizace již probíhá."), "warn")
            return
        self._update_alert_demo = False
        self._update_operation = "program"
        self._set_update_controls_busy(True)
        self._begin_update_percentage("program", self._t("Programm-Update wird vorbereitet …", "Preparing application update …", "Příprava aktualizace programu …"))
        self.set_status(self._t("Programm-Update: verbinde …", "App update: connecting …", "Aktualizace programu: připojování …"), "info")

        def progress(_state: str, message: str) -> None:
            GLib.idle_add(self._set_update_progress, message)

        def percentage(percent: int, message: str) -> None:
            GLib.idle_add(self._set_update_percentage, "program", percent, message)

        self.run_async(
            "program-update",
            lambda: self.core.run_hardwarecheck_update_check(progress, percentage),
            self._program_update_finished,
        )

    def _program_update_finished(self, result) -> None:
        ok, message, install_request = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        program_label: Gtk.Label | None = self._build_refs.get("program_update_status")
        if program_label is not None:
            program_label.set_text(self._translate_status(message))
            self._set_chip_state(program_label, "warn" if install_request else "good" if ok else "bad")
        self._finish_update_percentage("program", ok, message)
        self._set_update_availability(program_available=bool(install_request))
        self.set_status(self._translate_status(message), "warn" if install_request else "good" if ok else "bad")
        if ok and install_request:
            self._show_program_update_prompt(install_request)

    def _show_program_update_prompt(self, install_request: dict[str, str]) -> None:
        target_version = str(install_request.get("target_version") or "?")
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=self._t("Programm-Update bereit", "Application update ready", "Aktualizace programu je připravena"),
        )
        dialog.format_secondary_text(
            self._t(
                f"Version {target_version} wurde heruntergeladen, per SHA256 geprüft und kann jetzt installiert werden.",
                f"Version {target_version} was downloaded, verified with SHA256 and can now be installed.",
                f"Verze {target_version} byla stažena, ověřena pomocí SHA256 a nyní ji lze nainstalovat.",
            )
        )
        dialog.add_button(self._t("Später", "Later", "Později"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self._t("Jetzt installieren", "Install now", "Nainstalovat nyní"), Gtk.ResponseType.OK)
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.OK:
            self._start_program_update_install(install_request)

    def _start_program_update_install(self, install_request: dict[str, str]) -> None:
        config_path = pathlib.Path(str(install_request.get("config_path") or ""))
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            self.set_status(f"{self._t('Programm-Update: Installer-Konfiguration fehlt', 'App update: installer configuration is missing', 'Aktualizace programu: chybí konfigurace instalátoru')}: {exc}", "bad")
            return
        if not isinstance(config, dict):
            self.set_status(self._t("Programm-Update: ungültige Installer-Konfiguration", "App update: invalid installer configuration", "Aktualizace programu: neplatná konfigurace instalátoru"), "bad")
            return

        dialog = Gtk.Dialog(
            title=self._t("Programm-Update", "Application update", "Aktualizace programu"),
            transient_for=self.window,
            flags=Gtk.DialogFlags.MODAL,
        )
        dialog.set_deletable(False)
        dialog.set_default_size(640, 240)
        content = dialog.get_content_area()
        content.set_spacing(14)
        content.set_margin_start(24)
        content.set_margin_end(24)
        content.set_margin_top(22)
        content.set_margin_bottom(18)
        title = self._label(self._t("HardwareCheck wird aktualisiert", "Updating HardwareCheck", "Aktualizace HardwareCheck"), "hero-title")
        detail = self._label(self._t("Vorbereitung …", "Preparing …", "Příprava …"), wrap=True)
        progress_bar = Gtk.ProgressBar()
        progress_bar.set_show_text(True)
        close_button = dialog.add_button(self._t("Schließen", "Close", "Zavřít"), Gtk.ResponseType.CLOSE)
        close_button.set_no_show_all(True)
        close_button.hide()
        content.pack_start(title, False, False, 0)
        content.pack_start(detail, False, False, 0)
        content.pack_start(progress_bar, False, False, 0)
        dialog.connect("response", lambda current, _response: current.destroy())
        dialog.show_all()
        close_button.hide()

        self._update_operation = "program-install"
        self._set_update_controls_busy(True)
        self._begin_update_percentage(
            "program",
            self._t("Programm-Update wird installiert …", "Installing application update …", "Instalace aktualizace programu …"),
        )

        def progress(percent: int, message: str) -> None:
            GLib.idle_add(self._program_install_progress, progress_bar, detail, percent, message)

        def worker():
            try:
                app_path = self.core.apply_hardwarecheck_update(config, progress)
                return True, str(app_path), ""
            except Exception as exc:
                return False, str(exc), traceback.format_exc()

        self.run_async(
            "program-install",
            worker,
            lambda result: self._program_install_finished(dialog, detail, progress_bar, close_button, result),
        )

    def _program_install_progress(self, progress_bar: Gtk.ProgressBar, detail: Gtk.Label, percent: int, message: str) -> bool:
        value = max(0, min(100, int(percent)))
        detail.set_text(self._translate_status(message))
        progress_bar.set_fraction(value / 100.0)
        progress_bar.set_text(f"{value}%")
        self._set_update_percentage("program", value, message)
        self.set_status(f"{self._t('Programm-Update', 'App update', 'Aktualizace programu')}: {self._translate_status(message)}", "info")
        return False

    def _program_install_finished(
        self,
        dialog: Gtk.Dialog,
        detail: Gtk.Label,
        progress_bar: Gtk.ProgressBar,
        close_button: Gtk.Button,
        result,
    ) -> None:
        ok, value, error_detail = result
        self._update_operation = ""
        self._set_update_controls_busy(False)
        if ok:
            detail.set_text(self._t("Update erfolgreich. HardwareCheck wird neu gestartet …", "Update successful. Restarting HardwareCheck …", "Aktualizace byla úspěšná. HardwareCheck se restartuje …"))
            progress_bar.set_fraction(1.0)
            progress_bar.set_text("100%")
            self._finish_update_percentage("program", True, self._t("Programm-Update erfolgreich", "Application update successful", "Aktualizace programu byla úspěšná"))
            self._set_update_availability(program_available=False)
            self.set_status(self._t("Programm-Update erfolgreich – Neustart …", "Application update successful – restarting …", "Aktualizace programu byla úspěšná – restart …"), "good")
            GLib.timeout_add(900, self._restart_after_program_update, value)
            return

        detail.set_text(f"{self._t('Programm-Update fehlgeschlagen', 'Application update failed', 'Aktualizace programu se nezdařila')}: {value}")
        progress_bar.set_fraction(1.0)
        progress_bar.set_text("!")
        self._finish_update_percentage("program", False, str(value))
        close_button.show()
        self.set_status(f"{self._t('Programm-Update fehlgeschlagen', 'Application update failed', 'Aktualizace programu se nezdařila')}: {value}", "bad")
        try:
            debug_root = self.core.find_external_root() or self.core.SCRIPT_DIR
            debug_dir = pathlib.Path(debug_root) / "hardwarecheck-debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            self.core.write_text_durable(debug_dir / "v5-program-install-error.txt", error_detail)
        except Exception:
            pass

    def _restart_after_program_update(self, app_path: str) -> bool:
        self._save_battery_state()
        env = os.environ.copy()
        env.pop("HC_USE_LEGACY_UI", None)
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(app_path).resolve())], env)
        return False

    # ---------- settings ----------

    def _build_settings_page(self) -> Gtk.Widget:
        page, outer = self._page_shell(
            self._t("Einstellungen", "Settings", "Nastavení"),
            self._t("Updates, WLAN, Drucker, Sprache, Diagnose und Informationen zu HardwareCheck.", "Updates, Wi-Fi, printers, language, diagnostics and HardwareCheck information.", "Aktualizace, Wi-Fi, tiskárny, jazyk, diagnostika a informace o HardwareCheck."),
        )

        appearance = self._section(outer, self._t("Darstellung", "Appearance", "Vzhled"), 12)
        appearance_card = Gtk.Frame()
        appearance_card.set_shadow_type(Gtk.ShadowType.NONE)
        appearance_card.get_style_context().add_class("card")
        appearance_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        appearance_card.add(appearance_box)
        appearance.pack_start(appearance_card, False, False, 0)
        appearance_box.pack_start(
            self._label(
                self._t(
                    "Das gewählte Design gilt für Übersicht, ModelFinder, Akku-Test, Drucken, Reports und Einstellungen.",
                    "The selected design applies to Overview, ModelFinder, Battery test, Printing, Reports and Settings.",
                    "Zvolený vzhled platí pro Přehled, ModelFinder, Test baterie, Tisk, Reporty a Nastavení.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        appearance_box.pack_start(self._label(self._t("Oberfläche", "Interface", "Rozhraní"), "section-title"), False, False, 2)
        layout_flow = Gtk.FlowBox()
        layout_flow.set_selection_mode(Gtk.SelectionMode.NONE)
        layout_flow.set_homogeneous(True)
        layout_flow.set_min_children_per_line(2)
        layout_flow.set_max_children_per_line(4)
        layout_flow.set_row_spacing(8)
        layout_flow.set_column_spacing(8)
        layout_names = {
            "original": self._t("Original", "Original", "Original"),
            "service-light": self._t("Service Light", "Service Light", "Service Light"),
            "workshop-pro": self._t("Werkstatt Pro", "Workshop Pro", "Workshop Pro"),
            "blue-control": self._t("Blue Control", "Blue Control", "Blue Control"),
            "service-desk": self._t("Service Desk", "Service Desk", "Service Desk"),
            "workshop-console": self._t("Werkstatt-Konsole", "Workshop Console", "Workshop Console"),
            "studio-panels": self._t("Studio Panels", "Studio Panels", "Studio Panels"),
        }
        layout_icons = {
            "original": "view-grid-symbolic",
            "service-light": "weather-clear-symbolic",
            "workshop-pro": "applications-engineering-symbolic",
            "blue-control": "preferences-desktop-theme-symbolic",
            "service-desk": "view-list-symbolic",
            "workshop-console": "utilities-terminal-symbolic",
            "studio-panels": "view-grid-symbolic",
        }
        for layout_name in APPEARANCE_LAYOUTS:
            button = self._button(
                layout_names[layout_name],
                lambda _button, target=layout_name: self._select_appearance_layout(target),
                "secondary-button",
                layout_icons[layout_name],
            )
            button.get_style_context().add_class("appearance-option")
            if layout_name == self.appearance_layout:
                button.get_style_context().add_class("active")
            layout_flow.add(button)
            self._build_refs[f"appearance_layout_{layout_name}"] = button
        appearance_box.pack_start(layout_flow, False, False, 0)

        appearance_box.pack_start(self._label(self._t("Akzentfarbe", "Accent colour", "Barva zvýraznění"), "section-title"), False, False, 4)
        accent_flow = Gtk.FlowBox()
        accent_flow.set_selection_mode(Gtk.SelectionMode.NONE)
        accent_flow.set_homogeneous(True)
        accent_flow.set_min_children_per_line(3)
        accent_flow.set_max_children_per_line(6)
        accent_flow.set_row_spacing(7)
        accent_flow.set_column_spacing(7)
        accent_names = {
            "gold": self._t("Gold", "Gold", "Zlatá"),
            "teal": self._t("Türkis", "Teal", "Tyrkysová"),
            "blue": self._t("Blau", "Blue", "Modrá"),
            "violet": self._t("Violett", "Violet", "Fialová"),
            "green": self._t("Grün", "Green", "Zelená"),
            "red": self._t("Rot", "Red", "Červená"),
        }
        for accent_name, accent_color in APPEARANCE_ACCENTS:
            button = self._button(
                accent_names[accent_name],
                lambda _button, target=accent_color: self._select_appearance_accent(target),
                "secondary-button",
            )
            context = button.get_style_context()
            context.add_class("accent-choice")
            context.add_class(f"accent-{accent_name}")
            if self.appearance_accent.lower() == accent_color.lower():
                context.add_class("active")
            accent_flow.add(button)
        appearance_box.pack_start(accent_flow, False, False, 0)

        custom_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        custom_row.pack_start(
            self._label(self._t("Eigene Farbe", "Custom colour", "Vlastní barva"), "card-title"),
            False,
            False,
            0,
        )
        custom_color = Gtk.ColorButton()
        custom_color.set_use_alpha(False)
        custom_color.set_title(self._t("Akzentfarbe wählen", "Choose accent colour", "Zvolit barvu zvýraznění"))
        current_rgba = Gdk.RGBA()
        current_rgba.parse(self.appearance_accent)
        custom_color.set_rgba(current_rgba)
        custom_color.connect("color-set", self._custom_appearance_accent_changed)
        custom_row.pack_start(custom_color, False, False, 0)
        appearance_box.pack_start(custom_row, False, False, 0)

        workshop_mode = self._section(outer, self._t("Arbeitsmodus", "Work mode", "Pracovní režim"), 12)
        workshop_card = Gtk.Frame()
        workshop_card.set_shadow_type(Gtk.ShadowType.NONE)
        workshop_card.get_style_context().add_class("card")
        workshop_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        workshop_card.add(workshop_box)
        workshop_mode.pack_start(workshop_card, False, False, 0)
        workshop_box.pack_start(
            self._label(
                self._t(
                    "Für den nächsten Start auswählen. Der Wechsel startet das Programm nicht sofort neu.",
                    "Choose the application for the next launch. Switching does not restart the program immediately.",
                    "Vyberte aplikaci pro příští spuštění. Přepnutí program ihned nerestartuje.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        workshop_buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        available_modes = [("hardwarecheck", self._t("HardwareCheck", "HardwareCheck", "HardwareCheck"), "computer-symbolic")]
        if self._magic_image_available():
            available_modes.insert(0, ("magic", self._t("Magic Image", "Magic Image", "Magic Image"), "media-optical-symbolic"))
        active_mode = self._workshop_start_mode()
        for mode, label, icon in available_modes:
            button = self._button(
                label,
                lambda _button, target=mode: self._select_workshop_start_mode(target),
                "primary-button" if active_mode == mode else "secondary-button",
                icon,
            )
            workshop_buttons.pack_start(button, False, False, 0)
        workshop_box.pack_start(workshop_buttons, False, False, 0)

        updates = self._section(outer, self._t("Updates", "Updates", "Aktualizace"), 12)
        update_card = Gtk.Frame()
        update_card.set_shadow_type(Gtk.ShadowType.NONE)
        update_card.get_style_context().add_class("card")
        update_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        update_card.add(update_box)
        updates.pack_start(update_card, False, False, 0)
        self._build_refs["updates_overall_status"] = self._label(
            self._t(
                "Automatische Prüfung nach der WLAN-Verbindung.",
                "Automatic check after the Wi-Fi connection.",
                "Automatická kontrola po připojení k Wi-Fi.",
            ),
            "muted",
            wrap=True,
        )
        update_box.pack_start(self._build_refs["updates_overall_status"], False, False, 0)

        db_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        db_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        db_text.pack_start(self._label(self._t("Modelldatenbank", "Model database", "Databáze modelů"), "section-title"), False, False, 0)
        self._build_refs["db_update_status"] = self._label(self._t("Noch nicht geprüft", "Not checked yet", "Dosud nekontrolováno"), "status-chip", wrap=True)
        db_text.pack_start(self._build_refs["db_update_status"], False, False, 0)
        db_progress = Gtk.ProgressBar()
        db_progress.set_show_text(True)
        db_progress.set_no_show_all(True)
        db_progress.hide()
        db_text.pack_start(db_progress, False, False, 4)
        self._build_refs["db_update_progress"] = db_progress
        db_row.pack_start(db_text, True, True, 0)
        db_button = self._button(self._t("DB-Update", "DB update", "Aktualizace DB"), self._db_update_clicked, "primary-button", "view-refresh-symbolic")
        db_row.pack_end(db_button, False, False, 0)
        self._build_refs["db_update_button"] = db_button
        update_box.pack_start(db_row, False, False, 0)

        program_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        program_text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        program_text.pack_start(self._label(self._t("HardwareCheck-Programm", "HardwareCheck application", "Program HardwareCheck"), "section-title"), False, False, 0)
        self._build_refs["program_update_status"] = self._label(self._t("Noch nicht geprüft", "Not checked yet", "Dosud nekontrolováno"), "status-chip", wrap=True)
        program_text.pack_start(self._build_refs["program_update_status"], False, False, 0)
        program_progress = Gtk.ProgressBar()
        program_progress.set_show_text(True)
        program_progress.set_no_show_all(True)
        program_progress.hide()
        program_text.pack_start(program_progress, False, False, 4)
        self._build_refs["program_update_progress"] = program_progress
        program_row.pack_start(program_text, True, True, 0)
        program_button = self._button(self._t("Programm-Update", "App update", "Aktualizace programu"), self._program_update_clicked, "primary-button", "software-update-available-symbolic")
        program_row.pack_end(program_button, False, False, 0)
        self._build_refs["program_update_button"] = program_button
        update_box.pack_start(program_row, False, False, 0)

        check_button = self._button(
            self._t("DB und Programm jetzt prüfen", "Check DB and application now", "Zkontrolovat DB a program nyní"),
            self._manual_check_updates_clicked,
            "secondary-button",
            "system-search-symbolic",
        )
        update_box.pack_start(check_button, False, False, 0)
        self._build_refs["updates_check_button"] = check_button
        if any(marker in str(self.core.APP_VERSION).lower() for marker in ("dev", "test")):
            demo_button = self._button(
                self._t("Nur Teststand: Update-Alarm testen", "Test build only: test update alert", "Pouze testovací verze: vyzkoušet upozornění"),
                self._toggle_update_alert_demo,
                "secondary-button",
                "dialog-warning-symbolic",
            )
            update_box.pack_start(demo_button, False, False, 0)

        language_box = self._section(outer, self._t("Sprache", "Language", "Jazyk"), 12)
        languages = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        language_box.pack_start(languages, False, False, 0)
        for language, code in (("CZ", "CZ"), ("DE", "DE"), ("EN", "EN")):
            button = Gtk.Button()
            button.get_style_context().add_class("primary-button" if self.language == language else "secondary-button")
            inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            inner.pack_start(Gtk.Image.new_from_pixbuf(flag_pixbuf(language)), False, False, 0)
            inner.pack_start(self._label(code, "section-title"), False, False, 0)
            button.add(inner)
            button.connect("clicked", lambda _b, target=language: self._select_language(target))
            languages.pack_start(button, False, False, 0)
            self._build_refs[f"language_button_{language}"] = button

        connections = self._section(outer, self._t("Verbindungen & Geräte", "Connections & devices", "Připojení a zařízení"))
        connections.pack_start(
            self._label(
                self._t(
                    "Gespeicherte WLANs und Drucker werden hier verwaltet. Die schnelle WLAN-Auswahl bleibt jederzeit oben erreichbar.",
                    "Manage saved Wi-Fi networks and printers here. Quick Wi-Fi selection remains available at the top.",
                    "Zde můžete spravovat uložené sítě Wi-Fi a tiskárny. Rychlý výběr Wi-Fi zůstává dostupný nahoře.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        connection_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        connection_actions.pack_start(
            self._button(
                self._t("WLANs verwalten", "Manage Wi-Fi", "Spravovat Wi-Fi"),
                lambda _b: self.show_page("wifi"),
                "secondary-button",
                "network-wireless-symbolic",
            ),
            False,
            False,
            0,
        )
        connection_actions.pack_start(
            self._button(
                self._t("Drucker suchen und verwalten", "Find and manage printers", "Vyhledat a spravovat tiskárny"),
                lambda _b: self.show_page("printers"),
                "secondary-button",
                "printer-symbolic",
            ),
            False,
            False,
            0,
        )
        connection_actions.pack_start(
            self._button(
                self._t("Config-Server", "Config server", "Server konfigurací"),
                self._open_config_server_settings,
                "secondary-button",
                "network-server-symbolic",
            ),
            False,
            False,
            0,
        )
        connections.pack_start(connection_actions, False, False, 0)

        service = self._section(outer, self._t("Service", "Service", "Servis"))
        service_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        service.pack_start(service_row, False, False, 0)
        service_row.pack_start(self._button(self._t("Hardware neu scannen", "Rescan hardware", "Znovu skenovat hardware"), self._rescan_clicked, "primary-button", "view-refresh-symbolic"), False, False, 0)
        service_row.pack_start(self._button(self._t("Legacy-Oberfläche starten", "Start legacy interface", "Spustit původní rozhraní"), self._restart_legacy, "secondary-button", "go-previous-symbolic"), False, False, 0)

        about = Gtk.Frame()
        about.set_shadow_type(Gtk.ShadowType.NONE)
        about.get_style_context().add_class("card")
        about_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        about.add(about_box)
        about_box.pack_start(self._label(f"HardwareCheck {self.core.APP_VERSION}", "hero-title"), False, False, 0)
        about_box.pack_start(self._label(f"{self.core.APP_VERSION} · GTK {Gtk.get_major_version()}.{Gtk.get_minor_version()} · Python {sys.version.split()[0]}", "muted"), False, False, 0)
        about_box.pack_start(self._label(self._t("Der bewährte v3-Hardwarekern bleibt unverändert als Rückfall verfügbar. v5 lädt aufwendige Suchen erst bei Bedarf.", "The proven v3 hardware core remains available as a fallback. v5 loads expensive searches only when requested.", "Osvědčené jádro hardwaru v3 zůstává k dispozici jako záloha. v5 spouští náročná vyhledávání pouze na vyžádání."), wrap=True), False, False, 0)
        about_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        about_actions.pack_start(
            self._button(
                self._t("Versionsverlauf anzeigen", "Show version history", "Zobrazit historii verzí"),
                self._show_version_history,
                "secondary-button",
                "help-about-symbolic",
            ),
            False,
            False,
            0,
        )
        about_box.pack_start(about_actions, False, False, 8)
        outer.pack_start(about, False, False, 20)
        return page

    def _open_config_server_settings(self, _button=None) -> None:
        """Configure the read-only HTTPS config source without any secret.

        The endpoint is intentionally visible: an address on a client medium
        cannot be made secret.  TLS and an optional certificate pin protect
        the connection; credentials belong on the server, not on 150 SSDs.
        """

        root = self._magic_config_server_root()
        settings = config_server_sync.load_settings(root)
        dialog = Gtk.Dialog(
            title=self._t("Config-Server", "Config server", "Server konfigurací"),
            transient_for=self.window,
            modal=True,
        )
        dialog.set_default_size(720, -1)
        dialog.add_button(self._t("Abbrechen", "Cancel", "Zrušit"), Gtk.ResponseType.CANCEL)
        save = dialog.add_button(self._t("Speichern", "Save", "Uložit"), Gtk.ResponseType.OK)
        save.get_style_context().add_class("primary-button")
        content = dialog.get_content_area()
        content.set_spacing(10)
        content.set_margin_start(24); content.set_margin_end(24); content.set_margin_top(20); content.set_margin_bottom(20)
        content.pack_start(self._label(self._t("Config-Server", "Config server", "Server konfigurací"), "warning-title"), False, False, 0)
        content.pack_start(self._label(self._t(
            "Keine Kennwörter auf der Installations-SSD speichern. HTTPS schützt die Übertragung; der Server gibt diesem Tool nur lesenden Zugriff.",
            "Do not store passwords on the installation SSD. HTTPS protects transport; the server grants this tool read-only access only.",
            "Na instalační SSD neukládejte hesla. HTTPS chrání přenos; server tomuto nástroji poskytuje pouze přístup pro čtení.",
        ), "muted", wrap=True), False, False, 0)
        enabled = Gtk.CheckButton(label=self._t("Server-Abgleich aktivieren", "Enable server synchronisation", "Zapnout synchronizaci se serverem"))
        enabled.set_active(settings.enabled); content.pack_start(enabled, False, False, 0)
        content.pack_start(self._label(self._t("HTTPS-Serveradresse", "HTTPS server address", "Adresa serveru HTTPS"), "section-title"), False, False, 0)
        endpoint = Gtk.Entry(); endpoint.set_placeholder_text("https://configs.example.invalid/hardwarecheck/v1"); endpoint.set_text(settings.endpoint); content.pack_start(endpoint, False, False, 0)
        content.pack_start(self._label(self._t("Zertifikat-Fingerprint SHA-256 (optional)", "Certificate SHA-256 fingerprint (optional)", "Otisk certifikátu SHA-256 (volitelné)"), "section-title"), False, False, 0)
        pin = Gtk.Entry(); pin.set_placeholder_text("64 Hex-Zeichen"); pin.set_text(settings.certificate_sha256); content.pack_start(pin, False, False, 0)
        content.pack_start(self._label(self._t("Prüfintervall in Stunden", "Check interval in hours", "Interval kontroly v hodinách"), "section-title"), False, False, 0)
        interval = Gtk.SpinButton.new_with_range(1, 168, 1); interval.set_value(settings.check_interval_hours); content.pack_start(interval, False, False, 0)
        feedback = self._label("", "status-bad", wrap=True); content.pack_start(feedback, False, False, 0)
        dialog.show_all()
        while True:
            response = dialog.run()
            if response != Gtk.ResponseType.OK:
                break
            try:
                config_server_sync.save_settings(root, config_server_sync.ConfigServerSettings(
                    enabled.get_active(), endpoint.get_text(), pin.get_text(), int(interval.get_value())
                ))
            except (OSError, ValueError) as exc:
                feedback.set_text(str(exc)); feedback.show(); continue
            self._magic_config_server_checked.clear()
            self.set_status(self._t("Config-Server gespeichert.", "Config server saved.", "Server konfigurací uložen."), "good")
            break
        dialog.destroy()

    def _show_version_history(self, _button=None) -> None:
        dialog = Gtk.Dialog(
            title=self._t("HardwareCheck – Versionsverlauf", "HardwareCheck – Version history", "HardwareCheck – Historie verzí"),
            transient_for=self.window,
            modal=True,
        )
        dialog.set_default_size(900, 680)
        dialog.add_button(self._t("Schließen", "Close", "Zavřít"), Gtk.ResponseType.CLOSE)

        content = dialog.get_content_area()
        content.set_spacing(10)
        content.set_margin_start(18)
        content.set_margin_end(18)
        content.set_margin_top(14)
        content.set_margin_bottom(10)
        content.pack_start(
            self._label(
                self._t(
                    "Die wichtigsten Entwicklungsschritte von der ersten Grundversion bis zum aktuellen Werkstattstand.",
                    "The most important development milestones from the first basic version to the current workshop release.",
                    "Nejdůležitější vývojové kroky od první základní verze po aktuální dílenské vydání.",
                ),
                "page-subtitle",
                wrap=True,
            ),
            False,
            False,
            0,
        )

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_min_content_height(520)
        history_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        history_box.set_margin_end(8)
        scroll.add(history_box)
        content.pack_start(scroll, True, True, 0)

        for index, entry in enumerate(self.VERSION_HISTORY):
            frame = Gtk.Frame()
            frame.set_shadow_type(Gtk.ShadowType.NONE)
            frame.get_style_context().add_class("card")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            frame.add(box)

            header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            version_label = self._label(str(entry["version"]), "section-title")
            header.pack_start(version_label, False, False, 0)
            if index == 0:
                current = self._label(self._t("AKTUELL", "CURRENT", "AKTUÁLNÍ"), "status-chip")
                current.get_style_context().add_class("good")
                header.pack_start(current, False, False, 0)
            header.pack_end(self._label(str(entry["date"]), "muted"), False, False, 0)
            box.pack_start(header, False, False, 0)
            box.pack_start(self._label(self._t(*entry["title"]), "card-value", wrap=True), False, False, 0)
            for item in entry["items"]:
                bullet = self._label(f"• {self._t(*item)}", "card-subtitle", wrap=True)
                bullet.set_margin_start(8)
                box.pack_start(bullet, False, False, 0)
            history_box.pack_start(frame, False, False, 0)

        content.pack_start(
            self._label(
                self._t(
                    "Der Verlauf fasst die sichtbaren Meilensteine zusammen; kleine technische Korrekturen sind bewusst gebündelt.",
                    "This history summarizes visible milestones; minor technical fixes are intentionally grouped.",
                    "Historie shrnuje viditelné milníky; menší technické opravy jsou záměrně sloučeny.",
                ),
                "muted",
                wrap=True,
            ),
            False,
            False,
            0,
        )
        dialog.show_all()
        dialog.run()
        dialog.destroy()

    def _save_appearance(self) -> None:
        settings = self.core.load_settings()
        settings["v5_layout"] = self.appearance_layout
        settings["v5_layout_colors"] = dict(self.appearance_colors)
        self.core.save_settings(settings)

    def _workshop_start_mode(self) -> str:
        try:
            mode = str(self.core.get_workshop_start_mode()).strip().lower()
        except (AttributeError, OSError, ValueError):
            mode = "hardwarecheck"
        return mode if mode in {"magic", "hardwarecheck"} else "hardwarecheck"

    def _magic_image_available(self) -> bool:
        try:
            return (pathlib.Path(self.core.SCRIPT_DIR) / "magic_image_solo_gui.py").is_file()
        except (AttributeError, OSError):
            return False

    def _select_workshop_start_mode(self, mode: str) -> None:
        if mode not in {"magic", "hardwarecheck"} or (mode == "magic" and not self._magic_image_available()):
            return
        try:
            self.core.set_workshop_start_mode(mode)
        except (AttributeError, OSError, ValueError) as exc:
            self.set_status(str(exc), "bad")
            return
        target = self._t("Magic Image", "Magic Image", "Magic Image") if mode == "magic" else self._t("HardwareCheck", "HardwareCheck", "HardwareCheck")
        self.set_status(
            self._t(
                f"{target} wird beim nächsten Start geöffnet.",
                f"{target} will open on the next launch.",
                f"{target} se otevře při příštím spuštění.",
            ),
            "good",
        )

    def _select_appearance_layout(self, layout: str) -> None:
        if layout not in APPEARANCE_LAYOUTS or layout == self.appearance_layout:
            return
        self.appearance_layout = layout
        self.appearance_accent = self.appearance_colors[layout]
        self._save_appearance()
        self.set_status(
            self._t(
                "Oberfläche gespeichert; HardwareCheck wird neu geladen …",
                "Interface saved; HardwareCheck is reloading …",
                "Rozhraní bylo uloženo; HardwareCheck se znovu načítá …",
            ),
            "good",
        )
        GLib.timeout_add(350, self._restart_v5)

    def _select_appearance_accent(self, color: str) -> None:
        color = _valid_hex_color(color, self.appearance_accent)
        if color.lower() == self.appearance_accent.lower():
            return
        self.appearance_accent = color
        self.appearance_colors[self.appearance_layout] = color
        self._save_appearance()
        self.set_status(
            self._t(
                "Akzentfarbe gespeichert; HardwareCheck wird neu geladen …",
                "Accent colour saved; HardwareCheck is reloading …",
                "Barva zvýraznění byla uložena; HardwareCheck se znovu načítá …",
            ),
            "good",
        )
        GLib.timeout_add(350, self._restart_v5)

    def _custom_appearance_accent_changed(self, button: Gtk.ColorButton) -> None:
        rgba = button.get_rgba()
        color = "#{:02x}{:02x}{:02x}".format(
            round(max(0.0, min(1.0, rgba.red)) * 255),
            round(max(0.0, min(1.0, rgba.green)) * 255),
            round(max(0.0, min(1.0, rgba.blue)) * 255),
        )
        self._select_appearance_accent(color)

    def _select_language(self, language: str) -> None:
        if language not in self.core.LANGUAGES:
            return
        self.language = language
        self.core.save_language(language)
        self.set_status(self._t("Sprache gespeichert; Oberfläche wird neu geladen …", "Language saved; reloading the interface …", "Jazyk uložen; rozhraní se znovu načítá …"), "good")
        for key in self.core.LANGUAGES:
            button = self._build_refs.get(f"language_button_{key}")
            if button:
                context = button.get_style_context()
                if key == language:
                    context.add_class("primary-button")
                    context.remove_class("secondary-button")
                else:
                    context.add_class("secondary-button")
                    context.remove_class("primary-button")
        GLib.timeout_add(350, self._restart_v5)

    def _restart_v5(self) -> bool:
        self._save_battery_state()
        env = os.environ.copy()
        env.pop("HC_USE_LEGACY_UI", None)
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(self.core.__file__).resolve())], env)
        return False

    def _restart_legacy(self, _button=None) -> None:
        self._save_battery_state()
        env = os.environ.copy()
        env["HC_USE_LEGACY_UI"] = "1"
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(self.core.__file__).resolve())], env)

    def _power_menu_action(self, action: str, popover: Gtk.Popover | None = None) -> None:
        if popover is not None:
            popover.popdown()
        self._execute_power_action(action)

    def _execute_power_action(self, action: str) -> None:
        restart = action == "reboot"
        self.set_status(
            self._t("Computer wird neu gestartet …", "Restarting computer …", "Počítač se restartuje …")
            if restart
            else self._t("Computer wird heruntergefahren …", "Shutting down computer …", "Počítač se vypíná …"),
            "warn",
        )
        try:
            self.core.subprocess.Popen(["reboot" if restart else "poweroff"])
        except OSError as exc:
            self.set_status(str(exc), "bad")

    def _confirm_power_action(self, action: str) -> None:
        self._execute_power_action(action)

    def _confirm_poweroff(self, _button=None) -> None:
        self._execute_power_action("poweroff")

    # ---------- async lifecycle ----------

    def _start_initial_load(self) -> bool:
        self.set_status(self._t("Hardware wird im Hintergrund erkannt …", "Detecting hardware in the background …", "Rozpoznávání hardwaru na pozadí …"), "info")

        def worker():
            snapshot = self.core.get_system_snapshot()
            models = config_server_sync.merge_model_overrides(
                self.core.load_model_db(), self._magic_config_server_root()
            )
            matches = self.core.get_model_match_results(snapshot, models)
            relations = self.core.build_model_relation_map(models)
            battery = self.core.read_battery_details()
            manifest = self.core.load_local_model_manifest()
            network = self.core.active_local_network_message()
            return snapshot, models, matches, relations, battery, manifest, network

        self.run_async("initial-load", worker, self._initial_load_finished)
        return False

    def _initial_load_finished(self, result) -> None:
        self.snapshot, self.models, self.match_results, self._model_relation_map, battery, manifest, network = result
        vendor = _clean(self.snapshot.get("vendor_short") or self.snapshot.get("vendor"))
        model = _clean(self.snapshot.get("model_name"))
        self._build_refs["hero_title"].set_text(f"{vendor} {model}")
        product = _clean(self.snapshot.get("product_no"), self._t("Keine Produktnummer erkannt", "No product number detected", "Nebylo zjištěno produktové číslo"))
        self._build_refs["hero_subtitle"].set_text(f"{product} · {self._t('Scan abgeschlossen', 'Scan complete', 'Sken dokončen')}")
        self._build_refs["metric_system"].set_text(f"{vendor} {model}")
        self._build_refs["metric_system_sub"].set_text(product)
        self._build_refs["metric_cpu"].set_text(_clean(self.snapshot.get("cpu_short") or self.snapshot.get("cpu")))
        self._build_refs["metric_cpu_sub"].set_text(_short(self.snapshot.get("cpu"), 64))
        ram_total = _clean(self.snapshot.get("ram_total_gb"))
        self._build_refs["metric_ram"].set_text(f"{ram_total} GB {self.snapshot.get('ram_type') or ''}".strip())
        self._build_refs["metric_ram_sub"].set_text(_clean(self.snapshot.get("ram_layout")))
        storage_lines = self.snapshot.get("storage_lines") or []
        self._build_refs["metric_storage"].set_text(_short(storage_lines[0] if storage_lines else "–", 72))
        self._build_refs["metric_storage_sub"].set_text(_short(" · ".join(str(line) for line in storage_lines[1:3]), 72))
        display = f"{_clean(self.snapshot.get('display_inches'))}\" {self.snapshot.get('display_type') or ''}".strip()
        self._build_refs["metric_display"].set_text(display)
        self._build_refs["metric_display_sub"].set_text(_clean(self.snapshot.get("resolution")))
        if self.match_results:
            best = self.match_results[0]
            item = best.get("item") if isinstance(best.get("item"), dict) else {}
            self._build_refs["metric_match"].set_text(f"{_clean(item.get('model_id'))} · {int(best.get('score') or 0)}%")
            self._build_refs["metric_match_sub"].set_text(_short(self.core.model_notebook_summary(item), 72))
        else:
            self._build_refs["metric_match"].set_text(self._t("Kein Treffer", "No match", "Žádná shoda"))
            self._build_refs["metric_match_sub"].set_text("")
        self._render_dashboard_model_suggestions()
        version = self.core.format_database_version(str(manifest.get("version") or ""))
        count = manifest.get("models_count") or manifest.get("model_count") or len(self.models)
        self._build_refs["db_chip"].set_text(f"DB {version or '–'} · {count}")
        if network:
            self._set_network_chip(self._translate_status(network), "good")
        else:
            self._set_network_chip(self._t("Offline", "Offline", "Offline"), "warn")
        self._update_battery_ui(battery)
        self._refresh_model_table()
        if self.current_page == "print":
            self._refresh_print_page()
        self.set_status(self._t("HardwareCheck v5 ist bereit.", "HardwareCheck v5 is ready.", "HardwareCheck v5 je připraven."), "good")
        GLib.idle_add(self._start_wifi_autoconnect)

    def _rescan_clicked(self, _button=None) -> None:
        if self._busy_count:
            self.set_status(self._t("Bitte laufenden Vorgang abwarten.", "Please wait for the current task.", "Počkejte na dokončení aktuální úlohy."), "warn")
            return
        self._start_initial_load()

    def run_async(self, name: str, worker: Callable, done: Callable | None = None) -> None:
        self._busy_count += 1
        self._busy_changed()

        def target() -> None:
            try:
                result = worker()
            except Exception as exc:
                detail = traceback.format_exc()
                GLib.idle_add(self._async_failed, name, exc, detail)
                return
            GLib.idle_add(self._async_finished, done, result)

        threading.Thread(target=target, name=f"hc-v5-{name}", daemon=True).start()

    def _async_finished(self, done: Callable | None, result) -> bool:
        self._busy_count = max(0, self._busy_count - 1)
        self._busy_changed()
        if done is not None:
            done(result)
        return False

    def _async_failed(self, name: str, exc: Exception, detail: str) -> bool:
        self._busy_count = max(0, self._busy_count - 1)
        self._refresh_tasks.discard(name)
        if name == "magic-media":
            # A failed worker used to leave this flag set forever.  The
            # embedded Magic Image page then showed "wird noch geprüft" for
            # every config and offered no way to retry.  Keep the last known
            # safe inspection, make the failure visible and allow Refresh.
            self._magic_scan_pending = False
            media_status: Gtk.Label | None = self._build_refs.get("magic_media_status")
            if media_status is not None:
                media_status.set_text(
                    self._t(
                        f"Medienprüfung fehlgeschlagen: {exc}. Bitte Aktualisieren drücken.",
                        f"Media check failed: {exc}. Please press Refresh.",
                        f"Kontrola médií selhala: {exc}. Stiskněte Aktualizovat.",
                    )
                )
            self._magic_validate_config()
            self._magic_update_summary()
        elif name == "magic-clonezilla-engine":
            self._magic_engine_pending = False
        if name in {"updates-check", "db-update", "program-update", "program-install"}:
            self._update_operation = ""
            self._set_update_controls_busy(False)
            if name == "db-update":
                self._finish_update_percentage("db", False, str(exc))
            elif name in {"program-update", "program-install"}:
                self._finish_update_percentage("program", False, str(exc))
        if name in {"wifi-autoconnect", "wifi-connect"}:
            self._wifi_connection_busy = False
            self._set_network_chip(self._t("WLAN-Fehler", "Wi-Fi error", "Chyba Wi-Fi"), "bad")
        self._busy_changed()
        try:
            debug_root = self.core.find_external_root() or self.core.SCRIPT_DIR
            debug_dir = pathlib.Path(debug_root) / "hardwarecheck-debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            self.core.write_text_durable(debug_dir / f"v5-{name}-error.txt", detail)
        except Exception:
            pass
        self.set_status(f"{name}: {exc}", "bad")
        return False

    def _busy_changed(self) -> None:
        spinner: Gtk.Spinner | None = self._build_refs.get("top_spinner")
        progress: Gtk.ProgressBar | None = self._build_refs.get("footer_progress")
        if self._busy_count:
            if spinner is not None:
                spinner.start()
            if progress is not None:
                progress.show()
                if not self._update_progress_determinate:
                    progress.pulse()
        else:
            if spinner is not None:
                spinner.stop()
            if progress is not None:
                progress.hide()

    def _clock_tick(self) -> bool:
        clock: Gtk.Label = self._build_refs.get("clock")
        if clock:
            clock.set_text(datetime.datetime.now().strftime("%H:%M · %d.%m.%Y"))
        if self._busy_count:
            progress: Gtk.ProgressBar = self._build_refs.get("footer_progress")
            if progress and not self._update_progress_determinate:
                progress.pulse()
        return True

    def _translate_status(self, message: object) -> str:
        try:
            return self.core.translate_status_text(str(message or ""), self.language)
        except Exception:
            return str(message or "")

    def _set_chip_state(self, chip: Gtk.Label, state: str) -> None:
        context = chip.get_style_context()
        for name in ("good", "warn", "bad"):
            context.remove_class(name)
        if state in {"good", "warn", "bad"}:
            context.add_class(state)

    def set_status(self, message: str, state: str = "info") -> None:
        label: Gtk.Label = self._build_refs.get("footer_status")
        if label:
            label.set_text(self._translate_status(message))
            context = label.get_style_context()
            for name in ("good-text", "warn-text", "bad-text"):
                context.remove_class(name)
            if state == "good":
                context.add_class("good-text")
            elif state == "warn":
                context.add_class("warn-text")
            elif state == "bad":
                context.add_class("bad-text")


def run(core) -> int:
    """Start the v5 GTK application using an already-loaded core module."""
    app = HardwareCheckV5(core)
    return int(app.run([str(pathlib.Path(core.__file__).resolve())]))
