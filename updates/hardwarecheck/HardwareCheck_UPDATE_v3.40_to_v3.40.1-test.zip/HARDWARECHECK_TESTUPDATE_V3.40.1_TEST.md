# HardwareCheck Testupdate v3.40.1-test

## Zweck

Dieses Paket ist ein kleines, ungefährliches Testupdate für den geplanten Updateweg:

```text
ModelFinder Admin/Publisher
→ GitHub Upload
→ latest_hardwarecheck.json
→ HardwareCheck Update-Prüfung
→ Download
→ SHA256-Prüfung
→ Installation
```

## Ausgangsversion

```text
v3.40
```

## Zielversion

```text
v3.40.1-test
```

## Änderung

Es wurde bewusst nur eine kleine Änderung vorgenommen:

```text
APP_VERSION = "v3.40.1-test"
```

Zusätzlich wurde ein Kommentar-Marker am Ende der Datei ergänzt.

## Paketstruktur

```text
update_manifest.json
payload/
└─ hardwarecheck_fast_gui.py
```

## Ersetzt wird

```text
hardwarecheck_fast_gui.py
```

## Geschützt bleiben müssen

```text
wifi_networks.json
hardwarecheck-settings.json
model.json
model_manifest_local.json
device_id.json
Model Report/
backups/
hardwarecheck-debug/
```

## Wichtig für Codex / andere KI-Chats

Dieses Testupdate ist NICHT als echte Funktionsversion gedacht.

Es dient nur dazu, zu prüfen, ob:

1. ModelFinder das Updatepaket zu GitHub hochladen kann.
2. `latest_hardwarecheck.json` korrekt aktualisiert wird.
3. HardwareCheck das Update erkennt.
4. HardwareCheck das ZIP herunterlädt.
5. SHA256 korrekt geprüft wird.
6. Lokale Betriebsdaten erhalten bleiben.
7. Danach die Version `v3.40.1-test` angezeigt wird.

## Hinweis

Falls dieses Paket über GitHub Release Assets veröffentlicht wird, muss der endgültige Download-Link in `latest_hardwarecheck.json` eingetragen werden.
