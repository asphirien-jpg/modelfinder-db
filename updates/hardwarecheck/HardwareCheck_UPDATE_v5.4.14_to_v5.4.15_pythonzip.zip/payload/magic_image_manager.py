#!/usr/bin/env python3
"""Shared, explicitly confirmed HardwareCheck and Magic Image restore workflow.

Discovery and planning are read-only. Only execute_restore_proof, reached
after the application's final erase confirmation, runs a restore. Config
images receive a Windows config handoff; complete model images do not.

Drive letters (for example D:, F: or G:) and volatile Linux names (for example
/dev/sda2) are never configuration.  A role is instead identified by mounted
marker files, a manifest and the physical parent disk reported by ``lsblk``.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
import hashlib
import ipaddress
import json
import os
import pathlib
import re
import shutil
import struct
import subprocess
import sys
import time
import tempfile
import threading
import uuid
from typing import Callable, Iterable


MANIFEST_FILE = "magic-image-manifest.json"

_TIME_SYNC_LOCK = threading.Lock()
_TIME_SYNC_LAST = float('-inf')
_TIME_SYNC_RESULT = (False, 'Noch kein Zeitabgleich versucht.')


def synchronize_live_time() -> tuple[bool, str]:
    """Bounded worker-only NTP step, shared by both applications.

    Uses the existing Clonezilla ntpdig when absent from the host. Mounts
    remain read-only. Never writes the RTC, disables TLS, or installs packages.
    Cache uses monotonic time so correcting CLOCK_REALTIME cannot lock retries.
    """
    global _TIME_SYNC_LAST, _TIME_SYNC_RESULT
    if not sys.platform.startswith('linux') or getattr(os, 'geteuid', lambda: 1)() != 0:
        return False, 'Zeitabgleich benötigt das Linux-Live-System mit Root-Rechten.'
    with _TIME_SYNC_LOCK:
        interval = 3600 if _TIME_SYNC_RESULT[0] else 60
        if 0 <= time.monotonic() - _TIME_SYNC_LAST < interval:
            return _TIME_SYNC_RESULT
        _TIME_SYNC_RESULT = _synchronize_live_time_once()
        _TIME_SYNC_LAST = time.monotonic()
        try:
            log = pathlib.Path(__file__).resolve().parent / 'hardwarecheck-debug' / 'time-sync.log'
            log.parent.mkdir(parents=True, exist_ok=True)
            with log.open('a', encoding='utf-8') as handle:
                handle.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' ' + _TIME_SYNC_RESULT[1] + '\n')
        except OSError:
            pass
        return _TIME_SYNC_RESULT


def _synchronize_live_time_once() -> tuple[bool, str]:
    mounts = []
    workspace = None
    def run(command, timeout=4):
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
        if result.returncode:
            raise OSError(f'{command[0]}: {(result.stderr or result.stdout)[-300:].strip()}')
        return result.stdout
    try:
        # Resolve outside chroot; do not copy or replace its resolv.conf.
        resolved = run(['getent', 'ahostsv4', 'time.cloudflare.com', 'time.google.com'])
        addresses = []
        for line in resolved.splitlines():
            token = line.split()[0] if line.split() else ''
            try:
                address = str(ipaddress.IPv4Address(token))
            except ValueError:
                continue
            if address not in addresses:
                addresses.append(address)
        if not addresses:
            raise OSError('Keine Zeitserver erreichbar/auflösbar.')
        executable = shutil.which('ntpdig')
        prefix = []
        if not executable:
            partitions = [pathlib.Path('/dev/disk/by-label') / label
                          for label in ('MISOLOBOOT', 'HWCHECKBOOT')]
            partitions = [p for p in partitions if p.exists()]
            if len(partitions) != 1:
                raise OSError('Clonezilla-Zeitwerkzeug nicht eindeutig verfügbar.')
            workspace = pathlib.Path(tempfile.mkdtemp(prefix='hardwarecheck-time-', dir='/run'))
            media = workspace / 'media'
            engine = workspace / 'engine'
            media.mkdir()
            engine.mkdir()
            run(['mount', '-o', 'ro,nosuid,nodev,noexec', str(partitions[0]), str(media)])
            mounts.append(media)
            squashfs = media / 'live/filesystem.squashfs'
            if not squashfs.is_file():
                raise OSError('Clonezilla-Laufzeit fehlt.')
            run(['mount', '-o', 'ro,loop,nosuid,nodev', str(squashfs), str(engine)])
            mounts.append(engine)
            if not (engine / 'usr/bin/ntpdig').is_file():
                raise OSError('ntpdig fehlt im Clonezilla-Live-System.')
            prefix = ['chroot', str(engine)]
            executable = '/usr/bin/ntpdig'
        output = run([*prefix, executable, '-S', '-t', '3', *addresses[:2]], timeout=12)
        if not output.strip():
            raise OSError('Zeitwerkzeug lieferte keine Bestätigung.')
        # NTP synchronizes UTC.  The workshop media is used in Germany, so
        # choose the local display zone separately; this also keeps CET/CEST
        # correct at daylight-saving transitions.  timedatectl changes the
        # writable live overlay only, never the firmware RTC.
        timezone_note = 'Zeitzone Europe/Berlin gesetzt.'
        try:
            run(['timedatectl', 'set-timezone', 'Europe/Berlin'], timeout=5)
        except (OSError, subprocess.SubprocessError):
            timezone_note = 'Zeitzone Europe/Berlin für dieses Programm gesetzt.'
        # glibc caches the local-time zone in a running Python process.  Apply
        # it explicitly even after successful timedatectl so the header clock
        # changes at once rather than after the next program restart.
        os.environ['TZ'] = 'Europe/Berlin'
        if hasattr(time, 'tzset'):
            time.tzset()
        return True, 'Systemzeit per NTP abgeglichen; ' + timezone_note
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return False, f'Zeitabgleich nicht bestätigt; Offlinebetrieb bleibt möglich: {exc}'
    finally:
        for mountpoint in reversed(mounts):
            try:
                run(['umount', str(mountpoint)])
            except (OSError, subprocess.SubprocessError):
                pass
        if workspace is not None:
            # Never recursively remove mountpoints after a failed unmount.
            for path in (workspace / 'engine', workspace / 'media', workspace):
                try:
                    path.rmdir()
                except OSError:
                    pass
HARDWARECHECK_MARKERS = (
    ".hardwarecheck-portable",
    "hardwarecheck_v5_gui.py",
    "HardwareCheck/.hardwarecheck-portable",
    "HardwareCheck/hardwarecheck_v5_gui.py",
)
CLONEZILLA_MARKERS = ("Clonezilla-Live-Version", ".disk", "live")
REPOSITORY_MARKERS = ("#configs", "Treiber", "image-deploy.bat")
LSBLK_COLUMNS = (
    "NAME,KNAME,PATH,PKNAME,TYPE,TRAN,SIZE,MODEL,SERIAL,WWN,RM,HOTPLUG,ROTA,"
    "MOUNTPOINTS,LABEL,UUID,PARTUUID,FSTYPE"
)
READONLY_MOUNT_ROOT = pathlib.Path("/run/hardwarecheck-magic-media")
CLONEZILLA_RUNTIME_ROOT = pathlib.Path("/run/hardwarecheck-clonezilla-runtime")
CLONEZILLA_SQUASHFS_RELATIVE_PATH = pathlib.Path("live") / "filesystem.squashfs"
# Repository discovery runs in a background thread.  Large NTFS image
# partitions can legitimately need more than eight seconds to become ready
# after boot, especially through slower USB bridges.  Killing the read-only
# mount that early made an existing complete image look like a missing config.
MEDIA_MOUNT_COMMAND_TIMEOUT_SECONDS = 30
HANDOFF_WINDOWS_PATH = r"C:\MagicImage\hardwarecheck-config.txt"
ACRONIS_PARTITION_LABEL = "ACRONIS"
ACRONIS_EFI_PATH = r"\EFI\Boot\bootx64.efi"
ACRONIS_BOOT_DESCRIPTION = "HardwareCheck Acronis (einmalig)"
WINDOWS_EFI_PATH = r"\EFI\Microsoft\Boot\bootmgfw.efi"
WINDOWS_BOOT_DESCRIPTION = "HardwareCheck Windows (einmalig)"
WINDOWS_ESP_FILESYSTEMS = {"vfat", "fat", "fat32", "msdos"}
EFI_GLOBAL_VARIABLE_GUID = "8be4df61-93ca-11d2-aa0d-00e098032b8c"
EFI_VARIABLE_ATTRIBUTES = 0x00000007
GRUB_ONESHOT_ENTRY = "hwc_acronis"
GRUB_ENVIRONMENT_SIZE = 1024
GRUB_ENVIRONMENT_HEADER = (
    b"# GRUB Environment Block\n"
    b"# WARNING: Do not edit this file by tools other than grub-editenv!!!!\n"
)
# Both supported media layouts have exactly two GRUB-bearing partitions.  The
# compact Solo medium uses the MISOLO labels, while the four-partition medium
# also retains the Acronis fallback partition.  They must remain alternative
# sets: requiring all four labels would make either valid layout fail.
GRUB_BOOT_PARTITION_LABEL_SETS = (
    ("HWCHECKBOOT", "HCDEBIAN"),
    ("MISOLOBOOT", "MISODEBIAN"),
)


def _text(value: object) -> str:
    return str(value or "").strip()


def _mountpoints(value: object) -> tuple[str, ...]:
    if isinstance(value, list):
        candidates = value
    else:
        candidates = [value]
    return tuple(item for item in (_text(candidate) for candidate in candidates) if item)


def _safe_name(value: object, fallback: str = "") -> str:
    value = _text(value)
    return value if re.fullmatch(r"[A-Za-z0-9._+-]+", value) else fallback


def _format_size(size_bytes: int) -> str:
    if size_bytes <= 0:
        return "unbekannt"
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    value = float(size_bytes)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return "unbekannt"


@dataclass(frozen=True)
class BlockDevice:
    """One lsblk node, including its stable association with a physical disk."""

    path: str
    name: str
    parent_disk: str
    type: str
    transport: str
    size_bytes: int
    model: str
    serial: str
    wwn: str
    removable: bool
    hotplug: bool
    mountpoints: tuple[str, ...]
    label: str
    uuid: str
    partuuid: str
    filesystem: str = ""
    # ``lsblk`` reports a rotational device for classical HDDs.  Keep the
    # field optional so historic test data without ``ROTA`` remains valid.
    rotational: bool | None = None

    @property
    def is_disk(self) -> bool:
        return self.type == "disk"

    @property
    def is_usb(self) -> bool:
        return self.transport == "usb" or self.removable or self.hotplug

    @property
    def stable_identity(self) -> str:
        parts = [part for part in (self.wwn, self.serial, self.partuuid, self.uuid) if part]
        return " | ".join(parts) or "keine stabile Kennung"

    @property
    def description(self) -> str:
        model = " ".join(part for part in (self.model, self.serial) if part).strip() or "unbekanntes Modell"
        bus = self.transport.upper() if self.transport else "unbekannter Bus"
        return f"{self.path} · {model} · {_format_size(self.size_bytes)} · {bus}"


@dataclass(frozen=True)
class MediaRole:
    role: str
    mountpoint: str
    parent_disk: str
    label: str
    reason: str


@dataclass(frozen=True)
class MagicImage:
    image_id: str
    display_name: str
    version: str
    image_path: str
    minimum_target_bytes: int
    description: str
    managed: bool
    deployment_mode: str = "config"
    model_configs: tuple[str, ...] = ()
    display_location: str = ""

    @property
    def operator_label(self) -> str:
        """Short stable label for the UI while image_path keeps the exact source."""

        return self.display_location or self.display_name

    @property
    def display_text(self) -> str:
        version = f" · {self.version}" if self.version else ""
        source = "Clonezilla-Komplettimage" if self.deployment_mode == "complete" else "Manifest" if self.managed else "Image ohne Manifest"
        return f"{self.display_name}{version} ({source})"


@dataclass(frozen=True)
class ClassicAcronisImage:
    """A classical Acronis image kept as a visible, read-only fallback.

    Acronis is deliberately *not* a restore engine for the Magic Image flow.
    Discovering these files only tells the operator that a legacy, model-bound
    fallback exists on the Image partition.
    """

    config: str
    vendor: str
    source_folder: str
    file_paths: tuple[str, ...]
    total_bytes: int = 0

    @property
    def display_text(self) -> str:
        count = len(self.file_paths)
        plural = "Datei" if count == 1 else "Dateien"
        vendor = self.vendor or "Unbekannter Hersteller"
        return f"{vendor} · Config {self.config} · {count} Acronis-{plural}"


@dataclass(frozen=True)
class ConfigValidation:
    config: str
    valid: bool
    score: int
    message: str
    model: dict[str, object] | None = None
    details: tuple[str, ...] = ()
    strict_match: bool = False
    requires_confirmation: bool = False
    override_confirmed: bool = False
    magic_config_available: bool = False
    legacy_config_without_model: bool = False
    classic_acronis_images: tuple[ClassicAcronisImage, ...] = ()
    deployment_mode: str = "config"
    complete_images: tuple[MagicImage, ...] = ()


@dataclass(frozen=True)
class AcronisBootPlan:
    """A verified one-time GRUB hand-off to the Acronis partition.

    The plan never starts an image restore.  It only identifies the Acronis
    boot file on the *same external disk* as the running HardwareCheck medium.
    """

    ready: bool
    message: str
    parent_disk: str = ""
    partition_path: str = ""
    partition_number: int = 0


@dataclass(frozen=True)
class AcronisBootResult:
    ready: bool
    message: str
    boot_number: int | None = None


@dataclass(frozen=True)
class WindowsBootResult:
    """Verified one-time UEFI hand-off to the restored Windows SSD."""

    ready: bool
    message: str
    boot_number: int | None = None
    created_entry: bool = False


@dataclass(frozen=True)
class ClonezillaProbe:
    available: bool
    executable: str
    message: str
    source_path: str = ""
    usage_verified: bool = False
    log_excerpt: str = ""


@dataclass(frozen=True)
class RestoreProofPlan:
    """A reviewable restore job; building it never changes a disk."""

    ready: bool
    message: str
    config: str = ""
    image_name: str = ""
    image_path: str = ""
    repository_path: str = ""
    target_path: str = ""
    target_selector: str = ""
    target_model: str = ""
    target_size_bytes: int = 0
    confirmation_text: str = ""
    command: tuple[str, ...] = ()
    deployment_mode: str = "config"


@dataclass(frozen=True)
class DataDiskPreparePlan:
    """An explicitly selected secondary HDD to turn into a data volume.

    This plan is deliberately separate from the Windows restore plan.  It is
    optional, serial-bound, and can only describe an internal rotational disk
    other than the selected Windows SSD.  Building it never changes a disk.
    """

    ready: bool
    message: str
    disk_path: str = ""
    disk_selector: str = ""
    disk_model: str = ""
    disk_size_bytes: int = 0
    label: str = "Daten"


@dataclass(frozen=True)
class DataDiskPrepareResult:
    """Outcome of the optional secondary HDD preparation."""

    success: bool
    message: str
    partition_path: str = ""
    output_excerpt: str = ""


@dataclass(frozen=True)
class RestoreProofResult:
    success: bool
    phase: str
    message: str
    clonezilla_exit_code: int | None = None
    log_path: str = ""
    handoff_path: str = ""
    output_excerpt: str = ""
    deployment_mode: str = "config"


@dataclass
class MediaInspection:
    devices: list[BlockDevice] = field(default_factory=list)
    roles: list[MediaRole] = field(default_factory=list)
    images: list[MagicImage] = field(default_factory=list)
    safe_targets: list[BlockDevice] = field(default_factory=list)
    protected_disks: set[str] = field(default_factory=set)
    mounted_read_only: list[str] = field(default_factory=list)
    available_configs: set[str] = field(default_factory=set)
    config_profiles: dict[str, dict[str, object]] = field(default_factory=dict)
    config_repository_paths: tuple[str, ...] = ()
    classic_acronis_images: list[ClassicAcronisImage] = field(default_factory=list)
    clonezilla: ClonezillaProbe = field(
        default_factory=lambda: ClonezillaProbe(False, "", "Clonezilla wurde noch nicht geprüft.")
    )
    warnings: list[str] = field(default_factory=list)


def parse_lsblk(payload: str) -> list[BlockDevice]:
    """Parse lsblk JSON while preserving each partition's physical parent disk."""

    try:
        data = json.loads(payload)
    except (TypeError, json.JSONDecodeError):
        return []
    roots = data.get("blockdevices") if isinstance(data, dict) else None
    if not isinstance(roots, list):
        return []

    result: list[BlockDevice] = []

    def visit(raw: object, parent_disk: str = "") -> None:
        if not isinstance(raw, dict):
            return
        name = _safe_name(raw.get("name"))
        path = _text(raw.get("path")) or (f"/dev/{name}" if name else "")
        node_type = _text(raw.get("type")).lower()
        current_parent = path if node_type == "disk" else parent_disk
        if path and node_type in {"disk", "part"}:
            try:
                size_bytes = int(raw.get("size") or 0)
            except (TypeError, ValueError):
                size_bytes = 0
            removable = _text(raw.get("rm")).lower() in {"1", "true", "yes"}
            hotplug = _text(raw.get("hotplug")).lower() in {"1", "true", "yes"}
            result.append(
                BlockDevice(
                    path=path,
                    name=name,
                    parent_disk=current_parent or path,
                    type=node_type,
                    transport=_text(raw.get("tran")).lower(),
                    size_bytes=size_bytes,
                    model=_text(raw.get("model")),
                    serial=_text(raw.get("serial")),
                    wwn=_text(raw.get("wwn")),
                    removable=removable,
                    hotplug=hotplug,
                    mountpoints=_mountpoints(raw.get("mountpoints")),
                    label=_text(raw.get("label")),
                    uuid=_text(raw.get("uuid")),
                    partuuid=_text(raw.get("partuuid")),
                    filesystem=_text(raw.get("fstype")).lower(),
                    rotational=_text(raw.get("rota")).lower() in {"1", "true", "yes"}
                    if _text(raw.get("rota"))
                    else None,
                )
            )
        children = raw.get("children")
        if isinstance(children, list):
            for child in children:
                visit(child, current_parent)

    for root in roots:
        visit(root)
    return result


def collect_lsblk(runner: Callable[..., object] = subprocess.run) -> list[BlockDevice]:
    """Read only the running system's block-device metadata.  Never writes."""

    try:
        completed = runner(
            ["lsblk", "--json", "--bytes", "--output", LSBLK_COLUMNS],
            check=False,
            capture_output=True,
            text=True,
            timeout=8,
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return []
    if int(getattr(completed, "returncode", 1)) != 0:
        return []
    return parse_lsblk(_text(getattr(completed, "stdout", "")))


def external_unmounted_partitions(devices: Iterable[BlockDevice]) -> list[BlockDevice]:
    """Return only unmounted partitions whose *physical* parent is external."""

    external_disks = {
        device.path
        for device in devices
        if device.is_disk and device.is_usb
    }
    return [
        device
        for device in devices
        if device.type == "part"
        and not device.mountpoints
        and device.parent_disk in external_disks
    ]


def media_inspection_partitions(devices: Iterable[BlockDevice]) -> list[BlockDevice]:
    """Return only the partitions that are relevant to Magic Image discovery.

    A prepared four-partition medium has an Acronis fallback as well as the
    image and Clonezilla partitions.  Acronis is deliberately not part of the
    automatic Magic Image scan.  Trying to mount it through udisks on a live
    desktop can wait for a policy prompt and made the embedded HardwareCheck
    page appear to spin forever.

    If a known Magic/HardwareCheck layout is present, inspect just its named
    image and boot partitions.  For older, unlabeled media retain the safe
    fallback of inspecting all external partitions except Acronis.
    """

    unmounted = external_unmounted_partitions(devices)
    known_labels = {
        "misoloimages",
        "images",
        "misoloboot",
        "hwcheckboot",
        "misodebian",
        "hcdebian",
    }
    named = [item for item in unmounted if item.label.casefold() in known_labels]
    if named:
        return named
    return [item for item in unmounted if item.label.casefold() != ACRONIS_PARTITION_LABEL.casefold()]


def _run_read_only_mount(command: list[str], runner: Callable[..., object]) -> tuple[bool, str]:
    try:
        completed = runner(
            command,
            check=False,
            capture_output=True,
            text=True,
            timeout=MEDIA_MOUNT_COMMAND_TIMEOUT_SECONDS,
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError) as exc:
        return False, str(exc)
    output = "\n".join(
        value for value in (_text(getattr(completed, "stdout", "")), _text(getattr(completed, "stderr", ""))) if value
    )
    return int(getattr(completed, "returncode", 1)) == 0, output


def mount_external_partitions_read_only(
    devices: Iterable[BlockDevice], runner: Callable[..., object] = subprocess.run
) -> tuple[list[str], list[str]]:
    """Mount external, previously unmounted partitions read-only for inspection.

    This is intentionally limited to USB/removable parent disks.  It never
    mounts or modifies an internal target disk and never executes files from a
    mounted medium.  The mounts stay available while HardwareCheck prepares a
    later job, so a selected Clonezilla image path cannot silently disappear.
    """

    if not sys.platform.startswith("linux"):
        return [], []
    mounted: list[str] = []
    warnings: list[str] = []
    try:
        READONLY_MOUNT_ROOT.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return [], [f"Schreibgeschützter Medienordner kann nicht angelegt werden: {exc}"]
    for partition in media_inspection_partitions(devices):
        target = READONLY_MOUNT_ROOT / _safe_name(partition.name, "external")
        try:
            target.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            warnings.append(f"{partition.path} konnte nicht vorbereitet werden: {exc}")
            continue
        # udisksctl is only useful in an unprivileged desktop session.  The
        # normal HardwareCheck live session runs as root; asking udisks there
        # can block on an unavailable desktop/polkit prompt.  Mount directly
        # in that case, always read-only and with a strict timeout.
        running_as_root = getattr(os, "geteuid", lambda: 1)() == 0
        if shutil.which("udisksctl") and not running_as_root:
            ok, output = _run_read_only_mount(
                ["udisksctl", "mount", "-b", partition.path, "--options", "ro,nosuid,nodev,noexec"], runner
            )
            if ok:
                mounted.append(partition.path)
                continue
        else:
            output = "udisksctl nicht vorhanden"
        ntfs3_output = ""
        if partition.filesystem.casefold() in {"ntfs", "ntfs3"}:
            # The image repository is commonly NTFS.  Current Linux kernels
            # expose their in-kernel NTFS driver as ``ntfs3``.
            ok, ntfs3_output = _run_read_only_mount(
                ["mount", "-t", "ntfs3", "-o", "ro,nosuid,nodev,noexec", partition.path, str(target)], runner
            )
            if ok:
                mounted.append(partition.path)
                continue
        # Clonezilla-style live sessions commonly run with sufficient rights;
        # direct mount is the fallback and remains read-only.
        ok, fallback_output = _run_read_only_mount(
            ["mount", "-o", "ro,nosuid,nodev,noexec", partition.path, str(target)], runner
        )
        if ok:
            mounted.append(partition.path)
        else:
            detail = fallback_output or ntfs3_output or output
            warnings.append(f"{partition.path} konnte nicht schreibgeschützt eingehängt werden: {detail}")
    return mounted, warnings


def _marker_exists(root: pathlib.Path, marker: str) -> bool:
    try:
        return (root / marker).exists()
    except OSError:
        return False


def _is_hardwarecheck_root(root: pathlib.Path) -> bool:
    return any(_marker_exists(root, marker) for marker in HARDWARECHECK_MARKERS)


def _is_clonezilla_root(root: pathlib.Path) -> bool:
    return all(_marker_exists(root, marker) for marker in CLONEZILLA_MARKERS)


def _is_repository_root(root: pathlib.Path) -> bool:
    if _marker_exists(root, MANIFEST_FILE):
        return True
    # Compatibility with the already prepared TEST media.  A production
    # repository is later made explicit with magic-image-manifest.json.
    return all(_marker_exists(root, marker) for marker in REPOSITORY_MARKERS[:2])


def discover_media_roles(
    devices: Iterable[BlockDevice], tool_root: pathlib.Path | None = None
) -> list[MediaRole]:
    roles: list[MediaRole] = []
    seen: set[tuple[str, str]] = set()
    for device in devices:
        for mountpoint in device.mountpoints:
            root = pathlib.Path(mountpoint)
            candidates = (
                (
                    "hardwarecheck",
                    lambda candidate: _is_hardwarecheck_root(candidate)
                    or (tool_root is not None and _inside(candidate, tool_root)),
                    "HardwareCheck-Marker beziehungsweise laufender Programmordner gefunden",
                ),
                ("clonezilla", _is_clonezilla_root, "Clonezilla-Live-Marker gefunden"),
                ("repository", _is_repository_root, "Magic-Image-Repository-Marker gefunden"),
            )
            for role, predicate, reason in candidates:
                key = (role, device.parent_disk)
                if key not in seen and predicate(root):
                    roles.append(
                        MediaRole(
                            role=role,
                            mountpoint=mountpoint,
                            parent_disk=device.parent_disk,
                            label=device.label,
                            reason=reason,
                        )
                    )
                    seen.add(key)
    return roles


def _inside(root: pathlib.Path, candidate: pathlib.Path) -> bool:
    try:
        candidate.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def _manifest_images(root: pathlib.Path) -> list[MagicImage]:
    manifest_path = root / MANIFEST_FILE
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return []
    entries = data.get("images") if isinstance(data, dict) else None
    if not isinstance(entries, list):
        return []
    images: list[MagicImage] = []
    for raw in entries:
        if not isinstance(raw, dict):
            continue
        image_id = _safe_name(raw.get("id"))
        relative_path = _text(raw.get("clonezilla_path") or raw.get("path"))
        candidate = root / relative_path
        try:
            minimum = int(raw.get("minimum_target_bytes") or raw.get("minimum_target_size_bytes") or 0)
        except (TypeError, ValueError):
            minimum = 0
        if not image_id or not relative_path or not _inside(root, candidate) or not looks_like_clonezilla_image(candidate):
            continue
        images.append(
            MagicImage(
                image_id=image_id,
                display_name=_text(raw.get("display_name")) or image_id,
                version=_text(raw.get("version")),
                image_path=str(candidate),
                minimum_target_bytes=max(0, minimum),
                description=_text(raw.get("description")),
                managed=True,
            )
        )
    return images


def looks_like_clonezilla_image(path: pathlib.Path) -> bool:
    """Recognise Clonezilla's file structure, never merely a folder name."""

    try:
        if not path.is_dir():
            return False
        return (path / "parts").is_file() and (path / "disk").is_file()
    except OSError:
        return False


def discover_images(repository_roots: Iterable[str]) -> list[MagicImage]:
    repository_roots = tuple(repository_roots)
    images: list[MagicImage] = []
    seen_paths: set[str] = set()
    for root_text in repository_roots:
        root = pathlib.Path(root_text)
        managed = _manifest_images(root)
        for image in managed:
            if image.image_path not in seen_paths:
                images.append(image)
                seen_paths.add(image.image_path)
        # The first proof-of-concept already has a real image but no manifest.
        # It remains visibly labelled TEST-Fund and must be selected manually.
        if managed:
            continue
        try:
            children = list(root.iterdir())
        except OSError:
            continue
        for child in sorted(children, key=lambda item: item.name.lower()):
            if not looks_like_clonezilla_image(child):
                continue
            path = str(child)
            if path in seen_paths:
                continue
            images.append(
                MagicImage(
                    image_id=f"detected-{child.name}",
                    display_name=child.name,
                    version="",
                    image_path=path,
                    minimum_target_bytes=0,
                    description="Automatisch über Clonezilla-Dateistruktur erkannt; vor Produktion in ein Manifest übernehmen.",
                    managed=False,
                )
            )
            seen_paths.add(path)
    # Complete model images coexist with a manifest for the normal base image.
    # A model-bound image must never also appear as an unrestricted base image.
    complete = discover_complete_clonezilla_images(repository_roots)
    complete_paths = {str(pathlib.Path(item.image_path).resolve()) for item in complete}
    return [item for item in images if str(pathlib.Path(item.image_path).resolve()) not in complete_paths] + complete


def _model_folder_configs(name: str) -> tuple[str, ...]:
    """Only the initial model-number block is identity, never a CPU number."""
    match = re.match(r"^(\d{4}(?:\s*\+\s*\d{4})*)(?=$|[\s(_-])", name)
    return tuple(dict.fromkeys(re.findall(r"\d{4}", match.group(1)))) if match else ()


def _plain_repository_path(root: pathlib.Path, path: pathlib.Path) -> bool:
    """Reject escaped paths and symlink aliases, including Clonezilla markers."""
    try:
        relative = path.absolute().relative_to(root.absolute())
        current = root
        for part in relative.parts:
            current = current / part
            if current.is_symlink():
                return False
        return _inside(root, path) and not any((path / marker).is_symlink() for marker in ("disk", "parts"))
    except (OSError, ValueError):
        return False


def _complete_image_configs(root: pathlib.Path, path: pathlib.Path) -> tuple[str, ...]:
    """Recognise vendor/model[/image or /Clonezilla/image], with safe containment."""
    if not _plain_repository_path(root, path):
        return ()
    try:
        parts = path.resolve().relative_to(root.resolve()).parts
    except (OSError, ValueError):
        return ()
    if len(parts) not in (2, 3, 4) or parts[0].startswith(("#", ".")):
        return ()
    if len(parts) == 4 and parts[2].casefold() != "clonezilla":
        return ()
    return _model_folder_configs(parts[1])


def _child_directories(path: pathlib.Path) -> list[pathlib.Path]:
    try:
        return sorted((item for item in path.iterdir() if item.is_dir() and not item.is_symlink()), key=lambda item: item.name.casefold())
    except OSError:
        return []


def discover_complete_clonezilla_images(repository_roots: Iterable[str]) -> list[MagicImage]:
    """Read only shallow existing vendor/model folders, never the large image data."""
    images: list[MagicImage] = []
    seen: set[str] = set()
    for root_text in repository_roots:
        root = pathlib.Path(root_text)
        for vendor in _child_directories(root):
            if vendor.name.startswith(("#", ".")):
                continue
            for model_folder in _child_directories(vendor):
                if not _model_folder_configs(model_folder.name):
                    continue
                candidates = [model_folder]
                if not looks_like_clonezilla_image(model_folder):
                    children = _child_directories(model_folder)
                    candidates.extend(children)
                    for child in children:
                        if child.name.casefold() == "clonezilla" and not looks_like_clonezilla_image(child):
                            candidates.extend(_child_directories(child))
                for candidate in candidates:
                    configs = _complete_image_configs(root, candidate)
                    if not configs or not looks_like_clonezilla_image(candidate):
                        continue
                    resolved = str(candidate.resolve())
                    if resolved in seen:
                        continue
                    seen.add(resolved)
                    relative = candidate.relative_to(root).as_posix()
                    images.append(MagicImage(
                        image_id="complete-" + hashlib.sha256(resolved.encode("utf-8")).hexdigest()[:20],
                        display_name=relative,
                        version="",
                        image_path=str(candidate),
                        minimum_target_bytes=0,
                        description="Modellgebundenes Komplettimage; die Modellprüfung erfolgt durch das bereits im Windows-Image enthaltene Skript.",
                        managed=False,
                        deployment_mode="complete",
                        model_configs=configs,
                        display_location=model_folder.relative_to(root).as_posix(),
                    ))
    return images


def install_images_for_config(validation: ConfigValidation | None, images: Iterable[MagicImage]) -> list[MagicImage]:
    """Keep base and model-bound image selection separate, including transient UI input."""
    if validation is not None and validation.deployment_mode == "complete":
        allowed = {image.image_path for image in validation.complete_images}
        return [image for image in images if image.deployment_mode == "complete"
                and validation.config in image.model_configs and image.image_path in allowed]
    return [image for image in images if image.deployment_mode == "config"]


def _is_non_hdd_target(device: BlockDevice) -> bool:
    """Return whether a disk is not *explicitly* identified as an HDD.

    SATA describes only the connection, not the physical medium: a 2.5 inch
    SATA SSD is a valid Windows target.  ``lsblk`` reports ``ROTA=1`` for a
    classical spinning HDD and that value remains an absolute exclusion.

    Some SATA/RAID controllers do not publish a ``ROTA`` value at all.  Those
    SSDs used to disappear from Magic Image Solo even though HardwareCheck
    correctly identified them as SATA SSDs.  Missing metadata must therefore
    not be treated as proof that a disk is an HDD.  The restore preflight uses
    this same rule again immediately before Clonezilla is invoked.
    """

    return device.rotational is not True


def safe_restore_targets(devices: Iterable[BlockDevice], protected_disks: Iterable[str]) -> list[BlockDevice]:
    """Return only internal non-HDD disks that cannot host a known role."""

    protected = {path for path in protected_disks if path}
    targets: list[BlockDevice] = []
    for device in devices:
        if not device.is_disk or not device.path:
            continue
        if device.path in protected or device.parent_disk in protected:
            continue
        if device.is_usb:
            continue
        if not _is_non_hdd_target(device):
            continue
        if device.size_bytes <= 0:
            continue
        targets.append(device)
    return targets


def safe_data_disk_targets(devices: Iterable[BlockDevice], protected_disks: Iterable[str]) -> list[BlockDevice]:
    """Return internal, explicitly rotational disks eligible as data HDDs.

    This is intentionally the inverse of the Windows target list: only a
    classical HDD (``ROTA=1``) is offered, never an SSD, USB device, or any
    disk carrying a protected role from the Magic Image medium.
    """

    protected = {path for path in protected_disks if path}
    targets: list[BlockDevice] = []
    for device in devices:
        if not device.is_disk or not device.path or device.size_bytes <= 0:
            continue
        if device.path in protected or device.parent_disk in protected:
            continue
        if device.is_usb or device.rotational is not True:
            continue
        targets.append(device)
    return targets


def build_data_disk_prepare_plan(
    data_disk: BlockDevice,
    restore_target: BlockDevice,
    inspection: MediaInspection,
    label: str = "Daten",
) -> DataDiskPreparePlan:
    """Build a serial-bound, optional preparation plan for a secondary HDD."""

    safe_label = _safe_name(label, "Daten")[:32]
    if not data_disk.is_disk or not data_disk.path:
        return DataDiskPreparePlan(False, "Daten-HDD ist kein physischer Datenträger.")
    if data_disk.path == restore_target.path or data_disk.parent_disk == restore_target.parent_disk:
        return DataDiskPreparePlan(False, "Daten-HDD darf niemals mit der Windows-Ziel-SSD identisch sein.")
    if data_disk.is_usb or data_disk.rotational is not True:
        return DataDiskPreparePlan(False, "Als Datenplatte sind nur interne, eindeutig erkannte HDDs zulässig.")
    if data_disk.path in inspection.protected_disks or data_disk.parent_disk in inspection.protected_disks:
        return DataDiskPreparePlan(False, "Die ausgewählte Daten-HDD gehört zum geschützten Installationsmedium.")
    serial = re.sub(r"\s+", "_", data_disk.serial.strip())
    if not serial or not re.fullmatch(r"[A-Za-z0-9._+-]+", serial):
        return DataDiskPreparePlan(False, "Daten-HDD hat keine nutzbare Seriennummer.")
    return DataDiskPreparePlan(
        True,
        "Daten-HDD wird nach erfolgreicher Windows-Installation als leere NTFS-Datenplatte vorbereitet.",
        disk_path=data_disk.path,
        disk_selector=f"SERIALNO={serial}",
        disk_model=data_disk.model,
        disk_size_bytes=data_disk.size_bytes,
        label=safe_label,
    )


def _normalise_token(value: object) -> str:
    return re.sub(r"[^a-z0-9]+", "", _text(value).casefold())


def _number(value: object) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _format_number(value: object, unit: str = "") -> str:
    number = _number(value)
    if number is None:
        return "unbekannt"
    display = str(int(number)) if number.is_integer() else f"{number:.1f}"
    return f"{display} {unit}".strip()


def _vendor_token(value: object) -> str:
    token = _normalise_token(value)
    aliases = {
        "hewlettpackard": "hp",
        "hpinc": "hp",
        "asustekcomputerinc": "asus",
        "asustek": "asus",
    }
    return aliases.get(token, token)


def _cpu_token(value: object) -> str:
    raw = re.sub(r"\((?:r|tm)\)", "", _text(value).casefold())
    # Prefer the actual CPU model.  This makes e.g. "Intel Celeron N4500"
    # and the short hardware form "N4500" comparable without accepting a
    # different N-series processor as the same model.
    core_match = re.search(
        r"\b(?:intel\s+)?core\s+(?:ultra\s+)?[3579]\s*\d{3,5}[a-z0-9-]*\b",
        raw,
    )
    if core_match:
        # Firmware sometimes reports "Core 5 120U" while the database says
        # "Intel Core 5 120U". Intel is the manufacturer prefix, not a CPU
        # model difference.
        return _normalise_token(re.sub(r"^intel\s+", "", core_match.group(0)))
    patterns = (
        r"\bi[3579][\s-]*\d{4,5}[a-z0-9-]*\b",
        r"\b(?:n|u|h|p)\d{3,5}[a-z0-9-]*\b",
        r"\b(?:ryzen\s*)?\d{4,5}[a-z0-9-]*\b",
    )
    for pattern in patterns:
        match = re.search(pattern, raw)
        if match:
            return _normalise_token(match.group(0))
    return _normalise_token(raw)


def _ram_type_token(value: object) -> str:
    token = _normalise_token(value)
    for candidate in ("lpddr5", "lpddr4", "ddr5", "ddr4", "ddr3"):
        if candidate in token:
            return candidate
    return token


def _ram_layout_token(value: object) -> str:
    pairs = [
        (int(count), int(size))
        for count, size in re.findall(r"\b(\d+)\s*x\s*(\d+)\b", _text(value).casefold())
    ]
    if not pairs:
        return _normalise_token(value)
    modules = [size for count, size in pairs for _index in range(count)]
    if len(set(modules)) == 1:
        return f"{len(modules)}x{modules[0]}"
    return "+".join(f"1x{size}" for size in sorted(modules))


def _storage_kind(value: object) -> str:
    token = _normalise_token(value)
    if "nvme" in token:
        return "nvme"
    if "emmc" in token:
        return "emmc"
    if "hdd" in token or "harddisk" in token:
        return "hdd"
    # The live hardware scan reliably distinguishes SATA from NVMe, but it
    # cannot determine whether a SATA SSD is a 2.5-inch or M.2 drive.  Treat
    # both SATA forms as one category; NVMe remains a strict mismatch.
    if "sata" in token and "ssd" in token:
        return "sata-ssd"
    if "ssd" in token:
        return "sata-ssd"
    return token


def _display_type_token(value: object) -> str:
    raw = _text(value).casefold()
    token = _normalise_token(raw)
    if "3840x2160" in token or "4k" in token or "uhd" in token:
        return "uhd"
    if "2560x1440" in token or "qhd" in token:
        return "qhd"
    if "1920x1080" in token or "fullhd" in token or token == "fhd":
        return "full-hd"
    if "1600x900" in token or "hdplus" in token or "hdplusplus" in token:
        return "hd-plus"
    if "1366x768" in token or token == "hd":
        return "hd"
    return token


def _comparison_line(label: str, actual: str, expected: str, config: str, unknown: bool = False) -> str:
    if unknown:
        return f"{label}: Gerät unbekannt – Config {config}: {expected} kann nicht sicher geprüft werden."
    return f"{label}: Gerät {actual} ≠ Config {config}: {expected}"


def _strict_config_differences(
    config: str, model: dict[str, object], snapshot: dict[str, object]
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Compare required production characteristics without using a score.

    A similarity score is useful for suggestions, but it must not turn a
    different RAM size, SSD form factor, CPU or panel into a green result.
    Unknown hardware is therefore a confirmation warning rather than a match.
    """

    mismatches: list[str] = []
    unknowns: list[str] = []

    def compare_text(
        label: str,
        actual_value: object,
        expected_value: object,
        normaliser: Callable[[object], str] = _normalise_token,
    ) -> None:
        expected = normaliser(expected_value)
        if not expected:
            return
        actual = normaliser(actual_value)
        expected_text = _text(expected_value)
        if not actual:
            unknowns.append(_comparison_line(label, "", expected_text, config, unknown=True))
        elif actual != expected:
            mismatches.append(_comparison_line(label, _text(actual_value), expected_text, config))

    def compare_number(
        label: str,
        actual_value: object,
        expected_value: object,
        unit: str,
        tolerance: float = 0.0,
    ) -> None:
        expected = _number(expected_value)
        if expected is None:
            return
        actual = _number(actual_value)
        expected_text = _format_number(expected_value, unit)
        if actual is None:
            unknowns.append(_comparison_line(label, "", expected_text, config, unknown=True))
        elif abs(actual - expected) > tolerance:
            mismatches.append(
                _comparison_line(label, _format_number(actual_value, unit), expected_text, config)
            )

    compare_text("Hersteller", snapshot.get("vendor_short") or snapshot.get("vendor"), model.get("vendor"), _vendor_token)
    compare_text("CPU", snapshot.get("cpu_short") or snapshot.get("cpu"), model.get("cpu"), _cpu_token)
    compare_number("RAM gesamt", snapshot.get("ram_total_gb"), model.get("ram_total"), "GB")
    compare_text("RAM-Typ", snapshot.get("ram_type"), model.get("ram_type"), _ram_type_token)
    compare_text("RAM-Bestückung", snapshot.get("ram_layout"), model.get("ram_layout"), _ram_layout_token)

    expected_modules = _number(model.get("ram_module_count"))
    if expected_modules is not None:
        actual_modules = _ram_module_count(snapshot.get("ram_layout"))
        expected_text = _format_number(expected_modules, "Module")
        if actual_modules is None:
            unknowns.append(_comparison_line("RAM-Module", "", expected_text, config, unknown=True))
        elif int(actual_modules) != int(expected_modules):
            mismatches.append(
                _comparison_line("RAM-Module", _format_number(actual_modules, "Module"), expected_text, config)
            )

    expected_storage = _storage_kind(model.get("storage_type"))
    actual_storage = _storage_kind(snapshot.get("primary_storage_type"))
    if expected_storage:
        expected_text = _text(model.get("storage_type"))
        if not actual_storage:
            unknowns.append(_comparison_line("SSD-Typ", "", expected_text, config, unknown=True))
        elif actual_storage != expected_storage:
            mismatches.append(
                _comparison_line("SSD-Typ", _text(snapshot.get("primary_storage_type")), expected_text, config)
            )

    # HardwareCheck deliberately normalises manufacturer capacities such as
    # 512/500/480 GB and 1 TB/1000/960 GB before deciding that a disk differs.
    expected_disk = _number(model.get("ssd"))
    actual_disk = _number(snapshot.get("primary_disk_gb"))
    if expected_disk is not None:
        expected_text = _format_number(model.get("ssd"), "GB")
        if actual_disk is None:
            unknowns.append(_comparison_line("SSD-Größe", "", expected_text, config, unknown=True))
        else:
            capacity_groups = (
                {120, 128},
                {240, 250, 256},
                {480, 500, 512},
                {960, 1000, 1024},
                {1920, 2000, 2048},
                {3840, 4000, 4096},
            )
            actual_round = int(round(actual_disk))
            expected_round = int(round(expected_disk))
            equivalent = actual_round == expected_round or any(
                actual_round in group and expected_round in group for group in capacity_groups
            )
            if not equivalent:
                mismatches.append(
                    _comparison_line("SSD-Größe", _format_number(actual_disk, "GB"), expected_text, config)
                )

    compare_text("Display-Auflösung", snapshot.get("display_type"), model.get("display_type"), _display_type_token)
    compare_number("Display-Größe", snapshot.get("display_inches"), model.get("inch"), '"', tolerance=0.35)

    # A product/SKU number is intentionally *not* a release criterion.  It
    # is often unavailable or written differently by the firmware even for
    # the same device.  The actual, install-relevant hardware above (CPU,
    # RAM, storage and display) is the source of truth for a green result.
    return tuple(mismatches), tuple(unknowns)


def _ram_module_count(value: object) -> int | None:
    """Extract a module count from the normalized live RAM layout."""

    pairs = re.findall(r"\b(\d+)\s*x\s*\d+\b", _text(value).casefold())
    if not pairs:
        return None
    return sum(int(count) for count in pairs)


def _matching_classic_acronis_images(
    config: str, classic_acronis_images: Iterable[ClassicAcronisImage] | None
) -> tuple[ClassicAcronisImage, ...]:
    if classic_acronis_images is None:
        return ()
    return tuple(image for image in classic_acronis_images if image.config == config)


def _classic_acronis_note(images: tuple[ClassicAcronisImage, ...]) -> str:
    if not images:
        return "Kein klassisches Acronis-Image für diese Config gefunden."
    return "Klassisches Acronis-Image vorhanden: " + "; ".join(image.display_text for image in images)


def confirm_config_override(validation: ConfigValidation) -> ConfigValidation:
    """Record the operator's explicit acknowledgement for a warning only."""

    if validation.valid and validation.requires_confirmation:
        return replace(validation, override_confirmed=True)
    return validation


def validate_config(
    config: object,
    models: Iterable[dict[str, object]],
    snapshot: dict[str, object],
    scorer: Callable[..., object],
    available_configs: Iterable[str] | None = None,
    classic_acronis_images: Iterable[ClassicAcronisImage] | None = None,
    config_profiles: dict[str, dict[str, object]] | None = None,
    complete_images: Iterable[MagicImage] | None = None,
) -> ConfigValidation:
    """Validate an entered production config and show exact hardware deltas.

    The existing similarity score remains informative, but it is never the
    final pass criterion.  Each required characteristic is checked separately
    so two Lenovo devices with a high family score still warn for a RAM, SSD,
    CPU or display mismatch.
    """

    value = _text(config)
    if not re.fullmatch(r"\d{4}", value):
        return ConfigValidation(value, False, 0, "Config muss genau vier Ziffern enthalten.")

    acronis = _matching_classic_acronis_images(value, classic_acronis_images)
    config_folders = {_text(item) for item in available_configs} if available_configs is not None else set()
    matching_complete = tuple(image for image in (complete_images or ())
                              if image.deployment_mode == "complete" and value in image.model_configs)
    if available_configs is not None and value not in config_folders and matching_complete:
        return ConfigValidation(
            value, True, 0,
            "Clonezilla-Image gefunden.",
            classic_acronis_images=acronis,
            deployment_mode="complete",
            complete_images=matching_complete,
        )
    model = next((item for item in models if _text(item.get("model_id")) == value), None)
    profile_model = dict((config_profiles or {}).get(value) or {})
    if model is not None and profile_model.get("inch") not in (None, ""):
        # A config folder can carry a manually confirmed physical panel size.
        # It is more specific than a possibly stale model database row and must
        # therefore win for the display-size safety check.
        model = dict(model)
        model["inch"] = profile_model["inch"]
    model_from_config_folder = model is None and bool(profile_model)
    if model is None and profile_model:
        # The #configs folder is the primary deployment definition.  A full
        # model.json row adds manufacturer/SKU context, but must not be a
        # prerequisite for comparing the concrete values stored alongside the
        # deployment scripts themselves.
        model = profile_model
    if model is None:
        # Some long-standing production configurations predate their matching
        # model.json records.  The actual #configs folder is still a valid
        # Windows deployment configuration and must not disappear merely
        # because its descriptive hardware record is missing.  It deliberately
        # never becomes a green match: an operator has to acknowledge that no
        # automatic hardware comparison can be made before a restore is
        # possible.  A random/unknown four-digit number remains blocked.
        if value in config_folders:
            return ConfigValidation(
                value,
                True,
                0,
                f"ACHTUNG: Legacy-Config #configs\\{value} ist vorhanden, aber der Eintrag in model.json fehlt. "
                "Kein automatischer Hardwarevergleich möglich – bitte bewusst bestätigen.",
                details=(
                    "Hardware-Abgleich: Für diese vorhandene Legacy-Config fehlen die "
                    "Hardwaredaten in model.json. Die Config kann nur nach bewusster "
                    "Bestätigung verwendet werden.",
                ),
                strict_match=False,
                requires_confirmation=True,
                magic_config_available=True,
                legacy_config_without_model=True,
                classic_acronis_images=acronis,
            )
        return ConfigValidation(
            value,
            False,
            0,
            f"Keine Magic-Config {value} in model.json. {_classic_acronis_note(acronis)}",
            classic_acronis_images=acronis,
        )

    magic_config_available = available_configs is None or value in config_folders
    if not magic_config_available:
        if config_folders:
            missing = f"#configs\\{value} wurde auf dem Image-Medium nicht gefunden."
        else:
            missing = "Kein lesbarer #configs-Ordner auf dem Image-Medium erkannt."
        return ConfigValidation(
            value,
            False,
            0,
            f"Keine moderne Magic-Config: {missing} {_classic_acronis_note(acronis)}",
            model,
            magic_config_available=False,
            classic_acronis_images=acronis,
        )

    if model_from_config_folder:
        # A partial profile has no model family/name to score.  Strict value
        # checks below remain the actual safety gate in this situation.
        score = 0
    else:
        try:
            raw_result = scorer(snapshot, model, include_exclusion_reason=True)
        except Exception as exc:
            return ConfigValidation(
                value,
                False,
                0,
                f"Hardware-Abgleich fehlgeschlagen: {exc}",
                model,
                magic_config_available=True,
                classic_acronis_images=acronis,
            )
        result = raw_result if isinstance(raw_result, dict) else {}
        try:
            score = int(result.get("score") or 0)
        except (TypeError, ValueError):
            score = 0
    mismatches, unknowns = _strict_config_differences(value, model, snapshot)
    if model_from_config_folder:
        missing_profile_fields = tuple(
            label for key, label in (
                ("cpu", "CPU"),
                ("ram_total", "RAM gesamt"),
                ("ssd", "SSD-Größe"),
                ("display_type", "Display-Auflösung"),
            ) if not _text(model.get(key))
        )
        unknowns = unknowns + tuple(
            f"Config-Ordner: Sollwert für {label} fehlt; kein grüner Match ohne bewusste Bestätigung."
            for label in missing_profile_fields
        )
    details = mismatches + unknowns
    if mismatches:
        return ConfigValidation(
            value,
            True,
            score,
            f"ROTE WARNUNG: {len(mismatches)} Hardware-Abweichung(en) zur Config {value}. Bitte erst bewusst bestätigen.",
            model,
            details,
            strict_match=False,
            requires_confirmation=True,
            magic_config_available=True,
            classic_acronis_images=acronis,
        )
    if unknowns:
        return ConfigValidation(
            value,
            True,
            score,
            f"ACHTUNG: Hardwarevergleich für Config {value} ist unvollständig. Kein grüner Match ohne bewusste Bestätigung.",
            model,
            details,
            strict_match=False,
            requires_confirmation=True,
            magic_config_available=True,
            classic_acronis_images=acronis,
        )
    return ConfigValidation(
        value,
        True,
        score,
        f"Config {value} passt exakt zu allen prüfbaren Hardwaremerkmalen ({score} % Modellähnlichkeit).",
        model,
        (),
        strict_match=True,
        magic_config_available=True,
        classic_acronis_images=acronis,
    )


def discover_config_ids(repository_roots: Iterable[str]) -> set[str]:
    """Return four-digit configuration folders from verified repositories."""

    configs: set[str] = set()
    for root_text in repository_roots:
        root = pathlib.Path(root_text)
        config_root = root / "#configs"
        try:
            for candidate in config_root.iterdir():
                if candidate.is_dir() and re.fullmatch(r"\d{4}", candidate.name):
                    configs.add(candidate.name)
        except OSError:
            continue
    return configs


def _config_profile_text(config_directory: pathlib.Path, filename: str) -> str:
    """Read one small legacy config value without executing any script."""

    scripts = config_directory / "skripte"
    try:
        children = tuple(scripts.iterdir())
    except OSError:
        return ""
    candidate = next(
        (child for child in children if child.is_file() and child.name.casefold() == filename.casefold()),
        None,
    )
    if candidate is None:
        return ""
    try:
        return candidate.read_text(encoding="utf-8-sig", errors="replace").strip()
    except OSError:
        return ""


def _config_profile_number(value: object) -> float | None:
    match = re.search(r"[-+]?\d+(?:[.,]\d+)?", _text(value))
    if not match:
        return None
    try:
        return float(match.group(0).replace(",", "."))
    except ValueError:
        return None


def _config_profile_ssd_gb(value: object) -> int | None:
    """Convert the usable C: size stored by old scripts to SSD capacity."""

    raw = _config_profile_number(value)
    if raw is None or raw <= 0:
        return None
    capacities = (128, 256, 512, 1000, 2000, 4000)
    # A freshly restored Windows C: partition is typically about 93 % of the
    # advertised SSD.  Accept either the usable value or full capacity.
    capacity = min(capacities, key=lambda item: min(abs(raw - item), abs(raw - (item * 0.931))))
    tolerance = max(16.0, capacity * 0.10)
    return capacity if min(abs(raw - capacity), abs(raw - (capacity * 0.931))) <= tolerance else int(round(raw))


def _config_profile_ram_gb(value: object) -> int | None:
    raw = _config_profile_number(value)
    if raw is None or raw <= 0:
        return None
    common_sizes = (4, 8, 12, 16, 20, 24, 32, 40, 48, 64)
    capacity = min(common_sizes, key=lambda item: abs(raw - item))
    return capacity if abs(raw - capacity) <= 1.0 else int(round(raw))


def _config_folder_profile(config_directory: pathlib.Path) -> dict[str, object]:
    """Build a read-only hardware profile from a ``#configs/XXXX`` folder.

    Legacy deployment folders already contain the values later checked in
    Windows.  Reusing those small text files means a newly added config does
    not have to wait for a separate model.json entry before it can be checked.
    Missing values are intentionally left blank and therefore require an
    explicit acknowledgement instead of yielding a green match.
    """

    profile: dict[str, object] = {"model_id": config_directory.name, "_source": "config-folder"}
    cpu = _config_profile_text(config_directory, "CPU.txt")
    if cpu:
        profile["cpu"] = cpu
    ram_total = _config_profile_ram_gb(_config_profile_text(config_directory, "RAM.txt"))
    if ram_total is not None:
        profile["ram_total"] = ram_total
    ssd = _config_profile_ssd_gb(_config_profile_text(config_directory, "driveCsize.txt"))
    if ssd is not None:
        profile["ssd"] = ssd
    resolution = _config_profile_text(config_directory, "resolution.txt")
    if resolution:
        profile["display_type"] = resolution
    # ``inch-size.txt`` from the legacy creator is calculated from resolution
    # at a fixed 96 DPI (for example 1920x1080 becomes 22.9 inch).  It is not
    # a panel measurement and must not be used as expected hardware.  New or
    # migrated configs store the confirmed physical diagonal separately.
    inches = _config_profile_number(
        _config_profile_text(config_directory, "physical-display-size.txt")
    )
    if inches is not None and inches > 0:
        profile["inch"] = inches
    modules = _config_profile_number(_config_profile_text(config_directory, "ram-modules-amount.txt"))
    if modules is not None and modules > 0 and modules.is_integer():
        profile["ram_module_count"] = int(modules)
    return profile if len(profile) > 2 else {}


def discover_config_profiles(repository_roots: Iterable[str]) -> dict[str, dict[str, object]]:
    """Read direct config-folder hardware profiles from verified repositories."""

    profiles: dict[str, dict[str, object]] = {}
    for root_text in repository_roots:
        config_root = pathlib.Path(root_text) / "#configs"
        try:
            candidates = tuple(config_root.iterdir())
        except OSError:
            continue
        for candidate in candidates:
            if not candidate.is_dir() or not re.fullmatch(r"\d{4}", candidate.name):
                continue
            profile = _config_folder_profile(candidate)
            previous = profiles.get(candidate.name, {})
            if len(profile) > len(previous):
                profiles[candidate.name] = profile
    return profiles


_ACRONIS_SUFFIXES = {".tib", ".tibx"}
_CONFIG_IN_NAME = re.compile(r"(?<!\d)(\d{4})(?!\d)")


def _acronis_files(folder: pathlib.Path) -> tuple[tuple[str, ...], int]:
    """Read only Acronis payload names below one model folder.

    The result is intentionally capped.  Split Acronis backups may have many
    files, but the UI only needs evidence that the legacy model image exists.
    """

    paths: list[str] = []
    total_bytes = 0
    try:
        candidates = folder.rglob("*")
        for candidate in candidates:
            if not candidate.is_file() or candidate.suffix.casefold() not in _ACRONIS_SUFFIXES:
                continue
            try:
                total_bytes += candidate.stat().st_size
            except OSError:
                pass
            paths.append(str(candidate))
            if len(paths) >= 128:
                break
    except OSError:
        return (), 0
    return tuple(sorted(paths, key=str.casefold)), total_bytes


def discover_classic_acronis_images(
    repository_roots: Iterable[str], config_filter: str = ""
) -> list[ClassicAcronisImage]:
    """Discover model-bound ``.tib``/``.tibx`` backups on an Image partition.

    Historical Acronis folders typically use ``<vendor>/<config> (...)``.
    Only folders carrying a four-digit config and real Acronis files are
    reported; Clonezilla folders, `#configs`, and arbitrary files are ignored.
    This does not mount, alter, or start Acronis.

    ``config_filter`` is intentionally optional for compatibility.  The
    embedded HardwareCheck Magic Image page uses it after a user enters a
    missing config, avoiding an expensive recursive scan of every legacy
    Acronis image merely to open the page.
    """

    requested_config = config_filter.strip()
    if requested_config and not re.fullmatch(r"\d{4}", requested_config):
        return []
    results: list[ClassicAcronisImage] = []
    seen_folders: set[str] = set()
    for root_text in repository_roots:
        root = pathlib.Path(root_text)
        try:
            vendor_folders = [child for child in root.iterdir() if child.is_dir() and not child.name.startswith("#")]
        except OSError:
            continue
        for vendor_folder in sorted(vendor_folders, key=lambda item: item.name.casefold()):
            try:
                model_folders = [vendor_folder, *[child for child in vendor_folder.iterdir() if child.is_dir()]]
            except OSError:
                model_folders = [vendor_folder]
            for model_folder in model_folders:
                match = _CONFIG_IN_NAME.search(model_folder.name)
                if not match:
                    continue
                if requested_config and match.group(1) != requested_config:
                    continue
                try:
                    folder_key = str(model_folder.resolve())
                except OSError:
                    folder_key = str(model_folder)
                if folder_key in seen_folders:
                    continue
                seen_folders.add(folder_key)
                file_paths, total_bytes = _acronis_files(model_folder)
                if not file_paths:
                    continue
                results.append(
                    ClassicAcronisImage(
                        config=match.group(1),
                        vendor=vendor_folder.name,
                        source_folder=str(model_folder),
                        file_paths=file_paths,
                        total_bytes=total_bytes,
                    )
                )
    return sorted(results, key=lambda item: (item.config, item.vendor.casefold(), item.source_folder.casefold()))


def _tool_media_disk(inspection: MediaInspection) -> str:
    """Return the physical disk which actually contains this running program.

    More than one HardwareCheck medium can be connected.  An Acronis hand-off
    must never guess between them: only the partition on the same disk as this
    module is eligible.
    """

    tool_root = pathlib.Path(__file__).resolve().parent
    matches = [
        role.parent_disk
        for role in inspection.roles
        if role.role == "hardwarecheck" and _inside(pathlib.Path(role.mountpoint), tool_root)
    ]
    return matches[0] if len(matches) == 1 else ""


def _partition_number(device: BlockDevice) -> int:
    match = re.search(r"(\d+)$", device.name)
    return int(match.group(1)) if match else 0


def _acronis_boot_file_is_readable(partition: BlockDevice) -> tuple[bool, str]:
    """Verify Acronis' EFI loader without permanently mounting the partition.

    The normal Magic Image scan deliberately skips the Acronis partition.  It
    is a Windows/WinPE medium and has no images or configs needed for the
    regular page.  The manual Acronis fallback, however, must be able to
    verify its boot loader even when Debian did not auto-mount that FAT
    partition.  Mount it directly, read-only and only for this short check.
    """

    expected = pathlib.PureWindowsPath(ACRONIS_EFI_PATH).parts[1:]
    roots = [pathlib.Path(path) for path in partition.mountpoints]
    if roots:
        return any((root.joinpath(*expected)).is_file() for root in roots), ""

    workspace = pathlib.Path("/run/hardwarecheck-acronis-verify")
    target = workspace / _safe_name(partition.name, "acronis")
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return False, f"Prüfordner für die Acronis-Partition konnte nicht angelegt werden: {exc}"

    mounted = False
    try:
        result = subprocess.run(
            ["mount", "-o", "ro,nosuid,nodev,noexec", partition.path, str(target)],
            capture_output=True,
            text=True,
            timeout=MEDIA_MOUNT_COMMAND_TIMEOUT_SECONDS,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "unbekannter Mount-Fehler").strip()
            return False, f"Acronis-Partition konnte nicht lesbar eingebunden werden: {detail}"
        mounted = True
        return (target.joinpath(*expected)).is_file(), ""
    except (OSError, subprocess.SubprocessError) as exc:
        return False, f"Acronis-Partition konnte nicht lesbar eingebunden werden: {exc}"
    finally:
        if mounted:
            subprocess.run(
                ["umount", str(target)],
                capture_output=True,
                text=True,
                timeout=MEDIA_MOUNT_COMMAND_TIMEOUT_SECONDS,
                check=False,
            )
        try:
            target.rmdir()
        except OSError:
            pass


def build_acronis_boot_plan(inspection: MediaInspection) -> AcronisBootPlan:
    """Verify a one-time Acronis boot target without touching EFI variables."""

    if not sys.platform.startswith("linux"):
        return AcronisBootPlan(False, "Acronis kann nur aus dem HardwareCheck-Debian gestartet werden.")
    parent_disk = _tool_media_disk(inspection)
    if not parent_disk:
        return AcronisBootPlan(
            False,
            "Das laufende HardwareCheck-Medium konnte nicht eindeutig zugeordnet werden.",
        )
    matches = [
        device
        for device in inspection.devices
        if device.type == "part"
        and device.parent_disk == parent_disk
        and device.label.casefold() == ACRONIS_PARTITION_LABEL.casefold()
    ]
    if len(matches) != 1:
        return AcronisBootPlan(
            False,
            "Keine eindeutige Acronis-Partition auf dem laufenden HardwareCheck-Medium gefunden.",
            parent_disk=parent_disk,
        )
    partition = matches[0]
    number = _partition_number(partition)
    if not number:
        return AcronisBootPlan(False, "Die Acronis-Partitionsnummer konnte nicht bestimmt werden.", parent_disk)
    boot_file_found, detail = _acronis_boot_file_is_readable(partition)
    if not boot_file_found:
        message = "Der Acronis-UEFI-Startpunkt wurde auf der Acronis-Partition nicht gefunden."
        if detail:
            message = detail
        return AcronisBootPlan(
            False,
            message,
            parent_disk,
            partition.path,
            number,
        )
    return AcronisBootPlan(
        True,
        "Acronis auf demselben geschützten Medium geprüft. Der Neustart öffnet Acronis ohne Restore.",
        parent_disk,
        partition.path,
        number,
    )


def _efivar_path(variable: str) -> pathlib.Path | None:
    root = pathlib.Path("/sys/firmware/efi/efivars")
    if not root.is_dir():
        return None
    target = variable.casefold() + "-"
    for candidate in root.iterdir():
        if candidate.name.casefold().startswith(target):
            return candidate
    return root / f"{variable}-{EFI_GLOBAL_VARIABLE_GUID}"


def _read_efi_variable(variable: str) -> bytes:
    path = _efivar_path(variable)
    if path is None or not path.is_file():
        raise OSError(f"UEFI-Variable {variable} nicht verfügbar")
    payload = path.read_bytes()
    if len(payload) < 5:
        raise OSError(f"UEFI-Variable {variable} ist unvollständig")
    return payload


def _split_efi_device_path(payload: bytes) -> list[bytes]:
    nodes: list[bytes] = []
    offset = 0
    while offset + 4 <= len(payload):
        node_length = struct.unpack_from("<H", payload, offset + 2)[0]
        if node_length < 4 or offset + node_length > len(payload):
            raise ValueError("ungültiger UEFI-Gerätepfad")
        node = payload[offset : offset + node_length]
        nodes.append(node)
        offset += node_length
        if node[0] == 0x7F and node[1] == 0xFF:
            break
    if offset != len(payload) or not nodes or nodes[-1][:2] != b"\x7f\xff":
        raise ValueError("unvollständiger UEFI-Gerätepfad")
    return nodes


def _current_boot_option() -> tuple[int, bytes]:
    current = _read_efi_variable("BootCurrent")
    if len(current) < 6:
        raise OSError("UEFI BootCurrent ist unvollständig")
    number = struct.unpack_from("<H", current, 4)[0]
    return number, _read_efi_variable(f"Boot{number:04X}")[4:]


def _decode_boot_option(option: bytes) -> tuple[str, bytes, bytes]:
    if len(option) < 8:
        raise ValueError("UEFI-Booteintrag ist unvollständig")
    _attributes, path_length = struct.unpack_from("<IH", option, 0)
    position = 6
    while position + 2 <= len(option):
        if option[position : position + 2] == b"\x00\x00":
            description = option[6:position].decode("utf-16-le", errors="replace")
            position += 2
            break
        position += 2
    else:
        raise ValueError("UEFI-Booteintrag ohne Beschreibung")
    end = position + path_length
    if end > len(option):
        raise ValueError("UEFI-Booteintrag enthält einen ungültigen Gerätepfad")
    return description, option[position:end], option[end:]


def _hard_drive_node(device_path: bytes) -> bytes:
    """Return the EFI HD() node which identifies a concrete partition."""

    node = next(
        (item for item in _split_efi_device_path(device_path) if item[:2] == b"\x04\x01" and len(item) == 42),
        None,
    )
    if node is None:
        raise ValueError("Der aktuelle UEFI-Booteintrag enthält keinen nutzbaren Festplattenpfad")
    return node


def _hard_drive_extents(device_path: bytes) -> set[tuple[int, int]]:
    """Return every HD() start/size pair from a UEFI device path.

    Logical MBR partitions are represented by two HD() nodes by several
    firmwares: the extended partition followed by the logical volume.  The
    currently booted GRUB partition is therefore identified by its start and
    size, not merely by the first partition number in the path.
    """

    extents: set[tuple[int, int]] = set()
    for node in _split_efi_device_path(device_path):
        if node[:2] != b"\x04\x01" or len(node) != 42:
            continue
        extents.add((struct.unpack_from("<Q", node, 8)[0], struct.unpack_from("<Q", node, 16)[0]))
    if not extents:
        raise ValueError("Der aktuelle UEFI-Booteintrag enthält keinen nutzbaren Festplattenpfad")
    return extents


def _partition_extent(partition: BlockDevice) -> tuple[int, int]:
    sysfs = pathlib.Path("/sys/class/block") / partition.name
    try:
        return (
            int((sysfs / "start").read_text(encoding="ascii").strip()),
            int((sysfs / "size").read_text(encoding="ascii").strip()),
        )
    except (OSError, ValueError) as exc:
        raise OSError(f"Partitionsdaten von {partition.label} konnten nicht gelesen werden: {exc}") from exc


def _current_grub_boot_partition(
    inspection: MediaInspection, parent_disk: str, boot_option: bytes
) -> BlockDevice:
    """Find the exact GRUB partition selected by the active UEFI entry."""

    _description, device_path, _optional = _decode_boot_option(boot_option)
    active_extents = _hard_drive_extents(device_path)
    matches = [
        partition
        for partition in _grub_boot_partitions(inspection, parent_disk)
        if _partition_extent(partition) in active_extents
    ]
    if len(matches) != 1:
        labels = ", ".join(partition.label for partition in _grub_boot_partitions(inspection, parent_disk))
        raise OSError(
            "Die aktuell gestartete GRUB-Partition konnte nicht eindeutig zugeordnet werden "
            f"(erwartet eine von: {labels})."
        )
    return matches[0]


def _native_acronis_boot_option(source_path: bytes, partition_name: str, partition_number: int) -> tuple[int, str] | None:
    """Find the firmware's own boot entry for the verified Acronis partition.

    Some UEFI implementations reject entries assembled by software even when
    their visible fields look correct.  Reusing the firmware-created entry is
    therefore safer: BootOrder remains untouched and BootNext only points to
    a boot target that the same firmware already exposes in its boot menu.
    """

    source_node = _hard_drive_node(source_path)
    sysfs = pathlib.Path("/sys/class/block") / partition_name
    try:
        target_start = int((sysfs / "start").read_text(encoding="ascii").strip())
        target_size = int((sysfs / "size").read_text(encoding="ascii").strip())
    except (OSError, ValueError) as exc:
        raise ValueError(f"Acronis-Partitionsdaten nicht lesbar: {exc}") from exc
    source_signature = source_node[24:42]
    root = pathlib.Path("/sys/firmware/efi/efivars")
    for candidate in sorted(root.glob("Boot????-*")):
        match = re.match(r"Boot([0-9A-Fa-f]{4})-", candidate.name)
        if not match:
            continue
        try:
            _description, device_path, _optional = _decode_boot_option(candidate.read_bytes()[4:])
            node = _hard_drive_node(device_path)
        except (OSError, ValueError, struct.error):
            continue
        candidate_partition = struct.unpack_from("<I", node, 4)[0]
        candidate_start = struct.unpack_from("<Q", node, 8)[0]
        candidate_size = struct.unpack_from("<Q", node, 16)[0]
        if (
            candidate_partition == partition_number
            and candidate_start == target_start
            and candidate_size == target_size
            and node[24:42] == source_signature
        ):
            return int(match.group(1), 16), _description
    return None


def _efi_file_path(device_path: bytes) -> str:
    """Return the EFI File() node from a UEFI device path, if present."""

    for node in _split_efi_device_path(device_path):
        if node[:2] != b"\x04\x04" or len(node) < 6:
            continue
        return node[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
    return ""


def _efi_hd_node_matches_partition(node: bytes, partition: BlockDevice) -> bool:
    """Match a GPT HD() node to exactly one Linux partition.

    Start/size alone are insufficient: cloned or similarly sized disks can
    have identical extents.  The GPT partition GUID therefore has to match as
    well before a firmware entry may ever be used as a Windows boot target.
    """

    if len(node) != 42 or node[:2] != b"\x04\x01" or node[40] != 2 or node[41] != 2:
        return False
    try:
        start, size = _partition_extent(partition)
        signature = uuid.UUID(partition.partuuid).bytes_le
    except (OSError, ValueError, AttributeError):
        return False
    return (
        struct.unpack_from("<Q", node, 8)[0] == start
        and struct.unpack_from("<Q", node, 16)[0] == size
        and node[24:40] == signature
    )


def _windows_boot_options_for_partition(
    partition: BlockDevice, efi_root: pathlib.Path | None = None
) -> list[tuple[int, str]]:
    """Find active entries for the exact Microsoft loader on ``partition``."""

    root = efi_root if efi_root is not None else pathlib.Path("/sys/firmware/efi/efivars")
    if not root.is_dir():
        return []
    matches: list[tuple[int, str]] = []
    for candidate in sorted(root.glob("Boot????-*")):
        number_match = re.match(r"Boot([0-9A-Fa-f]{4})-", candidate.name)
        if number_match is None:
            continue
        try:
            option = candidate.read_bytes()[4:]
            if not (struct.unpack_from("<I", option)[0] & 1):
                continue
            description, device_path, _optional = _decode_boot_option(option)
            hd_node = _hard_drive_node(device_path)
        except (OSError, ValueError, struct.error):
            continue
        if not _efi_hd_node_matches_partition(hd_node, partition):
            continue
        file_path = _efi_file_path(device_path).replace("/", "\\").casefold()
        # Clonezilla can create a Windows-labelled entry with ``-l ''``.
        # That requests firmware default-loader discovery, not the Microsoft
        # file we actually verified. Do not treat that as a verified Windows
        # start: reuse an explicit entry or create one without changing BootOrder.
        if description not in {"Windows Boot Manager", WINDOWS_BOOT_DESCRIPTION}:
            continue
        if file_path != WINDOWS_EFI_PATH.casefold():
            continue
        matches.append((int(number_match.group(1), 16), description))
    return matches


def _windows_efi_boot_file_is_readable(partition: BlockDevice) -> tuple[bool, str]:
    """Verify the restored Microsoft boot file without writing to the ESP."""

    relative = pathlib.Path("EFI") / "Microsoft" / "Boot" / "bootmgfw.efi"
    for mountpoint in partition.mountpoints:
        candidate = pathlib.Path(mountpoint) / relative
        try:
            if candidate.is_file() and candidate.stat().st_size > 0:
                return True, ""
        except OSError:
            continue
    if not re.fullmatch(r"/dev/[A-Za-z0-9._-]+", partition.path):
        return False, "EFI-Partitionspfad ist ungültig."
    workspace = pathlib.Path("/run/hardwarecheck-windows-boot") / f"esp-{os.getpid()}-{partition.name}"
    mounted = False
    try:
        workspace.mkdir(parents=True, exist_ok=True)
        result = subprocess.run(
            ["mount", "-o", "ro,nosuid,nodev", partition.path, str(workspace)],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "unbekannter Mount-Fehler").strip()
            return False, f"EFI-Partition konnte nicht schreibgeschützt geprüft werden: {detail}"
        mounted = True
        candidate = workspace / relative
        if not candidate.is_file() or candidate.stat().st_size <= 0:
            return False, "Die wiederhergestellte EFI-Partition enthält keinen Windows Boot Manager."
        return True, ""
    except (OSError, subprocess.SubprocessError) as exc:
        return False, f"EFI-Partition konnte nicht geprüft werden: {exc}"
    finally:
        if mounted:
            try:
                subprocess.run(["umount", str(workspace)], capture_output=True, text=True, timeout=10, check=False)
            except (OSError, subprocess.SubprocessError):
                pass
        try:
            workspace.rmdir()
            workspace.parent.rmdir()
        except OSError:
            pass


def _create_windows_boot_option(target_disk: BlockDevice, partition: BlockDevice) -> tuple[int | None, str]:
    """Create a target-bound Windows entry without changing UEFI BootOrder."""

    executable = shutil.which("efibootmgr")
    number = _partition_number(partition)
    if not executable:
        return None, "efibootmgr ist im Live-System nicht verfügbar."
    if not number:
        return None, "Die EFI-Partitionsnummer der Ziel-SSD konnte nicht bestimmt werden."
    result = subprocess.run(
        [
            executable,
            "--create-only",
            "--disk",
            target_disk.path,
            "--part",
            str(number),
            "--label",
            WINDOWS_BOOT_DESCRIPTION,
            "--loader",
            WINDOWS_EFI_PATH,
        ],
        capture_output=True,
        text=True,
        timeout=15,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "unbekannter Fehler").strip()
        return None, f"temporärer Windows-UEFI-Eintrag konnte nicht erstellt werden: {detail}"
    created = [
        candidate_number
        for candidate_number, description in _windows_boot_options_for_partition(partition)
        if description == WINDOWS_BOOT_DESCRIPTION
    ]
    if len(created) != 1:
        return None, "der erstellte Windows-UEFI-Eintrag konnte nicht eindeutig geprüft werden."
    return created[0], ""


def schedule_restored_windows_boot_once(
    target_disk: BlockDevice, devices: Iterable[BlockDevice]
) -> WindowsBootResult:
    """Set UEFI BootNext to the Windows EFI system partition on ``target_disk``.

    ASUS systems often retain the external install SSD as their normal first
    boot target.  This function never modifies ``BootOrder``.  It only writes
    the single-use UEFI ``BootNext`` value after the target ESP and its
    explicit bootmgfw.efi path have been verified. The value is read back;
    success confirms the requested setting, not a firmware boot test.
    """

    if not sys.platform.startswith("linux"):
        return WindowsBootResult(False, "Windows-Einmalstart ist nur im HardwareCheck-Debian verfügbar.")
    if getattr(os, "geteuid", lambda: 1)() != 0:
        return WindowsBootResult(False, "Windows-Einmalstart benötigt Root-Rechte im Live-System.")
    if not target_disk.is_disk or target_disk.is_usb:
        return WindowsBootResult(False, "Die wiederhergestellte Ziel-SSD ist nicht als interner Datenträger verifiziert.")

    devices = list(devices)
    esp_candidates = [
        device
        for device in devices
        if (
            device.type == "part"
            and device.parent_disk == target_disk.path
            and device.filesystem.casefold() in WINDOWS_ESP_FILESYSTEMS
            and device.partuuid
        )
    ]
    verified: list[BlockDevice] = []
    errors: list[str] = []
    for partition in esp_candidates:
        ready, detail = _windows_efi_boot_file_is_readable(partition)
        if ready:
            verified.append(partition)
        elif detail:
            errors.append(detail)
    if len(verified) != 1:
        suffix = f" ({errors[0]})" if errors else ""
        return WindowsBootResult(
            False,
            "Windows-EFI-Partition der wiederhergestellten Ziel-SSD konnte nicht eindeutig geprüft werden." + suffix,
        )
    esp = verified[0]
    if sum(d.type == "part" and d.partuuid.casefold() == esp.partuuid.casefold() for d in devices) != 1:
        return WindowsBootResult(False, "Windows-EFI-Partitionskennung ist auf mehreren Partitionen vorhanden.")
    options = _windows_boot_options_for_partition(esp)
    native = [number for number, description in options if description == "Windows Boot Manager"]
    created = [number for number, description in options if description == WINDOWS_BOOT_DESCRIPTION]
    if native:
        # These entries have already been filtered by exact target ESP GUID,
        # active flag and explicit Microsoft loader. Duplicate names do not
        # constitute multiple target disks. Never delete firmware entries.
        boot_number = min(native)
        created_entry = False
    elif created:
        boot_number = min(created)
        created_entry = False
    else:
        try:
            boot_number, detail = _create_windows_boot_option(target_disk, esp)
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            return WindowsBootResult(False, f"Windows-UEFI-Eintrag konnte nicht erstellt werden: {exc}")
        if boot_number is None:
            return WindowsBootResult(False, detail)
        created_entry = True
    expected_next = struct.pack("<H", boot_number)
    try:
        _write_efi_variable("BootNext", expected_next)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return WindowsBootResult(False, f"UEFI BootNext für Windows konnte nicht gesetzt werden: {exc}")
    try:
        readback = _read_efi_variable("BootNext")
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return WindowsBootResult(False, f"UEFI BootNext für Windows konnte nicht zurückgelesen werden (erwartet Boot{boot_number:04X}): {exc}")
    if len(readback) != 6 or readback[4:] != expected_next:
        observed = f"Boot{struct.unpack_from('<H', readback, 4)[0]:04X}" if len(readback) == 6 else "ungültiger Wert"
        # Do not overwrite/delete an unexpected value: another component may
        # have set it. The actual next boot target is not verified in this case.
        return WindowsBootResult(False, f"UEFI BootNext für Windows nicht bestätigt: erwartet Boot{boot_number:04X}, gelesen {observed}.")
    source = "Windows Boot Manager" if not created_entry else "verifizierten Windows-UEFI-Eintrag"
    return WindowsBootResult(
        True,
        f"Windows-Einmalstart über {source} auf der wiederhergestellten Ziel-SSD vorbereitet (Boot{boot_number:04X}, {WINDOWS_EFI_PATH}); BootNext zurückgelesen und bestätigt. BootOrder bleibt unverändert. Verifizierte Kandidaten: {options!r}",
        boot_number,
        created_entry,
    )


WINDOWS_FALLBACK_BEGIN = "# BEGIN HARDWARECHECK WINDOWS ONCE"
WINDOWS_FALLBACK_END = "# END HARDWARECHECK WINDOWS ONCE"


def prioritize_verified_windows_boot(boot_result: WindowsBootResult) -> WindowsBootResult:
    """After a verified restore, retain all firmware entries but put Windows first."""
    if not sys.platform.startswith("linux") or not boot_result.ready or boot_result.boot_number is None:
        return WindowsBootResult(False, "Kein verifizierter Windows-Booteintrag für BootOrder.")
    try:
        original = _read_efi_variable("BootOrder")
        if len(original) < 6 or (len(original) - 4) % 2:
            raise ValueError("Vorhandene BootOrder ist nicht lesbar oder ungültig")
        order = list(struct.unpack("<" + "H" * ((len(original) - 4) // 2), original[4:]))
        number = boot_result.boot_number
        desired = [number] + [item for item in order if item != number]
        payload = struct.pack("<" + "H" * len(desired), *desired)
        if original[4:] != payload:
            _write_efi_variable("BootOrder", payload)
        if _read_efi_variable("BootOrder")[4:] != payload:
            raise ValueError("Windows-Bootpriorität wurde von der Firmware nicht bestätigt")
        return WindowsBootResult(True, f"Windows Boot{number:04X} dauerhaft zuerst; vorher={order}, nachher={desired}. Zurückgelesen und bestätigt.", number)
    except (OSError, ValueError, struct.error, subprocess.SubprocessError) as exc:
        return WindowsBootResult(False, f"Windows-Bootpriorität nicht bestätigt: {exc}")


def windows_fallback_grub_block(boot_uuid: str) -> str:
    """Both boot menus consume ONE shared marker before attempting Windows."""
    if not re.fullmatch(r"[0-9A-Fa-f-]+", boot_uuid):
        raise ValueError("Ungültige Boot-Dateisystem-UUID")
    return f'''{WINDOWS_FALLBACK_BEGIN}
if [ "$grub_platform" = "efi" ]; then
    insmod part_gpt
    insmod part_msdos
    insmod fat
    insmod search_fs_uuid
    insmod smbios
    insmod regexp
    insmod chain
    set hwc_once_disk=
    if search --no-floppy --fs-uuid --set=hwc_once_disk {boot_uuid}; then
        set hwc_once_file="($hwc_once_disk)/boot/grub/windows-once.env"
        set hwc_pending=
        set hwc_machine=
        set hwc_esp=
        if [ -s "$hwc_once_file" ]; then
            load_env --file="$hwc_once_file" hwc_pending hwc_machine hwc_esp
            if [ "$hwc_pending" = "1" ]; then
                set hwc_pending=0
                set hwc_status=consumed
                # Failure to consume must never produce a persistent boot loop.
                if save_env --file="$hwc_once_file" hwc_pending hwc_status; then
                    set hwc_current_machine=
                    set hwc_status=smbios_unavailable
                    if smbios --type 1 --get-uuid 8 --set hwc_current_machine; then
                        set hwc_status=machine_mismatch
                        if regexp "^$hwc_machine"'$' "$hwc_current_machine"; then
                            set hwc_windows_disk=
                            set hwc_status=esp_not_found
                            if search --no-floppy --fs-uuid --set=hwc_windows_disk "$hwc_esp"; then
                                set hwc_status=loader_missing
                                if [ -f "($hwc_windows_disk)/EFI/Microsoft/Boot/bootmgfw.efi" ]; then
                                    set hwc_saved_root="$root"
                                    set root="$hwc_windows_disk"
                                    set hwc_status=chainloader_failed
                                    if chainloader "($hwc_windows_disk)/EFI/Microsoft/Boot/bootmgfw.efi"; then
                                        set hwc_status=boot_attempt
                                        save_env --file="$hwc_once_file" hwc_status hwc_current_machine
                                        boot
                                        set hwc_status=boot_returned
                                    fi
                                    set root="$hwc_saved_root"
                                fi
                            fi
                        fi
                    fi
                    save_env --file="$hwc_once_file" hwc_status hwc_current_machine
                    if [ "$hwc_status" != "machine_mismatch" ]; then
                        echo "Windows automatic start failed: $hwc_status"
                        echo "Installation is complete. Do not restore again. Check Windows boot."
                        sleep --interruptible 20
                    fi
                fi
            fi
        fi
    fi
fi
{WINDOWS_FALLBACK_END}
'''


def _with_windows_fallback(config: str, boot_uuid: str) -> str:
    if (WINDOWS_FALLBACK_BEGIN in config) != (WINDOWS_FALLBACK_END in config):
        raise ValueError("Unvollständiger Windows-Bootblock")
    config = re.sub(re.escape(WINDOWS_FALLBACK_BEGIN) + r".*?" + re.escape(WINDOWS_FALLBACK_END) + r"\n?",
                    "", config, flags=re.S)
    return windows_fallback_grub_block(boot_uuid) + config


def _write_boot_file(path: pathlib.Path, payload: bytes) -> None:
    staging = path.with_name(path.name + ".hwc-new")
    try:
        with staging.open("wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(staging, path)
        if path.read_bytes() != payload:
            raise OSError(f"Bootdatei nicht bestätigt: {path}")
    finally:
        staging.unlink(missing_ok=True)


def schedule_windows_usb_fallback(target: BlockDevice, devices: Iterable[BlockDevice],
                                  inspection: MediaInspection) -> WindowsBootResult:
    """Arm only after successful restore, bound to this machine and target ESP.

    A shared FAT environment avoids a stale second marker on the other USB
    boot partition. A boot on a different machine consumes without redirecting.
    """
    devices = list(devices)
    mounts = []
    readonly = []
    env = None
    try:
        if not sys.platform.startswith("linux") or not target.is_disk or target.is_usb:
            raise ValueError("Nur für die interne Windows-Ziel-SSD verfügbar")
        machine = str(uuid.UUID(pathlib.Path("/sys/class/dmi/id/product_uuid").read_text().strip()))
        if machine in (str(uuid.UUID(int=0)), str(uuid.UUID(int=(1 << 128) - 1))):
            raise ValueError("Keine eindeutige Geräte-UUID")
        esp = [d for d in devices if d.type == "part" and d.parent_disk == target.path
               and d.filesystem.casefold() in WINDOWS_ESP_FILESYSTEMS
               and _windows_efi_boot_file_is_readable(d)[0]]
        if len(esp) != 1 or not re.fullmatch(r"[0-9A-Fa-f-]+", esp[0].uuid):
            raise ValueError("Windows-EFI-Dateisystem nicht eindeutig")
        esp_uuid = esp[0].uuid
        if sum(d.uuid.casefold() == esp_uuid.casefold() for d in devices) != 1:
            raise ValueError("Doppelte Windows-Dateisystem-UUID")
        parents = {r.parent_disk for r in inspection.roles if r.role == "hardwarecheck"}
        if len(parents) != 1 or target.path in parents:
            raise ValueError("Aktives USB-Medium nicht eindeutig")
        partitions = _grub_boot_partitions(inspection, next(iter(parents)))
        primary = next(p for p in partitions if p.label.casefold() in {"hcdebian", "misodebian"})
        if not primary.uuid or sum(d.uuid.casefold() == primary.uuid.casefold() for d in devices) != 1:
            raise ValueError("Boot-Dateisystem-UUID nicht eindeutig")
        workspace = pathlib.Path("/run/hardwarecheck-windows-once")
        workspace.mkdir(parents=True, exist_ok=True)
        roots = []
        for partition in partitions:
            root, temporary, was_readonly = _mount_grub_partition(partition, workspace)
            if temporary is not None: mounts.append(temporary)
            if was_readonly is not None: readonly.append(was_readonly)
            config = root / "boot/grub/grub.cfg"
            original = config.read_bytes()
            if GRUB_ONESHOT_ENTRY not in original.decode("utf-8"):
                raise ValueError("Unbekanntes USB-Bootmenü")
            roots.append((partition, config, original))
            if partition.path == primary.path:
                env = root / "boot/grub/windows-once.env"
        if env is None: raise ValueError("Gemeinsamer Bootmarker fehlt")
        # Disarm before installing either menu; arm only after both verify.
        _write_boot_file(env, GRUB_ENVIRONMENT_HEADER + b"#" * (GRUB_ENVIRONMENT_SIZE - len(GRUB_ENVIRONMENT_HEADER)))
        for partition, config, original in roots:
            backup = config.with_name("grub.cfg.before-windows-once")
            if not backup.exists():
                _write_boot_file(backup, original)
            _write_boot_file(config, _with_windows_fallback(original.decode("utf-8"), primary.uuid).encode("utf-8"))
        machine_pattern = "".join(f"[{c}{c.upper()}]" if c in "abcdef" else c for c in machine)
        payload = GRUB_ENVIRONMENT_HEADER + f"hwc_pending=1\nhwc_machine={machine_pattern}\nhwc_esp={esp_uuid}\n".encode("ascii")
        _write_boot_file(env, payload + b"#" * (GRUB_ENVIRONMENT_SIZE - len(payload)))
        return WindowsBootResult(True, f"USB-Windows-Weiterleitung einmalig vorbereitet: machine={machine}, esp={esp_uuid}, boot={primary.uuid}.")
    except (OSError, ValueError, StopIteration, subprocess.SubprocessError) as exc:
        if env is not None:
            try:
                _write_boot_file(env, GRUB_ENVIRONMENT_HEADER + b"#" * (GRUB_ENVIRONMENT_SIZE - len(GRUB_ENVIRONMENT_HEADER)))
            except OSError:
                pass
        return WindowsBootResult(False, f"USB-Windows-Weiterleitung nicht vorbereitet: {exc}")
    finally:
        for root in reversed(mounts):
            subprocess.run(["umount", str(root)], capture_output=True, timeout=10, check=False)
        for root in reversed(readonly):
            subprocess.run(["mount", "-o", "remount,ro", str(root)], capture_output=True, timeout=10, check=False)


def _bootnext_number() -> int | None:
    try:
        payload = _read_efi_variable("BootNext")
    except OSError:
        return None
    return struct.unpack_from("<H", payload, 4)[0] if len(payload) >= 6 else None


def _write_efi_variable(variable: str, payload: bytes) -> None:
    path = _efivar_path(variable)
    if path is None:
        raise OSError("UEFI-Variablenspeicher ist nicht verfügbar")
    if path.exists():
        subprocess.run(["chattr", "-i", str(path)], check=False, capture_output=True, text=True, timeout=5)
        path.unlink()
    with path.open("xb") as handle:
        handle.write(struct.pack("<I", EFI_VARIABLE_ATTRIBUTES) + payload)


def _schedule_current_hardwarecheck_boot_once(boot_number: int | None = None) -> int:
    """Boot the currently running HardwareCheck entry exactly once.

    The Acronis partition itself is intentionally *not* selected through
    firmware here. Several firmwares either ignore a second FAT partition or
    route it back to the first one. Instead BootNext returns once to the
    already working HardwareCheck GRUB entry, which then consumes its local
    one-shot marker and chainloads Acronis.
    """

    number = boot_number
    if number is None:
        number, _option = _current_boot_option()
    _write_efi_variable("BootNext", struct.pack("<H", number))
    return number


def _remove_efi_variable(variable: str) -> None:
    path = _efivar_path(variable)
    if path is None or not path.exists():
        return
    try:
        subprocess.run(["chattr", "-i", str(path)], check=False, capture_output=True, text=True, timeout=5)
        path.unlink()
    except OSError:
        pass


def _cleanup_stale_acronis_boot_entries(current_number: int) -> None:
    """Keep at most the pending one-time entry in firmware storage.

    UEFI consumes ``BootNext`` after the restart but deliberately keeps the
    referenced Boot#### variable.  Removing only our previous entries prevents
    an unbounded collection of firmware entries without ever changing normal
    boot entries or BootOrder.
    """

    root = pathlib.Path("/sys/firmware/efi/efivars")
    keep = {current_number, _bootnext_number()}
    for candidate in root.glob("Boot????-*"):
        match = re.match(r"Boot([0-9A-Fa-f]{4})-", candidate.name)
        if not match:
            continue
        number = int(match.group(1), 16)
        if number in keep:
            continue
        try:
            _description, _path, _optional = _decode_boot_option(candidate.read_bytes()[4:])
        except (OSError, ValueError):
            continue
        if _description == ACRONIS_BOOT_DESCRIPTION:
            _remove_efi_variable(f"Boot{number:04X}")


def _grub_boot_partitions(inspection: MediaInspection, parent_disk: str) -> list[BlockDevice]:
    """Return the two GRUB partitions for one supported medium layout."""

    for label_set in GRUB_BOOT_PARTITION_LABEL_SETS:
        wanted = {label.casefold() for label in label_set}
        matches = [
            device
            for device in inspection.devices
            if device.type == "part"
            and device.parent_disk == parent_disk
            and device.label.casefold() in wanted
        ]
        labels = {device.label.casefold() for device in matches}
        if labels == wanted and len(matches) == len(wanted):
            return sorted(matches, key=lambda device: device.label.casefold())
    raise OSError("Die beiden GRUB-Partitionen des aktiven Mediums konnten nicht eindeutig zugeordnet werden.")


def _grub_environment_with_next_entry(entry_id: str) -> bytes:
    """Build a standard 1024-byte GRUB environment block without a helper binary."""

    payload = GRUB_ENVIRONMENT_HEADER + f"next_entry={entry_id}\n".encode("ascii")
    if len(payload) > GRUB_ENVIRONMENT_SIZE:
        raise ValueError("GRUB-Umgebungsblock ist zu groß")
    return payload + (b"#" * (GRUB_ENVIRONMENT_SIZE - len(payload)))


def _mount_is_read_only(mountpoint: pathlib.Path) -> bool:
    """Return the actual mount mode instead of guessing from file permissions."""

    result = subprocess.run(
        ["findmnt", "--noheadings", "--output", "OPTIONS", "--target", str(mountpoint)],
        capture_output=True,
        text=True,
        timeout=5,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "unbekannter Mount-Status").strip()
        raise OSError(f"Mount-Status von {mountpoint} konnte nicht gelesen werden: {detail}")
    return "ro" in {item.strip() for item in result.stdout.strip().split(",")}


def _mount_grub_partition(
    partition: BlockDevice, workspace: pathlib.Path
) -> tuple[pathlib.Path, pathlib.Path | None, pathlib.Path | None]:
    """Use a verified boot partition and temporarily make an existing RO mount writable."""

    for mountpoint in partition.mountpoints:
        root = pathlib.Path(mountpoint)
        if root.is_dir():
            if not _mount_is_read_only(root):
                return root, None, None
            result = subprocess.run(
                ["mount", "-o", "remount,rw", str(root)],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                detail = (result.stderr or result.stdout or "unbekannter Mount-Fehler").strip()
                raise OSError(f"{partition.label} konnte nicht schreibbar eingebunden werden: {detail}")
            return root, None, root
    mountpoint = workspace / partition.name
    mountpoint.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["mount", "-o", "rw", partition.path, str(mountpoint)],
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "unbekannter Mount-Fehler").strip()
        raise OSError(f"{partition.label} konnte nicht eingebunden werden: {detail}")
    return mountpoint, mountpoint, None


def _write_grub_environment(environment: pathlib.Path, entry_id: str) -> None:
    """Atomically replace one GRUB environment block."""

    staging = environment.with_name(".grubenv.hardwarecheck-new")
    try:
        with staging.open("wb") as handle:
            handle.write(_grub_environment_with_next_entry(entry_id))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(staging, environment)
    finally:
        if staging.exists():
            try:
                staging.unlink()
            except OSError:
                pass


def _write_grub_one_shot_entry(
    inspection: MediaInspection, parent_disk: str, active_partition: BlockDevice
) -> int:
    """Mark only the GRUB partition selected by BootNext.

    A medium has two firmware-visible GRUB partitions.  Marking both seemed
    defensive, but GRUB clears ``next_entry`` only on the partition it has
    actually booted.  The second marker then survived and could start Acronis
    much later from a different firmware boot entry.  Clear stale markers on
    the inactive partition and mark exactly the active one instead.
    """

    partitions = _grub_boot_partitions(inspection, parent_disk)
    if active_partition.path not in {partition.path for partition in partitions}:
        raise OSError("Die aktive GRUB-Partition gehört nicht zum geschützten HardwareCheck-Medium.")
    workspace = pathlib.Path("/run/hardwarecheck-acronis-once")
    workspace.mkdir(parents=True, exist_ok=True)
    temporary_mounts: list[pathlib.Path] = []
    remounted_readonly_roots: list[pathlib.Path] = []
    roots: list[tuple[BlockDevice, pathlib.Path]] = []
    try:
        for partition in partitions:
            root, temporary_mount, remounted_readonly = _mount_grub_partition(partition, workspace)
            config = root / "boot" / "grub" / "grub.cfg"
            if not config.is_file():
                raise OSError(f"{partition.label} enthält keine HardwareCheck-GRUB-Konfiguration.")
            if GRUB_ONESHOT_ENTRY not in config.read_text(encoding="utf-8", errors="replace"):
                raise OSError(f"{partition.label} enthält keinen Acronis-GRUB-Eintrag.")
            roots.append((partition, root))
            if temporary_mount is not None:
                temporary_mounts.append(temporary_mount)
            if remounted_readonly is not None:
                remounted_readonly_roots.append(remounted_readonly)
        # First remove markers left behind by older releases.  If this fails,
        # no active marker is written and BootNext is rolled back by the caller.
        for partition, root in roots:
            if partition.path != active_partition.path:
                _write_grub_environment(root / "boot" / "grub" / "grubenv", "")
        for partition, root in roots:
            if partition.path != active_partition.path:
                continue
            environment = root / "boot" / "grub" / "grubenv"
            _write_grub_environment(environment, GRUB_ONESHOT_ENTRY)
            return 1
        raise OSError("Die aktive GRUB-Partition konnte nicht zum Acronis-Start markiert werden.")
    finally:
        for mountpoint in reversed(temporary_mounts):
            subprocess.run(["umount", str(mountpoint)], capture_output=True, text=True, timeout=10, check=False)
        for mountpoint in reversed(remounted_readonly_roots):
            subprocess.run(["mount", "-o", "remount,ro", str(mountpoint)], capture_output=True, text=True, timeout=10, check=False)


def schedule_acronis_boot(inspection: MediaInspection) -> AcronisBootResult:
    """Select Acronis once through the already working HardwareCheck GRUB menu.

    BootNext returns once to the current HardwareCheck boot entry. GRUB then
    clears its local marker before it chainloads Acronis; normal BootOrder is
    never changed.
    """

    plan = build_acronis_boot_plan(inspection)
    if not plan.ready:
        return AcronisBootResult(False, plan.message)
    if getattr(os, "geteuid", lambda: 1)() != 0:
        return AcronisBootResult(False, "Acronis-Start benötigt Root-Rechte im HardwareCheck-Debian.")
    try:
        boot_number, boot_option = _current_boot_option()
        active_partition = _current_grub_boot_partition(inspection, plan.parent_disk, boot_option)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return AcronisBootResult(False, f"Acronis-Start konnte die aktive GRUB-Partition nicht bestimmen: {exc}")
    try:
        _schedule_current_hardwarecheck_boot_once(boot_number)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        return AcronisBootResult(False, f"Acronis-Start konnte UEFI BootNext nicht setzen: {exc}")
    try:
        configured = _write_grub_one_shot_entry(inspection, plan.parent_disk, active_partition)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        _remove_efi_variable("BootNext")
        return AcronisBootResult(False, f"Acronis-Start konnte den GRUB-Einmalstart nicht setzen: {exc}")
    return AcronisBootResult(
        True,
        f"Acronis ist über HardwareCheck Boot{boot_number:04X} und {configured} GRUB-Bootpartition für den einmaligen nächsten Neustart vorbereitet.",
    )


def clonezilla_squashfs_source(roles: Iterable[MediaRole]) -> pathlib.Path | None:
    """Find the Clonezilla root filesystem through its verified media role."""

    for role in roles:
        if role.role != "clonezilla":
            continue
        candidate = pathlib.Path(role.mountpoint) / CLONEZILLA_SQUASHFS_RELATIVE_PATH
        try:
            if candidate.is_file():
                return candidate
        except OSError:
            continue
    return None


def probe_clonezilla(roles: Iterable[MediaRole] = ()) -> ClonezillaProbe:
    """Report a local engine or the verified external Clonezilla runtime source."""

    executable = shutil.which("ocs-sr") or ""
    if executable:
        return ClonezillaProbe(
            True,
            executable,
            f"ocs-sr gefunden: {executable}. CLI-Optionen werden vor einem Restore separat verifiziert.",
            source_path=executable,
        )
    source = clonezilla_squashfs_source(roles)
    if source:
        return ClonezillaProbe(
            False,
            "",
            "Clonezilla-Engine auf geschütztem Medium erkannt. Bitte die Backend-Diagnose ausführen.",
            source_path=str(source),
        )
    return ClonezillaProbe(False, "", "ocs-sr ist im laufenden HardwareCheck-Debian nicht verfügbar.")


def _run_command(command: list[str], runner: Callable[..., object], timeout: int = 45) -> tuple[int, str]:
    try:
        completed = runner(command, check=False, capture_output=True, text=True, timeout=timeout)
    except (FileNotFoundError, OSError, subprocess.SubprocessError) as exc:
        return 127, str(exc)
    output = "\n".join(
        value for value in (_text(getattr(completed, "stdout", "")), _text(getattr(completed, "stderr", ""))) if value
    )
    return int(getattr(completed, "returncode", 1)), output


def diagnose_clonezilla_runtime(
    inspection: MediaInspection, runner: Callable[..., object] = subprocess.run
) -> ClonezillaProbe:
    """Run a non-destructive ``ocs-sr`` usage check from the Clonezilla medium.

    The checked Clonezilla filesystem is loop-mounted read-only below ``/run``
    only for this diagnostic, then unmounted again.  The command is strictly
    ``ocs-sr --help``: no image, target device or restore subcommand can reach
    this function.
    """

    local = shutil.which("ocs-sr") or ""
    if local:
        exit_code, output = _run_command([local, "--help"], runner)
        verified = "Usage:" in output or "savedisk|saveparts|restoredisk" in output
        return ClonezillaProbe(
            verified,
            local,
            "Lokale Clonezilla-CLI wurde ohne Restore-Befehl geprüft."
            if verified
            else f"Lokale Clonezilla-CLI-Diagnose fehlgeschlagen (Exit-Code {exit_code}).",
            source_path=local,
            usage_verified=verified,
            log_excerpt=output[-2000:],
        )

    source = clonezilla_squashfs_source(inspection.roles)
    if not source:
        return ClonezillaProbe(False, "", "Kein geprüftes Clonezilla-Live-System mit filesystem.squashfs gefunden.")
    if not sys.platform.startswith("linux"):
        return ClonezillaProbe(False, "", "Die Clonezilla-Backend-Diagnose kann nur im HardwareCheck-Debian laufen.", str(source))
    if getattr(os, "geteuid", lambda: 1)() != 0:
        return ClonezillaProbe(False, "", "Die Clonezilla-Backend-Diagnose benötigt Root-Rechte im Live-System.", str(source))

    runtime_root = CLONEZILLA_RUNTIME_ROOT / f"clonezilla-{os.getpid()}"
    try:
        runtime_root.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return ClonezillaProbe(False, "", f"Clonezilla-Laufzeitordner kann nicht angelegt werden: {exc}", str(source))

    mounted = False
    mount_exit, mount_output = _run_command(
        ["mount", "-o", "ro,loop,nosuid,nodev", str(source), str(runtime_root)], runner
    )
    if mount_exit != 0:
        try:
            runtime_root.rmdir()
        except OSError:
            pass
        return ClonezillaProbe(
            False,
            "",
            f"Clonezilla-Dateisystem konnte nicht schreibgeschützt vorbereitet werden (Exit-Code {mount_exit}).",
            str(source),
            log_excerpt=mount_output[-2000:],
        )
    mounted = True
    try:
        exit_code, output = _run_command(
            ["chroot", str(runtime_root), "/usr/sbin/ocs-sr", "--help"], runner
        )
        verified = "Usage:" in output or "savedisk|saveparts|restoredisk" in output
        message = (
            "Clonezilla-Engine vom geschützten Medium erfolgreich geprüft; kein Restore wurde ausgeführt."
            if verified
            else f"Clonezilla-Engine-Diagnose fehlgeschlagen (Exit-Code {exit_code}); kein Restore wurde ausgeführt."
        )
        return ClonezillaProbe(
            verified,
            "chroot:/usr/sbin/ocs-sr",
            message,
            str(source),
            usage_verified=verified,
            log_excerpt=output[-2000:],
        )
    finally:
        if mounted:
            _run_command(["umount", str(runtime_root)], runner)
        try:
            runtime_root.rmdir()
        except OSError:
            pass


def _restore_command(image_name: str, selector: str) -> tuple[str, ...]:
    return ("/usr/sbin/ocs-sr", "--batch", "-nogui", "-g", "auto", "-e1", "auto",
            "-e2", "-r", "-j2", "-p", "true", "restoredisk", image_name, selector)


def build_restore_proof_plan(
    config: ConfigValidation, image: MagicImage, target: BlockDevice, inspection: MediaInspection
) -> RestoreProofPlan:
    """Create the exact restore command after all non-destructive gates pass.

    The plan is bound to the drive serial number.  Clonezilla itself expects a
    current Linux device path, which is resolved from that serial immediately
    before execution, after the final safety revalidation.  This function
    returns data only; it cannot start a restore.
    """

    if not config.valid:
        return RestoreProofPlan(False, "Config ist nicht gültig geprüft.")
    if config.deployment_mode not in {"config", "complete"} or image.deployment_mode != config.deployment_mode:
        return RestoreProofPlan(False, "Image und Installationsmodus passen nicht zusammen; bitte erneut auswählen.")
    if config.deployment_mode == "complete" and (
        config.config in inspection.available_configs
        or config.config not in image.model_configs
        or image not in config.complete_images
        or image not in inspection.images
    ):
        return RestoreProofPlan(False, "Komplettimage ist nicht für diese Modellnummer freigegeben oder eine Config hat Vorrang.")
    if config.requires_confirmation and not config.override_confirmed:
        return RestoreProofPlan(
            False,
            "Config weist Hardware-Abweichungen oder unbekannte Pflichtdaten auf. Bitte die rote Warnung bewusst bestätigen.",
        )
    if not inspection.clonezilla.usage_verified:
        return RestoreProofPlan(False, "Clonezilla-Engine wurde noch nicht erfolgreich geprüft.")
    if (
        not target.is_disk
        or target.is_usb
        or not _is_non_hdd_target(target)
        or target.path in inspection.protected_disks
    ):
        return RestoreProofPlan(False, "Ziel ist kein zulässiger interner, ungeschützter Datenträger.")
    serial = re.sub(r"\s+", "_", target.serial.strip())
    if not serial or not re.fullmatch(r"[A-Za-z0-9._+-]+", serial):
        return RestoreProofPlan(False, "Ziel-SSD hat keine für Clonezilla nutzbare Seriennummer.")
    if image.minimum_target_bytes and target.size_bytes < image.minimum_target_bytes:
        return RestoreProofPlan(False, "Ziel-SSD ist kleiner als die Mindestgröße des Images.")

    image_path = pathlib.Path(image.image_path)
    repository_roots = [pathlib.Path(role.mountpoint) for role in inspection.roles if role.role == "repository"]
    repository: pathlib.Path | None = None
    image_name = "complete-image" if config.deployment_mode == "complete" else _safe_name(image_path.name)
    if not image_name or (config.deployment_mode == "config" and image_name != image_path.name):
        return RestoreProofPlan(False, "Image-Ordnername ist für Clonezilla nicht zulässig.")
    for candidate in repository_roots:
        try:
            relative = image_path.resolve().relative_to(candidate.resolve())
        except (OSError, ValueError):
            continue
        if config.deployment_mode == "complete":
            if config.config not in _complete_image_configs(candidate, image_path):
                continue
        elif relative.parts != (image_name,):
            continue
        if _plain_repository_path(candidate, image_path):
            repository = candidate
            break
    if repository is None:
        return RestoreProofPlan(False, "Image liegt nicht unmittelbar im geprüften Magic-Image-Repository.")
    try:
        if not (image_path / "parts").is_file() or not (image_path / "disk").is_file():
            return RestoreProofPlan(False, "Image hat keine vollständige Clonezilla-Disk-Struktur.")
    except OSError:
        return RestoreProofPlan(False, "Image-Struktur konnte nicht erneut geprüft werden.")

    selector = f"SERIALNO={serial}"
    command = _restore_command(image_name, selector)
    confirmation = f"RESTORE {serial}"
    return RestoreProofPlan(
        True,
        "Restore ist vorbereitet. Die Ziel-SSD wird erst nach der expliziten Bestätigung gelöscht.",
        config=config.config,
        image_name=image_name,
        image_path=str(image_path),
        repository_path=str(repository),
        target_path=target.path,
        target_selector=selector,
        target_model=target.model,
        target_size_bytes=target.size_bytes,
        confirmation_text=confirmation,
        command=command,
        deployment_mode=config.deployment_mode,
    )


def find_windows_partition(target_path: str, devices: Iterable[BlockDevice]) -> BlockDevice | None:
    """Choose the restored Windows volume by filesystem, label and size."""

    candidates = [
        device
        for device in devices
        if device.type == "part"
        and device.parent_disk == target_path
        and device.filesystem in {"ntfs", "ntfs3"}
        and device.size_bytes >= 10 * 1024**3
    ]
    if not candidates:
        return None
    return max(
        candidates,
        key=lambda device: (
            int("windows" in device.label.lower()),
            device.size_bytes,
        ),
    )


def _restore_log_path(roles: Iterable[MediaRole]) -> pathlib.Path:
    """Prefer the HardwareCheck medium for durable local restore logs."""

    stamp = time.strftime("%Y%m%d-%H%M%S")
    candidates: list[pathlib.Path] = []
    for role in roles:
        if role.role != "hardwarecheck":
            continue
        root = pathlib.Path(role.mountpoint)
        candidates.extend((root / "HardwareCheck" / "hardwarecheck-debug" / "magic-image", root / "hardwarecheck-debug" / "magic-image"))
    candidates.append(pathlib.Path("/run") / "hardwarecheck-magic-logs")
    for directory in candidates:
        try:
            directory.mkdir(parents=True, exist_ok=True)
            return directory / f"restore-proof-{stamp}.log"
        except OSError:
            continue
    return pathlib.Path("/tmp") / f"hardwarecheck-restore-proof-{stamp}.log"


def _write_log(log_path: pathlib.Path, lines: Iterable[str]) -> None:
    try:
        log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError:
        pass


def execute_restore_proof(
    plan: RestoreProofPlan,
    inspection: MediaInspection,
    runner: Callable[..., object] = subprocess.run,
    device_reader: Callable[[Callable[..., object]], list[BlockDevice]] = collect_lsblk,
    progress_callback: Callable[[int, str], object] | None = None,
    data_disk_plan: DataDiskPreparePlan | None = None,
) -> RestoreProofResult:
    """Run the explicitly confirmed restore and offline Handoff transaction.

    This function is intentionally reachable only after HardwareCheck's final
    confirmation dialog.  It rechecks the target serial immediately before
    executing Clonezilla, runs no reboot action, and leaves a local log for
    every outcome.
    """

    if not plan.ready:
        return RestoreProofResult(False, "preflight", plan.message)
    if (plan.deployment_mode not in {"config", "complete"}
            or not re.fullmatch(r"\d{4}", plan.config)
            or not re.fullmatch(r"SERIALNO=[A-Za-z0-9._+-]+", plan.target_selector)
            or plan.command != _restore_command(plan.image_name, plan.target_selector)):
        return RestoreProofResult(False, "preflight", "Clonezilla-Plan ist nicht konsistent; Restore abgebrochen.")
    if not sys.platform.startswith("linux"):
        return RestoreProofResult(False, "preflight", "Restore-Proof kann nur im HardwareCheck-Debian laufen.")
    if getattr(os, "geteuid", lambda: 1)() != 0:
        return RestoreProofResult(False, "preflight", "Restore-Proof benötigt Root-Rechte im Live-System.")

    log_path = _restore_log_path(inspection.roles)
    log_lines = [
        f"HardwareCheck Magic Image restore started: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Target path at planning time: {plan.target_path}",
        f"Target selector: {plan.target_selector}",
        f"Image: {plan.image_name}",
        f"Deployment mode: {plan.deployment_mode}; source image: {plan.image_path}",
        f"Repository: {plan.repository_path}",
        "The requested completion action is executed only after restore and handoff validation.",
    ]
    _write_log(log_path, log_lines)

    def report_progress(percent: int, message: str) -> None:
        if progress_callback is None:
            return
        try:
            progress_callback(max(0, min(100, int(percent))), message)
        except Exception:
            pass

    def record(name: str, command: list[str], timeout: int = 60) -> tuple[int, str]:
        exit_code, output = _run_command(command, runner, timeout)
        log_lines.extend((f"[{name}] command: {' '.join(command)}", f"[{name}] exit-code: {exit_code}"))
        if output:
            log_lines.append(f"[{name}] output:\n{output}")
        _write_log(log_path, log_lines)
        return exit_code, output

    def record_restore(command: list[str], timeout: int) -> tuple[int, str]:
        """Run Clonezilla while forwarding its Partclone percentage to the GUI.

        Test doubles retain the previous ``runner`` contract.  The live GTK
        path uses ``Popen`` so the operator sees actual Clonezilla progress
        instead of a frozen window until the process exits.
        """

        if progress_callback is None or runner is not subprocess.run:
            return record("clonezilla-restoredisk", command, timeout)
        report_progress(1, "Clonezilla startet …")
        output_parts: list[str] = []
        try:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
            if process.stdout is not None:
                for line in process.stdout:
                    output_parts.append(line)
                    match = re.search(r"Comple(?:te|ted):\s*([0-9]+(?:\.[0-9]+)?)%", line, re.IGNORECASE)
                    if match:
                        report_progress(int(float(match.group(1))), "Clonezilla schreibt das Image …")
            exit_code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            output_parts.append("\nTimeout: Clonezilla-Restore überschritt die erlaubte Laufzeit.\n")
            exit_code = 124
        except OSError as exc:
            output_parts.append(f"\nClonezilla konnte nicht gestartet werden: {exc}\n")
            exit_code = 127
        output = "".join(output_parts)
        log_lines.extend((f"[clonezilla-restoredisk] command: {' '.join(command)}", f"[clonezilla-restoredisk] exit-code: {exit_code}"))
        if output:
            log_lines.append(f"[clonezilla-restoredisk] output:\n{output}")
        _write_log(log_path, log_lines)
        return exit_code, output

    devices = device_reader(runner)
    planned_serial = plan.target_selector.removeprefix("SERIALNO=")
    matching_targets = [
        device
        for device in devices
        if device.is_disk and re.sub(r"\s+", "_", device.serial.strip()) == planned_serial
    ]
    current_target = matching_targets[0] if len(matching_targets) == 1 else None
    current_serial = re.sub(r"\s+", "_", current_target.serial.strip()) if current_target else ""
    expected_model = re.sub(r"\s+", " ", plan.target_model.strip())
    current_model = re.sub(r"\s+", " ", current_target.model.strip()) if current_target else ""
    if (
        current_target is None
        or current_target.is_usb
        or not _is_non_hdd_target(current_target)
        or current_target.path in inspection.protected_disks
        or current_serial != planned_serial
        or (expected_model and current_model != expected_model)
        or (plan.target_size_bytes and current_target.size_bytes != plan.target_size_bytes)
    ):
        message = "Ziel-SSD hat sich seit der Bestätigung geändert, ist mehrdeutig oder nicht mehr zulässig; Restore abgebrochen."
        log_lines.append(message)
        _write_log(log_path, log_lines)
        return RestoreProofResult(False, "preflight", message, log_path=str(log_path))
    log_lines.append(f"Validated current Clonezilla target: {current_target.path} ({current_target.serial})")

    source = pathlib.Path(inspection.clonezilla.source_path)
    repository = pathlib.Path(plan.repository_path)
    image_path = pathlib.Path(plan.image_path)
    try:
        source_ok = source.is_file()
        image_ok = image_path.is_dir() and (image_path / "parts").is_file() and (image_path / "disk").is_file()
        repository_ok = any(role.role == "repository" and pathlib.Path(role.mountpoint).resolve() == repository.resolve()
                            for role in inspection.roles) and _plain_repository_path(repository, image_path)
        if plan.deployment_mode == "complete":
            repository_ok = (repository_ok and plan.image_name == "complete-image"
                             and plan.config in _complete_image_configs(repository, image_path)
                             and plan.config not in discover_config_ids([str(repository)])
                             and plan.config not in inspection.available_configs)
        else:
            repository_ok = (repository_ok and image_path.resolve().parent == repository.resolve()
                             and plan.image_name == image_path.name
                             and _safe_name(plan.image_name) == plan.image_name)
    except OSError:
        source_ok = image_ok = repository_ok = False
    if not source_ok or not image_ok or not repository_ok:
        message = "Clonezilla-Quelle oder geprüftes Image ist vor Restore nicht mehr unverändert verfügbar; Restore abgebrochen."
        log_lines.append(message)
        _write_log(log_path, log_lines)
        return RestoreProofResult(False, "preflight", message, log_path=str(log_path))

    nonce = uuid.uuid4().hex
    runtime_root = CLONEZILLA_RUNTIME_ROOT / f"restore-engine-{nonce}"
    workspace = CLONEZILLA_RUNTIME_ROOT / f"restore-work-{nonce}"
    mounted_engine = mounted_home = mounted_repository = mounted_workspace = mounted_windows = False
    mounted_tmp = mounted_run = mounted_var_log = mounted_var_lib = False
    mounted_dev = mounted_proc = mounted_sys = False
    image_mount_target: pathlib.Path | None = None
    clonezilla_exit: int | None = None
    output_excerpt = ""
    handoff_path = ""
    try:
        runtime_root.mkdir(parents=True, exist_ok=False)
        (workspace / "windows").mkdir(parents=True, exist_ok=False)
        (workspace / "home" / "partimag").mkdir(parents=True, exist_ok=False)
        if plan.deployment_mode == "complete":
            (workspace / "home" / "partimag" / "complete-image").mkdir()
        (workspace / "tmp").mkdir(parents=True, exist_ok=False)
        (workspace / "run").mkdir(parents=True, exist_ok=False)
        (workspace / "var" / "log" / "clonezilla").mkdir(parents=True, exist_ok=False)
        (workspace / "var" / "lib" / "clonezilla").mkdir(parents=True, exist_ok=False)
    except OSError as exc:
        message = f"Laufzeitordner für Restore-Proof kann nicht angelegt werden: {exc}"
        log_lines.append(message)
        _write_log(log_path, log_lines)
        return RestoreProofResult(False, "preflight", message, log_path=str(log_path))

    try:
        exit_code, output = record("mount-clonezilla-readonly", ["mount", "-o", "ro,loop,nosuid,nodev", str(source), str(runtime_root)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-mount", "Clonezilla-Engine konnte nicht schreibgeschützt vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_engine = True
        home_target = runtime_root / "home"
        mnt_target = runtime_root / "mnt"
        tmp_target = runtime_root / "tmp"
        run_target = runtime_root / "run"
        log_target = runtime_root / "var" / "log"
        lib_target = runtime_root / "var" / "lib"
        dev_target = runtime_root / "dev"
        proc_target = runtime_root / "proc"
        sys_target = runtime_root / "sys"
        runtime_targets = (home_target, mnt_target, tmp_target, run_target, log_target, lib_target, dev_target, proc_target, sys_target)
        if not all(target.is_dir() for target in runtime_targets):
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Laufzeitumgebung hat keinen erwarteten Mountpunkt.", log_path=str(log_path))
        # Clonezilla Live normally runs on a writable overlay filesystem.  The
        # TEST backend deliberately mounts its squashfs read-only, therefore
        # the mutable areas have to be supplied from an isolated RAM workspace.
        exit_code, output = record("bind-clonezilla-tmp", ["mount", "--bind", str(workspace / "tmp"), str(tmp_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Temp-Verzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_tmp = True
        exit_code, output = record("bind-clonezilla-run", ["mount", "--bind", str(workspace / "run"), str(run_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Run-Verzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_run = True
        exit_code, output = record("bind-clonezilla-var-log", ["mount", "--bind", str(workspace / "var" / "log"), str(log_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Log-Verzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_var_log = True
        exit_code, output = record("bind-clonezilla-var-lib", ["mount", "--bind", str(workspace / "var" / "lib"), str(lib_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Statusverzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_var_lib = True

        # A chroot into the read-only Clonezilla squashfs needs the live
        # kernel interfaces as well.  rbind preserves devpts and the other
        # nested mounts; rslave prevents cleanup from propagating to the host.
        for name, source_path, target_path in (
            ("dev", "/dev", dev_target),
            ("proc", "/proc", proc_target),
            ("sys", "/sys", sys_target),
        ):
            exit_code, output = record(f"bind-clonezilla-{name}", ["mount", "--rbind", source_path, str(target_path)])
            if exit_code != 0:
                return RestoreProofResult(False, "engine-layout", f"Clonezilla-Systempfad /{name} konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
            if name == "dev":
                mounted_dev = True
            elif name == "proc":
                mounted_proc = True
            else:
                mounted_sys = True
            exit_code, output = record(f"isolate-clonezilla-{name}", ["mount", "--make-rslave", str(target_path)])
            if exit_code != 0:
                return RestoreProofResult(False, "engine-layout", f"Clonezilla-Systempfad /{name} konnte nicht isoliert werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        exit_code, output = record("bind-clonezilla-home", ["mount", "--bind", str(workspace / "home"), str(home_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Home konnte nicht für das Image-Repository vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_home = True
        partimag_target = home_target / "partimag"
        # Model folders may contain spaces/parentheses. Bind just the selected
        # image under a fixed safe name, without renaming or modifying any files.
        image_mount_target = partimag_target / "complete-image" if plan.deployment_mode == "complete" else partimag_target
        mount_source = image_path if plan.deployment_mode == "complete" else repository
        exit_code, output = record("bind-image-repository", ["mount", "--bind", str(mount_source), str(image_mount_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "repository-mount", "Image-Repository konnte nicht an Clonezilla übergeben werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_repository = True
        exit_code, output = record("remount-image-repository-readonly", ["mount", "-o", "remount,bind,ro", str(image_mount_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "repository-mount", "Image-Repository konnte nicht schreibgeschützt an Clonezilla gebunden werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        exit_code, output = record("bind-handoff-workspace", ["mount", "--bind", str(workspace), str(mnt_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "workspace-mount", "Handoff-Arbeitsbereich konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_workspace = True

        if not plan.command or plan.command[-1] != plan.target_selector:
            return RestoreProofResult(False, "preflight", "Clonezilla-Plan ist nicht konsistent; Restore abgebrochen.", log_path=str(log_path))
        runtime_restore_command = [*plan.command[:-1], current_target.path]
        clonezilla_command = [
            "chroot",
            str(runtime_root),
            "/usr/bin/env",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "TERM=linux",
            "HOME=/root",
            "TMPDIR=/tmp",
            *runtime_restore_command,
        ]
        report_progress(1, "Clonezilla-Umgebung wird vorbereitet …")
        clonezilla_exit, output = record_restore(clonezilla_command, timeout=6 * 60 * 60)
        output_excerpt = output[-2000:]
        if clonezilla_exit != 0:
            return RestoreProofResult(
                False,
                "clonezilla",
                f"Clonezilla-Restore fehlgeschlagen (Exit-Code {clonezilla_exit}). Windows wird nicht gestartet.",
                clonezilla_exit,
                str(log_path),
                output_excerpt=output_excerpt,
            )

        if data_disk_plan is not None:
            report_progress(96, "Daten-HDD wird vorbereitet …")
            planned_data_serial = data_disk_plan.disk_selector.removeprefix("SERIALNO=")
            refreshed_data_devices = device_reader(runner)
            matching_data_disks = [
                device
                for device in refreshed_data_devices
                if device.is_disk and re.sub(r"\s+", "_", device.serial.strip()) == planned_data_serial
            ]
            current_data_disk = matching_data_disks[0] if len(matching_data_disks) == 1 else None
            current_data_serial = re.sub(r"\s+", "_", current_data_disk.serial.strip()) if current_data_disk else ""
            current_data_model = re.sub(r"\s+", " ", current_data_disk.model.strip()) if current_data_disk else ""
            expected_data_model = re.sub(r"\s+", " ", data_disk_plan.disk_model.strip())
            if (
                current_data_disk is None
                or current_data_disk.path == current_target.path
                or current_data_disk.is_usb
                or current_data_disk.rotational is not True
                or current_data_disk.path in inspection.protected_disks
                or current_data_serial != planned_data_serial
                or (expected_data_model and current_data_model != expected_data_model)
                or (data_disk_plan.disk_size_bytes and current_data_disk.size_bytes != data_disk_plan.disk_size_bytes)
            ):
                message = "Clonezilla war erfolgreich, aber die ausgewählte Daten-HDD hat sich geändert oder ist nicht mehr zulässig. Windows wird nicht gestartet."
                log_lines.append(message)
                _write_log(log_path, log_lines)
                return RestoreProofResult(False, "data-disk-preflight", message, clonezilla_exit, str(log_path), output_excerpt=output_excerpt)

            for partition in refreshed_data_devices:
                if partition.type != "part" or partition.parent_disk != current_data_disk.path:
                    continue
                for mountpoint in partition.mountpoints:
                    exit_code, output = record("unmount-data-hdd", ["umount", mountpoint])
                    if exit_code != 0:
                        message = "Clonezilla war erfolgreich, aber die Daten-HDD konnte nicht ausgehängt werden. Windows wird nicht gestartet."
                        return RestoreProofResult(False, "data-disk-unmount", message, clonezilla_exit, str(log_path), output_excerpt=output[-2000:])

            # The small HardwareCheck/Solo Debian deliberately has no full
            # partitioning toolset.  The verified Clonezilla runtime does,
            # however, carry the exact tools required here.  Run every
            # destructive data-disk command in that already mounted runtime,
            # never against a possibly incomplete host environment.
            if not re.fullmatch(r"/dev/[A-Za-z0-9._-]+", current_data_disk.path):
                message = "Clonezilla war erfolgreich, aber der Daten-HDD-Pfad ist ungültig. Windows wird nicht gestartet."
                log_lines.append(message)
                _write_log(log_path, log_lines)
                return RestoreProofResult(False, "data-disk-path", message, clonezilla_exit, str(log_path), output_excerpt=output_excerpt)

            runtime_tools = {
                "wipefs": "/usr/sbin/wipefs",
                "sfdisk": "/usr/sbin/sfdisk",
                "partprobe": "/usr/sbin/partprobe",
                "mkfs.ntfs": "/usr/sbin/mkfs.ntfs",
            }
            missing_runtime_tools = [
                name for name, path in runtime_tools.items() if not (runtime_root / path.lstrip("/")).is_file()
            ]
            if missing_runtime_tools:
                message = (
                    "Clonezilla war erfolgreich, aber die Daten-HDD kann mit dieser Clonezilla-Version nicht vorbereitet werden "
                    f"(fehlend: {', '.join(missing_runtime_tools)}). Windows wird nicht gestartet."
                )
                log_lines.append(message)
                _write_log(log_path, log_lines)
                return RestoreProofResult(False, "data-disk-tools", message, clonezilla_exit, str(log_path), output_excerpt=output_excerpt)

            # sfdisk receives its table description via stdin.  The workspace
            # is bound at /mnt inside Clonezilla, so the shell only reads a
            # fixed local file.  The disk path was validated above and does
            # not contain user-controlled shell syntax.
            data_disk_layout = workspace / "data-hdd.sfdisk"
            try:
                data_disk_layout.write_text(
                    "label: gpt\n"
                    "unit: sectors\n"
                    "\n"
                    "start=2048, type=EBD0A0A2-B9E5-4433-87C0-68B6B72699C7\n",
                    encoding="ascii",
                )
            except OSError as exc:
                message = f"Clonezilla war erfolgreich, aber die Daten-HDD-Vorbereitung konnte nicht angelegt werden: {exc}"
                log_lines.append(message)
                _write_log(log_path, log_lines)
                return RestoreProofResult(False, "data-disk-layout", message, clonezilla_exit, str(log_path), output_excerpt=output_excerpt)

            runtime_prefix = ["chroot", str(runtime_root)]
            for step, command in (
                ("wipe-data-hdd-signatures", [*runtime_prefix, runtime_tools["wipefs"], "--all", "--force", current_data_disk.path]),
                (
                    "create-data-hdd-gpt",
                    [
                        *runtime_prefix,
                        "/bin/sh",
                        "-c",
                        f"{runtime_tools['sfdisk']} --wipe always --wipe-partitions always {current_data_disk.path} < /mnt/data-hdd.sfdisk",
                    ],
                ),
                ("reread-data-hdd-partitions", [*runtime_prefix, runtime_tools["partprobe"], current_data_disk.path]),
            ):
                exit_code, output = record(step, command)
                if exit_code != 0:
                    message = "Clonezilla war erfolgreich, aber die Daten-HDD konnte nicht vorbereitet werden. Windows wird nicht gestartet."
                    return RestoreProofResult(False, "data-disk-format", message, clonezilla_exit, str(log_path), output_excerpt=output[-2000:])

            # The live kernel has no udev service inside the isolated runtime
            # workspace.  Give the kernel a short moment, then query lsblk
            # again instead of relying on a host-only udevadm command.
            time.sleep(2)
            prepared_devices = device_reader(runner)
            data_partitions = [
                device
                for device in prepared_devices
                if device.type == "part" and device.parent_disk == current_data_disk.path and device.size_bytes > 0
            ]
            data_partition = max(data_partitions, key=lambda device: device.size_bytes, default=None)
            if data_partition is None:
                message = "Clonezilla war erfolgreich, aber die neue Datenpartition wurde nicht erkannt. Windows wird nicht gestartet."
                log_lines.append(message)
                _write_log(log_path, log_lines)
                return RestoreProofResult(False, "data-disk-partition", message, clonezilla_exit, str(log_path), output_excerpt=output_excerpt)
            # A full NTFS format writes across every sector of a multi-TB HDD
            # and can easily take hours.  The disk has already been wiped and
            # repartitioned above, so a quick NTFS format is both sufficient
            # and the intended preparation here.  Keep a generous timeout for
            # unusually slow internal drives rather than interrupting it after
            # the generic one-minute command limit.
            exit_code, output = record(
                "format-data-hdd-ntfs",
                [*runtime_prefix, runtime_tools["mkfs.ntfs"], "-F", "-Q", "-L", data_disk_plan.label, data_partition.path],
                timeout=10 * 60,
            )
            if exit_code != 0:
                message = "Clonezilla war erfolgreich, aber die Datenpartition konnte nicht als NTFS formatiert werden. Windows wird nicht gestartet."
                return RestoreProofResult(False, "data-disk-ntfs", message, clonezilla_exit, str(log_path), output_excerpt=output[-2000:])
            record("sync-data-hdd", ["sync"])
            log_lines.append(f"Data HDD prepared and verified: {data_partition.path} ({data_disk_plan.label})")
            _write_log(log_path, log_lines)
            report_progress(98, "Daten-HDD als NTFS vorbereitet …")

        record("settle-restored-disk", ["sync"])
        refreshed = device_reader(runner)
        if plan.deployment_mode == "complete":
            log_lines.append("Complete model image: no Windows mount, no config handoff, no external config/driver copy. Embedded ModelCheck unchanged.")
            report_progress(100, "Komplettimage wiederhergestellt; Windows-Modellprüfung bleibt unverändert.")
        else:
            windows_partition = find_windows_partition(current_target.path, refreshed)
            if windows_partition is None:
                return RestoreProofResult(
                    False, "handoff-detect",
                    "Clonezilla war erfolgreich, aber keine große Windows-NTFS-Partition wurde gefunden. Windows wird nicht gestartet.",
                    clonezilla_exit, str(log_path), output_excerpt=output_excerpt,
                )
            exit_code, output = record(
                "mount-restored-windows",
                ["chroot", str(runtime_root), "/usr/bin/ntfs-3g", windows_partition.path, "/mnt/windows", "-o", "rw,uid=0,gid=0,umask=022"],
            )
            if exit_code != 0:
                return RestoreProofResult(
                    False, "handoff-mount",
                    "Clonezilla war erfolgreich, aber die Windows-Partition konnte für den Handoff nicht eingebunden werden. Windows wird nicht gestartet.",
                    clonezilla_exit, str(log_path), output_excerpt=output[-2000:],
                )
            mounted_windows = True
            report_progress(100, "Windows-Handoff wird geschrieben …")
            handoff_file = workspace / "windows" / "MagicImage" / "hardwarecheck-config.txt"
            handoff_file.parent.mkdir(parents=True, exist_ok=True)
            with handoff_file.open("w", encoding="ascii", newline="\n") as handle:
                handle.write(config_value := plan.config + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            if handoff_file.read_text(encoding="ascii") != config_value:
                return RestoreProofResult(
                    False, "handoff-verify",
                    "Handoff-Datei konnte nicht erneut validiert werden. Windows wird nicht gestartet.",
                    clonezilla_exit, str(log_path),
                )
            handoff_path = HANDOFF_WINDOWS_PATH
            log_lines.append(f"Handoff written and validated: {handoff_path} -> {config_value.strip()}")
            _write_log(log_path, log_lines)
            record("sync-handoff", ["sync"])
        # A normal reboot lets firmware choose its persistent BootOrder again.
        # Some ASUS devices consequently return to the still-attached install
        # SSD.  Request Windows exactly once, but never turn a boot-target
        # preparation issue into a false restore failure: the restore and its
        # Windows handoff have already been verified at this point.
        boot_result = schedule_restored_windows_boot_once(current_target, refreshed)
        log_lines.append(f"[windows-boot-once] ready={boot_result.ready}: {boot_result.message}")
        priority_result = prioritize_verified_windows_boot(boot_result)
        log_lines.append(f"[windows-boot-priority] ready={priority_result.ready}: {priority_result.message}")
        usb_boot = schedule_windows_usb_fallback(current_target, refreshed, inspection)
        log_lines.append(f"[windows-usb-fallback] ready={usb_boot.ready}: {usb_boot.message}")
        _write_log(log_path, log_lines)
        completion_message = (
            "Clonezilla-Komplettimage erfolgreich installiert. Die Modellprüfung startet mit dem vorhandenen Windows-Skript."
            if plan.deployment_mode == "complete"
            else "Restore und Windows-Handoff erfolgreich. Der gewählte Abschluss wird jetzt ausgeführt."
        )
        if boot_result.ready:
            completion_message += " Der nächste Neustart ist einmalig auf die wiederhergestellte Windows-SSD festgelegt."
        else:
            completion_message += " Der nächste Neustart verwendet die vorhandene Firmware-Bootreihenfolge."
        if priority_result.ready:
            completion_message += " Windows steht auch für weitere Neustarts an erster Stelle."
        else:
            completion_message += " Achtung: dauerhafte Windows-Bootpriorität nicht bestätigt; siehe Protokoll."
        return RestoreProofResult(
            True,
            "complete",
            completion_message,
            clonezilla_exit,
            str(log_path),
            handoff_path,
            output_excerpt,
            deployment_mode=plan.deployment_mode,
        )
    finally:
        if mounted_windows:
            record("unmount-restored-windows", ["umount", str(workspace / "windows")])
        if mounted_workspace:
            record("unmount-handoff-workspace", ["umount", str(runtime_root / "mnt")])
        if mounted_repository:
            record("unmount-image-repository", ["umount", str(image_mount_target)])
        if mounted_home:
            record("unmount-clonezilla-home", ["umount", str(runtime_root / "home")])
        if mounted_var_log:
            record("unmount-clonezilla-var-log", ["umount", str(runtime_root / "var" / "log")])
        if mounted_var_lib:
            record("unmount-clonezilla-var-lib", ["umount", str(runtime_root / "var" / "lib")])
        if mounted_tmp:
            record("unmount-clonezilla-tmp", ["umount", str(runtime_root / "tmp")])
        if mounted_run:
            record("unmount-clonezilla-run", ["umount", str(runtime_root / "run")])
        if mounted_sys:
            record("unmount-clonezilla-sys", ["umount", "--recursive", str(runtime_root / "sys")])
        if mounted_proc:
            record("unmount-clonezilla-proc", ["umount", "--recursive", str(runtime_root / "proc")])
        if mounted_dev:
            record("unmount-clonezilla-dev", ["umount", "--recursive", str(runtime_root / "dev")])
        if mounted_engine:
            record("unmount-clonezilla-engine", ["umount", str(runtime_root)])
        for path in (
            workspace / "windows",
            workspace / "home" / "partimag" / "complete-image",
            workspace / "home" / "partimag",
            workspace / "home",
            workspace / "tmp",
            workspace / "run",
            workspace / "var" / "log" / "clonezilla",
            workspace / "var" / "log",
            workspace / "var" / "lib" / "clonezilla",
            workspace / "var" / "lib",
            workspace / "var",
            workspace,
            runtime_root,
        ):
            try:
                path.rmdir()
            except OSError:
                pass


def inspect_media(
    runner: Callable[..., object] = subprocess.run,
    *,
    include_classic_acronis: bool = True,
) -> MediaInspection:
    devices = collect_lsblk(runner)
    inspection = MediaInspection(devices=devices)
    if not devices:
        inspection.warnings.append("Datenträger konnten nicht über lsblk gelesen werden.")
        return inspection
    # The Clonezilla and image partitions may not be mounted when the
    # HardwareCheck live system starts.  Inspect only external partitions and
    # mount those read-only before looking for our marker files.  A fresh
    # lsblk pass is required because udisksctl can choose its own mount path.
    mounted, mount_warnings = mount_external_partitions_read_only(devices, runner)
    inspection.mounted_read_only = mounted
    inspection.warnings.extend(mount_warnings)
    if mounted:
        devices = collect_lsblk(runner)
        inspection.devices = devices
    inspection.roles = discover_media_roles(devices, pathlib.Path(__file__).resolve().parent)
    inspection.protected_disks = {role.parent_disk for role in inspection.roles}
    repositories = [role.mountpoint for role in inspection.roles if role.role == "repository"]
    inspection.config_repository_paths = tuple(repositories)
    inspection.available_configs = discover_config_ids(repositories)
    inspection.config_profiles = discover_config_profiles(repositories)
    if include_classic_acronis:
        inspection.classic_acronis_images = discover_classic_acronis_images(repositories)
    inspection.images = discover_images(repositories)
    inspection.safe_targets = safe_restore_targets(devices, inspection.protected_disks)
    inspection.clonezilla = probe_clonezilla(inspection.roles)
    if mounted:
        inspection.warnings.insert(0, f"Schreibgeschützt eingehängt: {', '.join(mounted)}.")
    if not repositories:
        inspection.warnings.append("Kein Magic-Image-Repository erkannt.")
    elif not inspection.available_configs:
        inspection.warnings.append("Im Image-Repository wurde kein lesbarer #configs-Ordner erkannt.")
    if include_classic_acronis and inspection.classic_acronis_images:
        inspection.warnings.append(
            f"Klassische Acronis-Images nur als Hinweis erkannt: {len(inspection.classic_acronis_images)} Config(s)."
        )
    if not inspection.safe_targets:
        inspection.warnings.append("Kein zulässiger interner Zieldatenträger erkannt.")
    return inspection


def build_simulation_summary(config: ConfigValidation, image: MagicImage, target: BlockDevice, inspection: MediaInspection) -> str:
    """Build an auditable job preview without creating or running a command."""

    roles = ", ".join(f"{role.role}: {role.parent_disk}" for role in inspection.roles) or "keine Rollen erkannt"
    validation_state = (
        "Komplettimage; Modellprüfung nach Windows-Start" if config.deployment_mode == "complete"
        else "exakter Hardware-Match" if config.strict_match
        else "Warnung bewusst bestätigt" if config.override_confirmed else "Warnung noch nicht bestätigt"
    )
    lines = [
            "SIMULATION – kein Clonezilla- oder Schreibvorgang wurde gestartet.",
            f"Config: {config.config} ({config.score} % Modellähnlichkeit; {validation_state})",
            f"Image: {image.display_name}",
            f"Image-Pfad: {image.image_path}",
            f"Ziel: {target.description}",
            f"Zielkennung: {target.stable_identity}",
            f"Geschützte Medien: {roles}",
            f"Clonezilla-Backend: {inspection.clonezilla.message}",
            ("Kein Config-Handoff: Das eingebettete Windows-ModelCheck-Skript bleibt unverändert."
             if config.deployment_mode == "complete"
             else f"Geplanter Windows-Handoff: {HANDOFF_WINDOWS_PATH} mit Config {config.config}"),
            "Vor echtem Restore: Ziel erneut über Seriennummer/WWN, Modell und Größe validieren.",
    ]
    if config.details:
        lines.append("Config-Prüfung: " + " | ".join(config.details))
    if config.classic_acronis_images:
        lines.append("Klassisches Acronis-Image (nur Hinweis): " + "; ".join(
            image.display_text for image in config.classic_acronis_images
        ))
    return "\n".join(lines)
