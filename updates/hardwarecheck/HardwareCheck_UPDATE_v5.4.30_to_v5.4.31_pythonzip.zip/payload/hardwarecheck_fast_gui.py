#!/usr/bin/env python3
"""Fast full-screen hardware inspector for a Porteus USB stick.

This app is designed to launch directly after boot on lightweight Linux media.
It keeps the existing HardwareCheck.sh spirit, but improves two weak spots:
1. RAM type is read from SMBIOS where possible instead of guessed from speed.
2. Display size is derived from EDID physical dimensions instead of model hints.
"""

from __future__ import annotations

import json
import base64
import concurrent.futures
import hashlib
import html as html_lib
import datetime
import email.utils
import ipaddress
import math
import os
import pathlib
import queue
import re
import select
import shutil
import socket
import ssl
import subprocess
import sys
import struct
import tempfile
import threading
import textwrap
import time
import tkinter as tk
import traceback
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from html.parser import HTMLParser
from tkinter import messagebox, ttk

# Avoid __pycache__ writes on the FAT32 live partition.  The source files are
# intentionally the only program files ever changed by the updater.
sys.dont_write_bytecode = True

try:
    import fcntl
except ImportError:  # pragma: no cover - only relevant outside Linux.
    fcntl = None


APP_VERSION = "v5.4.31"
# Fixed digest of the dependency carried by the v5.4.9 bridge package.
CONFIG_SERVER_SYNC_BRIDGE_SHA256 = "8bb0818d92ccb0bdb2f413a0fe3275751e80c801b01860355db104f42539cb07"
APP_TITLE = f"HardwareCheck {APP_VERSION}"
SCRIPT_DIR = pathlib.Path(__file__).resolve().parent
REPORT_DIR = SCRIPT_DIR / "Model Report"
BATTERY_REPORT_DIR_NAME = "Battery Report"
BATTERY_SESSION_MAX_GAP_SECONDS = 15 * 60
BATTERY_CHARGE_STALL_SECONDS = 15 * 60
BATTERY_MIN_PLAUSIBLE_VOLTAGE = 2.5
BATTERY_ESTIMATE_MIN_SECONDS = 3 * 60
BATTERY_RAPID_DROP_MIN_SECONDS = 2 * 60
BATTERY_RAPID_DROP_WARN_PERCENT = 5.0
BATTERY_RAPID_DROP_WARN_RATE = 60.0
BATTERY_RAPID_DROP_CRITICAL_RATE = 120.0
BATTERY_TEST_MIN_SECONDS = 30 * 60
BATTERY_TEST_MAX_SECONDS = 60 * 60
BATTERY_TEST_TARGET_CHANGE_PERCENT = 5.0
BATTERY_TEST_LOW_LEVEL_PERCENT = 15.0
BATTERY_TEST_CHARGE_STOP_PERCENT = 95.0
PORTABLE_DIR_NAME = "HardwareCheck"
PORTABLE_MARKER = ".hardwarecheck-portable"
COMMON_DISPLAY_SIZES = [10.1, 11.6, 12.5, 13.3, 14.0, 15.6, 16.0, 16.1, 17.3, 18.0]
COMMON_DISK_SIZES = [32, 64, 120, 128, 240, 250, 256, 320, 480, 500, 512, 640, 750, 960, 1000, 1024, 2000, 2048]
LANGUAGES = ("DE", "EN", "CZ")
LANGUAGE_SELECTOR_ORDER = ("CZ", "DE", "EN")
SETTINGS_FILE = "hardwarecheck-settings.json"
WIFI_NETWORKS_FILE = "wifi_networks.json"
PRINTER_CONFIG_FILE = "printer_config.json"
PRINTER_PROFILES_FILE = "printer_profiles.json"
PRINTER_SCAN_RANGES_FILE = "printer_scan_ranges.json"
PRINTER_MANUAL_SELECTION_GRACE_SECONDS = 10 * 60
DEFAULT_WIFI_COUNTRY = "CZ"
DEFAULT_PRINTER_URI = "ipp://192.168.223.1/ipp/print"
DEFAULT_PRINTER_RAW_HOST = "192.168.223.1"
DEFAULT_PRINTER_RAW_PORT = 9100
DEFAULT_OFFICE_PRINTER_SCAN_RANGES = (
    "10.40.100.0/24",
    "10.40.101.0/24",
    "10.40.102.0/24",
    "10.40.103.0/24",
    "10.40.107.0/24",
)
DEFAULT_MODEL_MANIFEST_URL = "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/model_manifest.json"
DEFAULT_MODEL_DATABASE_URL = "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/model.json"
DEFAULT_HARDWARECHECK_UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/asphirien-jpg/modelfinder-db/refs/heads/main/latest_hardwarecheck_v5.json"
DEFAULT_STATUS_OWNER = "asphirien-jpg"
DEFAULT_STATUS_REPO = "hardwarecheck-status"
DEFAULT_STATUS_BRANCH = "main"
NETWORK_READY_CACHE_SECONDS = 15 * 60
NETWORK_READY_UNTIL = 0.0
NETWORK_READY_MESSAGE = ""
WIFI_SECURITY_MODES = {"WPA3", "WPA3/WPA2", "WPA2", "OPEN"}
STATUS_TOKEN_FILE = "hardwarecheck-status-token.txt"
DEVICE_IDENTITY_FILE = "device_identity.json"
XRANDR_MODELINES = {
    "1366x768": ("1366x768_60.00", "85.50", "1366", "1436", "1579", "1792", "768", "771", "774", "798", "-hsync", "+vsync"),
    "1600x900": ("1600x900_60.00", "118.25", "1600", "1696", "1856", "2112", "900", "903", "908", "934", "-hsync", "+vsync"),
    "1920x1080": ("1920x1080_60.00", "173.00", "1920", "2048", "2248", "2576", "1080", "1083", "1088", "1120", "-hsync", "+vsync"),
}

EV_SYN = 0
EV_KEY = 1
EV_REL = 2
EV_ABS = 3
REL_X = 0
REL_Y = 1
ABS_X = 0
ABS_Y = 1
ABS_MT_POSITION_X = 53
ABS_MT_POSITION_Y = 54
BTN_LEFT = 272
BTN_TOUCH = 330
INPUT_EVENT = struct.Struct("llHHi")
RAW_SHIFT_CODES = {42, 54}
RAW_ALTGR_CODES = {100}
RAW_TEXT_KEYS = {
    41: "^",
    2: "1",
    3: "2",
    4: "3",
    5: "4",
    6: "5",
    7: "6",
    8: "7",
    9: "8",
    10: "9",
    11: "0",
    12: "ß",
    13: "´",
    16: "q",
    17: "w",
    18: "e",
    19: "r",
    20: "t",
    21: "z",
    22: "u",
    23: "i",
    24: "o",
    25: "p",
    26: "ü",
    27: "+",
    30: "a",
    31: "s",
    32: "d",
    33: "f",
    34: "g",
    35: "h",
    36: "j",
    37: "k",
    38: "l",
    39: "ö",
    40: "ä",
    43: "#",
    44: "y",
    45: "x",
    46: "c",
    47: "v",
    48: "b",
    49: "n",
    50: "m",
    51: ",",
    52: ".",
    53: "-",
    57: " ",
    86: "<",
}
RAW_TEXT_SHIFT_KEYS = {
    "1": "!",
    "2": '"',
    "3": "§",
    "4": "$",
    "5": "%",
    "6": "&",
    "7": "/",
    "8": "(",
    "9": ")",
    "0": "=",
    "ß": "?",
    "´": "`",
    "ü": "Ü",
    "+": "*",
    "ö": "Ö",
    "ä": "Ä",
    "^": "°",
    "#": "'",
    ",": ";",
    ".": ":",
    "-": "_",
    "<": ">",
}
RAW_TEXT_ALTGR_KEYS = {
    3: "²",
    4: "³",
    8: "{",
    9: "[",
    10: "]",
    11: "}",
    12: "\\",
    16: "@",
    18: "€",
    27: "~",
    50: "µ",
    86: "|",
}
VIRTUAL_KEY_ALTGR_VALUES = {
    "2": "²",
    "3": "³",
    "7": "{",
    "8": "[",
    "9": "]",
    "0": "}",
    "ß": "\\",
    "q": "@",
    "e": "€",
    "+": "~",
    "m": "µ",
    "<": "|",
}

def run_command(*args: str) -> str:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=3,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""
    return result.stdout.strip()


def run_quiet(*args: str) -> bool:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=3,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def read_text(path: os.PathLike[str] | str) -> str:
    try:
        return pathlib.Path(path).read_text(encoding="utf-8", errors="ignore").strip()
    except OSError:
        return ""


def read_bytes(path: os.PathLike[str] | str) -> bytes:
    try:
        return pathlib.Path(path).read_bytes()
    except OSError:
        return b""


def first_existing_text(paths: list[os.PathLike[str] | str]) -> str:
    for path in paths:
        value = read_text(path)
        if value:
            return value
    return ""


def sanitize_filename(value: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", value).strip() or "report"


def same_path(left: pathlib.Path, right: pathlib.Path) -> bool:
    try:
        return left.resolve() == right.resolve()
    except OSError:
        return left == right


def add_unique_path(paths: list[pathlib.Path], candidate: pathlib.Path) -> None:
    if not candidate:
        return
    if any(same_path(existing, candidate) for existing in paths):
        return
    paths.append(candidate)


def case_insensitive_child(directory: pathlib.Path, filename: str) -> pathlib.Path | None:
    direct = directory / filename
    if direct.is_file():
        return direct
    try:
        for child in directory.iterdir():
            if child.is_file() and child.name.lower() == filename.lower():
                return child
    except OSError:
        return None
    return None


def candidate_external_roots() -> list[pathlib.Path]:
    roots: list[pathlib.Path] = []
    env_root = os.environ.get("HC_DATA_DIR", "").strip()
    if env_root:
        add_unique_path(roots, pathlib.Path(env_root))

    for candidate in [
        pathlib.Path("/cdrom") / PORTABLE_DIR_NAME,
        pathlib.Path("/cdrom"),
    ]:
        add_unique_path(roots, candidate)

    for base in [pathlib.Path("/media"), pathlib.Path("/mnt"), pathlib.Path("/run/media")]:
        if not base.exists():
            continue
        for pattern in [PORTABLE_DIR_NAME, f"*/{PORTABLE_DIR_NAME}", f"*/*/{PORTABLE_DIR_NAME}"]:
            for candidate in base.glob(pattern):
                add_unique_path(roots, candidate)

    return [root for root in roots if root.is_dir()]


def find_external_file(filename: str) -> pathlib.Path | None:
    for root in candidate_external_roots():
        candidate = case_insensitive_child(root, filename)
        if candidate:
            return candidate

    for root in [pathlib.Path("/cdrom"), pathlib.Path("/media"), pathlib.Path("/mnt"), pathlib.Path("/run/media")]:
        if not root.exists():
            continue
        for candidate in root.glob(f"**/{filename}"):
            if candidate.is_file():
                return candidate
    return None


def find_external_root() -> pathlib.Path | None:
    for root in candidate_external_roots():
        if (
            case_insensitive_child(root, "model.json")
            or case_insensitive_child(root, SETTINGS_FILE)
            or (root / PORTABLE_MARKER).is_file()
            or (root / ".alpine-release").is_file()
        ):
            return root

    external_model = find_external_file("model.json")
    if external_model:
        return external_model.parent
    for root in [pathlib.Path("/cdrom"), pathlib.Path("/media"), pathlib.Path("/mnt"), pathlib.Path("/run/media")]:
        if not root.exists():
            continue
        for candidate in root.glob("**/.alpine-release"):
            if candidate.is_file():
                return candidate.parent
    return None


def path_is_writable_directory(path: pathlib.Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".hardwarecheck-write-test"
        probe.write_text("ok\n", encoding="ascii")
        probe.unlink()
        return True
    except OSError:
        return False


def path_is_readable_file(path: pathlib.Path) -> bool:
    try:
        with path.open("rb") as handle:
            handle.read(1)
        return True
    except OSError:
        return False


def writable_data_root() -> pathlib.Path | None:
    for root in candidate_report_roots():
        if path_is_writable_directory(root):
            return root
    return None


def writable_tool_root() -> pathlib.Path | None:
    writable_root = writable_data_root()
    if writable_root:
        return writable_root
    if path_is_writable_directory(SCRIPT_DIR):
        return SCRIPT_DIR
    return None


def writable_companion_path(filename: str, preferred_root: pathlib.Path | None = None) -> pathlib.Path | None:
    if preferred_root and path_is_writable_directory(preferred_root):
        return preferred_root / filename
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / filename
    return None


def readable_file_sha256(path: pathlib.Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else ""
    except OSError:
        return ""


def writable_model_path(preferred: pathlib.Path | None = None) -> pathlib.Path:
    if preferred and path_is_writable_directory(preferred.parent):
        return preferred
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / "model.json"
    return preferred or (SCRIPT_DIR / "model.json")


def candidate_report_roots() -> list[pathlib.Path]:
    roots: list[pathlib.Path] = []
    external_root = find_external_root()
    if external_root:
        add_unique_path(roots, external_root)
    for root in candidate_external_roots():
        add_unique_path(roots, root)
    for base in [pathlib.Path("/media"), pathlib.Path("/mnt"), pathlib.Path("/run/media")]:
        if not base.exists():
            continue
        for candidate in base.glob("**/" + PORTABLE_DIR_NAME):
            if candidate.is_dir():
                add_unique_path(roots, candidate)
        for candidate in base.glob("*"):
            if candidate.is_dir():
                add_unique_path(roots, candidate)
    add_unique_path(roots, SCRIPT_DIR)
    return roots


def find_debug_roots() -> list[pathlib.Path]:
    roots: list[pathlib.Path] = []
    external_root = find_external_root()
    if external_root:
        roots.append(external_root)

    patterns = [
        pathlib.Path("/cdrom").glob("*"),
        pathlib.Path("/media").glob("*"),
        pathlib.Path("/mnt").glob("*"),
        pathlib.Path("/run/media").glob("*/*"),
    ]
    for pattern in patterns:
        for candidate in pattern:
            if candidate.is_dir() and candidate not in roots:
                roots.append(candidate)
    if SCRIPT_DIR not in roots:
        roots.append(SCRIPT_DIR)
    return roots


def get_models_path() -> pathlib.Path:
    for root in candidate_report_roots():
        candidate = case_insensitive_child(root, "model.json")
        if candidate and path_is_readable_file(candidate):
            return candidate
    external_model = find_external_file("model.json")
    if external_model and path_is_readable_file(external_model):
        return external_model
    writable_root = writable_data_root()
    if writable_root:
        return writable_root / "model.json"
    return SCRIPT_DIR / "model.json"


def get_report_dir() -> pathlib.Path:
    for root in candidate_report_roots():
        report_dir = root / "Model Report"
        if path_is_writable_directory(report_dir):
            return report_dir
    external_root = find_external_root()
    if external_root:
        return external_root / "Model Report"
    return SCRIPT_DIR / "Model Report"


def get_battery_report_dir() -> pathlib.Path:
    for root in candidate_report_roots():
        report_dir = root / BATTERY_REPORT_DIR_NAME
        if path_is_writable_directory(report_dir):
            return report_dir
    external_root = find_external_root()
    if external_root:
        return external_root / BATTERY_REPORT_DIR_NAME
    return SCRIPT_DIR / BATTERY_REPORT_DIR_NAME


def get_settings_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        return external_root / SETTINGS_FILE
    return SCRIPT_DIR / SETTINGS_FILE


def load_settings() -> dict[str, object]:
    try:
        data = json.loads(get_settings_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def save_settings(settings: dict[str, object]) -> None:
    try:
        write_text_durable(get_settings_path(), json.dumps(settings, indent=2) + "\n")
    except OSError:
        pass


WORKSHOP_START_MODE_FILENAME = "workshop-start-mode.json"
WORKSHOP_START_MODES = frozenset({"magic", "hardwarecheck", "compactcheck"})


def get_workshop_start_mode_path() -> pathlib.Path:
    """Return the local, update-safe storage for the selected workshop UI."""

    return get_settings_path().with_name(WORKSHOP_START_MODE_FILENAME)


def get_workshop_start_mode() -> str:
    """Load the remembered UI, with Magic Image as the Solo-medium default."""

    try:
        data = json.loads(get_workshop_start_mode_path().read_text(encoding="utf-8"))
        mode = str(data.get("mode") or "").strip().lower() if isinstance(data, dict) else ""
        if mode in WORKSHOP_START_MODES:
            return mode
    except (OSError, json.JSONDecodeError):
        pass
    # A normal HardwareCheck stick does not carry the Magic module and must
    # keep its established behavior. A combined Magic SSD starts Magic Image.
    return "magic" if (SCRIPT_DIR / "magic_image_solo_gui.py").is_file() else "hardwarecheck"


def set_workshop_start_mode(mode: str) -> None:
    """Persist the explicitly chosen UI for the next application start."""

    normalized = str(mode or "").strip().lower()
    if normalized not in WORKSHOP_START_MODES:
        raise ValueError("Ungültiger Arbeitsmodus.")
    write_json_atomic(get_workshop_start_mode_path(), {"mode": normalized})


def write_text_durable(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())

    try:
        directory_fd = os.open(str(path.parent), os.O_RDONLY)
    except OSError:
        directory_fd = -1
    if directory_fd >= 0:
        try:
            os.fsync(directory_fd)
        except OSError:
            pass
        finally:
            os.close(directory_fd)

    if os.environ.get("HC_DURABLE_SYNC") == "1":
        run_quiet("sync")


def write_bytes_atomic(path: pathlib.Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f".{path.name}.tmp")
    try:
        with temp_path.open("wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        temp_path.replace(path)
        try:
            directory_fd = os.open(str(path.parent), os.O_RDONLY)
        except OSError:
            directory_fd = -1
        if directory_fd >= 0:
            try:
                os.fsync(directory_fd)
            except OSError:
                pass
            finally:
                os.close(directory_fd)
        if sys.platform == "linux" or os.environ.get("HC_DURABLE_SYNC") == "1":
            run_quiet("sync")
    finally:
        try:
            if temp_path.exists():
                temp_path.unlink()
        except OSError:
            pass


def write_json_atomic(path: pathlib.Path, data: object) -> None:
    payload = (json.dumps(data, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    write_bytes_atomic(path, payload)


def github_api_json(method: str, url: str, token: str, payload: dict[str, object] | None = None) -> dict[str, object]:
    body = None
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "User-Agent": "HardwareCheck-Status/1.0",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=15) as response:
        raw = response.read().decode("utf-8-sig")
        return json.loads(raw) if raw else {}


def github_contents_url(owner: str, repo: str, path: str, branch: str) -> str:
    encoded = urllib.parse.quote(path.strip("/"))
    return f"https://api.github.com/repos/{owner}/{repo}/contents/{encoded}?{urllib.parse.urlencode({'ref': branch})}"


def github_put_url(owner: str, repo: str, path: str) -> str:
    encoded = urllib.parse.quote(path.strip("/"))
    return f"https://api.github.com/repos/{owner}/{repo}/contents/{encoded}"


def github_existing_sha(owner: str, repo: str, branch: str, token: str, path: str) -> str:
    try:
        data = github_api_json("GET", github_contents_url(owner, repo, path, branch), token)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return ""
        raise
    return str(data.get("sha") or "")


def publish_hardwarecheck_status(event: str, extra: dict[str, object] | None = None) -> tuple[bool, str]:
    token = load_status_token()
    if not token:
        return False, "Status: Token fehlt"
    identity = load_device_identity()
    device_id = sanitize_filename(str(identity.get("device_id") or "hardwarecheck-stick")).lower()
    owner = DEFAULT_STATUS_OWNER
    repo = DEFAULT_STATUS_REPO
    branch = DEFAULT_STATUS_BRANCH
    repo_value = str(identity.get("status_repo") or "").strip()
    if "/" in repo_value:
        owner, repo = repo_value.split("/", 1)
    repo_path = f"status/{device_id}.json"
    local_manifest = load_local_model_manifest()
    db_model_count = manifest_value(local_manifest, "models_count", "count", "entries")
    last_seen = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat()
    payload: dict[str, object] = {
        "tool": "HardwareCheck",
        "device_id": device_id,
        "device_name": str(identity.get("device_name") or identity.get("display_name") or device_id),
        "display_name": str(identity.get("display_name") or identity.get("device_name") or device_id),
        "owner": str(identity.get("owner") or ""),
        "app_version": APP_VERSION,
        "db_version": manifest_value(local_manifest, "version", "db_version", "database_version"),
        "db_model_count": db_model_count,
        "db_models_count": db_model_count,
        "hostname": socket.gethostname(),
        "event": event,
        "last_seen": last_seen,
        "last_seen_utc": last_seen,
    }
    if extra:
        payload.update(extra)
    content = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    api_payload: dict[str, object] = {
        "message": f"HardwareCheck status {device_id}: {APP_VERSION}",
        "content": base64.b64encode(content.encode("utf-8")).decode("ascii"),
        "branch": branch,
    }
    sha = github_existing_sha(owner, repo, branch, token, repo_path)
    if sha:
        api_payload["sha"] = sha
    github_api_json("PUT", github_put_url(owner, repo, repo_path), token, api_payload)
    return True, f"Status gemeldet: {device_id}"


def get_model_manifest_local_path() -> pathlib.Path:
    for root in candidate_report_roots():
        candidate = root / "model_manifest_local.json"
        if candidate.is_file() and path_is_readable_file(candidate):
            return candidate
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / "model_manifest_local.json"
    external_root = find_external_root()
    if external_root:
        return external_root / "model_manifest_local.json"
    return SCRIPT_DIR / "model_manifest_local.json"


def get_writable_model_manifest_local_path(preferred_model_path: pathlib.Path | None = None) -> pathlib.Path | None:
    preferred_root = preferred_model_path.parent if preferred_model_path else None
    return writable_companion_path("model_manifest_local.json", preferred_root)


def get_model_backup_dir() -> pathlib.Path:
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / "backups" / "model_json"
    external_root = find_external_root()
    if external_root:
        return external_root / "backups" / "model_json"
    return SCRIPT_DIR / "backups" / "model_json"


def get_update_download_dir() -> pathlib.Path:
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / "updates" / "downloads"
    return SCRIPT_DIR / "updates" / "downloads"


def get_update_staging_dir() -> pathlib.Path:
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / "updates" / "staging"
    return SCRIPT_DIR / "updates" / "staging"


def install_v53_magic_image_module_from_staging() -> tuple[bool, str]:
    """Complete the v5.2 -> v5.3 bridge after the legacy updater restarts.

    HardwareCheck v5.2 deliberately accepts only the two historical program
    files as ``replace_paths``.  The signed/hashed v5.3 package therefore keeps
    those two paths in its manifest and carries ``magic_image_manager.py`` as
    an additional payload file.  On the first v5.3 start we copy that module
    from the already validated staging directory before importing the GTK UI.
    Future v5.3+ packages can update the module normally because v5.3 expands
    the explicit updater whitelist.
    """

    target = SCRIPT_DIR / "magic_image_manager.py"
    if target.is_file() and target.stat().st_size > 0:
        return True, "Magic-Image-Modul bereits vorhanden"
    staged = get_update_staging_dir() / sanitize_filename(APP_VERSION) / "payload" / target.name
    if not staged.is_file() or staged.stat().st_size <= 0:
        return False, f"Magic-Image-Modul nicht im Update-Staging gefunden: {staged}"
    try:
        source_text = staged.read_text(encoding="utf-8-sig")
        compile(source_text, str(staged), "exec")
        write_bytes_atomic(target, staged.read_bytes())
        if not target.is_file() or target.stat().st_size != staged.stat().st_size:
            raise OSError("kopierte Moduldatei ist unvollstaendig")
    except (OSError, SyntaxError) as exc:
        return False, f"Magic-Image-Modul konnte nicht uebernommen werden: {exc}"
    return True, f"Magic-Image-Modul aus v5.3-Staging installiert: {target}"


def install_config_server_sync_module_from_staging() -> tuple[bool, str]:
    """Complete the dependency migration before either GTK interface imports it.

    Updaters through v5.4.8 cannot replace config_server_sync.py. The v5.4.9
    package carries it as extra payload; the restarted core installs it from
    this version's staging directory. The fixed digest binds that extra file
    to the released core, including on USB sticks with no previous copy.
    Complete installations (including USB SSDs and fresh creator media) keep
    their existing module. Subsequent packages can use the expanded whitelist.
    """
    target = SCRIPT_DIR / "config_server_sync.py"
    try:
        if target.is_file() and target.stat().st_size > 0:
            return True, "Config-Sync-Modul bereits vorhanden"
        staged = get_update_staging_dir() / sanitize_filename(APP_VERSION) / "payload" / target.name
        if not staged.is_file():
            return False, f"Config-Sync-Modul nicht im Update-Staging gefunden: {staged}"
        payload = staged.read_bytes()
        if hashlib.sha256(payload).hexdigest() != CONFIG_SERVER_SYNC_BRIDGE_SHA256:
            return False, "Config-Sync-Modul im Update-Staging hat eine falsche Pruefsumme"
        compile(payload.decode("utf-8-sig"), str(staged), "exec")
        write_bytes_atomic(target, payload)
        if target.read_bytes() != payload:
            raise OSError("kopierte Moduldatei ist unvollstaendig")
    except (OSError, SyntaxError, UnicodeError) as exc:
        return False, f"Config-Sync-Modul konnte nicht uebernommen werden: {exc}"
    return True, f"Config-Sync-Modul aus Update-Staging installiert: {target}"


def install_gpu_name_database_from_staging() -> tuple[bool, str]:
    """Install the compact GPU-name lookup carried as a v5.4.30 bridge asset.

    v5.4.29 does not yet whitelist this data file in ``replace_paths``.  Its
    updater nevertheless stages every verified payload member.  The new core
    validates the JSON and adopts that staged, small lookup before launching
    the UI; later releases can replace it normally.
    """

    target = SCRIPT_DIR / "gpu_names.json"
    if target.is_file() and target.stat().st_size > 0:
        return True, "GPU-Namensdatenbank bereits vorhanden"
    staged = get_update_staging_dir() / sanitize_filename(APP_VERSION) / "payload" / target.name
    try:
        raw = staged.read_bytes()
        data = json.loads(raw.decode("utf-8-sig"))
        if not isinstance(data, dict) or not isinstance(data.get("entries"), dict):
            return False, "GPU-Namensdatenbank im Update-Staging ist ungültig"
        write_bytes_atomic(target, raw)
        if target.read_bytes() != raw:
            raise OSError("kopierte GPU-Namensdatenbank ist unvollständig")
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return False, f"GPU-Namensdatenbank konnte nicht übernommen werden: {exc}"
    return True, f"GPU-Namensdatenbank aus {APP_VERSION}-Staging installiert"


def install_pci_database_from_staging() -> tuple[bool, str]:
    """Adopt the current bundled PCI-ID database after the v5.4.30 bridge."""

    target = SCRIPT_DIR / "pci.ids"
    if target.is_file() and target.stat().st_size > 0:
        return True, "PCI-ID-Datenbank bereits vorhanden"
    staged = get_update_staging_dir() / sanitize_filename(APP_VERSION) / "payload" / target.name
    try:
        raw = staged.read_bytes()
        if b"10de" not in raw.lower() or len(raw) < 100_000:
            return False, "PCI-ID-Datenbank im Update-Staging ist ungültig"
        write_bytes_atomic(target, raw)
        if target.read_bytes() != raw:
            raise OSError("kopierte PCI-ID-Datenbank ist unvollständig")
    except OSError as exc:
        return False, f"PCI-ID-Datenbank konnte nicht übernommen werden: {exc}"
    return True, f"PCI-ID-Datenbank aus {APP_VERSION}-Staging installiert"


def get_update_backup_dir() -> pathlib.Path:
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / "updates" / "backups"
    return SCRIPT_DIR / "updates" / "backups"


def get_update_log_dir() -> pathlib.Path:
    writable_root = writable_tool_root()
    if writable_root:
        return writable_root / "updates" / "logs"
    return SCRIPT_DIR / "updates" / "logs"


def get_device_identity_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root and (external_root / DEVICE_IDENTITY_FILE).exists():
        return external_root / DEVICE_IDENTITY_FILE
    return SCRIPT_DIR / DEVICE_IDENTITY_FILE


def get_status_token_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root and (external_root / STATUS_TOKEN_FILE).exists():
        return external_root / STATUS_TOKEN_FILE
    return SCRIPT_DIR / STATUS_TOKEN_FILE


def load_device_identity() -> dict[str, object]:
    try:
        data = json.loads(get_device_identity_path().read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    if not str(data.get("device_id") or "").strip():
        data["device_id"] = f"hardwarecheck-{sanitize_filename(socket.gethostname() or 'stick').lower()}"
    if not str(data.get("device_name") or data.get("display_name") or "").strip():
        data["device_name"] = str(data.get("device_id") or "HardwareCheck")
    return data


def load_status_token() -> str:
    try:
        return get_status_token_path().read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def get_wifi_networks_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        external_wifi = case_insensitive_child(external_root, WIFI_NETWORKS_FILE)
        if external_wifi:
            return external_wifi
    external_wifi = find_external_file(WIFI_NETWORKS_FILE)
    if external_wifi:
        return external_wifi
    if external_root:
        return external_root / WIFI_NETWORKS_FILE
    return SCRIPT_DIR / WIFI_NETWORKS_FILE


def get_printer_config_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        external_printer = case_insensitive_child(external_root, PRINTER_CONFIG_FILE)
        if external_printer:
            return external_printer
    external_printer = find_external_file(PRINTER_CONFIG_FILE)
    if external_printer:
        return external_printer
    if external_root:
        return external_root / PRINTER_CONFIG_FILE
    return SCRIPT_DIR / PRINTER_CONFIG_FILE


def get_printer_profiles_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        external_profiles = case_insensitive_child(external_root, PRINTER_PROFILES_FILE)
        if external_profiles:
            return external_profiles
    external_profiles = find_external_file(PRINTER_PROFILES_FILE)
    if external_profiles:
        return external_profiles
    if external_root:
        return external_root / PRINTER_PROFILES_FILE
    return SCRIPT_DIR / PRINTER_PROFILES_FILE


def get_printer_scan_ranges_path() -> pathlib.Path:
    external_root = find_external_root()
    if external_root:
        external_ranges = case_insensitive_child(external_root, PRINTER_SCAN_RANGES_FILE)
        if external_ranges:
            return external_ranges
    external_ranges = find_external_file(PRINTER_SCAN_RANGES_FILE)
    if external_ranges:
        return external_ranges
    if external_root:
        return external_root / PRINTER_SCAN_RANGES_FILE
    return SCRIPT_DIR / PRINTER_SCAN_RANGES_FILE


def manifest_value(data: dict[str, object], *keys: str) -> str:
    for key in keys:
        value = data.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def format_database_version(value: str) -> str:
    text = str(value or "").strip()
    match = re.fullmatch(r"(\d{4})[.-](\d{1,2})[.-](\d{1,2})(.*)", text)
    if not match:
        return text
    year, month, day, suffix = match.groups()
    return f"{int(day):02d}.{int(month):02d}.{int(year):04d}{suffix}"


def format_database_versions_in_text(text: str) -> str:
    def replace(match: re.Match[str]) -> str:
        return format_database_version(match.group(0))

    return re.sub(r"\b\d{4}[.-]\d{1,2}[.-]\d{1,2}(?:[.-]\d+)?\b", replace, str(text or ""))


def parse_database_version(value: str) -> list[int]:
    return [int(part) for part in re.findall(r"\d+", value or "")]


def version_prerelease_rank(value: str) -> int:
    text = (value or "").lower()
    if any(marker in text for marker in ("test", "alpha", "beta", "rc", "dev")):
        return 0
    return 1


def version_is_newer(remote: str, local: str) -> bool:
    remote_parts = parse_database_version(remote)
    local_parts = parse_database_version(local)
    length = max(len(remote_parts), len(local_parts), 1)
    remote_parts.extend([0] * (length - len(remote_parts)))
    local_parts.extend([0] * (length - len(local_parts)))
    if remote_parts != local_parts:
        return remote_parts > local_parts
    return version_prerelease_rank(remote) > version_prerelease_rank(local)


def normalized_app_version() -> str:
    return APP_VERSION.lstrip("vV").strip()


def load_local_model_manifest() -> dict[str, object]:
    try:
        data = json.loads(get_model_manifest_local_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def local_model_database_info() -> tuple[str, int]:
    manifest = load_local_model_manifest()
    version = manifest_value(manifest, "version", "db_version", "database_version") or "lokal"
    count = 0
    for key in ("models_count", "model_count", "count", "entries"):
        value = manifest.get(key)
        if value in (None, ""):
            continue
        try:
            count = int(float(str(value)))
            break
        except ValueError:
            continue
    if count <= 0:
        count = len(load_model_db())
    return version, count


def download_bytes(url: str, timeout: int = 8, token: str = "", progress_callback=None) -> bytes:
    headers = {"User-Agent": "HardwareCheck-ModelUpdater/1.0"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        try:
            total = max(0, int(response.headers.get("Content-Length") or 0))
        except (TypeError, ValueError):
            total = 0
        chunks: list[bytes] = []
        downloaded = 0
        if progress_callback is not None:
            progress_callback(downloaded, total)
        while True:
            chunk = response.read(128 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
            downloaded += len(chunk)
            if progress_callback is not None:
                progress_callback(downloaded, total)
        return b"".join(chunks)


def download_json(url: str, timeout: int = 8, token: str = "") -> object:
    return json.loads(download_bytes(url, timeout, token).decode("utf-8-sig"))


def filename_from_url(url: str, fallback: str) -> str:
    try:
        path = urllib.parse.urlparse(url).path
    except Exception:
        path = ""
    name = pathlib.PurePosixPath(path).name if path else ""
    return sanitize_filename(name or fallback)


PROTECTED_UPDATE_PATHS = {
    "model.json",
    "model_manifest_local.json",
    "hardwarecheck-settings.json",
    "wifi_networks.json",
    "printer_config.json",
    "printer_profiles.json",
    "printer_scan_ranges.json",
    ".hardwarecheck-portable",
    "model report",
    "battery report",
    "hardwarecheck-debug",
    "backups",
    "updates/backups",
}

ALLOWED_UPDATE_REPLACE_PATHS = {
    "hardwarecheck_fast_gui.py",
    "hardwarecheck_v5_gui.py",
    "magic_image_manager.py",
    "config_server_sync.py",
    "gpu_names.json",
}


def normalize_update_path(value: object) -> str:
    text = str(value or "").replace("\\", "/").strip().strip("/")
    parts = [part for part in text.split("/") if part and part not in {".", ".."}]
    return "/".join(parts)


def validate_hardwarecheck_update_package(package_dir: pathlib.Path) -> tuple[bool, str]:
    manifest_path = package_dir / "update_manifest.json"
    payload_dir = package_dir / "payload"
    if not manifest_path.is_file():
        return False, "update_manifest.json fehlt"
    if not payload_dir.is_dir():
        return False, "payload/ fehlt"
    try:
        manifest_raw = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return False, "update_manifest.json ungültig"
    if not isinstance(manifest_raw, dict):
        return False, "update_manifest.json ist kein Objekt"
    app_name = manifest_value(manifest_raw, "app", "name", "product")
    if app_name.lower() != "hardwarecheck":
        return False, f"falsches Paket ({app_name or '?'})"
    replace_raw = manifest_raw.get("replace_paths")
    preserve_raw = manifest_raw.get("preserve_paths")
    if not isinstance(replace_raw, list) or not replace_raw:
        return False, "replace_paths fehlt oder ist leer"
    if not isinstance(preserve_raw, list):
        return False, "preserve_paths fehlt oder ist keine Liste"
    replace_paths = [normalize_update_path(item) for item in replace_raw]
    replace_paths = [item for item in replace_paths if item]
    if not replace_paths:
        return False, "replace_paths enthaelt keine gültigen Pfade"
    for path in replace_paths:
        if path.lower() in PROTECTED_UPDATE_PATHS:
            return False, f"geschuetzter Pfad in replace_paths: {path}"
        if path not in ALLOWED_UPDATE_REPLACE_PATHS:
            return False, f"nicht erlaubter replace_path: {path}"
        if not (payload_dir / path).is_file():
            return False, f"payload-Datei fehlt: {path}"
    preserve_paths = {normalize_update_path(item).lower() for item in preserve_raw}
    missing_preserves = sorted(PROTECTED_UPDATE_PATHS - preserve_paths)
    if missing_preserves:
        return False, "preserve_paths unvollstaendig: " + ", ".join(missing_preserves[:4])
    return True, f"Paket geprüft: {len(replace_paths)} Datei(en)"


def safe_extract_zip(zip_path: pathlib.Path, target_dir: pathlib.Path) -> None:
    target_root = target_dir.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            member_name = member.filename.replace("\\", "/")
            if member_name.startswith("/") or ".." in pathlib.PurePosixPath(member_name).parts:
                raise ValueError(f"unsicherer ZIP-Pfad: {member.filename}")
            member_target = (target_dir / member_name).resolve()
            if member_target != target_root and not str(member_target).startswith(str(target_root) + os.sep):
                raise ValueError(f"ZIP-Pfad ausserhalb Staging: {member.filename}")
        archive.extractall(target_dir)


def load_update_manifest(package_dir: pathlib.Path) -> dict[str, object]:
    data = json.loads((package_dir / "update_manifest.json").read_text(encoding="utf-8-sig"))
    return data if isinstance(data, dict) else {}


def update_replace_paths(manifest: dict[str, object]) -> list[str]:
    raw = manifest.get("replace_paths")
    if not isinstance(raw, list):
        return []
    return [path for path in (normalize_update_path(item) for item in raw) if path]


def write_hardwarecheck_update_installer(staging_dir: pathlib.Path, target_version: str) -> dict[str, str]:
    manifest = load_update_manifest(staging_dir)
    replace_paths = update_replace_paths(manifest)
    safe_version = sanitize_filename(target_version)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backup_dir = get_update_backup_dir() / f"{stamp}_{sanitize_filename(APP_VERSION)}_to_{safe_version}"
    log_dir = get_update_log_dir()
    log_path = log_dir / "update_install.log"
    script_path = staging_dir / "apply_hardwarecheck_update.py"
    config_path = staging_dir / "installer_config.json"
    tool_root = SCRIPT_DIR
    python_exe = sys.executable or "python3"
    config = {
        "tool_root": str(tool_root),
        "payload_dir": str(staging_dir / "payload"),
        "backup_dir": str(backup_dir),
        "log_path": str(log_path),
        "replace_paths": replace_paths,
        "python_exe": python_exe,
        "app_file": "hardwarecheck_fast_gui.py",
        "target_version": target_version,
    }
    installer_script = r'''#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
import traceback


class ProgressWindow:
    def __init__(self) -> None:
        self.root = None
        self.label = None
        self.bar = None
        try:
            import tkinter as tk
            from tkinter import ttk
            self.root = tk.Tk()
            self.root.title("HardwareCheck Update")
            self.root.geometry("520x150+120+120")
            self.root.configure(bg="#12161b")
            self.root.attributes("-topmost", True)
            self.label = tk.Label(
                self.root,
                text="Update wird vorbereitet ...",
                bg="#12161b",
                fg="#f3f6f9",
                font=("Segoe UI", 12, "bold"),
                anchor="w",
                padx=18,
                pady=16,
            )
            self.label.pack(fill="x")
            self.bar = ttk.Progressbar(self.root, orient="horizontal", length=460, mode="determinate", maximum=100)
            self.bar.pack(fill="x", padx=18, pady=(4, 12))
            self.root.update()
        except Exception:
            self.root = None

    def update(self, percent: int, message: str) -> None:
        print(f"{percent}% {message}", flush=True)
        if self.root is None:
            return
        try:
            if self.label is not None:
                self.label.configure(text=message)
            if self.bar is not None:
                self.bar["value"] = max(0, min(100, percent))
            self.root.update()
        except Exception:
            self.root = None

    def close(self, delay: float = 1.5) -> None:
        if self.root is None:
            time.sleep(delay)
            return
        try:
            self.root.after(int(delay * 1000), self.root.destroy)
            self.root.mainloop()
        except Exception:
            pass


def safe_relative(value: str) -> pathlib.PurePosixPath:
    text = str(value or "").replace("\\", "/").strip().strip("/")
    path = pathlib.PurePosixPath(text)
    if not text or path.is_absolute() or ".." in path.parts:
        raise ValueError(f"Unsicherer Pfad: {value}")
    return path


def append_log(log_path: pathlib.Path, message: str) -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {message}\n")


def copy_atomic(source: pathlib.Path, target: pathlib.Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_target = target.with_name(f".{target.name}.update_tmp")
    try:
        shutil.copy2(source, temp_target)
        os.replace(temp_target, target)
    finally:
        try:
            if temp_target.exists():
                temp_target.unlink()
        except OSError:
            pass


def restore_backup(tool_root: pathlib.Path, backup_dir: pathlib.Path, replace_paths: list[str], log_path: pathlib.Path) -> None:
    for rel_text in replace_paths:
        rel = safe_relative(rel_text)
        backup_file = backup_dir.joinpath(*rel.parts)
        target_file = tool_root.joinpath(*rel.parts)
        if backup_file.is_file():
            append_log(log_path, f"Rollback {backup_file} -> {target_file}")
            copy_atomic(backup_file, target_file)


def main() -> int:
    if len(sys.argv) < 2:
        print("installer_config.json fehlt", file=sys.stderr)
        return 2
    config_path = pathlib.Path(sys.argv[1]).resolve()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    tool_root = pathlib.Path(config["tool_root"]).resolve()
    payload_dir = pathlib.Path(config["payload_dir"]).resolve()
    backup_dir = pathlib.Path(config["backup_dir"]).resolve()
    log_path = pathlib.Path(config["log_path"]).resolve()
    replace_paths = [str(item) for item in config.get("replace_paths", [])]
    python_exe = str(config.get("python_exe") or sys.executable or "python3")
    app_file = str(config.get("app_file") or "hardwarecheck_fast_gui.py")
    progress = ProgressWindow()
    try:
        append_log(log_path, "HardwareCheck Update gestartet")
        progress.update(5, "Warte auf HardwareCheck ...")
        time.sleep(1.2)

        progress.update(18, "Backup wird erstellt ...")
        backup_dir.mkdir(parents=True, exist_ok=True)
        for rel_text in replace_paths:
            rel = safe_relative(rel_text)
            source_current = tool_root.joinpath(*rel.parts)
            backup_target = backup_dir.joinpath(*rel.parts)
            if source_current.is_file():
                backup_target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_current, backup_target)
                append_log(log_path, f"Backup {source_current} -> {backup_target}")

        progress.update(42, "Neue Dateien werden kopiert ...")
        for rel_text in replace_paths:
            rel = safe_relative(rel_text)
            source_new = payload_dir.joinpath(*rel.parts)
            target_file = tool_root.joinpath(*rel.parts)
            if not source_new.is_file():
                raise FileNotFoundError(f"Payload fehlt: {source_new}")
            append_log(log_path, f"Kopiere {source_new} -> {target_file}")
            copy_atomic(source_new, target_file)

        progress.update(70, "Installation wird geprüft ...")
        for rel_text in replace_paths:
            rel = safe_relative(rel_text)
            target_file = tool_root.joinpath(*rel.parts)
            if not target_file.is_file() or target_file.stat().st_size <= 0:
                raise RuntimeError(f"Zieldatei ungültig: {target_file}")

        progress.update(84, "Daten werden geschrieben ...")
        if hasattr(os, "sync"):
            try:
                os.sync()
            except OSError:
                pass

        progress.update(96, "HardwareCheck wird neu gestartet ...")
        append_log(log_path, "Update erfolgreich")
        app_path = tool_root / app_file
        subprocess.Popen([python_exe, str(app_path)], cwd=str(tool_root))
        progress.update(100, "Update abgeschlossen")
        progress.close(1.3)
        return 0
    except Exception as exc:
        append_log(log_path, "Update fehlgeschlagen: " + repr(exc))
        append_log(log_path, traceback.format_exc())
        try:
            progress.update(88, "Fehler - alte Version wird wiederhergestellt ...")
            restore_backup(tool_root, backup_dir, replace_paths, log_path)
            if hasattr(os, "sync"):
                os.sync()
        except Exception as restore_exc:
            append_log(log_path, "Rollback fehlgeschlagen: " + repr(restore_exc))
        progress.update(100, "Update fehlgeschlagen - siehe Log")
        progress.close(6.0)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
'''
    write_text_durable(script_path, installer_script)
    write_json_atomic(config_path, config)
    try:
        script_path.chmod(0o755)
    except OSError:
        pass
    return {
        "script_path": str(script_path),
        "config_path": str(config_path),
        "target_version": target_version,
    }


def apply_hardwarecheck_update(config: dict[str, object], progress_callback=None) -> pathlib.Path:
    """Install a validated HardwareCheck payload for either the Tk or GTK UI."""

    def progress(percent: int, message: str) -> None:
        if progress_callback is not None:
            progress_callback(max(0, min(100, int(percent))), message)

    def append_install_log(log_path: pathlib.Path, message: str) -> None:
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {message}\n")
        except OSError:
            pass

    tool_root = pathlib.Path(str(config["tool_root"])).resolve()
    payload_dir = pathlib.Path(str(config["payload_dir"])).resolve()
    backup_dir = pathlib.Path(str(config["backup_dir"])).resolve()
    log_path = pathlib.Path(str(config["log_path"])).resolve()
    app_file = normalize_update_path(config.get("app_file") or "hardwarecheck_fast_gui.py")
    raw_replace_paths = config.get("replace_paths")
    if not isinstance(raw_replace_paths, list) or not raw_replace_paths:
        raise ValueError("replace_paths leer")

    replace_paths: list[str] = []
    for raw_path in raw_replace_paths:
        path = normalize_update_path(raw_path)
        if not path or path.lower() in PROTECTED_UPDATE_PATHS:
            raise ValueError(f"Unsicherer Updatepfad: {raw_path}")
        if path not in ALLOWED_UPDATE_REPLACE_PATHS:
            raise ValueError(f"Nicht erlaubter Updatepfad: {path}")
        if path not in replace_paths:
            replace_paths.append(path)
    if app_file not in ALLOWED_UPDATE_REPLACE_PATHS:
        raise ValueError(f"Nicht erlaubte Startdatei: {app_file}")

    append_install_log(log_path, "HardwareCheck In-Process-Update gestartet")
    progress(10, "Backup wird erstellt ...")
    backup_dir.mkdir(parents=True, exist_ok=True)
    originally_present: dict[str, bool] = {}
    copied: list[str] = []
    for path in replace_paths:
        rel = pathlib.PurePosixPath(path)
        source_current = tool_root.joinpath(*rel.parts)
        backup_target = backup_dir.joinpath(*rel.parts)
        originally_present[path] = source_current.is_file()
        if source_current.is_file():
            backup_target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_current, backup_target)
            append_install_log(log_path, f"Backup {source_current} -> {backup_target}")

    try:
        progress(42, "Neue Dateien werden kopiert ...")
        for path in replace_paths:
            rel = pathlib.PurePosixPath(path)
            source_new = payload_dir.joinpath(*rel.parts)
            target_file = tool_root.joinpath(*rel.parts)
            if not source_new.is_file():
                raise FileNotFoundError(f"Payload fehlt: {source_new}")
            write_bytes_atomic(target_file, source_new.read_bytes())
            copied.append(path)
            append_install_log(log_path, f"Kopiere {source_new} -> {target_file}")

        progress(72, "Installation wird geprüft ...")
        for path in replace_paths:
            rel = pathlib.PurePosixPath(path)
            target_file = tool_root.joinpath(*rel.parts)
            if not target_file.is_file() or target_file.stat().st_size <= 0:
                raise RuntimeError(f"Zieldatei ungültig: {target_file}")
    except Exception:
        progress(82, "Fehler - alte Version wird wiederhergestellt ...")
        for path in copied:
            rel = pathlib.PurePosixPath(path)
            backup_file = backup_dir.joinpath(*rel.parts)
            target_file = tool_root.joinpath(*rel.parts)
            if backup_file.is_file():
                write_bytes_atomic(target_file, backup_file.read_bytes())
            elif not originally_present.get(path, False):
                try:
                    target_file.unlink()
                except OSError:
                    pass
        append_install_log(log_path, "Update fehlgeschlagen\n" + traceback.format_exc())
        raise

    progress(90, "Daten werden geschrieben ...")
    if hasattr(os, "sync"):
        try:
            os.sync()
        except OSError:
            pass
    append_install_log(log_path, "Update erfolgreich")
    progress(100, "Neustart ...")
    return tool_root.joinpath(*pathlib.PurePosixPath(app_file).parts)


def set_system_utc_time(timestamp: int, debug_lines: list[str] | None = None) -> bool:
    if timestamp < 1_700_000_000 or timestamp > 2_100_000_000:
        if debug_lines is not None:
            append_network_debug(debug_lines, f"time sync ignored implausible timestamp: {timestamp}")
        return False
    date_cmd = find_executable("date")
    if not date_cmd:
        if debug_lines is not None:
            append_network_debug(debug_lines, "time sync failed: date command missing")
        return False
    try:
        result = subprocess.run(
            [date_cmd, "-u", "-s", f"@{timestamp}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=4,
            check=False,
        )
        output = (result.stdout or "").strip()
        ok = result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        output = str(exc)
        ok = False
    if debug_lines is not None:
        stamp = datetime.datetime.fromtimestamp(timestamp, datetime.timezone.utc).isoformat()
        append_network_debug(debug_lines, f"time sync set {stamp}: {output or ('ok' if ok else 'failed')}")
    return ok


def ntp_timestamp(host: str, timeout: float = 3.0) -> int | None:
    packet = b"\x1b" + (b"\0" * 47)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(timeout)
            sock.sendto(packet, (host, 123))
            data, _ = sock.recvfrom(48)
    except OSError:
        return None
    if len(data) < 48:
        return None
    seconds = struct.unpack("!I", data[40:44])[0]
    return int(seconds - 2_208_988_800)


def http_date_timestamp(host: str, timeout: float = 3.0) -> int | None:
    request = f"HEAD / HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n".encode("ascii")
    try:
        with socket.create_connection((host, 80), timeout=timeout) as sock:
            sock.settimeout(timeout)
            sock.sendall(request)
            data = sock.recv(4096).decode("iso-8859-1", errors="ignore")
    except OSError:
        return None
    for line in data.splitlines():
        if not line.lower().startswith("date:"):
            continue
        try:
            parsed = email.utils.parsedate_to_datetime(line.split(":", 1)[1].strip())
        except (TypeError, ValueError):
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=datetime.timezone.utc)
        return int(parsed.timestamp())
    return None


def sync_system_time_from_network(debug_lines: list[str], status_callback=None) -> bool:
    if sys.platform != "linux":
        return False
    if status_callback is not None:
        status_callback("online", "synchronisiere Uhr")
    append_network_debug(debug_lines, f"time before sync: {time.strftime('%Y-%m-%dT%H:%M:%S')}")

    for host in ["time.cloudflare.com", "time.google.com", "pool.ntp.org", "162.159.200.1", "216.239.35.0"]:
        timestamp = ntp_timestamp(host)
        if timestamp and set_system_utc_time(timestamp, debug_lines):
            append_network_debug(debug_lines, f"time sync ok via NTP {host}")
            return True
        append_network_debug(debug_lines, f"time sync NTP failed: {host}")

    for host in ["example.com", "neverssl.com", "google.com"]:
        timestamp = http_date_timestamp(host)
        if timestamp and set_system_utc_time(timestamp, debug_lines):
            append_network_debug(debug_lines, f"time sync ok via HTTP Date {host}")
            return True
        append_network_debug(debug_lines, f"time sync HTTP Date failed: {host}")

    append_network_debug(debug_lines, "time sync failed: all methods failed")
    return False


def is_certificate_time_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    return (
        "certificate_verify_failed" in text
        or "certificate verify failed" in text
        or "certificate is not yet valid" in text
        or "certificate has expired" in text
    )


def find_executable(*names: str) -> str:
    search_paths = os.environ.get("PATH", "").split(os.pathsep) + ["/usr/sbin", "/sbin", "/usr/bin", "/bin"]
    for name in names:
        found = shutil.which(name)
        if found:
            return found
        for directory in search_paths:
            candidate = pathlib.Path(directory) / name
            if candidate.exists() and os.access(candidate, os.X_OK):
                return str(candidate)
    return ""


def run_quiet_timeout(args: list[str], timeout: int = 8) -> bool:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def run_debug_command(args: list[str], timeout: int = 5) -> str:
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=timeout,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return str(exc)
    return (result.stdout or "").strip()


def is_wifi_interface(name: str) -> bool:
    return (pathlib.Path("/sys/class/net") / name / "wireless").exists()


def list_network_interfaces(wifi: bool) -> list[str]:
    root = pathlib.Path("/sys/class/net")
    if not root.exists():
        return []
    names: list[str] = []
    for path in sorted(root.iterdir()):
        name = path.name
        if name == "lo":
            continue
        if is_wifi_interface(name) == wifi:
            names.append(name)
    return names


def interface_operstate(name: str) -> str:
    return read_text(pathlib.Path("/sys/class/net") / name / "operstate") or "unknown"


def interface_carrier(name: str) -> str:
    carrier_path = pathlib.Path("/sys/class/net") / name / "carrier"
    if not carrier_path.exists():
        return "unknown"
    return read_text(carrier_path) or "unknown"


def wait_for_wired_link(interface: str, timeout: float = 3.0) -> bool:
    carrier_path = pathlib.Path("/sys/class/net") / interface / "carrier"
    if not carrier_path.exists():
        return True
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if read_text(carrier_path) == "1":
            return True
        time.sleep(0.3)
    return read_text(carrier_path) == "1"


def wifi_country() -> str:
    country = str(load_settings().get("wifi_country") or DEFAULT_WIFI_COUNTRY).strip().upper()
    return country if re.fullmatch(r"[A-Z]{2}", country) else DEFAULT_WIFI_COUNTRY


def unblock_wifi_radios(debug_lines: list[str] | None = None) -> None:
    rfkill = find_executable("rfkill")
    if rfkill:
        append_network_debug(debug_lines or [], "rfkill unblock wifi")
        run_quiet_timeout([rfkill, "unblock", "wifi"], timeout=3)
    for rfkill_type in pathlib.Path("/sys/class/rfkill").glob("rfkill*/type"):
        if read_text(rfkill_type).lower() not in {"wlan", "wifi"}:
            continue
        soft = rfkill_type.parent / "soft"
        try:
            if soft.exists():
                soft.write_text("0\n", encoding="ascii")
                if debug_lines is not None:
                    append_network_debug(debug_lines, f"sysfs rfkill unblock: {rfkill_type.parent.name}")
        except OSError as exc:
            if debug_lines is not None:
                append_network_debug(debug_lines, f"sysfs rfkill unblock failed: {exc}")


def set_wifi_country(debug_lines: list[str] | None = None) -> None:
    iw = find_executable("iw")
    if not iw:
        return
    country = wifi_country()
    output = run_debug_command([iw, "reg", "set", country], timeout=3)
    if debug_lines is not None:
        append_network_debug(debug_lines, f"iw reg set {country}: {output or 'ok'}")


def stop_wifi_runtime(interface: str, debug_lines: list[str] | None = None) -> None:
    wpa_cli = find_executable("wpa_cli")
    pkill = find_executable("pkill")
    ip_cmd = find_executable("ip")
    try:
        stop_dhcp(interface)
    except Exception:
        pass
    if wpa_cli:
        output = run_debug_command([wpa_cli, "-i", interface, "terminate"], timeout=2)
        if debug_lines is not None and output:
            append_network_debug(debug_lines, f"wpa_cli terminate {interface}: {output}")
    if pkill:
        pattern = rf"wpa_supplicant.*-i\s*{re.escape(interface)}(\s|$)"
        output = run_debug_command([pkill, "-f", pattern], timeout=2)
        if debug_lines is not None and output:
            append_network_debug(debug_lines, f"pkill wpa_supplicant {interface}: {output}")
    if ip_cmd:
        run_quiet_timeout([ip_cmd, "addr", "flush", "dev", interface], timeout=2)


def prepare_wifi_interface(interface: str, debug_lines: list[str] | None = None) -> None:
    ip_cmd = find_executable("ip")
    iw = find_executable("iw")
    unblock_wifi_radios(debug_lines)
    set_wifi_country(debug_lines)
    stop_wifi_runtime(interface, debug_lines)
    if ip_cmd:
        down = run_debug_command([ip_cmd, "link", "set", interface, "down"], timeout=2)
        up = run_debug_command([ip_cmd, "link", "set", interface, "up"], timeout=4)
        if debug_lines is not None:
            append_network_debug(debug_lines, f"ip link reset {interface}: down={down or 'ok'} up={up or 'ok'}")
    if iw:
        run_quiet_timeout([iw, "dev", interface, "set", "power_save", "off"], timeout=2)
    time.sleep(0.8)
    if debug_lines is not None:
        append_network_debug(
            debug_lines,
            f"{interface} state after prepare: oper={interface_operstate(interface)} carrier={interface_carrier(interface)}",
        )


def wifi_associated(interface: str, ctrl_dir: str = "/tmp") -> bool:
    wpa_cli = find_executable("wpa_cli")
    if wpa_cli:
        status = run_debug_command([wpa_cli, "-p", ctrl_dir, "-i", interface, "status"], timeout=2)
        if "wpa_state=COMPLETED" in status:
            return True
    iw = find_executable("iw")
    if iw:
        link = run_debug_command([iw, "dev", interface, "link"], timeout=2)
        if "Connected to" in link:
            return True
    return False


def wait_for_wifi_association(interface: str, ctrl_dir: str = "/tmp", timeout: float = 12.0) -> bool:
    if not find_executable("wpa_cli") and not find_executable("iw"):
        time.sleep(min(timeout, 7.0))
        return True
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if wifi_associated(interface, ctrl_dir):
            return True
        time.sleep(0.5)
    return wifi_associated(interface, ctrl_dir)


def append_network_debug(debug_lines: list[str], text: str) -> None:
    stamp = time.strftime("%H:%M:%S")
    debug_lines.append(f"[{stamp}] {text}")


def write_network_update_debug(ok: bool, message: str, debug_lines: list[str]) -> None:
    if sys.platform != "linux":
        return
    if ok and os.environ.get("HC_DEBUG") != "1":
        return
    sections = [
        f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
        f"ok={ok}",
        f"message={message}",
        f"version={APP_VERSION}",
        "",
        "=== attempts ===",
        "\n".join(debug_lines) or "no attempts recorded",
        "",
        "=== tools ===",
    ]
    for tool in ["ip", "dhcpcd", "dhclient", "wpa_supplicant", "wpa_cli", "iw", "rfkill", "lspci", "lsusb"]:
        sections.append(f"{tool}={find_executable(tool) or 'missing'}")
    commands = [
        ("ip -br link", ["sh", "-c", "ip -br link 2>&1 || true"]),
        ("ip -br addr", ["sh", "-c", "ip -br addr 2>&1 || true"]),
        ("ip route", ["sh", "-c", "ip route 2>&1 || true"]),
        ("resolv.conf", ["sh", "-c", "cat /etc/resolv.conf 2>&1 || true"]),
        ("rfkill", ["sh", "-c", "rfkill list 2>&1 || true"]),
        ("iw dev", ["sh", "-c", "iw dev 2>&1 || true"]),
        (
            "sysfs net",
            [
                "sh",
                "-c",
                "for i in /sys/class/net/*; do n=${i##*/}; echo \"$n carrier=$(cat $i/carrier 2>/dev/null) oper=$(cat $i/operstate 2>/dev/null) wifi=$([ -d $i/wireless ] && echo yes || echo no)\"; done",
            ],
        ),
        (
            "wifi scan",
            [
                "sh",
                "-c",
                "for i in /sys/class/net/*; do n=${i##*/}; [ -d $i/wireless ] || continue; echo \"--- $n scan ---\"; ip link set $n up 2>/dev/null; iw dev $n scan 2>&1 | grep -E 'SSID:|signal:' | head -n 40; done",
            ],
        ),
        ("lspci network", ["sh", "-c", "lspci -nnk 2>&1 | grep -A4 -Ei 'network|ethernet|wireless|wifi' || true"]),
        ("lsusb", ["sh", "-c", "lsusb 2>&1 || true"]),
        (
            "dmesg network",
            [
                "sh",
                "-c",
                "dmesg 2>&1 | grep -Ei 'firmware|wifi|wlan|wireless|iwlwifi|rtw|rtl|ath|mt76|brcm|r8169|igc|e1000|ethernet|enp|wlp' | tail -n 140 || true",
            ],
        ),
    ]
    for title, command in commands:
        sections.extend(["", f"=== {title} ===", run_debug_command(command, timeout=8)])
    text = "\n".join(sections).rstrip() + "\n"
    for root in find_debug_roots():
        try:
            write_text_durable(root / "hardwarecheck-debug" / "network-update.txt", text)
        except OSError:
            pass


def current_printer_debug_host() -> str:
    try:
        config, _path = load_printer_config()
    except Exception:
        config = {}
    if not config:
        return DEFAULT_PRINTER_RAW_HOST
    host = ""
    try:
        host = str(printer_ipp_target(config)[0] or "").strip()
    except Exception:
        host = ""
    if not host:
        try:
            host = str(printer_raw_target(config)[0] or "").strip()
        except Exception:
            host = ""
    return host or DEFAULT_PRINTER_RAW_HOST


def write_printer_debug(ok: bool, message: str, debug_lines: list[str]) -> None:
    if sys.platform != "linux":
        return
    sections = [
        f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
        f"ok={ok}",
        f"message={message}",
        f"version={APP_VERSION}",
        "",
        "=== attempts ===",
        "\n".join(debug_lines) or "no attempts recorded",
        "",
        "=== printer network ===",
    ]
    route_host = current_printer_debug_host()
    commands = [
        ("ip -br link", ["sh", "-c", "ip -br link 2>&1 || true"]),
        ("ip -br addr", ["sh", "-c", "ip -br addr 2>&1 || true"]),
        ("ip route", ["sh", "-c", "ip route 2>&1 || true"]),
        ("route to printer", ["sh", "-c", f"ip route get {route_host} 2>&1 || true"]),
        ("iw link", ["sh", "-c", "for i in /sys/class/net/*; do n=${i##*/}; [ -d $i/wireless ] || continue; echo \"--- $n ---\"; iw dev $n link 2>&1; done"]),
    ]
    for title, command in commands:
        sections.extend(["", f"=== {title} ===", run_debug_command(command, timeout=5)])
    text = "\n".join(sections).rstrip() + "\n"
    for root in find_debug_roots():
        try:
            write_text_durable(root / "hardwarecheck-debug" / "printer-debug.txt", text)
        except OSError:
            pass


def write_printer_discovery_debug(ok: bool, message: str, debug_lines: list[str]) -> None:
    if sys.platform != "linux":
        return
    sections = [
        f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
        f"ok={ok}",
        f"message={message}",
        f"version={APP_VERSION}",
        "",
        "=== discovery ===",
        "\n".join(debug_lines) or "no discovery attempts recorded",
        "",
        "=== network ===",
    ]
    commands = [
        ("ip -br link", ["sh", "-c", "ip -br link 2>&1 || true"]),
        ("ip -br addr", ["sh", "-c", "ip -br addr 2>&1 || true"]),
        ("ip route", ["sh", "-c", "ip route 2>&1 || true"]),
        ("ip neigh", ["sh", "-c", "ip neigh show 2>&1 || true"]),
        ("iw link", ["sh", "-c", "for i in /sys/class/net/*; do n=${i##*/}; [ -d $i/wireless ] || continue; echo \"--- $n ---\"; iw dev $n link 2>&1; done"]),
    ]
    for title, command in commands:
        sections.extend(["", f"=== {title} ===", run_debug_command(command, timeout=5)])
    text = "\n".join(sections).rstrip() + "\n"
    for root in find_debug_roots():
        try:
            write_text_durable(root / "hardwarecheck-debug" / "printer-discovery-debug.txt", text)
        except OSError:
            pass


def load_wifi_networks(debug_lines: list[str] | None = None) -> list[dict[str, str]]:
    path = get_wifi_networks_path()
    if debug_lines is not None:
        append_network_debug(debug_lines, f"WLAN-Datei: {path} exists={path.is_file()}")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        if debug_lines is not None:
            append_network_debug(debug_lines, f"WLAN-Datei nicht lesbar: {exc}")
        return []
    if isinstance(data, dict):
        raw_networks = data.get("wifi_networks") or data.get("networks") or []
    else:
        raw_networks = data
    networks: list[dict[str, str]] = []
    if isinstance(raw_networks, list):
        for item in raw_networks:
            if not isinstance(item, dict):
                continue
            ssid = str(item.get("ssid") or "").strip()
            password = str(item.get("password") or item.get("psk") or "")
            if ssid and password:
                network = {"ssid": ssid, "password": password}
                last_mode = str(item.get("last_mode") or "").strip().upper()
                if last_mode in {"WPA3", "WPA3/WPA2", "WPA2"}:
                    network["last_mode"] = last_mode
                security_mode = normalize_wifi_security(item.get("security_mode") or item.get("security"))
                if security_mode and security_mode != "OPEN":
                    network["security_mode"] = security_mode
                networks.append(network)
    if debug_lines is not None:
        append_network_debug(debug_lines, f"WLAN-Netze geladen: {len(networks)}")
    return networks


def saved_wifi_passwords() -> dict[str, str]:
    return {network["ssid"]: network["password"] for network in load_wifi_networks()}


def normalize_wifi_security(value: object) -> str:
    text = str(value or "").strip().upper().replace(" ", "")
    if text in {"WPA3/WPA2", "WPA2/WPA3", "SAEWPA-PSK", "SAE+WPA-PSK", "TRANSITION"}:
        return "WPA3/WPA2"
    if text in {"WPA3", "SAE"}:
        return "WPA3"
    if text in {"WPA2", "WPA", "WPA-PSK", "PSK", "RSN"}:
        return "WPA2"
    if text in {"OPEN", "OFFEN", "NONE", "UNSECURED"}:
        return "OPEN"
    return ""


def save_wifi_network(ssid: str, password: str, security_mode: str = "") -> None:
    ssid = ssid.strip()
    if not ssid:
        raise ValueError("SSID fehlt")
    password = password.strip()
    if not password:
        raise ValueError("Passwort fehlt")
    networks = load_wifi_networks()
    previous = next((network for network in networks if network["ssid"] == ssid), {})
    first = {"ssid": ssid, "password": password}
    if previous.get("last_mode"):
        first["last_mode"] = previous["last_mode"]
    security = normalize_wifi_security(security_mode) or normalize_wifi_security(previous.get("security_mode"))
    if security and security != "OPEN":
        first["security_mode"] = security
    updated = [first]
    for network in networks:
        if network["ssid"] != ssid:
            updated.append(network)
    write_json_atomic(get_wifi_networks_path(), {"wifi_networks": updated})


def delete_wifi_network(ssid: str) -> bool:
    ssid = ssid.strip()
    if not ssid:
        return False
    networks = load_wifi_networks()
    updated = [network for network in networks if network["ssid"] != ssid]
    if len(updated) == len(networks):
        return False
    write_json_atomic(get_wifi_networks_path(), {"wifi_networks": updated})
    return True


def remember_successful_wifi(network: dict[str, str], mode: str) -> None:
    ssid = str(network.get("ssid") or "").strip()
    password = str(network.get("password") or "").strip()
    if not ssid or not password:
        return
    mode = mode.strip().upper()
    if mode not in {"WPA3", "WPA3/WPA2", "WPA2"}:
        mode = ""
    security = normalize_wifi_security(network.get("security_mode") or mode)
    updated = [
        {
            "ssid": ssid,
            "password": password,
            **({"last_mode": mode} if mode else {}),
            **({"security_mode": security} if security and security != "OPEN" else {}),
        }
    ]
    for saved in load_wifi_networks():
        if saved["ssid"] == ssid:
            continue
        item = {"ssid": saved["ssid"], "password": saved["password"]}
        if saved.get("last_mode"):
            item["last_mode"] = saved["last_mode"]
        if saved.get("security_mode"):
            item["security_mode"] = saved["security_mode"]
        updated.append(item)
    try:
        write_json_atomic(get_wifi_networks_path(), {"wifi_networks": updated})
    except OSError:
        pass


def wifi_mode_order(network: dict[str, str]) -> list[str]:
    modes = ["WPA3", "WPA3/WPA2", "WPA2"]
    security_mode = normalize_wifi_security(network.get("security_mode") or network.get("security"))
    if security_mode in modes:
        return [security_mode] + [mode for mode in modes if mode != security_mode]
    last_mode = str(network.get("last_mode") or "").strip().upper()
    if last_mode in modes:
        return [last_mode] + [mode for mode in modes if mode != last_mode]
    return modes


def detect_wifi_security_from_lines(lines: list[str]) -> str:
    text = "\n".join(lines).lower()
    has_privacy = "capability:" in text and "privacy" in text
    has_rsn = "\n\trsn:" in text or "\nrsn:" in text or "ieee 802.11i/wpa2" in text
    has_wpa = "\n\twpa:" in text or "\nwpa:" in text or "wpa version" in text
    has_sae = "authentication suites" in text and "sae" in text
    has_psk = "authentication suites" in text and "psk" in text
    if has_sae and has_psk:
        return "WPA3/WPA2"
    if has_sae:
        return "WPA3"
    if has_psk or has_rsn or has_wpa:
        return "WPA2"
    if has_privacy:
        return "WPA2"
    return "OPEN"


def parse_iw_scan(output: str, interface: str) -> list[dict[str, str]]:
    networks: list[dict[str, str]] = []
    blocks: list[list[str]] = []
    current: list[str] = []
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if line.startswith("BSS "):
            if current:
                blocks.append(current)
            current = [raw_line]
        elif current:
            current.append(raw_line)
    if current:
        blocks.append(current)
    for block in blocks:
        ssid = ""
        signal = ""
        for raw_line in block:
            line = raw_line.strip()
            if line.startswith("signal:"):
                signal = line.split(":", 1)[1].strip()
            elif line.startswith("SSID:"):
                ssid = line.split(":", 1)[1].strip()
        if ssid:
            security = detect_wifi_security_from_lines(block)
            networks.append({"ssid": ssid, "signal": signal, "interface": interface, "security_mode": security, "security_source": "scan"})
    return networks


def parse_iwlist_scan(output: str, interface: str) -> list[dict[str, str]]:
    networks: list[dict[str, str]] = []
    blocks: list[list[str]] = []
    current: list[str] = []
    for raw_line in output.splitlines():
        if "Cell " in raw_line and "Address:" in raw_line:
            if current:
                blocks.append(current)
            current = [raw_line]
        elif current:
            current.append(raw_line)
    if current:
        blocks.append(current)
    for block in blocks:
        ssid = ""
        signal = ""
        for raw_line in block:
            line = raw_line.strip()
            if "Signal level=" in line:
                signal = line.split("Signal level=", 1)[1].split()[0].strip()
            match = re.search(r'ESSID:"(.*)"', line)
            if match:
                ssid = match.group(1).strip()
        if ssid:
            security = detect_wifi_security_from_lines(block)
            networks.append({"ssid": ssid, "signal": signal, "interface": interface, "security_mode": security, "security_source": "scan"})
    return networks


def wifi_signal_sort_value(value: str) -> float:
    match = re.search(r"-?\d+(?:\.\d+)?", value or "")
    if not match:
        return -999.0
    try:
        return float(match.group(0))
    except ValueError:
        return -999.0


def wifi_scan_output_summary(output: str, max_lines: int = 4) -> str:
    lines = [line.strip() for line in (output or "").splitlines() if line.strip()]
    if not lines:
        return "keine Ausgabe"
    return " | ".join(lines[-max_lines:])[:260]


def scan_wifi_interface(iface: str, iw: str | None, iwlist: str | None, debug_lines: list[str]) -> list[dict[str, str]]:
    ip_cmd = find_executable("ip")
    last_output = ""
    for attempt in range(1, 4):
        if attempt > 1:
            append_network_debug(debug_lines, f"WLAN-Scan {iface}: neuer Versuch {attempt}/3")
            if ip_cmd:
                run_quiet_timeout([ip_cmd, "link", "set", iface, "up"], timeout=3)
            time.sleep(1.4 * attempt)
        if iw:
            output = run_debug_command([iw, "dev", iface, "scan"], timeout=18)
            last_output = output
            networks = parse_iw_scan(output, iface)
            append_network_debug(debug_lines, f"WLAN-Scan {iface} iw Versuch {attempt}: {len(networks)} Netze")
            if networks:
                return networks
        if iwlist:
            output = run_debug_command([iwlist, iface, "scan"], timeout=18)
            last_output = output
            networks = parse_iwlist_scan(output, iface)
            append_network_debug(debug_lines, f"WLAN-Scan {iface} iwlist Versuch {attempt}: {len(networks)} Netze")
            if networks:
                return networks
    append_network_debug(debug_lines, f"WLAN-Scan {iface}: kein Ergebnis, letzte Ausgabe: {wifi_scan_output_summary(last_output)}")
    return []


def scan_wifi_networks(status_callback=None, debug_lines: list[str] | None = None, preserve_active: bool = True) -> tuple[list[dict[str, str]], str]:
    if sys.platform != "linux":
        return [], "WLAN-Scan nur unter Linux verfuegbar"
    if debug_lines is None:
        debug_lines = []
    reset_network_ready_cache()
    iw = find_executable("iw")
    iwlist = find_executable("iwlist")
    ifaces = list_network_interfaces(wifi=True)
    if not ifaces:
        return [], "Kein WLAN-Adapter gefunden"
    found: dict[str, dict[str, str]] = {}
    for iface in ifaces:
        if status_callback is not None:
            status_callback("searching", f"scanne WLAN {iface}")
        # A discovery scan is safe while associated.  Do not reset the
        # interface (which stops DHCP and wpa_supplicant) merely because the
        # operator opened WLAN settings.
        active = preserve_active and interface_has_ipv4(iface) and bool(current_wifi_ssid(iface))
        if active:
            append_network_debug(debug_lines, f"WLAN-Scan {iface}: aktive Verbindung bleibt erhalten")
        else:
            prepare_wifi_interface(iface, debug_lines)
        networks = scan_wifi_interface(iface, iw, iwlist, debug_lines)
        append_network_debug(debug_lines, f"WLAN-Scan {iface}: {len(networks)} Netze")
        for network in networks:
            ssid = network["ssid"]
            old = found.get(ssid)
            if old is None or wifi_signal_sort_value(network.get("signal", "")) > wifi_signal_sort_value(old.get("signal", "")):
                found[ssid] = network
    networks = sorted(found.values(), key=lambda item: wifi_signal_sort_value(item.get("signal", "")), reverse=True)
    if not networks:
        return [], "Keine WLAN-Netze gefunden"
    return networks, f"{len(networks)} WLAN-Netze gefunden"


def wpa_quote(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def wifi_config_variants(network: dict[str, str], ctrl_dir: str) -> list[tuple[str, str]]:
    ssid = wpa_quote(network["ssid"])
    password = wpa_quote(network["password"])
    country = wifi_country()
    base = f"ctrl_interface={ctrl_dir}\nap_scan=1\ncountry={country}\nsae_pwe=2\n"
    wpa3 = (
        base
        + "network={\n"
        f"    ssid={ssid}\n"
        "    scan_ssid=1\n"
        "    key_mgmt=SAE\n"
        "    ieee80211w=2\n"
        f"    sae_password={password}\n"
        "}\n"
    )
    transition = (
        base
        + "network={\n"
        f"    ssid={ssid}\n"
        "    scan_ssid=1\n"
        "    key_mgmt=SAE WPA-PSK\n"
        "    ieee80211w=1\n"
        f"    sae_password={password}\n"
        f"    psk={password}\n"
        "}\n"
    )
    wpa2 = (
        base
        + "network={\n"
        f"    ssid={ssid}\n"
        "    scan_ssid=1\n"
        "    key_mgmt=WPA-PSK\n"
        f"    psk={password}\n"
        "}\n"
    )
    return [("WPA3", wpa3), ("WPA3/WPA2", transition), ("WPA2", wpa2)]


def start_dhcp(interface: str, lease_timeout: int = 18) -> bool:
    dhcpcd = find_executable("dhcpcd")
    if dhcpcd:
        return run_quiet_timeout([dhcpcd, "-4", "-q", "-t", str(lease_timeout), interface], timeout=max(12, lease_timeout + 4))
    dhclient = find_executable("dhclient")
    if dhclient:
        return run_quiet_timeout([dhclient, "-1", interface], timeout=max(14, lease_timeout + 4))
    return False


def stop_dhcp(interface: str) -> None:
    dhcpcd = find_executable("dhcpcd")
    if dhcpcd:
        run_quiet_timeout([dhcpcd, "-k", interface], timeout=3)
    dhclient = find_executable("dhclient")
    if dhclient:
        run_quiet_timeout([dhclient, "-r", interface], timeout=3)


def configure_static_ipv4(interface: str, cidr: str, debug_lines: list[str]) -> bool:
    ip_cmd = find_executable("ip")
    if not ip_cmd or not cidr:
        return False
    append_network_debug(debug_lines, f"Setze statische IPv4 {interface}: {cidr}")
    run_quiet_timeout([ip_cmd, "addr", "flush", "dev", interface], timeout=3)
    if not run_quiet_timeout([ip_cmd, "addr", "add", cidr, "dev", interface], timeout=3):
        return False
    run_quiet_timeout([ip_cmd, "link", "set", interface, "up"], timeout=3)
    return wait_for_ipv4(interface, timeout=2)


def interface_has_ipv4(interface: str) -> bool:
    ip_cmd = find_executable("ip")
    if not ip_cmd:
        return False
    try:
        result = subprocess.run(
            [ip_cmd, "-o", "-4", "addr", "show", "dev", interface, "scope", "global"],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=2,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0 and " inet " in f" {result.stdout} "


def wait_for_ipv4(interface: str, timeout: float = 10.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if interface_has_ipv4(interface):
            return True
        time.sleep(0.4)
    return interface_has_ipv4(interface)


def current_wifi_ssid(interface: str) -> str:
    iw = find_executable("iw")
    if iw:
        link = run_debug_command([iw, "dev", interface, "link"], timeout=2)
        for line in link.splitlines():
            line = line.strip()
            if line.startswith("SSID:"):
                return line.split(":", 1)[1].strip()
    return ""


def mark_network_ready(message: str) -> None:
    global NETWORK_READY_UNTIL, NETWORK_READY_MESSAGE
    NETWORK_READY_UNTIL = time.monotonic() + NETWORK_READY_CACHE_SECONDS
    NETWORK_READY_MESSAGE = message


def reset_network_ready_cache() -> None:
    global NETWORK_READY_UNTIL, NETWORK_READY_MESSAGE
    NETWORK_READY_UNTIL = 0.0
    NETWORK_READY_MESSAGE = ""


def cached_network_ready_message() -> str:
    if time.monotonic() >= NETWORK_READY_UNTIL:
        return ""
    for iface in list_network_interfaces(wifi=True):
        if interface_has_ipv4(iface) and current_wifi_ssid(iface):
            return NETWORK_READY_MESSAGE or f"Netzwerk aktiv ({iface})"
    for iface in list_network_interfaces(wifi=False):
        if interface_has_ipv4(iface):
            return NETWORK_READY_MESSAGE or f"Netzwerk aktiv ({iface})"
    return ""


def active_network_message(timeout: float = 1.2) -> str:
    cached = cached_network_ready_message()
    if cached:
        return cached

    wifi_ifaces = [iface for iface in list_network_interfaces(wifi=True) if interface_has_ipv4(iface) and current_wifi_ssid(iface)]
    wired_ifaces = [iface for iface in list_network_interfaces(wifi=False) if interface_has_ipv4(iface)]
    if not wifi_ifaces and not wired_ifaces:
        return ""

    if not dns_resolves(timeout=timeout):
        return ""

    if wifi_ifaces:
        iface = wifi_ifaces[0]
        ssid = current_wifi_ssid(iface)
        message = f"WLAN bereits aktiv ({iface}, {ssid})" if ssid else f"WLAN bereits aktiv ({iface})"
    else:
        iface = wired_ifaces[0]
        message = f"LAN bereits aktiv ({iface})"
    mark_network_ready(message)
    return message


def active_local_network_message() -> str:
    cached = cached_network_ready_message()
    if cached:
        return cached
    wifi_ifaces = [iface for iface in list_network_interfaces(wifi=True) if interface_has_ipv4(iface)]
    wired_ifaces = [iface for iface in list_network_interfaces(wifi=False) if interface_has_ipv4(iface)]
    if wifi_ifaces:
        iface = wifi_ifaces[0]
        ssid = current_wifi_ssid(iface)
        return f"WLAN bereits aktiv ({iface}, {ssid})" if ssid else f"WLAN bereits aktiv ({iface})"
    if wired_ifaces:
        return f"LAN bereits aktiv ({wired_ifaces[0]})"
    return ""


def active_wifi_message_for_ssids(ssids: set[str]) -> str:
    requested = {str(ssid or "").strip() for ssid in ssids if str(ssid or "").strip()}
    if not requested:
        return ""
    for iface in list_network_interfaces(wifi=True):
        if not interface_has_ipv4(iface):
            continue
        ssid = current_wifi_ssid(iface)
        if ssid in requested:
            return f"WLAN bereits aktiv ({iface}, {ssid})" if ssid else f"WLAN bereits aktiv ({iface})"
    return ""


def dns_resolves(host: str = "raw.githubusercontent.com", timeout: float = 6.0) -> bool:
    getent = find_executable("getent")
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if getent:
            try:
                result = subprocess.run(
                    [getent, "hosts", host],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=2,
                )
                if result.returncode == 0:
                    return True
            except (OSError, subprocess.TimeoutExpired):
                pass
        else:
            old_timeout = socket.getdefaulttimeout()
            socket.setdefaulttimeout(2)
            try:
                socket.gethostbyname(host)
                return True
            except OSError:
                pass
            finally:
                socket.setdefaulttimeout(old_timeout)
        time.sleep(0.5)
    return False


def wait_for_internet(interface: str) -> tuple[bool, str]:
    if not wait_for_ipv4(interface):
        return False, "keine IPv4-Adresse"
    if not dns_resolves():
        return False, "DNS/Internet nicht erreichbar"
    return True, "ok"


def internet_already_available(timeout: float = 2.5) -> bool:
    if active_network_message(timeout=min(timeout, 1.5)):
        return True
    ok = dns_resolves(timeout=timeout)
    if ok:
        mark_network_ready("Internet bereits aktiv")
    return ok


def connect_temporary_network(
    status_callback=None,
    debug_lines: list[str] | None = None,
    networks_override: list[dict[str, str]] | None = None,
    require_internet: bool = True,
    allow_active: bool = True,
    allow_lan: bool = True,
    cleanup_success: bool = False,
) -> tuple[bool, str, callable]:
    if sys.platform != "linux":
        return False, "Netzwerk nur unter Linux verfuegbar", lambda: None
    if debug_lines is None:
        debug_lines = []

    ip_cmd = find_executable("ip")
    wpa_supplicant = find_executable("wpa_supplicant")
    rfkill = find_executable("rfkill")
    started_ifaces: list[str] = []
    processes: list[subprocess.Popen[bytes]] = []
    temp_files: list[pathlib.Path] = []
    temp_dirs: list[pathlib.Path] = []
    last_error = ""
    requested_ssids = {
        str(network.get("ssid") or "").strip()
        for network in (networks_override or [])
        if str(network.get("ssid") or "").strip()
    }

    def notify(state: str, message: str) -> None:
        append_network_debug(debug_lines, f"{state}: {message}")
        if status_callback is not None:
            status_callback(state, message)

    def cleanup() -> None:
        for iface in started_ifaces:
            stop_dhcp(iface)
        for process in processes:
            try:
                process.terminate()
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                try:
                    process.kill()
                except OSError:
                    pass
        if ip_cmd:
            for iface in started_ifaces:
                run_quiet_timeout([ip_cmd, "link", "set", iface, "down"], timeout=3)
        for path in temp_files:
            try:
                path.unlink()
            except OSError:
                pass
        for path in temp_dirs:
            try:
                shutil.rmtree(path, ignore_errors=True)
            except OSError:
                pass

    if allow_active:
        if requested_ssids and not require_internet:
            active_message = active_wifi_message_for_ssids(requested_ssids)
        else:
            active_message = active_network_message() if require_internet else active_local_network_message()
        if active_message:
            notify("online", active_message)
            return True, active_message, lambda: None

    networks = list(networks_override) if networks_override is not None else load_wifi_networks(debug_lines)
    notify("searching", "suche Netzwerk")
    if allow_active and require_internet and internet_already_available():
        notify("online", "Internet bereits aktiv")
        return True, "Internet bereits aktiv", lambda: None

    if rfkill:
        run_quiet_timeout([rfkill, "unblock", "wifi"], timeout=3)

    if allow_lan and ip_cmd and not networks:
        for iface in list_network_interfaces(wifi=False):
            notify("searching", f"teste LAN {iface}")
            run_quiet_timeout([ip_cmd, "link", "set", iface, "up"], timeout=3)
            started_ifaces.append(iface)
            if not wait_for_wired_link(iface):
                last_error = f"LAN {iface}: kein Link/Kabel"
                notify("searching", last_error)
                continue
            stop_dhcp(iface)
            if start_dhcp(iface):
                notify("searching", f"LAN {iface}: pruefe Internet")
                ready, reason = wait_for_internet(iface)
                if ready:
                    message = f"LAN aktiv ({iface})"
                    mark_network_ready(message)
                    notify("online", f"LAN online ({iface})")
                    return True, message, lambda: None
                last_error = f"LAN {iface}: {reason}"
                notify("searching", last_error)
                stop_dhcp(iface)
            else:
                last_error = f"LAN {iface}: kein DHCP"
                notify("searching", last_error)

    if not networks:
        wifi_config_error = f"Keine WLAN-Konfiguration gefunden ({get_wifi_networks_path()})"
        notify("error", f"{last_error} | {wifi_config_error}" if last_error else wifi_config_error)
        return False, f"{last_error} | {wifi_config_error}" if last_error else wifi_config_error, cleanup
    if not ip_cmd or not wpa_supplicant:
        notify("error", last_error or "WLAN-Tools fehlen")
        return False, last_error or "WLAN-Tools fehlen", cleanup

    wifi_ifaces = list_network_interfaces(wifi=True)
    if not wifi_ifaces:
        wifi_error = "WLAN nicht gefunden (Treiber/Firmware?)"
        notify("error", f"{last_error} | {wifi_error}" if last_error else wifi_error)
        return False, f"{last_error} | {wifi_error}" if last_error else wifi_error, cleanup

    if requested_ssids and not require_internet:
        for iface in wifi_ifaces:
            current_ssid = current_wifi_ssid(iface)
            if current_ssid not in requested_ssids:
                continue
            notify("searching", f"WLAN {current_ssid}: warte auf IPv4")
            run_quiet_timeout([ip_cmd, "link", "set", iface, "up"], timeout=3)
            if wait_for_ipv4(iface, timeout=4) or (start_dhcp(iface) and wait_for_ipv4(iface, timeout=4)):
                message = f"WLAN aktiv ({iface}, {current_ssid})"
                notify("online", f"WLAN online ({current_ssid})")
                return True, message, lambda: None
            last_error = f"WLAN {iface}/{current_ssid}: keine IPv4-Adresse"
            notify("searching", last_error)

    def try_wifi_networks(candidate_networks: list[dict[str, str]], known_mode_only: bool = False) -> tuple[bool, str, callable] | None:
        nonlocal last_error
        for iface in wifi_ifaces:
            prepare_wifi_interface(iface, debug_lines)
            if iface not in started_ifaces:
                started_ifaces.append(iface)
            for network in candidate_networks:
                modes = wifi_mode_order(network)
                last_mode = str(network.get("last_mode") or "").strip().upper()
                if known_mode_only and last_mode in modes:
                    modes = [last_mode]
                security_mode = normalize_wifi_security(network.get("security_mode") or network.get("security"))
                if security_mode in modes and (known_mode_only or network.get("security_source") == "scan"):
                    modes = [security_mode]
                for mode in modes:
                    notify("searching", f"teste WLAN {network['ssid']} ({mode})")
                    stop_dhcp(iface)
                    prepare_wifi_interface(iface, debug_lines)
                    config_path: pathlib.Path | None = None
                    ctrl_dir_path: pathlib.Path | None = None
                    log_path: pathlib.Path | None = None
                    log_handle = None
                    process: subprocess.Popen[bytes] | None = None
                    keep_connection = False
                    try:
                        ctrl_dir_path = pathlib.Path(tempfile.mkdtemp(prefix=f"hc_wpa_{iface}_"))
                        temp_dirs.append(ctrl_dir_path)
                        config = dict(wifi_config_variants(network, str(ctrl_dir_path)))[mode]
                        handle = tempfile.NamedTemporaryFile("w", encoding="utf-8", prefix="hc_wifi_", suffix=".conf", delete=False)
                        with handle:
                            handle.write(config)
                        config_path = pathlib.Path(handle.name)
                        temp_files.append(config_path)
                        log_file = tempfile.NamedTemporaryFile("w+", encoding="utf-8", prefix="hc_wpa_", suffix=".log", delete=False)
                        log_path = pathlib.Path(log_file.name)
                        temp_files.append(log_path)
                        log_handle = log_file
                        process = subprocess.Popen(
                            [wpa_supplicant, "-D", "nl80211,wext", "-i", iface, "-c", str(config_path)],
                            stdout=log_handle,
                            stderr=subprocess.STDOUT,
                        )
                        processes.append(process)
                        if not wait_for_wifi_association(iface, str(ctrl_dir_path)):
                            last_error = f"WLAN {iface}/{network['ssid']} ({mode}): keine Verbindung"
                            if find_executable("wpa_cli"):
                                append_network_debug(
                                    debug_lines,
                                    "wpa_cli status: " + run_debug_command([find_executable("wpa_cli"), "-p", str(ctrl_dir_path), "-i", iface, "status"], timeout=2),
                                )
                            if find_executable("iw"):
                                append_network_debug(
                                    debug_lines,
                                    "iw link: " + run_debug_command([find_executable("iw"), "dev", iface, "link"], timeout=2),
                                )
                            notify("searching", last_error)
                        else:
                            static_ipv4 = str(network.get("static_ipv4") or "").strip()
                            if not require_internet and static_ipv4:
                                notify("searching", f"WLAN {network['ssid']}: setze statische IP {static_ipv4}")
                                stop_dhcp(iface)
                                if configure_static_ipv4(iface, static_ipv4, debug_lines):
                                    message = f"WLAN aktiv ({iface}, {network['ssid']}, statische IP)"
                                    notify("online", f"WLAN verbunden ({network['ssid']})")
                                    keep_connection = True
                                    return True, message, cleanup if cleanup_success else lambda: None
                                last_error = f"WLAN {iface}/{network['ssid']} ({mode}): statische IPv4 fehlgeschlagen"
                                notify("searching", last_error)
                                continue

                        if start_dhcp(iface):
                            notify("searching", f"WLAN {network['ssid']}: pruefe Internet" if require_internet else f"WLAN {network['ssid']}: pruefe Verbindung")
                            if require_internet:
                                ready, reason = wait_for_internet(iface)
                            else:
                                ready = wait_for_ipv4(iface)
                                reason = "ok" if ready else "keine IPv4-Adresse"
                            if ready:
                                remember_successful_wifi(network, mode)
                                message = f"WLAN aktiv ({iface}, {network['ssid']})"
                                if require_internet:
                                    mark_network_ready(message)
                                notify("online", f"WLAN online ({network['ssid']})")
                                keep_connection = True
                                return True, message, cleanup if cleanup_success else lambda: None
                            last_error = f"WLAN {iface}/{network['ssid']}: {reason}"
                            notify("searching", last_error)
                            stop_dhcp(iface)
                        else:
                            static_ipv4 = str(network.get("static_ipv4") or "").strip()
                            if not require_internet and static_ipv4:
                                notify("searching", f"WLAN {network['ssid']}: kein DHCP, setze {static_ipv4}")
                                if configure_static_ipv4(iface, static_ipv4, debug_lines):
                                    message = f"WLAN aktiv ({iface}, {network['ssid']}, statische IP)"
                                    notify("online", f"WLAN verbunden ({network['ssid']})")
                                    keep_connection = True
                                    return True, message, cleanup if cleanup_success else lambda: None
                                last_error = f"WLAN {iface}/{network['ssid']} ({mode}): keine statische IPv4"
                            else:
                                last_error = f"WLAN {iface}/{network['ssid']} ({mode}): kein DHCP"
                            notify("searching", last_error)
                    except OSError as exc:
                        last_error = f"WLAN {iface}/{network['ssid']} ({mode}): wpa_supplicant startet nicht"
                        append_network_debug(debug_lines, f"{last_error}: {exc}")
                        notify("searching", last_error)
                    finally:
                        if process is not None and not keep_connection:
                            try:
                                process.terminate()
                                process.wait(timeout=2)
                            except (OSError, subprocess.TimeoutExpired):
                                try:
                                    process.kill()
                                except OSError:
                                    pass
                            if process in processes:
                                processes.remove(process)
                        if log_handle is not None:
                            try:
                                log_handle.flush()
                                log_handle.close()
                            except OSError:
                                pass
                        if log_path is not None:
                            try:
                                log_text = log_path.read_text(encoding="utf-8", errors="ignore")
                                if log_text.strip():
                                    tail = "\n".join(log_text.strip().splitlines()[-30:])
                                    append_network_debug(debug_lines, f"wpa_supplicant log {network['ssid']} ({mode}):\n{tail}")
                            except OSError:
                                pass
                        if not keep_connection:
                            if config_path is not None:
                                try:
                                    config_path.unlink()
                                except OSError:
                                    pass
                            if log_path is not None:
                                try:
                                    log_path.unlink()
                                except OSError:
                                    pass
                            if ctrl_dir_path is not None:
                                try:
                                    shutil.rmtree(ctrl_dir_path, ignore_errors=True)
                                except OSError:
                                    pass
        return None

    last_known = networks[:1]
    if last_known:
        notify("searching", f"teste letztes WLAN {last_known[0]['ssid']}")
        result = try_wifi_networks(last_known, known_mode_only=True)
        if result:
            return result

    notify("searching", "letztes WLAN nicht erreichbar - scanne gespeicherte Netze")
    scanned_networks, scan_message = scan_wifi_networks(status_callback, debug_lines)
    scanned_by_ssid = {network["ssid"]: network for network in scanned_networks}
    visible_saved: list[dict[str, str]] = []
    for network in networks:
        scanned = scanned_by_ssid.get(network["ssid"])
        if not scanned:
            continue
        merged = dict(network)
        for key in ("signal", "interface", "security_mode", "security_source"):
            if scanned.get(key):
                merged[key] = scanned[key]
        visible_saved.append(merged)
    if visible_saved:
        names = ", ".join(network["ssid"] for network in visible_saved[:3])
        if len(visible_saved) > 3:
            names += ", ..."
        notify("searching", f"gespeichertes WLAN sichtbar: {names}")
        result = try_wifi_networks(visible_saved)
        if result:
            return result
    else:
        notify("searching", f"{scan_message}; kein gespeichertes WLAN sichtbar")

    remaining_saved = [network for network in networks if network not in last_known and network not in visible_saved]
    if remaining_saved and not scanned_networks:
        notify("searching", "WLAN-Scan ohne Ergebnis - teste weitere gespeicherte Netze")
        result = try_wifi_networks(remaining_saved)
        if result:
            return result
    notify("error", last_error or "Kein Netzwerk verbunden")
    return False, last_error or "Kein Netzwerk verbunden", cleanup


def load_printer_config() -> tuple[dict[str, object], pathlib.Path]:
    path = get_printer_config_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return {}, path
    return data if isinstance(data, dict) else {}, path


def printer_config_public_copy(config: dict[str, object]) -> dict[str, object]:
    result = {key: value for key, value in config.items() if key not in {"profile_id", "profile_name"}}
    wifi = result.get("wifi")
    if isinstance(wifi, dict):
        cleaned_wifi = dict(wifi)
        if not str(cleaned_wifi.get("password") or cleaned_wifi.get("psk") or "").strip():
            cleaned_wifi.pop("password", None)
            cleaned_wifi.pop("psk", None)
        result["wifi"] = cleaned_wifi
    return result


def printer_config_signature(config: dict[str, object]) -> tuple[str, str, str, str]:
    return (
        str(config.get("printer_name") or "").strip().lower(),
        str(config.get("raw_host") or config.get("printer_host") or "").strip().lower(),
        str(config.get("printer_uri") or config.get("uri") or "").strip().lower(),
        str(config.get("raw_port") or config.get("printer_port") or "").strip(),
    )


def printer_profile_name(profile: dict[str, object]) -> str:
    return str(profile.get("name") or profile.get("profile_name") or profile.get("printer_name") or profile.get("id") or "Drucker").strip()


def printer_profile_config(profile: dict[str, object]) -> dict[str, object]:
    config = profile.get("config")
    if isinstance(config, dict):
        return printer_config_public_copy(config)
    return printer_config_public_copy(profile)


def load_printer_profiles() -> list[dict[str, object]]:
    path = get_printer_profiles_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        data = {}
    raw_profiles = data.get("profiles") if isinstance(data, dict) else None
    profiles: list[dict[str, object]] = []
    if isinstance(raw_profiles, list):
        for item in raw_profiles:
            if isinstance(item, dict):
                config = printer_profile_config(item)
                if config:
                    profiles.append({
                        "id": str(item.get("id") or item.get("profile_id") or printer_profile_name(item)).strip(),
                        "name": printer_profile_name(item),
                        "config": config,
                    })
    if profiles:
        return profiles

    active_config, _path = load_printer_config()
    if active_config:
        profiles.append({"id": "active", "name": str(active_config.get("printer_name") or "Aktiver Drucker"), "config": active_config})
    for path in sorted(SCRIPT_DIR.glob("printer_config.*.json")):
        if path.name.lower() in {"printer_config.before-canon-test.json"}:
            continue
        try:
            config = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(config, dict):
            continue
        name = str(config.get("printer_name") or path.stem.replace("printer_config.", "")).replace("_", " ")
        profiles.append({"id": path.stem.replace("printer_config.", ""), "name": name, "config": config})
    return profiles


def save_printer_profiles(profiles: list[dict[str, object]]) -> None:
    cleaned: list[dict[str, object]] = []
    for profile in profiles:
        if not isinstance(profile, dict):
            continue
        config = printer_profile_config(profile)
        if not config:
            continue
        cleaned.append({
            "id": str(profile.get("id") or sanitize_filename(printer_profile_name(profile)).lower()).strip(),
            "name": printer_profile_name(profile),
            "config": config,
        })
    write_json_atomic(get_printer_profiles_path(), {"profiles": cleaned})


def load_printer_scan_ranges(debug_lines: list[str] | None = None) -> list[ipaddress.IPv4Network]:
    path = get_printer_scan_ranges_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        return []
    except (OSError, json.JSONDecodeError) as exc:
        if debug_lines is not None:
            append_network_debug(debug_lines, f"Drucker-Scanbereiche nicht geladen: {path} ({exc})")
        return []

    raw_ranges: list[object] = []
    if isinstance(data, list):
        raw_ranges = data
    elif isinstance(data, dict):
        for key in ("ranges", "networks", "printer_networks", "scan_ranges"):
            value = data.get(key)
            if isinstance(value, list):
                raw_ranges.extend(value)

    ranges: list[ipaddress.IPv4Network] = []
    for item in raw_ranges:
        value = ""
        if isinstance(item, dict):
            value = str(item.get("cidr") or item.get("network") or item.get("range") or item.get("ip") or "").strip()
        else:
            value = str(item or "").strip()
        if not value:
            continue
        try:
            if "/" in value:
                network = ipaddress.ip_network(value, strict=False)
            else:
                address = ipaddress.ip_address(value)
                network = ipaddress.ip_network(f"{address}/32", strict=False)
        except ValueError:
            if debug_lines is not None:
                append_network_debug(debug_lines, f"Drucker-Scanbereich ignoriert: {value}")
            continue
        if not isinstance(network, ipaddress.IPv4Network):
            continue
        if not network.is_private:
            if debug_lines is not None:
                append_network_debug(debug_lines, f"Drucker-Scanbereich nicht privat, ignoriert: {network}")
            continue
        if network not in ranges:
            ranges.append(network)

    if debug_lines is not None and ranges:
        append_network_debug(debug_lines, "Drucker-Scanbereiche aus Datei: " + ", ".join(str(item) for item in ranges))
    return ranges


def upsert_printer_profile(profile: dict[str, object]) -> None:
    profile_id = str(profile.get("id") or sanitize_filename(printer_profile_name(profile)).lower()).strip()
    profiles = load_printer_profiles()
    updated: list[dict[str, object]] = []
    replaced = False
    for existing in profiles:
        existing_id = str(existing.get("id") or "").strip()
        if existing_id == profile_id:
            updated.append(profile)
            replaced = True
        else:
            updated.append(existing)
    if not replaced:
        updated.append(profile)
    save_printer_profiles(updated)


def active_printer_profile_index(profiles: list[dict[str, object]], active_config: dict[str, object]) -> int:
    active_signature = printer_config_signature(active_config)
    for index, profile in enumerate(profiles):
        if printer_config_signature(printer_profile_config(profile)) == active_signature:
            return index
    return 0


def mark_printer_selected_now(config: dict[str, object]) -> dict[str, object]:
    result = printer_config_public_copy(config)
    result["manual_selection_until"] = time.time() + PRINTER_MANUAL_SELECTION_GRACE_SECONDS
    return result


def printer_manual_selection_recent(config: dict[str, object]) -> bool:
    try:
        return float(config.get("manual_selection_until") or 0) > time.time()
    except (TypeError, ValueError):
        return False


def save_active_printer_profile(profile: dict[str, object], manual_selected: bool = False) -> None:
    config = printer_profile_config(profile)
    if not config:
        raise OSError("Druckerprofil leer")
    if manual_selected:
        config = mark_printer_selected_now(config)
    write_json_atomic(get_printer_config_path(), config)


def clear_active_printer_profile() -> None:
    write_json_atomic(get_printer_config_path(), {})


def printer_config_bool(config: dict[str, object], key: str, default: bool) -> bool:
    value = config.get(key)
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "ja", "on"}
    return default


def printer_config_int(config: dict[str, object], key: str, default: int) -> int:
    try:
        return int(config.get(key) or default)
    except (TypeError, ValueError):
        return default


def printer_wifi_network(config: dict[str, object]) -> dict[str, str] | None:
    wifi = config.get("wifi")
    if not isinstance(wifi, dict):
        wifi = {}
    ssid = str(wifi.get("ssid") or config.get("wifi_ssid") or "").strip()
    password = str(wifi.get("password") or wifi.get("psk") or config.get("wifi_password") or "").strip()
    if ssid and not password:
        for saved in load_wifi_networks():
            if saved.get("ssid") == ssid:
                password = str(saved.get("password") or "").strip()
                if not wifi.get("mode") and saved.get("last_mode"):
                    wifi = {**wifi, "mode": saved.get("last_mode")}
                break
    if not ssid or not password:
        return None
    network = {"ssid": ssid, "password": password}
    mode = str(wifi.get("mode") or config.get("wifi_mode") or "").strip().upper()
    if mode in {"WPA3", "WPA3/WPA2", "WPA2"}:
        network["last_mode"] = mode
    static_ipv4 = str(wifi.get("static_ipv4") or config.get("static_ipv4") or "").strip()
    if static_ipv4:
        network["static_ipv4"] = static_ipv4
    return network


def safe_printer_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip())
    text = text.strip("._-")
    return text or "HardwareCheck_Printer"


def printer_uri(config: dict[str, object]) -> str:
    return str(config.get("printer_uri") or config.get("uri") or DEFAULT_PRINTER_URI).strip() or DEFAULT_PRINTER_URI


def printer_uri_with_scheme(uri: str, scheme: str) -> str:
    parsed = urllib.parse.urlparse(str(uri or DEFAULT_PRINTER_URI).strip() or DEFAULT_PRINTER_URI)
    if parsed.scheme == scheme:
        return str(uri)
    host = parsed.hostname or DEFAULT_PRINTER_RAW_HOST
    port = parsed.port or 631
    netloc = f"{host}:{port}"
    path = parsed.path or "/ipp/print"
    return urllib.parse.urlunparse((scheme, netloc, path, "", "", ""))


def printer_config_with_uri(config: dict[str, object], uri: str) -> dict[str, object]:
    updated = dict(config)
    updated["printer_uri"] = uri
    return updated


def ipp_upgrade_required(exc: BaseException) -> bool:
    if isinstance(exc, urllib.error.HTTPError) and exc.code == 426:
        return True
    return "426" in str(exc) and "upgrade" in str(exc).lower()


def printer_raw_target(config: dict[str, object]) -> tuple[str, int]:
    uri = printer_uri(config)
    parsed = urllib.parse.urlparse(uri)
    host = str(config.get("raw_host") or config.get("printer_host") or parsed.hostname or DEFAULT_PRINTER_RAW_HOST).strip()
    try:
        port = int(config.get("raw_port") or config.get("printer_port") or DEFAULT_PRINTER_RAW_PORT)
    except (TypeError, ValueError):
        port = DEFAULT_PRINTER_RAW_PORT
    return host or DEFAULT_PRINTER_RAW_HOST, port


def printer_ipp_target(config: dict[str, object]) -> tuple[str, int]:
    uri = printer_uri(config)
    parsed = urllib.parse.urlparse(uri)
    host = str(parsed.hostname or "").strip()
    try:
        port = int(parsed.port or 631)
    except (TypeError, ValueError):
        port = 631
    return host, port


def printer_target_reachable(config: dict[str, object], debug_lines: list[str], timeout: float = 2.8) -> tuple[bool, str]:
    targets: list[tuple[str, int, str]] = []
    ipp_host, ipp_port = printer_ipp_target(config)
    if ipp_host and (
        printer_config_bool(config, "direct_ipp_fallback", True)
        or printer_config_bool(config, "use_cups", True)
    ):
        targets.append((ipp_host, ipp_port, "IPP"))
    if printer_config_bool(config, "raw_socket_fallback", False):
        raw_host, raw_port = printer_raw_target(config)
        if raw_host:
            targets.append((raw_host, raw_port, "RAW"))

    if not targets:
        return False, "kein Druckerziel konfiguriert"

    failed: list[str] = []
    for host, port, label in targets:
        ok = tcp_port_open(host, port, timeout=timeout)
        append_network_debug(debug_lines, f"Drucker erreichbar Test {label} {host}:{port}: {'ok' if ok else 'nein'}")
        if ok:
            return True, f"Drucker erreichbar ({label} {host}:{port})"
        failed.append(f"{label} {host}:{port}")
    return False, "Drucker nicht erreichbar: " + ", ".join(failed)


PRINTER_IDENTITY_IGNORE_TOKENS = {
    "printer",
    "drucker",
    "series",
    "serie",
    "serien",
    "marcel",
    "daniel",
    "jana",
    "maik",
    "kaci",
    "kancelar",
    "notebook",
    "notebooks",
    "notebook2",
    "hardwarecheck",
    "mfp",
    "pro",
    "copy",
    "kopie",
}


def replace_uri_host(uri: str, new_host: str) -> str:
    parsed = urllib.parse.urlparse(str(uri or DEFAULT_PRINTER_URI).strip() or DEFAULT_PRINTER_URI)
    host = str(new_host or "").strip()
    if not host:
        return urllib.parse.urlunparse(parsed)
    if ":" in host and not host.startswith("["):
        host_part = f"[{host}]"
    else:
        host_part = host
    netloc = host_part
    if parsed.port:
        netloc = f"{host_part}:{parsed.port}"
    return urllib.parse.urlunparse(parsed._replace(netloc=netloc))


def printer_identity_tokens(value: str) -> set[str]:
    normalized = unicodedata.normalize("NFKD", str(value or ""))
    normalized = normalized.encode("ascii", errors="ignore").decode("ascii", errors="ignore").lower()
    raw_tokens = re.findall(r"[a-z0-9]+", normalized.replace("_", " "))
    clean_tokens = [
        token
        for token in raw_tokens
        if len(token) >= 2 and token not in PRINTER_IDENTITY_IGNORE_TOKENS
    ]
    tokens: set[str] = set()
    for token in clean_tokens:
        tokens.add(token)
    for first, second in zip(clean_tokens, clean_tokens[1:]):
        combined = f"{first}{second}"
        if len(combined) >= 5 and combined not in PRINTER_IDENTITY_IGNORE_TOKENS:
            tokens.add(combined)
    return tokens


def printer_config_identity_tokens(config: dict[str, object], profile_name: str = "") -> set[str]:
    values = [
        profile_name,
        str(config.get("printer_name") or "").replace("_", " "),
        str(config.get("display_name") or ""),
        str(config.get("name") or ""),
    ]
    tokens: set[str] = set()
    for value in values:
        tokens.update(printer_identity_tokens(value))
    return tokens


def printer_identity_match_score(config: dict[str, object], discovered: dict[str, object], profile_name: str = "") -> float:
    desired = printer_config_identity_tokens(config, profile_name)
    candidate = printer_identity_tokens(str(discovered.get("name") or discovered.get("printer_name") or ""))
    if not desired or not candidate:
        return 0.0
    overlap = desired & candidate
    if not overlap:
        return 0.0
    return len(overlap) / max(1, len(desired))


def updated_printer_config_host(config: dict[str, object], host: str, discovered: dict[str, object] | None = None) -> dict[str, object]:
    updated = printer_config_public_copy(config)
    host = str(host or "").strip()
    if not host:
        return updated
    updated["raw_host"] = host
    if str(updated.get("printer_uri") or "").strip():
        updated["printer_uri"] = replace_uri_host(printer_uri(updated), host)
    elif discovered and str(discovered.get("printer_uri") or "").strip():
        updated["printer_uri"] = str(discovered.get("printer_uri"))
    else:
        updated["printer_uri"] = f"ipp://{host}:631/ipp/print"
    return updated


def save_printer_endpoint_refresh(old_config: dict[str, object], new_config: dict[str, object], debug_lines: list[str]) -> None:
    old_signature = printer_config_signature(old_config)
    old_name = str(old_config.get("printer_name") or "").strip().lower()
    profiles = load_printer_profiles()
    changed = False
    refreshed_profiles: list[dict[str, object]] = []
    for profile in profiles:
        profile_config = printer_profile_config(profile)
        profile_signature = printer_config_signature(profile_config)
        profile_name = str(profile_config.get("printer_name") or "").strip().lower()
        if profile_signature == old_signature or (old_name and profile_name == old_name):
            replacement = dict(profile)
            replacement["config"] = printer_config_public_copy(new_config)
            refreshed_profiles.append(replacement)
            changed = True
        else:
            refreshed_profiles.append(profile)
    if changed:
        save_printer_profiles(refreshed_profiles)
        append_network_debug(debug_lines, "Druckerprofil mit neuer IP aktualisiert")
    write_json_atomic(get_printer_config_path(), printer_config_public_copy(new_config))
    append_network_debug(debug_lines, "Aktive Drucker-Konfiguration mit neuer IP aktualisiert")


def resolve_ipv4_candidate(value: str) -> str:
    text = str(value or "").strip().strip("[]").rstrip(".")
    if not text:
        return ""
    try:
        address = ipaddress.ip_address(text)
        return str(address) if isinstance(address, ipaddress.IPv4Address) else ""
    except ValueError:
        pass
    if any(char.isspace() for char in text):
        return ""
    try:
        resolved = socket.gethostbyname(text)
    except OSError:
        return ""
    try:
        address = ipaddress.ip_address(resolved)
    except ValueError:
        return ""
    return str(address) if isinstance(address, ipaddress.IPv4Address) else ""


def printer_service_discovery_targets(debug_lines: list[str] | None = None, limit: int = 64) -> list[str]:
    found: list[str] = []
    seen: set[str] = set()

    def add(value: str) -> None:
        if len(found) >= limit:
            return
        ipv4 = resolve_ipv4_candidate(value)
        if not ipv4 or ipv4 in seen:
            return
        seen.add(ipv4)
        found.append(ipv4)

    avahi = find_executable("avahi-browse")
    if avahi:
        for service in ("_ipp._tcp", "_ipps._tcp", "_printer._tcp", "_pdl-datastream._tcp"):
            output = run_debug_command([avahi, "-rtp", service], timeout=6)
            if debug_lines is not None:
                append_network_debug(debug_lines, f"Service-Discovery avahi {service}: {wifi_scan_output_summary(output, 3)}")
            for line in output.splitlines():
                fields = line.split(";")
                for field in fields:
                    add(field)
                for match in re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", line):
                    add(match)

    lpinfo = find_executable("lpinfo")
    if lpinfo:
        output = run_debug_command([lpinfo, "-v"], timeout=6)
        if debug_lines is not None:
            append_network_debug(debug_lines, f"Service-Discovery lpinfo: {wifi_scan_output_summary(output, 4)}")
        for line in output.splitlines():
            for match in re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", line):
                add(match)
            for uri in re.findall(r"(?:ipp|ipps|socket|lpd)://\S+", line, flags=re.IGNORECASE):
                host = urllib.parse.urlparse(uri).hostname or ""
                add(host)

    if debug_lines is not None and found:
        append_network_debug(debug_lines, "Service-Discovery Druckerziele: " + ", ".join(found[:12]))
    return found


def local_ipv4_scan_targets(max_hosts_per_network: int = 254, max_total: int = 2300, debug_lines: list[str] | None = None) -> list[str]:
    targets: list[str] = []
    seen: set[str] = set()
    own_addresses: set[ipaddress.IPv4Address] = set()
    networks: list[ipaddress.IPv4Network] = []
    context_networks: list[ipaddress.IPv4Network] = []
    office_network_seen = False

    def add_target(value: str) -> None:
        if len(targets) >= max_total:
            return
        try:
            address = ipaddress.ip_address(str(value).strip())
        except ValueError:
            return
        if not isinstance(address, ipaddress.IPv4Address):
            return
        if address.is_loopback or address.is_link_local or address in own_addresses:
            return
        text = str(address)
        if text in seen:
            return
        seen.add(text)
        targets.append(text)

    def add_scan_network(network: ipaddress.IPv4Network, target: list[ipaddress.IPv4Network], reason: str = "") -> None:
        if not isinstance(network, ipaddress.IPv4Network):
            return
        if network.is_loopback or network.is_link_local:
            return
        if network.num_addresses > max_total + 2:
            if debug_lines is not None:
                append_network_debug(debug_lines, f"Drucker-Scanbereich zu gross, ignoriert: {network} {reason}".strip())
            return
        if network not in target:
            target.append(network)
            if debug_lines is not None and reason:
                append_network_debug(debug_lines, f"Drucker-Scanbereich: {network} ({reason})")

    def add_nearby_context(value: str, radius: int = 2) -> None:
        try:
            address = ipaddress.ip_address(str(value).strip())
        except ValueError:
            return
        if not isinstance(address, ipaddress.IPv4Address) or not address.is_private:
            return
        parts = str(address).split(".")
        if len(parts) != 4:
            return
        try:
            third = int(parts[2])
        except ValueError:
            return
        for offset in range(-radius, radius + 1):
            candidate_third = third + offset
            if candidate_third < 0 or candidate_third > 255:
                continue
            try:
                network = ipaddress.ip_network(f"{parts[0]}.{parts[1]}.{candidate_third}.0/24", strict=False)
            except ValueError:
                continue
            add_scan_network(network, context_networks, "Umfeld gespeicherter Drucker")

    def add_cidr_context(value: str, reason: str) -> None:
        text = str(value or "").strip()
        if not text:
            return
        try:
            network = ipaddress.ip_network(text, strict=False)
        except ValueError:
            return
        if isinstance(network, ipaddress.IPv4Network):
            add_scan_network(network, context_networks, reason)

    def config_target_ip(config: dict[str, object]) -> str:
        host = str(config.get("raw_host") or config.get("printer_host") or "").strip()
        if not host:
            host = str(urllib.parse.urlparse(printer_uri(config)).hostname or "").strip()
        return resolve_ipv4_candidate(host)

    def config_target_is_current(config: dict[str, object]) -> bool:
        target = config_target_ip(config)
        if not target:
            return False
        try:
            address = ipaddress.ip_address(target)
        except ValueError:
            return False
        return any(isinstance(address, ipaddress.IPv4Address) and address in network for network in networks)

    def add_config_target(config: dict[str, object]) -> None:
        host = config_target_ip(config)
        add_target(host)
        add_nearby_context(host)

    ip_cmd = find_executable("ip")
    if ip_cmd:
        try:
            result = subprocess.run(
                [ip_cmd, "-o", "-4", "addr", "show", "scope", "global"],
                check=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                timeout=2,
            )
        except (OSError, subprocess.TimeoutExpired):
            result = subprocess.CompletedProcess([], 1, "", "")
        for line in result.stdout.splitlines():
            match = re.search(r"\binet\s+([0-9.]+/\d+)", line)
            if not match:
                continue
            try:
                interface = ipaddress.ip_interface(match.group(1))
            except ValueError:
                continue
            if interface.ip.is_loopback:
                continue
            own_addresses.add(interface.ip)
            network = interface.network
            if network.num_addresses > max_hosts_per_network + 2:
                try:
                    local_network = ipaddress.ip_network(f"{interface.ip}/24", strict=False)
                except ValueError:
                    continue
                add_scan_network(local_network, networks, "aktuelles Teilnetz")
                if str(interface.ip).startswith("10.40."):
                    office_network_seen = True
                elif interface.ip.is_private:
                    add_nearby_context(str(interface.ip), radius=2)
            else:
                add_scan_network(network, networks, "aktuelles Netz")
                if str(interface.ip).startswith("10.40."):
                    office_network_seen = True

    active_config, _path = load_printer_config()
    deferred_configs: list[dict[str, object]] = []
    if active_config and config_target_is_current(active_config):
        add_config_target(active_config)
    elif active_config:
        deferred_configs.append(active_config)

    for discovered_host in printer_service_discovery_targets(debug_lines):
        add_target(discovered_host)

    if ip_cmd:
        try:
            neigh = subprocess.run(
                [ip_cmd, "neigh", "show"],
                check=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                timeout=2,
            )
        except (OSError, subprocess.TimeoutExpired):
            neigh = subprocess.CompletedProcess([], 1, "", "")
        for line in neigh.stdout.splitlines():
            match = re.match(r"\s*([0-9.]+)\s+", line)
            if match:
                add_target(match.group(1))

    for network in networks:
        for address in network.hosts():
            add_target(str(address))
            if len(targets) >= max_total:
                return targets

    # Previously saved printers remain useful hints, but only after the current local network.
    for config in deferred_configs:
        add_config_target(config)
    for profile in load_printer_profiles():
        add_config_target(printer_profile_config(profile))

    if office_network_seen:
        for value in DEFAULT_OFFICE_PRINTER_SCAN_RANGES:
            add_cidr_context(value, "bekannte Buero-Druckerbereiche")

    for network in load_printer_scan_ranges(debug_lines):
        add_scan_network(network, context_networks, "printer_scan_ranges.json")

    for network in context_networks:
        for address in network.hosts():
            add_target(str(address))
            if len(targets) >= max_total:
                return targets
    return targets


def tcp_port_open(host: str, port: int, timeout: float = 0.22) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def fetch_http_device_name_url(url: str, timeout: float = 0.8) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": "HardwareCheck"})
    try:
        context = ssl._create_unverified_context() if url.startswith("https://") else None
        with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
            body = response.read(8192).decode("utf-8", errors="ignore")
            server = str(response.headers.get("Server") or "").strip()
    except (OSError, urllib.error.URLError):
        return ""
    title_match = re.search(r"<title[^>]*>(.*?)</title>", body, flags=re.IGNORECASE | re.DOTALL)
    if title_match:
        title = re.sub(r"\s+", " ", title_match.group(1)).strip()
        if title:
            return title[:80]
    return server[:80]


def fetch_http_device_name(host: str, timeout: float = 0.8) -> str:
    host = str(host or "").strip()
    if not host:
        return ""
    for scheme in ("http", "https"):
        name = fetch_http_device_name_url(f"{scheme}://{host}/", timeout=timeout)
        if name:
            return name
    return ""


def fetch_ipp_printer_attributes(host: str, timeout: float = 1.0) -> dict[str, list[object]]:
    paths = ("/ipp/print", "/ipp/printer", "/printers/printer", "/printers/HardwareCheck")
    for path in paths:
        for scheme in ("ipp", "ipps"):
            config = {"printer_uri": f"{scheme}://{host}:631{path}"}
            body = build_ipp_get_printer_attributes_request(config)
            url = ipp_http_url(str(config["printer_uri"]))
            request = urllib.request.Request(url, data=body, headers={"Content-Type": "application/ipp"}, method="POST")
            try:
                context = ssl._create_unverified_context() if url.startswith("https://") else None
                with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
                    response_body = response.read(32768)
            except (OSError, urllib.error.URLError) as exc:
                if scheme == "ipp" and ipp_upgrade_required(exc):
                    continue
                continue
            if len(response_body) >= 4:
                ipp_status = int.from_bytes(response_body[2:4], "big")
                if ipp_status > 0x00FF:
                    continue
            values = parse_ipp_attribute_values(response_body)
            if values:
                values.setdefault("_printer-uri", []).append(str(config["printer_uri"]))
                return values
    return {}


def first_text_attribute(values: dict[str, list[object]], *names: str) -> str:
    for name in names:
        for value in values.get(name, []):
            text = str(value).strip()
            if text:
                return text
    return ""


def saved_printer_profile_for_host(host: str) -> dict[str, object] | None:
    needle = str(host or "").strip().lower()
    if not needle:
        return None
    for profile in load_printer_profiles():
        config = printer_profile_config(profile)
        candidates = [
            str(config.get("raw_host") or config.get("printer_host") or "").strip().lower(),
            str(urllib.parse.urlparse(printer_uri(config)).hostname or "").strip().lower(),
        ]
        if needle in candidates:
            return profile
    return None


def printer_profile_method(config: dict[str, object]) -> str:
    if printer_config_bool(config, "raw_socket_fallback", False):
        return "RAW/PCL LaserJet"
    document_format = str(config.get("document_format") or "").strip().lower()
    if document_format == "application/pdf":
        return "IPP/PDF"
    return "IPP/PWG Raster"


def printer_device_prefers_ipp_raster(name: str, http_name: str, ipp_open: bool) -> bool:
    if not ipp_open:
        return False
    text = f"{name} {http_name}".lower()
    raster_markers = (
        "epson",
        "canon",
        "pixma",
        "ib4100",
        "mb5100",
        "wf-",
        "wf ",
        "brother",
    )
    return any(marker in text for marker in raster_markers)


def discovered_printer_profile(discovered: dict[str, object], wifi_ssid: str = "", display_name: str = "") -> dict[str, object]:
    detected_name = str(discovered.get("name") or discovered.get("host") or "Netzwerkdrucker").strip()
    name = str(display_name or "").strip() or detected_name
    host = str(discovered.get("host") or "").strip()
    method = str(discovered.get("method") or "RAW/PCL LaserJet").strip()
    printer_uri_value = str(discovered.get("printer_uri") or f"ipp://{host}:631/ipp/print").strip()
    wifi_config: dict[str, object] = {"ssid": wifi_ssid} if wifi_ssid else {}
    config: dict[str, object] = {
        "enabled": True,
        "connect_wifi": bool(wifi_config),
        "disconnect_after_print": False,
        "use_cups": False,
        "printer_name": safe_printer_name(name),
        "printer_uri": printer_uri_value,
        "raw_host": host,
        "raw_port": 9100,
        "media": "iso_a4_210x297mm",
        "media_source": str(discovered.get("media_source") or "auto").strip() or "auto",
        "use_media_col": bool(discovered.get("use_media_col")),
        "wifi": wifi_config,
    }
    if method == "RAW/PCL LaserJet":
        config.update({
            "direct_ipp_fallback": False,
            "raw_socket_fallback": True,
            "document_format": "application/vnd.hp-PCL",
            "raw_job_control": "pcl",
            "model": "raw-pcl",
        })
    elif method == "IPP/PDF":
        config.update({
            "direct_ipp_fallback": True,
            "raw_socket_fallback": False,
            "document_format": "application/pdf",
            "raw_job_control": "plain",
            "model": "everywhere",
        })
    else:
        config.update({
            "direct_ipp_fallback": True,
            "raw_socket_fallback": False,
            "document_format": "image/pwg-raster",
            "pwg_raster_type": "sgray_8",
            "raster_resolution": 600,
            "raster_font_scale": 10,
            "raw_job_control": "plain",
            "model": "everywhere",
        })
    profile_id = sanitize_filename(f"{detected_name}-{host}").lower().replace(" ", "-")
    return {"id": profile_id, "name": name, "config": config}


def probe_printer_host(host: str) -> dict[str, object] | None:
    raw_open = tcp_port_open(host, 9100, timeout=0.75)
    ipp_open = tcp_port_open(host, 631, timeout=0.75)
    http_open = tcp_port_open(host, 80, timeout=0.55)
    https_open = tcp_port_open(host, 443, timeout=0.55)
    http_name = ""
    if http_open or https_open:
        http_name = fetch_http_device_name(host)
    if not raw_open and not ipp_open and not http_open and not https_open:
        return None
    if not raw_open and not ipp_open:
        lower_http_name = http_name.lower()
        printer_markers = ("printer", "drucker", "laserjet", "officejet", "deskjet", "mfp", "epson", "canon", "brother", "hp ")
        if not any(marker in lower_http_name for marker in printer_markers):
            return None
    saved_profile = saved_printer_profile_for_host(host)
    saved_config = printer_profile_config(saved_profile) if saved_profile else {}
    values = fetch_ipp_printer_attributes(host, timeout=1.4) if ipp_open else {}
    name = first_text_attribute(values, "printer-make-and-model", "printer-info", "printer-name")
    if not name:
        name = http_name
    if not name and saved_profile:
        name = printer_profile_name(saved_profile)
    if not name:
        name = f"Drucker {host}"
    lower_name = name.lower()
    printer_uri_value = first_text_attribute(values, "_printer-uri") or str(saved_config.get("printer_uri") or "") or f"ipp://{host}:631/ipp/print"
    media_source = str(saved_config.get("media_source") or "").strip()
    prefers_ipp_raster = printer_device_prefers_ipp_raster(name, http_name, ipp_open)
    if saved_config:
        saved_method = printer_profile_method(saved_config)
        if saved_method == "RAW/PCL LaserJet" and prefers_ipp_raster:
            method = "IPP/PWG Raster"
        else:
            method = saved_method
    elif raw_open and not prefers_ipp_raster:
        method = "RAW/PCL LaserJet"
    elif ipp_open:
        method = "IPP/PWG Raster"
    else:
        method = "RAW/PCL LaserJet"
    use_media_col = False
    if not media_source and "canon" in lower_name and "ib4100" in lower_name:
        media_source = "tray-2"
        use_media_col = True
    if "canon" in lower_name and "ib4100" in lower_name:
        use_media_col = True
    ports: list[str] = []
    if raw_open:
        ports.append("RAW 9100")
    if ipp_open:
        ports.append("IPP 631")
    if http_open:
        ports.append("HTTP 80")
    if https_open:
        ports.append("HTTPS 443")
    return {
        "name": name[:80],
        "host": host,
        "method": method,
        "printer_uri": printer_uri_value,
        "media_source": media_source or "auto",
        "use_media_col": use_media_col or printer_config_bool(saved_config, "use_media_col", False),
        "ports": ", ".join(ports),
    }


def discover_network_printers(status_callback=None, found_callback=None) -> tuple[list[dict[str, object]], str]:
    debug_lines: list[str] = []
    append_network_debug(debug_lines, "Drucker-Suche gestartet")
    if not active_local_network_message():
        ok, message, cleanup = connect_temporary_network(
            status_callback,
            debug_lines,
            require_internet=False,
            allow_active=True,
            allow_lan=True,
            cleanup_success=False,
        )
        if not ok:
            cleanup()
            result_message = f"Kein Netzwerk für Druckersuche gefunden: {message}"
            write_printer_discovery_debug(False, result_message, debug_lines)
            return [], result_message
    else:
        append_network_debug(debug_lines, f"Netzwerk aktiv: {active_local_network_message()}")
    targets = local_ipv4_scan_targets(debug_lines=debug_lines)
    if not targets:
        result_message = "Kein Netzwerk für Druckersuche gefunden"
        write_printer_discovery_debug(False, result_message, debug_lines)
        return [], result_message
    found: list[dict[str, object]] = []
    completed = 0
    total = len(targets)
    append_network_debug(debug_lines, f"Drucker-Suche Ziele: {total}")
    append_network_debug(debug_lines, "Drucker-Suche erste Ziele: " + ", ".join(targets[:16]))
    if status_callback:
        status_callback("searching", f"Drucker-Suche: {total} Adressen")
    with concurrent.futures.ThreadPoolExecutor(max_workers=48) as executor:
        future_map = {executor.submit(probe_printer_host, host): host for host in targets}
        for future in concurrent.futures.as_completed(future_map):
            completed += 1
            if status_callback and (completed == total or completed % 32 == 0):
                status_callback("searching", f"Drucker-Suche: {completed}/{total}")
            try:
                printer = future.result()
            except Exception:
                printer = None
            if printer:
                found.append(printer)
                append_network_debug(debug_lines, f"Drucker gefunden: {printer.get('name')} | {printer.get('host')} | {printer.get('ports')}")
                if found_callback:
                    try:
                        found_callback(printer)
                    except Exception:
                        pass
                if status_callback:
                    status_callback("searching", f"Drucker gefunden: {printer.get('name')}")
    found.sort(key=lambda item: tuple(int(part) for part in str(item.get("host") or "0.0.0.0").split(".") if part.isdigit()))
    if not found:
        result_message = "Keine Netzwerkdrucker gefunden"
        write_printer_discovery_debug(False, result_message, debug_lines)
        return [], result_message
    result_message = f"{len(found)} Netzwerkdrucker gefunden"
    write_printer_discovery_debug(True, result_message, debug_lines)
    return found, result_message


def saved_printer_profile_matches_config(profile: dict[str, object], config: dict[str, object]) -> bool:
    profile_config = printer_profile_config(profile)
    if printer_config_signature(profile_config) == printer_config_signature(config):
        return True
    left = str(profile_config.get("printer_name") or "").strip().lower()
    right = str(config.get("printer_name") or "").strip().lower()
    return bool(left and right and left == right)


def find_refreshed_printer_endpoint(
    config: dict[str, object],
    debug_lines: list[str],
    status_callback=None,
) -> tuple[dict[str, object] | None, str]:
    old_host = str(printer_ipp_target(config)[0] or printer_raw_target(config)[0] or "").strip()
    profile_name = str(config.get("profile_name") or config.get("printer_name") or "").replace("_", " ")
    desired_tokens = printer_config_identity_tokens(config, profile_name)
    if not desired_tokens:
        return None, "Drucker-IP nicht repariert: kein Druckername zum Vergleichen"

    append_network_debug(debug_lines, "Drucker-IP-Reparatur sucht nach: " + ", ".join(sorted(desired_tokens)))

    def discovery_status(state: str, message: str) -> None:
        append_network_debug(debug_lines, f"Drucker-IP-Reparatur {state}: {message}")
        if status_callback is not None:
            status_callback(state, message)

    found, message = discover_network_printers(status_callback=discovery_status)
    append_network_debug(debug_lines, f"Drucker-IP-Reparatur Suche: {message}")
    if not found:
        return None, message

    candidates: list[tuple[float, dict[str, object]]] = []
    skipped_other_profile: list[str] = []
    for discovered in found:
        host = str(discovered.get("host") or "").strip()
        if not host or host == old_host:
            continue
        score = printer_identity_match_score(config, discovered, profile_name)
        append_network_debug(
            debug_lines,
            f"Drucker-IP-Reparatur Kandidat {discovered.get('name')} {host}: Score {score:.2f}",
        )
        if score < 0.65:
            continue
        saved_profile = saved_printer_profile_for_host(host)
        if saved_profile and not saved_printer_profile_matches_config(saved_profile, config):
            skipped_other_profile.append(f"{printer_profile_name(saved_profile)} ({host})")
            append_network_debug(
                debug_lines,
                f"Drucker-IP-Reparatur Kandidat gehoert zu anderem Profil: {printer_profile_name(saved_profile)}",
            )
            continue
        candidates.append((score, discovered))

    if not candidates:
        if skipped_other_profile:
            return None, "Aehnlicher Drucker gehoert zu anderem Profil: " + ", ".join(skipped_other_profile[:2])
        return None, "Kein passender Drucker mit neuer IP gefunden"

    candidates.sort(key=lambda item: item[0], reverse=True)
    best_score, best = candidates[0]
    if len(candidates) > 1 and candidates[1][0] >= best_score - 0.01:
        names = ", ".join(str(item[1].get("name") or item[1].get("host")) for item in candidates[:3])
        return None, "Mehrere passende Drucker gefunden, bitte manuell waehlen: " + names

    refreshed = updated_printer_config_host(config, str(best.get("host") or ""), best)
    return refreshed, f"Drucker-IP aktualisiert: {old_host or '?'} -> {best.get('host')}"


def printer_config_wifi_ssid(config: dict[str, object]) -> str:
    wifi = config.get("wifi")
    if isinstance(wifi, dict):
        return str(wifi.get("ssid") or "").strip()
    return str(config.get("wifi_ssid") or "").strip()


def printer_config_display_name(config: dict[str, object], detected: dict[str, object]) -> str:
    detected_name = str(detected.get("name") or "").strip()
    candidates = [
        str(config.get("profile_name") or "").strip(),
        str(config.get("display_name") or "").strip(),
        str(config.get("name") or "").strip(),
        str(config.get("printer_name") or "").replace("_", " ").strip(),
    ]
    generic_re = re.compile(r"^drucker\s*\d{1,3}(?:\.\d{1,3}){3}$", re.IGNORECASE)
    for candidate in candidates:
        if not candidate:
            continue
        if generic_re.match(candidate):
            continue
        if candidate.lower().startswith("drucker "):
            continue
        return candidate
    return detected_name or str(config.get("printer_name") or "Drucker").replace("_", " ").strip()


def corrected_reachable_printer_config(
    config: dict[str, object],
    debug_lines: list[str],
) -> tuple[dict[str, object] | None, str]:
    host = str(printer_ipp_target(config)[0] or printer_raw_target(config)[0] or "").strip()
    if not host:
        return None, ""
    detected = probe_printer_host(host)
    if not detected:
        append_network_debug(debug_lines, f"Drucker-Typpruefung {host}: keine Erkennung")
        return None, ""
    old_method = printer_profile_method(config)
    new_method = str(detected.get("method") or old_method).strip() or old_method
    old_uri = printer_uri(config)
    new_uri = str(detected.get("printer_uri") or "").strip()
    append_network_debug(
        debug_lines,
        f"Drucker-Typpruefung {host}: Profil {old_method}, erkannt {new_method} ({detected.get('name')})",
    )
    if old_method == new_method:
        if new_uri and new_uri != old_uri and new_uri.startswith("ipps://"):
            corrected = dict(config)
            corrected["printer_uri"] = new_uri
            if new_method in {"IPP/PWG Raster", "IPP/PDF"}:
                corrected["direct_ipp_fallback"] = True
                corrected["raw_socket_fallback"] = False
            return corrected, f"Drucker-URI korrigiert: {old_uri} -> {new_uri}"
        return None, ""
    if old_method != "RAW/PCL LaserJet" or new_method not in {"IPP/PWG Raster", "IPP/PDF"}:
        return None, ""
    profile = discovered_printer_profile(
        detected,
        wifi_ssid=printer_config_wifi_ssid(config),
        display_name=printer_config_display_name(config, detected),
    )
    corrected = printer_profile_config(profile)
    for key in ("media", "media_source", "use_media_col", "raster_resolution", "raster_font_scale"):
        if key in config and key in corrected:
            corrected[key] = config[key]
    return corrected, f"Druckermodus korrigiert: {old_method} -> {new_method}"


def refresh_printer_endpoint_if_needed(
    config: dict[str, object],
    debug_lines: list[str],
    status_callback=None,
) -> tuple[dict[str, object], bool, str]:
    reachable, message = printer_target_reachable(config, debug_lines)
    if reachable:
        corrected, correction_message = corrected_reachable_printer_config(config, debug_lines)
        if corrected:
            save_printer_endpoint_refresh(config, corrected, debug_lines)
            return corrected, True, correction_message
        return config, False, message
    if status_callback is not None:
        status_callback("searching", "Drucker-IP pruefen")
    refreshed, refresh_message = find_refreshed_printer_endpoint(config, debug_lines, status_callback=status_callback)
    if not refreshed:
        return config, False, refresh_message
    reachable, reach_message = printer_target_reachable(refreshed, debug_lines)
    if not reachable:
        return config, False, f"{refresh_message}; neues Ziel nicht erreichbar: {reach_message}"
    save_printer_endpoint_refresh(config, refreshed, debug_lines)
    return refreshed, True, refresh_message


def split_cidr_address(cidr: str) -> str:
    return str(cidr or "").split("/", 1)[0].strip()


def find_interface_with_ipv4(address: str) -> str:
    ip_cmd = find_executable("ip")
    if not ip_cmd or not address:
        return ""
    try:
        result = subprocess.run(
            [ip_cmd, "-o", "-4", "addr", "show", "scope", "global"],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=2,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    marker = f" inet {address}/"
    for line in result.stdout.splitlines():
        if marker not in f" {line} ":
            continue
        parts = line.split()
        if len(parts) >= 2:
            return parts[1]
    return ""


def ensure_printer_route(config: dict[str, object], debug_lines: list[str]) -> None:
    ip_cmd = find_executable("ip")
    if not ip_cmd:
        return
    host, _port = printer_raw_target(config)
    static_ipv4 = str(config.get("static_ipv4") or "").strip()
    source_ip = split_cidr_address(static_ipv4)
    preferred_iface = find_interface_with_ipv4(source_ip)
    candidate_ifaces = [preferred_iface] if preferred_iface else []
    ssid = ""
    wifi = config.get("wifi")
    if isinstance(wifi, dict):
        ssid = str(wifi.get("ssid") or "").strip()
    for iface in list_network_interfaces(wifi=True):
        if iface not in candidate_ifaces:
            candidate_ifaces.append(iface)
    for iface in candidate_ifaces:
        if not iface:
            continue
        current_ssid = current_wifi_ssid(iface)
        if ssid and current_ssid and current_ssid != ssid:
            continue
        if static_ipv4:
            run_quiet_timeout([ip_cmd, "addr", "replace", static_ipv4, "dev", iface], timeout=3)
        route_command = [ip_cmd, "route", "replace", f"{host}/32", "dev", iface]
        if source_ip:
            route_command.extend(["src", source_ip])
        append_network_debug(debug_lines, "Drucker-Route: " + " ".join(route_command))
        run_quiet_timeout(route_command, timeout=3)
        append_network_debug(debug_lines, "Route-Test: " + run_debug_command([ip_cmd, "route", "get", host], timeout=2))
        return


def printer_document_bytes(report_path: pathlib.Path) -> bytes:
    text = printer_ascii_text(report_path)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    if not text.endswith("\n"):
        text += "\n"
    return text.replace("\n", "\r\n").encode("ascii", errors="replace")


def pdf_escape_text(value: str) -> bytes:
    data = value.encode("cp1252", errors="replace")
    escaped = bytearray()
    for byte in data:
        if byte in (0x28, 0x29, 0x5C):
            escaped.append(0x5C)
        escaped.append(byte)
    return bytes(escaped)


def build_pdf_content_stream(lines: list[str]) -> bytes:
    commands = [b"BT", b"/F1 10 Tf", b"40 800 Td", b"12 TL"]
    for line in lines:
        commands.append(b"(" + pdf_escape_text(line) + b") Tj")
        commands.append(b"T*")
    commands.append(b"ET")
    return b"\n".join(commands) + b"\n"


def printer_pdf_document_bytes(report_path: pathlib.Path) -> bytes:
    text = printer_ascii_text(report_path)
    raw_lines = text.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    wrapped_lines: list[str] = []
    for line in raw_lines:
        if not line:
            wrapped_lines.append("")
            continue
        wrapped = textwrap.wrap(line, width=88, replace_whitespace=False, drop_whitespace=False)
        wrapped_lines.extend(wrapped or [""])
    lines_per_page = 64
    pages = [wrapped_lines[index : index + lines_per_page] for index in range(0, len(wrapped_lines), lines_per_page)] or [[]]

    objects: list[bytes] = []
    page_object_numbers: list[int] = []
    content_object_numbers: list[int] = []

    objects.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objects.append(b"")
    objects.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>")

    for page_lines in pages:
        page_number = len(objects) + 1
        content_number = page_number + 1
        page_object_numbers.append(page_number)
        content_object_numbers.append(content_number)
        page = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            f"/Resources << /Font << /F1 3 0 R >> >> /Contents {content_number} 0 R >>"
        ).encode("ascii")
        stream = build_pdf_content_stream(page_lines)
        content = b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"endstream"
        objects.append(page)
        objects.append(content)

    kids = " ".join(f"{number} 0 R" for number in page_object_numbers).encode("ascii")
    objects[1] = b"<< /Type /Pages /Kids [" + kids + b"] /Count " + str(len(page_object_numbers)).encode("ascii") + b" >>"

    output = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for number, obj in enumerate(objects, start=1):
        offsets.append(len(output))
        output.extend(f"{number} 0 obj\n".encode("ascii"))
        output.extend(obj)
        output.extend(b"\nendobj\n")
    xref_offset = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    output.extend(b"0000000000 65535 f \n")
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
    output.extend(
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n".encode("ascii")
    )
    return bytes(output)


FONT5X7 = {
    " ": ["00000", "00000", "00000", "00000", "00000", "00000", "00000"],
    "!": ["00100", "00100", "00100", "00100", "00100", "00000", "00100"],
    '"': ["01010", "01010", "01010", "00000", "00000", "00000", "00000"],
    "#": ["01010", "11111", "01010", "01010", "11111", "01010", "00000"],
    "%": ["11001", "11010", "00100", "01011", "10011", "00000", "00000"],
    "&": ["01100", "10010", "10100", "01000", "10101", "10010", "01101"],
    "'": ["00100", "00100", "01000", "00000", "00000", "00000", "00000"],
    "(": ["00010", "00100", "01000", "01000", "01000", "00100", "00010"],
    ")": ["01000", "00100", "00010", "00010", "00010", "00100", "01000"],
    "*": ["00000", "10101", "01110", "11111", "01110", "10101", "00000"],
    "+": ["00000", "00100", "00100", "11111", "00100", "00100", "00000"],
    ",": ["00000", "00000", "00000", "00000", "00100", "00100", "01000"],
    "-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000"],
    ".": ["00000", "00000", "00000", "00000", "00000", "00100", "00100"],
    "/": ["00001", "00010", "00100", "01000", "10000", "00000", "00000"],
    "0": ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
    "1": ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
    "2": ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
    "3": ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
    "4": ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
    "5": ["11111", "10000", "10000", "11110", "00001", "00001", "11110"],
    "6": ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
    "7": ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
    "8": ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
    "9": ["01110", "10001", "10001", "01111", "00001", "00010", "11100"],
    ":": ["00000", "00100", "00100", "00000", "00100", "00100", "00000"],
    ";": ["00000", "00100", "00100", "00000", "00100", "00100", "01000"],
    "<": ["00010", "00100", "01000", "10000", "01000", "00100", "00010"],
    "=": ["00000", "00000", "11111", "00000", "11111", "00000", "00000"],
    ">": ["01000", "00100", "00010", "00001", "00010", "00100", "01000"],
    "?": ["01110", "10001", "00001", "00010", "00100", "00000", "00100"],
    "@": ["01110", "10001", "10111", "10101", "10111", "10000", "01110"],
    "A": ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
    "B": ["11110", "10001", "10001", "11110", "10001", "10001", "11110"],
    "C": ["01110", "10001", "10000", "10000", "10000", "10001", "01110"],
    "D": ["11110", "10001", "10001", "10001", "10001", "10001", "11110"],
    "E": ["11111", "10000", "10000", "11110", "10000", "10000", "11111"],
    "F": ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
    "G": ["01110", "10001", "10000", "10111", "10001", "10001", "01110"],
    "H": ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
    "I": ["01110", "00100", "00100", "00100", "00100", "00100", "01110"],
    "J": ["00111", "00010", "00010", "00010", "10010", "10010", "01100"],
    "K": ["10001", "10010", "10100", "11000", "10100", "10010", "10001"],
    "L": ["10000", "10000", "10000", "10000", "10000", "10000", "11111"],
    "M": ["10001", "11011", "10101", "10101", "10001", "10001", "10001"],
    "N": ["10001", "11001", "10101", "10011", "10001", "10001", "10001"],
    "O": ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
    "P": ["11110", "10001", "10001", "11110", "10000", "10000", "10000"],
    "Q": ["01110", "10001", "10001", "10001", "10101", "10010", "01101"],
    "R": ["11110", "10001", "10001", "11110", "10100", "10010", "10001"],
    "S": ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
    "T": ["11111", "00100", "00100", "00100", "00100", "00100", "00100"],
    "U": ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
    "V": ["10001", "10001", "10001", "10001", "10001", "01010", "00100"],
    "W": ["10001", "10001", "10001", "10101", "10101", "10101", "01010"],
    "X": ["10001", "10001", "01010", "00100", "01010", "10001", "10001"],
    "Y": ["10001", "10001", "01010", "00100", "00100", "00100", "00100"],
    "Z": ["11111", "00001", "00010", "00100", "01000", "10000", "11111"],
    "[": ["01110", "01000", "01000", "01000", "01000", "01000", "01110"],
    "\\": ["10000", "01000", "00100", "00010", "00001", "00000", "00000"],
    "]": ["01110", "00010", "00010", "00010", "00010", "00010", "01110"],
    "_": ["00000", "00000", "00000", "00000", "00000", "00000", "11111"],
}


def printer_ascii_text_legacy(report_path: pathlib.Path) -> str:
    text = report_path.read_text(encoding="utf-8", errors="replace")
    replacements = {
        "Ä": "AE", "Ö": "OE", "Ü": "UE", "ä": "AE", "ö": "OE", "ü": "UE", "ß": "SS",
        "Ã": "A", "ÄŒ": "C", "ÄŽ": "D", "Ã‰": "E", "Äš": "E", "Ã": "I", "Å‡": "N", "Ã“": "O", "Å˜": "R", "Å ": "S", "Å¤": "T", "Ãš": "U", "Å®": "U", "Ã": "Y", "Å½": "Z",
        "Ã¡": "A", "Ä": "C", "Ä": "D", "Ã©": "E", "Ä›": "E", "Ã­": "I", "Åˆ": "N", "Ã³": "O", "Å™": "R", "Å¡": "S", "Å¥": "T", "Ãº": "U", "Å¯": "U", "Ã½": "Y", "Å¾": "Z",
        "Â²": "2", "Â³": "3", "â€“": "-", "â€”": "-", "â€œ": '"', "â€": '"', "â€˜": "'", "â€™": "'",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return "".join(ch if 32 <= ord(ch) <= 126 or ch in "\r\n\t" else "?" for ch in text).upper()


def printer_ascii_text(report_path: pathlib.Path) -> str:
    text = report_path.read_text(encoding="utf-8", errors="replace")
    if report_path.suffix.lower() in {".html", ".htm"}:
        text = battery_html_to_text(text)
    replacements = {
        "\u00c4": "AE", "\u00d6": "OE", "\u00dc": "UE", "\u00e4": "ae", "\u00f6": "oe", "\u00fc": "ue", "\u00df": "ss",
        "\u010c": "C", "\u010e": "D", "\u011a": "E", "\u0147": "N", "\u0158": "R", "\u0160": "S", "\u0164": "T", "\u016e": "U", "\u017d": "Z",
        "\u010d": "c", "\u010f": "d", "\u011b": "e", "\u0148": "n", "\u0159": "r", "\u0161": "s", "\u0165": "t", "\u016f": "u", "\u017e": "z",
        "\u00b2": "2", "\u00b3": "3", "\u2013": "-", "\u2014": "-", "\u201c": '"', "\u201d": '"', "\u2018": "'", "\u2019": "'",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", errors="ignore").decode("ascii", errors="ignore")
    return "".join(ch if 32 <= ord(ch) <= 126 or ch in "\r\n\t" else "?" for ch in text).upper()


def render_text_row(width: int, line_entries: list[tuple[int, str]], row: int, scale: int, margin_x: int) -> bytes:
    pixels = bytearray([255]) * width
    glyph_height = 7 * scale
    char_width = 6 * scale
    for y, line in line_entries:
        rel = row - y
        if rel < 0 or rel >= glyph_height:
            continue
        glyph_row = rel // scale
        x = margin_x
        for char in line:
            glyph = FONT5X7.get(char, FONT5X7.get("?", FONT5X7[" "]))
            pattern = glyph[glyph_row]
            for gx, bit in enumerate(pattern):
                if bit != "1":
                    continue
                start = x + gx * scale
                end = min(start + scale, width)
                if 0 <= start < width:
                    pixels[start:end] = b"\x00" * (end - start)
            x += char_width
            if x >= width:
                break
    return bytes(pixels)


def rle_line(line: bytes) -> bytes:
    out = bytearray()
    i = 0
    length = len(line)
    while i < length:
        run = 1
        while i + run < length and run < 128 and line[i + run] == line[i]:
            run += 1
        if run >= 2:
            out.append(run - 1)
            out.append(line[i])
            i += run
            continue
        start = i
        i += 1
        while i < length and (i - start) < 128:
            lookahead = 1
            while i + lookahead < length and lookahead < 128 and line[i + lookahead] == line[i]:
                lookahead += 1
            if lookahead >= 2:
                break
            i += 1
        count = i - start
        if count == 1:
            out.append(0)
            out.append(line[start])
        else:
            out.append(257 - count)
            out.extend(line[start:i])
    return bytes(out)


def pwg_cstring(value: str, size: int) -> bytes:
    data = value.encode("ascii", errors="ignore")[: max(0, size - 1)]
    return data + b"\x00" * (size - len(data))


def pwg_page_header(width: int, height: int, resolution: int, media: str) -> bytes:
    header = bytearray(1796)

    def put_int(offset: int, value: int) -> None:
        header[offset : offset + 4] = int(value).to_bytes(4, "big", signed=False)

    def put_float(offset: int, value: float) -> None:
        header[offset : offset + 4] = struct.pack(">f", float(value))

    header[128:192] = pwg_cstring("stationery", 64)
    put_int(276, resolution)
    put_int(280, resolution)
    for offset, value in zip((284, 288, 292, 296), (0, 0, 595, 842)):
        put_int(offset, value)
    put_int(308, 0)
    put_int(340, 1)
    put_int(352, 595)
    put_int(356, 842)
    put_int(372, width)
    put_int(376, height)
    put_int(384, 8)
    put_int(388, 8)
    put_int(392, width)
    put_int(396, 0)
    put_int(400, 18)  # sGray
    put_int(420, 1)
    put_float(424, 1.0)
    put_float(428, 595.0)
    put_float(432, 842.0)
    for offset, value in zip((436, 440, 444, 448), (0.0, 0.0, 595.0, 842.0)):
        put_float(offset, value)
    header[1668:1732] = pwg_cstring("relative", 64)
    header[1732:1796] = pwg_cstring(media, 64)
    return bytes(header)


def printer_pwg_raster_document_bytes(config: dict[str, object], report_path: pathlib.Path) -> bytes:
    resolution = int(config.get("raster_resolution") or 300)
    width = int(210 / 25.4 * resolution)
    height = int(297 / 25.4 * resolution)
    margin_x = int(10 / 25.4 * resolution)
    margin_y = int(12 / 25.4 * resolution)
    default_scale = 5 if resolution <= 300 else 10
    try:
        scale = int(config.get("raster_font_scale") or default_scale)
    except (TypeError, ValueError):
        scale = default_scale
    scale = max(3, min(scale, 8 if resolution <= 300 else 16))
    line_height = 9 * scale
    max_chars = max(40, (width - margin_x * 2) // (6 * scale))
    text = printer_ascii_text(report_path).replace("\t", "    ")
    lines: list[str] = []
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").splitlines():
        if not raw:
            lines.append("")
        else:
            lines.extend(textwrap.wrap(raw, width=max_chars, replace_whitespace=False, drop_whitespace=False) or [""])
    lines_per_page = max(1, (height - margin_y * 2) // line_height)
    pages = [lines[index : index + lines_per_page] for index in range(0, len(lines), lines_per_page)] or [[]]
    media = str(config.get("media") or "iso_a4_210x297mm").strip()

    output = bytearray(b"RaS2")
    for page_lines in pages:
        output.extend(pwg_page_header(width, height, resolution, media))
        entries = [(margin_y + index * line_height, line) for index, line in enumerate(page_lines)]
        previous: bytes | None = None
        repeat = 0

        def flush() -> None:
            nonlocal previous, repeat
            if previous is None or repeat <= 0:
                return
            while repeat:
                count = min(repeat, 256)
                output.append(count - 1)
                output.extend(rle_line(previous))
                repeat -= count
            previous = None

        for row in range(height):
            line_bytes = render_text_row(width, entries, row, scale, margin_x)
            if previous is None:
                previous = line_bytes
                repeat = 1
            elif line_bytes == previous and repeat < 256:
                repeat += 1
            else:
                flush()
                previous = line_bytes
                repeat = 1
        flush()
    return bytes(output)


def printer_ipp_document_bytes(config: dict[str, object], report_path: pathlib.Path) -> bytes:
    document_format = str(config.get("document_format") or "application/pdf").strip().lower()
    if document_format == "application/pdf":
        return printer_pdf_document_bytes(report_path)
    if document_format == "image/pwg-raster":
        return printer_pwg_raster_document_bytes(config, report_path)
    return printer_document_bytes(report_path)


def printer_raw_payload(config: dict[str, object], report_path: pathlib.Path) -> bytes:
    text_payload = printer_document_bytes(report_path)
    mode = str(config.get("raw_job_control") or "plain").strip().lower()
    if mode in {"", "plain", "text"}:
        return text_payload + b"\r\n\f"
    if mode in {"pcl", "pcl_a4", "laserjet"}:
        prefix_parts = [
            b"\x1bE",         # reset printer
            b"\x1b&l26A",     # A4
            b"\x1b&l0O",      # portrait
        ]
        source_value = str(config.get("pcl_media_source") or config.get("pcl_tray") or "").strip()
        if source_value:
            try:
                prefix_parts.append(f"\x1b&l{int(source_value)}H".encode("ascii"))
            except ValueError:
                pass
        prefix_parts.append(b"\x1b(s0p10h12v0s0b4099T")  # 10 cpi Courier
        pcl_prefix = b"".join(prefix_parts)
        return pcl_prefix + text_payload + b"\r\n\f\x1bE"
    pjl_prefix = (
        b"\x1b%-12345X"
        b"@PJL JOB NAME=\"HardwareCheck\"\r\n"
        b"@PJL SET PAPER=A4\r\n"
        b"@PJL SET MEDIASIZE=A4\r\n"
        b"@PJL SET ORIENTATION=PORTRAIT\r\n"
        b"@PJL ENTER LANGUAGE=PCL\r\n"
    )
    pcl_prefix = (
        b"\x1bE"          # reset printer
        b"\x1b&l26A"     # A4
        b"\x1b&l0O"      # portrait
        b"\x1b&l6D"      # 6 lines per inch
        b"\x1b(s0p10h12v0s0b4099T"  # 10 cpi Courier
    )
    suffix = b"\r\n\f\x1bE\x1b%-12345X@PJL EOJ\r\n\x1b%-12345X"
    return pjl_prefix + pcl_prefix + text_payload + suffix


def ipp_raw_attribute(tag: int, name: str, value: bytes) -> bytes:
    name_bytes = name.encode("utf-8")
    return bytes([tag]) + len(name_bytes).to_bytes(2, "big") + name_bytes + len(value).to_bytes(2, "big") + value


def ipp_attribute(tag: int, name: str, value: str) -> bytes:
    return ipp_raw_attribute(tag, name, value.encode("utf-8"))


def ipp_member_name(name: str) -> bytes:
    return ipp_raw_attribute(0x4A, "", name.encode("utf-8"))


def ipp_integer_member(name: str, value: int) -> bytes:
    return ipp_member_name(name) + ipp_raw_attribute(0x21, "", int(value).to_bytes(4, "big", signed=True))


def ipp_keyword_member(name: str, value: str) -> bytes:
    return ipp_member_name(name) + ipp_attribute(0x44, "", value)


def ipp_media_dimensions(media: str) -> tuple[int, int] | None:
    normalized = str(media or "").strip().lower()
    if normalized in {"a4", "iso_a4_210x297mm"}:
        return 21000, 29700
    if normalized in {"a5", "iso_a5_148x210mm"}:
        return 14800, 21000
    match = re.search(r"_(\d+)x(\d+)mm", normalized)
    if match:
        return int(match.group(1)) * 100, int(match.group(2)) * 100
    return None


def ipp_media_col_attribute(media: str, media_source: str, media_type: str = "stationery") -> bytes:
    dimensions = ipp_media_dimensions(media)
    if not dimensions:
        return b""
    x_dimension, y_dimension = dimensions
    body = bytearray()
    body += ipp_raw_attribute(0x34, "media-col", b"")
    body += ipp_member_name("media-size")
    body += ipp_raw_attribute(0x34, "", b"")
    body += ipp_integer_member("x-dimension", x_dimension)
    body += ipp_integer_member("y-dimension", y_dimension)
    body += ipp_raw_attribute(0x37, "", b"")
    if media_source:
        body += ipp_keyword_member("media-source", media_source)
    if media_type:
        body += ipp_keyword_member("media-type", media_type)
    body += ipp_raw_attribute(0x37, "", b"")
    return bytes(body)


def ipp_enum_attribute(name: str, value: int) -> bytes:
    name_bytes = name.encode("utf-8")
    return bytes([0x23]) + len(name_bytes).to_bytes(2, "big") + name_bytes + (4).to_bytes(2, "big") + int(value).to_bytes(4, "big")


def ipp_resolution_attribute(name: str, xres: int, yres: int, unit: int = 3) -> bytes:
    name_bytes = name.encode("utf-8")
    value = int(xres).to_bytes(4, "big", signed=True) + int(yres).to_bytes(4, "big", signed=True) + bytes([int(unit)])
    return bytes([0x32]) + len(name_bytes).to_bytes(2, "big") + name_bytes + len(value).to_bytes(2, "big") + value


def build_ipp_print_job_request(config: dict[str, object], report_path: pathlib.Path) -> bytes:
    request_id = int(time.time()) & 0x7FFFFFFF
    job_name = report_path.stem[:80] or "HardwareCheck Report"
    uri = printer_uri(config)
    media = str(config.get("media") or config.get("paper") or "iso_a4_210x297mm").strip()
    media_source = str(config.get("media_source") or "").strip()
    body = bytearray()
    body += b"\x02\x00"  # IPP 2.0
    body += (0x0002).to_bytes(2, "big")  # Print-Job
    body += request_id.to_bytes(4, "big")
    body += b"\x01"  # operation-attributes-tag
    body += ipp_attribute(0x47, "attributes-charset", "utf-8")
    body += ipp_attribute(0x48, "attributes-natural-language", "de")
    body += ipp_attribute(0x45, "printer-uri", uri)
    body += ipp_attribute(0x42, "requesting-user-name", "HardwareCheck")
    body += ipp_attribute(0x42, "job-name", job_name)
    document_format = str(config.get("document_format") or "application/pdf").strip()
    body += ipp_attribute(0x49, "document-format", document_format)
    body += b"\x02"  # job-attributes-tag
    use_media_col = printer_config_bool(config, "use_media_col", False) or printer_config_bool(config, "force_media_col", False)
    if use_media_col and media_source:
        media_col = ipp_media_col_attribute(media, media_source, str(config.get("media_type") or "stationery").strip())
        if media_col:
            body += media_col
        else:
            body += ipp_attribute(0x44, "media", media)
            body += ipp_attribute(0x44, "media-source", media_source)
    else:
        body += ipp_attribute(0x44, "media", media)
        if media_source:
            body += ipp_attribute(0x44, "media-source", media_source)
    if document_format == "image/pwg-raster":
        raster_type = str(config.get("pwg_raster_type") or "sgray_8").strip()
        resolution = int(config.get("raster_resolution") or 300)
        body += ipp_attribute(0x44, "pwg-raster-document-type", raster_type)
        body += ipp_resolution_attribute("printer-resolution", resolution, resolution)
    body += ipp_attribute(0x44, "sides", "one-sided")
    body += ipp_enum_attribute("orientation-requested", 3)  # 3 = portrait
    body += b"\x03"  # end-of-attributes-tag
    body += printer_ipp_document_bytes(config, report_path)
    return bytes(body)


def ipp_http_url(uri: str) -> str:
    parsed = urllib.parse.urlparse(uri)
    scheme = "https" if parsed.scheme == "ipps" else "http"
    host = parsed.hostname or DEFAULT_PRINTER_RAW_HOST
    port = parsed.port or 631
    netloc = f"{host}:{port}"
    path = parsed.path or "/ipp/print"
    return urllib.parse.urlunparse((scheme, netloc, path, "", "", ""))


def parse_ipp_attribute_values(response_body: bytes) -> dict[str, list[object]]:
    values: dict[str, list[object]] = {}
    index = 8
    last_name = ""
    while index < len(response_body):
        tag = response_body[index]
        index += 1
        if tag == 0x03:
            break
        if tag in {0x01, 0x02, 0x04, 0x05, 0x06, 0x07}:
            last_name = ""
            continue
        if index + 4 > len(response_body):
            break
        name_length = int.from_bytes(response_body[index : index + 2], "big")
        index += 2
        name = response_body[index : index + name_length].decode("utf-8", errors="replace")
        index += name_length
        value_length = int.from_bytes(response_body[index : index + 2], "big")
        index += 2
        raw_value = response_body[index : index + value_length]
        index += value_length
        if name:
            last_name = name
        else:
            name = last_name
        if not name:
            continue
        if tag in {0x21, 0x23} and len(raw_value) == 4:
            value: object = int.from_bytes(raw_value, "big", signed=True)
        elif tag == 0x22 and raw_value:
            value = bool(raw_value[0])
        else:
            value = raw_value.decode("utf-8", errors="replace")
        values.setdefault(name, []).append(value)
    return values


def build_ipp_get_printer_attributes_request(config: dict[str, object]) -> bytes:
    request_id = int(time.time()) & 0x7FFFFFFF
    uri = printer_uri(config)
    body = bytearray()
    body += b"\x02\x00"
    body += (0x000B).to_bytes(2, "big")  # Get-Printer-Attributes
    body += request_id.to_bytes(4, "big")
    body += b"\x01"
    body += ipp_attribute(0x47, "attributes-charset", "utf-8")
    body += ipp_attribute(0x48, "attributes-natural-language", "de")
    body += ipp_attribute(0x45, "printer-uri", uri)
    body += ipp_attribute(0x42, "requesting-user-name", "HardwareCheck")
    requested = [
        "printer-state",
        "printer-state-reasons",
        "printer-is-accepting-jobs",
        "printer-name",
        "printer-info",
        "printer-make-and-model",
        "document-format-supported",
    ]
    for index, value in enumerate(requested):
        body += ipp_attribute(0x44, "requested-attributes" if index == 0 else "", value)
    body += b"\x03"
    return bytes(body)


def check_direct_ipp_printer_ready(config: dict[str, object], debug_lines: list[str]) -> tuple[bool, str | None]:
    uri = printer_uri(config)
    url = ipp_http_url(uri)
    body = build_ipp_get_printer_attributes_request(config)
    request = urllib.request.Request(url, data=body, headers={"Content-Type": "application/ipp"}, method="POST")
    try:
        context = ssl._create_unverified_context() if url.startswith("https://") else None
        with urllib.request.urlopen(request, timeout=10, context=context) as response:
            response_body = response.read(16384)
    except (OSError, urllib.error.URLError) as exc:
        append_network_debug(debug_lines, f"Direkt-IPP Statuscheck nicht möglich: {exc}")
        return True, None
    if len(response_body) >= 4:
        ipp_status = int.from_bytes(response_body[2:4], "big")
        if ipp_status > 0x00FF:
            append_network_debug(debug_lines, f"Direkt-IPP Statuscheck IPP 0x{ipp_status:04X}")
            return True, None
    values = parse_ipp_attribute_values(response_body)
    state_values = [value for value in values.get("printer-state", []) if isinstance(value, int)]
    accepting_values = [value for value in values.get("printer-is-accepting-jobs", []) if isinstance(value, bool)]
    reasons = [
        str(value)
        for value in values.get("printer-state-reasons", [])
        if str(value).strip() and str(value).strip().lower() != "none"
    ]
    # A consumable-low signal is a warning, not a stopped printer.  Epson
    # devices in particular report marker-supply-low-warning while they still
    # accept and print IPP jobs.  Keep these warnings in the debug log, but do
    # not reject a report before the printer gets the chance to process it.
    soft_warning_reasons = [
        reason
        for reason in reasons
        if reason.strip().lower() in {"marker-supply-low-warning", "toner-low-warning", "media-low-warning"}
    ]
    blocking_reasons = [reason for reason in reasons if reason not in soft_warning_reasons]
    state = state_values[0] if state_values else 0
    accepting = accepting_values[0] if accepting_values else True
    append_network_debug(debug_lines, f"Direkt-IPP Status: state={state}, accepting={accepting}, reasons={', '.join(reasons) or '-'}")
    if soft_warning_reasons:
        append_network_debug(debug_lines, f"Direkt-IPP Druckwarnung wird nicht blockiert: {', '.join(soft_warning_reasons)}")
    if not accepting or state == 5 or blocking_reasons:
        detail_parts: list[str] = []
        if state == 5:
            detail_parts.append("angehalten")
        if not accepting:
            detail_parts.append("nimmt keine Jobs an")
        if blocking_reasons:
            detail_parts.append(", ".join(blocking_reasons))
        detail = "; ".join(detail_parts) or "unbekannter Druckerfehler"
        return False, f"Drucker nicht bereit: {detail}"
    return True, None


def send_report_direct_ipp(config: dict[str, object], report_path: pathlib.Path, debug_lines: list[str]) -> tuple[bool, str]:
    configs = [config]
    uri = printer_uri(config)
    if urllib.parse.urlparse(uri).scheme == "ipp":
        configs.append(printer_config_with_uri(config, printer_uri_with_scheme(uri, "ipps")))

    last_error = ""
    for index, candidate in enumerate(configs):
        candidate_uri = printer_uri(candidate)
        url = ipp_http_url(candidate_uri)
        body = build_ipp_print_job_request(candidate, report_path)
        ensure_printer_route(candidate, debug_lines)
        append_network_debug(debug_lines, f"Direkt-IPP: {url}")
        ready, not_ready_message = check_direct_ipp_printer_ready(candidate, debug_lines)
        if not ready:
            return False, not_ready_message or "Drucker nicht bereit"
        request = urllib.request.Request(url, data=body, headers={"Content-Type": "application/ipp"}, method="POST")
        try:
            context = ssl._create_unverified_context() if url.startswith("https://") else None
            with urllib.request.urlopen(request, timeout=25, context=context) as response:
                response_body = response.read(256)
                http_status = getattr(response, "status", 200)
        except (OSError, urllib.error.URLError) as exc:
            last_error = str(exc)
            if index + 1 < len(configs) and ipp_upgrade_required(exc):
                append_network_debug(debug_lines, "Direkt-IPP verlangt IPPS, versuche verschluesselt")
                continue
            return False, f"Direkt-IPP fehlgeschlagen: {exc}"
        if http_status < 200 or http_status >= 300:
            last_error = f"HTTP {http_status}"
            if index + 1 < len(configs) and http_status == 426:
                append_network_debug(debug_lines, "Direkt-IPP HTTP 426, versuche IPPS")
                continue
            return False, f"Direkt-IPP fehlgeschlagen: HTTP {http_status}"
        if len(response_body) >= 4:
            ipp_status = int.from_bytes(response_body[2:4], "big")
            if ipp_status > 0x00FF:
                return False, f"Direkt-IPP fehlgeschlagen: IPP Status 0x{ipp_status:04X}"
        return True, "Druckauftrag per Direkt-IPP gesendet"
    return False, f"Direkt-IPP fehlgeschlagen: {last_error or 'unbekannter Fehler'}"


def send_report_raw_socket(config: dict[str, object], report_path: pathlib.Path, debug_lines: list[str]) -> tuple[bool, str]:
    host, port = printer_raw_target(config)
    payload = printer_raw_payload(config, report_path)
    errors: list[str] = []
    for attempt in range(1, 4):
        ensure_printer_route(config, debug_lines)
        append_network_debug(debug_lines, f"RAW-Druck Versuch {attempt}: {host}:{port}")
        try:
            with socket.create_connection((host, port), timeout=25) as connection:
                connection.settimeout(45)
                connection.sendall(payload)
        except OSError as exc:
            errors.append(str(exc))
            append_network_debug(debug_lines, f"RAW-Druck Versuch {attempt} fehlgeschlagen: {exc}")
            time.sleep(2.0)
            continue
        return True, f"Druckauftrag per RAW {host}:{port} gesendet"
    detail = errors[-1] if errors else "unbekannter Fehler"
    return False, f"RAW-Druck fehlgeschlagen: {detail}"


def lpstat_queue_exists(printer_name: str) -> bool:
    lpstat = find_executable("lpstat")
    if not lpstat or not printer_name:
        return False
    try:
        result = subprocess.run(
            [lpstat, "-p", printer_name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=4,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def cups_running() -> bool:
    lpstat = find_executable("lpstat")
    if not lpstat:
        return False
    try:
        result = subprocess.run(
            [lpstat, "-r"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=4,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def ensure_cups_running(debug_lines: list[str]) -> bool:
    if cups_running():
        return True
    attempts = [
        ("systemctl", ["systemctl", "start", "cups"]),
        ("service", ["service", "cups", "start"]),
        ("cupsd", ["cupsd"]),
    ]
    for executable, command in attempts:
        if not find_executable(executable):
            continue
        append_network_debug(debug_lines, "Druckdienst starten: " + " ".join(command))
        run_quiet_timeout(command, timeout=8)
        time.sleep(0.8)
        if cups_running():
            return True
    return cups_running()


def ensure_printer_queue(config: dict[str, object], debug_lines: list[str]) -> tuple[bool, str]:
    printer_name = safe_printer_name(str(config.get("printer_name") or config.get("name") or "HardwareCheck_Epson"))
    if lpstat_queue_exists(printer_name):
        return True, printer_name
    lpadmin = find_executable("lpadmin")
    if not lpadmin:
        return False, "Drucker nicht eingerichtet und lpadmin fehlt"
    uri = printer_uri(config)
    if not uri:
        return False, "Drucker-URI fehlt"
    model = str(config.get("model") or config.get("driver") or "everywhere").strip() or "everywhere"
    command = [lpadmin, "-p", printer_name, "-E", "-v", uri, "-m", model]
    append_network_debug(debug_lines, "Drucker-Queue anlegen: " + " ".join(command))
    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"Drucker konnte nicht eingerichtet werden: {exc}"
    if result.returncode != 0:
        output = (result.stdout or "").strip().splitlines()
        detail = output[-1] if output else f"Exit {result.returncode}"
        return False, f"Drucker konnte nicht eingerichtet werden: {detail}"
    return True, printer_name


def report_print_source_path(report_path: pathlib.Path) -> pathlib.Path:
    """Prefer the concise TXT companion when a battery HTML report is selected."""
    if report_path.suffix.lower() in {".html", ".htm"}:
        text_report = report_path.with_suffix(".txt")
        if text_report.is_file():
            return text_report
    return report_path


def run_report_print(report_path: pathlib.Path, status_callback=None) -> tuple[bool, str]:
    debug_lines: list[str] = []

    def notify(state: str, message: str) -> None:
        append_network_debug(debug_lines, f"Druck {state}: {message}")
        if status_callback is not None:
            status_callback(state, message)

    def complete(ok: bool, message: str) -> tuple[bool, str]:
        write_printer_debug(ok, message, debug_lines)
        return ok, message

    if sys.platform != "linux":
        return complete(False, "Drucken nur unter Linux verfuegbar")
    if not report_path or not report_path.is_file():
        return complete(False, "Bericht nicht gefunden")
    print_path = report_print_source_path(report_path)
    if print_path != report_path:
        append_network_debug(debug_lines, f"Druckquelle: {report_path.name} -> {print_path.name}")
    config, config_path = load_printer_config()
    if not config or not printer_config_bool(config, "enabled", True):
        return complete(False, f"Drucker-Konfiguration fehlt ({config_path})")

    cleanup = lambda: None
    skip_auto_refresh = printer_manual_selection_recent(config)
    printer_reachable, reach_message = printer_target_reachable(config, debug_lines)
    if printer_reachable:
        notify("online", reach_message)
    elif printer_config_bool(config, "connect_wifi", True):
        network = printer_wifi_network(config)
        if network:
            notify("searching", f"verbinde Drucker-WLAN {network['ssid']}")
            ok, message, cleanup = connect_temporary_network(
                notify,
                debug_lines,
                networks_override=[network],
                require_internet=False,
                allow_active=True,
                allow_lan=False,
                cleanup_success=False,
            )
            if not ok:
                cleanup()
                return complete(False, f"Drucker-WLAN: {message}")
            notify("online", message)
        else:
            notify("searching", reach_message)
        printer_reachable, reach_message = printer_target_reachable(config, debug_lines)
        notify("online" if printer_reachable else "searching", reach_message)
    else:
        printer_reachable, reach_message = printer_target_reachable(config, debug_lines)
        if printer_reachable:
            notify("online", reach_message)
        else:
            local_message = active_local_network_message()
            if local_message:
                notify("online", local_message)
            else:
                notify("searching", "verbinde gespeichertes WLAN")
                ok, message, cleanup = connect_temporary_network(
                    notify,
                    debug_lines,
                    require_internet=False,
                    allow_active=True,
                    allow_lan=True,
                    cleanup_success=False,
                )
                if not ok:
                    cleanup()
                    return complete(False, f"Drucker-WLAN: {message}")

    if not printer_reachable:
        printer_reachable, reach_message = printer_target_reachable(config, debug_lines)
        notify("online" if printer_reachable else "searching", reach_message)
        if not printer_reachable:
            if skip_auto_refresh:
                notify("searching", "manuell gewaehlter Drucker nicht erreichbar - automatische Suche uebersprungen")
                return complete(False, f"{reach_message} | Manuelle Auswahl: automatische Druckersuche uebersprungen")
            refreshed_config, refreshed, refresh_message = refresh_printer_endpoint_if_needed(config, debug_lines, notify)
            if refreshed:
                config = refreshed_config
                printer_reachable = True
                notify("online", refresh_message)
            else:
                notify("searching", refresh_message)
                return complete(False, f"{reach_message} | {refresh_message}")

    try:
        errors: list[str] = []
        lp = find_executable("lp")
        if printer_config_bool(config, "use_cups", True) and lp:
            notify("searching", "starte Druckdienst")
            if ensure_cups_running(debug_lines):
                ok, printer_name_or_error = ensure_printer_queue(config, debug_lines)
                if ok:
                    printer_name = printer_name_or_error
                    notify("searching", f"drucke auf {printer_name}")
                    media_value = str(config.get("media") or config.get("paper") or "iso_a4_210x297mm").strip()
                    cups_media = "A4" if "a4" in media_value.lower() else media_value
                    args = [
                        lp,
                        "-d",
                        printer_name,
                        "-o",
                        f"media={cups_media}",
                        "-o",
                        f"PageSize={cups_media}",
                        "-o",
                        "fit-to-page",
                        str(print_path),
                    ]
                    try:
                        result = subprocess.run(
                            args,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                            text=True,
                            encoding="utf-8",
                            errors="ignore",
                            timeout=30,
                            check=False,
                        )
                    except (OSError, subprocess.TimeoutExpired) as exc:
                        errors.append(f"CUPS: {exc}")
                    else:
                        output = (result.stdout or "").strip()
                        append_network_debug(debug_lines, "lp Ausgabe: " + output)
                        if result.returncode == 0:
                            return complete(True, f"Druckauftrag per CUPS gesendet: {printer_name}")
                        detail = output.splitlines()[-1] if output else f"Exit {result.returncode}"
                        errors.append(f"CUPS: {detail}")
                else:
                    errors.append(f"CUPS: {printer_name_or_error}")
            else:
                errors.append("CUPS: Druckdienst läuft nicht")
        elif printer_config_bool(config, "use_cups", True):
            errors.append("CUPS: lp nicht gefunden")

        if printer_config_bool(config, "direct_ipp_fallback", True):
            notify("searching", "drucke per Direkt-IPP")
            ok, message = send_report_direct_ipp(config, print_path, debug_lines)
            if ok:
                return complete(True, message)
            errors.append(message)

        if printer_config_bool(config, "raw_socket_fallback", True):
            notify("searching", "drucke per RAW-Port")
            ok, message = send_report_raw_socket(config, print_path, debug_lines)
            if ok:
                return complete(True, message)
            errors.append(message)

        return complete(False, " | ".join(errors[-3:]) if errors else "Druck fehlgeschlagen")
    finally:
        if printer_config_bool(config, "disconnect_after_print", True):
            cleanup()


def backup_current_model(model_path: pathlib.Path, version: str) -> None:
    if not model_path.is_file():
        return
    backup_dir = get_model_backup_dir()
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    safe_version = sanitize_filename(version or "unknown")
    target = backup_dir / f"model_{stamp}_{safe_version}.json"
    try:
        shutil.copy2(model_path, target)
    except OSError:
        return
    backups = sorted(backup_dir.glob("model_*.json"), key=lambda path: path.stat().st_mtime, reverse=True)
    for old in backups[3:]:
        try:
            old.unlink()
        except OSError:
            pass


def _synchronize_time_before_updates() -> tuple[bool, str]:
    """Called from update workers; a failed time check never blocks offline use."""
    try:
        import magic_image_manager
        return magic_image_manager.synchronize_live_time()
    except Exception as exc:
        return False, f"Zeitabgleich nicht verfügbar: {exc}"


def run_model_database_update(status_callback=None, progress_callback=None) -> tuple[bool, str]:
    _synchronize_time_before_updates()
    settings = load_settings()
    token = str(settings.get("github_token") or "").strip()
    manifest_url = str(settings.get("model_manifest_url") or DEFAULT_MODEL_MANIFEST_URL).strip()
    database_url_default = str(settings.get("model_database_url") or DEFAULT_MODEL_DATABASE_URL).strip()
    debug_lines: list[str] = []

    last_progress = 0

    def report_progress(percent: int, message: str) -> None:
        nonlocal last_progress
        last_progress = max(last_progress, max(0, min(100, int(percent))))
        if progress_callback is not None:
            progress_callback(last_progress, message)

    def complete(ok: bool, message: str) -> tuple[bool, str]:
        report_progress(100 if ok else last_progress, message)
        write_network_update_debug(ok, message, debug_lines)
        return ok, message

    report_progress(2, "Netzwerk wird vorbereitet ...")
    connected, network_message, cleanup = connect_temporary_network(status_callback, debug_lines)
    if not connected:
        message = f"DB-Update: {network_message}"
        write_network_update_debug(False, message, debug_lines)
        cleanup()
        return False, message

    try:
        report_progress(8, "Verbindung steht - Systemzeit wird geprüft ...")
        sync_system_time_from_network(debug_lines, status_callback)
        if status_callback is not None:
            status_callback("online", "lade Manifest")
        report_progress(12, "DB-Manifest wird geladen ...")
        remote_manifest_raw = download_json(manifest_url, token=token)
        if not isinstance(remote_manifest_raw, dict):
            return complete(False, "DB-Update: Manifest ungültig")
        remote_manifest: dict[str, object] = remote_manifest_raw
        local_manifest = load_local_model_manifest()
        remote_version = manifest_value(remote_manifest, "version", "db_version", "database_version")
        local_version = manifest_value(local_manifest, "version", "db_version", "database_version")
        remote_sha = manifest_value(remote_manifest, "sha256", "model_sha256", "database_sha256")
        database_url = manifest_value(remote_manifest, "database_url", "model_url", "raw_database_url") or database_url_default
        model_path = get_models_path()
        current_sha = readable_file_sha256(model_path)
        writable_target = writable_model_path(model_path)
        manifest_target = get_writable_model_manifest_local_path(writable_target)
        if not path_is_writable_directory(writable_target.parent) or manifest_target is None:
            return complete(
                False,
                "DB-Update: kein beschreibbarer HardwareCheck-Ordner gefunden (Stick unter Windows reparieren oder neu erstellen)",
            )
        if remote_sha and current_sha.lower() == remote_sha.lower() and not version_is_newer(remote_version, local_version):
            write_json_atomic(manifest_target, remote_manifest)
            return complete(True, f"DB-Update: aktuell ({remote_version or 'ok'})")
        if remote_version and local_version and not version_is_newer(remote_version, local_version) and not remote_sha:
            return complete(True, f"DB-Update: aktuell ({remote_version})")

        report_progress(20, "Modelldatenbank wird geladen ...")
        if status_callback is not None:
            status_callback("online", "lade model.json")
        def download_progress(downloaded: int, total: int) -> None:
            if total > 0:
                percent = 20 + int(min(downloaded, total) * 55 / total)
            else:
                percent = 35 if downloaded else 20
            report_progress(percent, "Modelldatenbank wird geladen ...")

        payload = download_bytes(database_url, token=token, progress_callback=download_progress)
        report_progress(78, "Prüfsumme wird kontrolliert ...")
        if remote_sha:
            payload_sha = hashlib.sha256(payload).hexdigest()
            if payload_sha.lower() != remote_sha.lower():
                return complete(False, "DB-Update: SHA256 passt nicht")
        report_progress(84, "Modelldatenbank wird geprüft ...")
        try:
            database = json.loads(payload.decode("utf-8-sig"))
        except json.JSONDecodeError:
            return complete(False, "DB-Update: model.json ist ungültig")
        if not isinstance(database, list) or not all(isinstance(item, dict) for item in database):
            return complete(False, "DB-Update: model.json ist keine Modell-Liste")

        report_progress(90, "Vorhandene Datenbank wird gesichert ...")
        backup_current_model(model_path if model_path.is_file() else writable_target, local_version or "old")
        report_progress(95, "Neue Modelldatenbank wird installiert ...")
        write_bytes_atomic(writable_target, payload)
        write_json_atomic(manifest_target, remote_manifest)
        return complete(True, f"DB-Update: {len(database)} Modelle geladen ({remote_version or 'GitHub'})")
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, socket.gaierror):
            return complete(False, "DB-Update: DNS-Aufloesung fehlgeschlagen")
        if isinstance(reason, TimeoutError):
            return complete(False, "DB-Update: Verbindung zu GitHub dauert zu lange")
        if is_certificate_time_error(exc):
            return complete(False, "DB-Update: Uhrzeit/Zertifikat falsch")
        return complete(False, f"DB-Update: GitHub nicht erreichbar ({reason})")
    except TimeoutError:
        return complete(False, "DB-Update: Verbindung zu GitHub dauert zu lange")
    except OSError as exc:
        return complete(False, f"DB-Update: Netzwerk/Datei-Fehler ({exc})")
    except json.JSONDecodeError:
        return complete(False, "DB-Update: Antwort von GitHub ungültig")
    finally:
        cleanup()


def check_model_database_update_available(status_callback=None) -> tuple[bool, str, bool]:
    _synchronize_time_before_updates()
    settings = load_settings()
    token = str(settings.get("github_token") or "").strip()
    manifest_url = str(settings.get("model_manifest_url") or DEFAULT_MODEL_MANIFEST_URL).strip()
    debug_lines: list[str] = []

    def complete(ok: bool, message: str, available: bool = False) -> tuple[bool, str, bool]:
        write_network_update_debug(ok, message, debug_lines)
        return ok, message, available

    connected, network_message, cleanup = connect_temporary_network(status_callback, debug_lines)
    if not connected:
        message = f"Auto-Check DB: {network_message}"
        write_network_update_debug(False, message, debug_lines)
        cleanup()
        return False, message, False

    try:
        sync_system_time_from_network(debug_lines, status_callback)
        if status_callback is not None:
            status_callback("online", "pruefe DB")
        remote_manifest_raw = download_json(manifest_url, token=token)
        if not isinstance(remote_manifest_raw, dict):
            return complete(False, "Auto-Check DB: Manifest ungültig")
        remote_manifest: dict[str, object] = remote_manifest_raw
        local_manifest = load_local_model_manifest()
        remote_version = manifest_value(remote_manifest, "version", "db_version", "database_version")
        local_version = manifest_value(local_manifest, "version", "db_version", "database_version")
        remote_sha = manifest_value(remote_manifest, "sha256", "model_sha256", "database_sha256")
        model_path = get_models_path()
        current_sha = readable_file_sha256(model_path)
        if remote_sha and current_sha.lower() != remote_sha.lower():
            return complete(True, f"DB-Update verfuegbar: {remote_version or 'GitHub'}", True)
        if remote_version and local_version and version_is_newer(remote_version, local_version):
            return complete(True, f"DB-Update verfuegbar: {remote_version}", True)
        return complete(True, f"DB aktuell: {remote_version or local_version or 'ok'}")
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, socket.gaierror):
            return complete(False, "Auto-Check DB: DNS-Aufloesung fehlgeschlagen")
        if is_certificate_time_error(exc):
            return complete(False, "Auto-Check DB: Uhrzeit/Zertifikat falsch")
        return complete(False, f"Auto-Check DB: GitHub nicht erreichbar ({reason})")
    except (TimeoutError, OSError) as exc:
        return complete(False, f"Auto-Check DB: Netzwerk/Datei-Fehler ({exc})")
    except json.JSONDecodeError:
        return complete(False, "Auto-Check DB: Antwort von GitHub ungültig")
    finally:
        cleanup()


def check_hardwarecheck_update_available(status_callback=None) -> tuple[bool, str, bool]:
    _synchronize_time_before_updates()
    settings = load_settings()
    token = str(settings.get("github_token") or "").strip()
    manifest_url = str(
        settings.get("hardwarecheck_update_manifest_url") or DEFAULT_HARDWARECHECK_UPDATE_MANIFEST_URL
    ).strip()
    debug_lines: list[str] = []

    def complete(ok: bool, message: str, available: bool = False) -> tuple[bool, str, bool]:
        write_network_update_debug(ok, message, debug_lines)
        return ok, message, available

    connected, network_message, cleanup = connect_temporary_network(status_callback, debug_lines)
    if not connected:
        message = f"Auto-Check Programm: {network_message}"
        write_network_update_debug(False, message, debug_lines)
        cleanup()
        return False, message, False

    try:
        sync_system_time_from_network(debug_lines, status_callback)
        if status_callback is not None:
            status_callback("online", "pruefe Programm")
        raw_manifest = download_json(manifest_url, token=token)
        if not isinstance(raw_manifest, dict):
            return complete(False, "Auto-Check Programm: Manifest ungültig")
        app_name = manifest_value(raw_manifest, "app", "name", "product")
        if app_name and app_name.lower() != "hardwarecheck":
            return complete(False, f"Auto-Check Programm: falsches Paket ({app_name})")
        remote_version = manifest_value(raw_manifest, "version", "app_version")
        if not remote_version:
            return complete(False, "Auto-Check Programm: Version fehlt")
        if version_is_newer(remote_version, normalized_app_version()):
            return complete(True, f"Programm-Update verfuegbar: {remote_version}", True)
        return complete(True, f"Programm aktuell: {APP_VERSION}")
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, socket.gaierror):
            return complete(False, "Auto-Check Programm: DNS-Aufloesung fehlgeschlagen")
        if is_certificate_time_error(exc):
            return complete(False, "Auto-Check Programm: Uhrzeit/Zertifikat falsch")
        return complete(False, f"Auto-Check Programm: GitHub nicht erreichbar ({reason})")
    except (TimeoutError, OSError) as exc:
        return complete(False, f"Auto-Check Programm: Netzwerk/Datei-Fehler ({exc})")
    except json.JSONDecodeError:
        return complete(False, "Auto-Check Programm: Antwort von GitHub ungültig")
    finally:
        cleanup()


def run_hardwarecheck_update_check(status_callback=None, progress_callback=None) -> tuple[bool, str, dict[str, str] | None]:
    _synchronize_time_before_updates()
    settings = load_settings()
    token = str(settings.get("github_token") or "").strip()
    manifest_url = str(
        settings.get("hardwarecheck_update_manifest_url") or DEFAULT_HARDWARECHECK_UPDATE_MANIFEST_URL
    ).strip()
    debug_lines: list[str] = []

    last_progress = 0

    def report_progress(percent: int, message: str) -> None:
        nonlocal last_progress
        last_progress = max(last_progress, max(0, min(100, int(percent))))
        if progress_callback is not None:
            progress_callback(last_progress, message)

    def complete(ok: bool, message: str, install_request: dict[str, str] | None = None) -> tuple[bool, str, dict[str, str] | None]:
        report_progress(100 if ok else last_progress, message)
        write_network_update_debug(ok, message, debug_lines)
        return ok, message, install_request

    report_progress(2, "Netzwerk wird vorbereitet ...")
    connected, network_message, cleanup = connect_temporary_network(status_callback, debug_lines)
    if not connected:
        message = f"Programm-Update: {network_message}"
        write_network_update_debug(False, message, debug_lines)
        cleanup()
        return False, message, None

    try:
        report_progress(8, "Verbindung steht - Systemzeit wird geprüft ...")
        sync_system_time_from_network(debug_lines, status_callback)
        if status_callback is not None:
            status_callback("online", "lade Programm-Manifest")
        report_progress(12, "Programm-Manifest wird geladen ...")
        raw_manifest = download_json(manifest_url, token=token)
        if not isinstance(raw_manifest, dict):
            return complete(False, "Programm-Update: Manifest ungültig")
        app_name = manifest_value(raw_manifest, "app", "name", "product")
        if app_name and app_name.lower() != "hardwarecheck":
            return complete(False, f"Programm-Update: falsches Paket ({app_name})")
        remote_version = manifest_value(raw_manifest, "version", "app_version")
        download_url = manifest_value(raw_manifest, "download_url", "url")
        remote_sha = manifest_value(raw_manifest, "sha256")
        if not remote_version:
            return complete(False, "Programm-Update: Version fehlt")
        if not download_url:
            return complete(False, "Programm-Update: Download-URL fehlt")
        if not remote_sha:
            return complete(False, "Programm-Update: SHA256 fehlt")
        local_version = normalized_app_version()
        if version_is_newer(remote_version, local_version):
            report_progress(20, "Programm-Paket wird geladen ...")
            if status_callback is not None:
                status_callback("online", "lade Programm-ZIP")
            def download_progress(downloaded: int, total: int) -> None:
                if total > 0:
                    percent = 20 + int(min(downloaded, total) * 50 / total)
                else:
                    percent = 35 if downloaded else 20
                report_progress(percent, "Programm-Paket wird geladen ...")

            payload = download_bytes(download_url, token=token, progress_callback=download_progress)
            report_progress(74, "Prüfsumme wird kontrolliert ...")
            payload_sha = hashlib.sha256(payload).hexdigest()
            if payload_sha.lower() != remote_sha.lower():
                return complete(False, "Programm-Update: SHA256 passt nicht")
            download_dir = get_update_download_dir()
            download_dir.mkdir(parents=True, exist_ok=True)
            safe_version = sanitize_filename(remote_version)
            fallback_name = f"HardwareCheck_update_{safe_version}.zip"
            target = download_dir / filename_from_url(download_url, fallback_name)
            report_progress(80, "Programm-Paket wird gespeichert ...")
            write_bytes_atomic(target, payload)
            if status_callback is not None:
                status_callback("online", "pruefe Programm-ZIP")
            staging_root = get_update_staging_dir()
            staging_dir = staging_root / safe_version
            if staging_dir.exists():
                shutil.rmtree(staging_dir, ignore_errors=True)
            staging_dir.mkdir(parents=True, exist_ok=True)
            try:
                report_progress(86, "Programm-Paket wird entpackt ...")
                safe_extract_zip(target, staging_dir)
            except (OSError, ValueError, zipfile.BadZipFile):
                return complete(False, "Programm-Update: ZIP ungültig")
            report_progress(94, "Programm-Paket wird geprüft ...")
            package_ok, package_message = validate_hardwarecheck_update_package(staging_dir)
            if not package_ok:
                return complete(False, f"Programm-Update: {package_message}")
            report_progress(98, "Installation wird vorbereitet ...")
            install_request = write_hardwarecheck_update_installer(staging_dir, remote_version)
            return complete(
                True,
                f"Programm-Update bereit: {remote_version} | {package_message}",
                install_request,
            )
        return complete(True, f"Programm-Update: aktuell ({APP_VERSION})")
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", exc)
        if isinstance(reason, socket.gaierror):
            return complete(False, "Programm-Update: DNS-Aufloesung fehlgeschlagen")
        if isinstance(reason, TimeoutError):
            return complete(False, "Programm-Update: Verbindung zu GitHub dauert zu lange")
        if is_certificate_time_error(exc):
            return complete(False, "Programm-Update: Uhrzeit/Zertifikat falsch")
        return complete(False, f"Programm-Update: GitHub nicht erreichbar ({reason})")
    except TimeoutError:
        return complete(False, "Programm-Update: Verbindung zu GitHub dauert zu lange")
    except OSError as exc:
        return complete(False, f"Programm-Update: Netzwerk/Datei-Fehler ({exc})")
    except json.JSONDecodeError:
        return complete(False, "Programm-Update: Antwort von GitHub ungültig")
    finally:
        cleanup()


def load_language_index() -> int:
    language = str(load_settings().get("language") or "DE").upper()
    return LANGUAGES.index(language) if language in LANGUAGES else 0


def save_language(language: str) -> None:
    settings = load_settings()
    settings["language"] = language
    save_settings(settings)


def language_flag_pixels(language: str, width: int, height: int) -> list[list[str]]:
    """Return a small dependency-free flag image as a Tk-compatible color matrix."""
    width = max(12, int(width))
    height = max(8, int(height))
    language = str(language or "DE").upper()
    border = "#8fa3b8"
    rows: list[list[str]] = []
    for y in range(height):
        row: list[str] = []
        for x in range(width):
            if x in {0, width - 1} or y in {0, height - 1}:
                row.append(border)
                continue

            nx = (x - 1) / max(1, width - 3)
            ny = (y - 1) / max(1, height - 3)
            if language == "CZ":
                color = "#f7f7f7" if ny < 0.5 else "#d7141a"
                triangle_edge = 0.5 * (1.0 - abs(2.0 * ny - 1.0))
                if nx <= triangle_edge:
                    color = "#11457e"
            elif language == "EN":
                color = "#21468b"
                on_diagonal = abs(ny - nx) <= 0.13 or abs(ny - (1.0 - nx)) <= 0.13
                on_red_diagonal = abs(ny - nx) <= 0.055 or abs(ny - (1.0 - nx)) <= 0.055
                if on_diagonal:
                    color = "#f7f7f7"
                if on_red_diagonal:
                    color = "#cf142b"
                if abs(nx - 0.5) <= 0.13 or abs(ny - 0.5) <= 0.20:
                    color = "#f7f7f7"
                if abs(nx - 0.5) <= 0.065 or abs(ny - 0.5) <= 0.10:
                    color = "#cf142b"
            else:
                if ny < 1.0 / 3.0:
                    color = "#151515"
                elif ny < 2.0 / 3.0:
                    color = "#dd1e2f"
                else:
                    color = "#f5ca28"
            row.append(color)
        rows.append(row)
    return rows


def get_input_summary() -> str:
    input_root = pathlib.Path("/dev/input")
    events = sorted(input_root.glob("event*")) if input_root.exists() else []
    names = []
    for name_file in sorted(pathlib.Path("/sys/class/input").glob("event*/device/name")):
        name = read_text(name_file)
        if name:
            names.append(name[:24])
    if not events:
        return "Input: 0 events"
    suffix = ", ".join(names[:2])
    if len(names) > 2:
        suffix += f" +{len(names) - 2}"
    return f"Input: {len(events)} events" + (f" ({suffix})" if suffix else "")


def to_int(value: str) -> int | None:
    match = re.search(r"(\d+)", value or "")
    return int(match.group(1)) if match else None


def normalize_generic_token(value: str) -> str:
    return re.sub(r"\s+", "", (value or "").lower().replace("gb", ""))


PRODUCT_NUMBER_RE = re.compile(
    r"\b(?=[a-z0-9#-]{5,}\b)(?=[a-z0-9#-]*\d)(?=[a-z0-9#-]*[a-z])[a-z0-9]+(?:#[a-z0-9]+)?\b",
    re.IGNORECASE,
)


def product_number_variants(value: object) -> list[str]:
    raw_text = str(value or "").casefold()
    text = raw_text.replace("-", "").replace("_", " ")
    values: list[str] = []

    def add(candidate: str) -> None:
        candidate = re.sub(r"[^a-z0-9#]", "", candidate.strip().strip("#"))
        if len(candidate) >= 5 and candidate not in values:
            values.append(candidate)

    for pattern in (
        r"\bv\s*\d{2}\s*g\s*\d{1,2}(?:\s*[a-z]{2,4})?\b",
        r"\b(?:mt|bu|fm)\s*v\s*\d{2}\s*g\s*\d{1,2}(?:\s*[a-z]{2,4})?\b",
    ):
        for match in re.findall(pattern, text, flags=re.IGNORECASE):
            add(match)

    for match in PRODUCT_NUMBER_RE.findall(text):
        candidate = match.strip("#")
        add(candidate)
        if "#" in candidate:
            add(candidate.split("#", 1)[0])

    return values


def row_product_numbers(row: dict[str, object]) -> list[str]:
    values: list[str] = []
    sources = (
        row.get("product_number", ""),
        row.get("product_number_2", ""),
        row.get("product_no", ""),
        row.get("note", ""),
    )
    for source in sources:
        for candidate in product_number_variants(source):
            if candidate not in values:
                values.append(candidate)
    return values


def snapshot_product_numbers(snapshot: dict[str, object]) -> list[str]:
    values: list[str] = []
    sources = (
        snapshot.get("product_no", ""),
        snapshot.get("model_name", ""),
        snapshot.get("product_version", ""),
    )
    for source in sources:
        for candidate in product_number_variants(source):
            if candidate not in values:
                values.append(candidate)
    return values


def product_number_matches(snapshot: dict[str, object], item: dict[str, object]) -> bool:
    hw_product_numbers = set(snapshot_product_numbers(snapshot))
    db_product_numbers = set(row_product_numbers(item))
    return bool(hw_product_numbers and db_product_numbers and hw_product_numbers.intersection(db_product_numbers))


def normalize_cpu_token(value: str) -> str:
    raw = (value or "").lower()
    patterns = [
        r"n\d{4}",
        r"n\d{3}",
        r"core\s+ultra\s+[3579]\s+\d{3,4}[a-z0-9-]*",
        r"core\s+[3579]\s+\d{3,4}[a-z0-9-]*",
        r"i[3579][- ]?\d{4,5}[a-z0-9-]*",
        r"ryzen\s+[3579]\s+\d{4}[a-z0-9]*",
        r"athlon\s+(?:gold|silver)\s+\d{4}u",
        r"athlon\s+\d{4}u",
        r"u300",
        r"7220u",
        r"7520u",
        r"5825u",
        r"7730u",
        r"5300u",
        r"5625u",
        r"7530u",
        r"n100",
        r"n200",
        r"n305",
    ]
    for pattern in patterns:
        match = re.search(pattern, raw)
        if match:
            value = re.sub(r"\b(?:gold|silver)\b", "", match.group(0), flags=re.IGNORECASE)
            return re.sub(r"[^a-z0-9]", "", value)
    return re.sub(r"[^a-z0-9]", "", raw)


def vendor_short(value: str) -> str:
    lowered = (value or "").lower()
    known = {
        "lenovo": "Lenovo",
        "hewlett": "HP",
        "hp": "HP",
        "asus": "Asus",
        "acer": "Acer",
        "dell": "Dell",
    }
    for key, label in known.items():
        if key in lowered:
            return label
    return value.strip() or "Unbekannt"


def get_cpu_short(full_cpu: str) -> str:
    patterns = [
        r"N\d{3,4}",
        r"(?:Intel\s+)?Core\s+Ultra\s+[3579]\s+\d{3,4}[A-Z0-9-]*",
        r"(?:Intel\s+)?Core\s+[3579]\s+\d{3,4}[A-Z0-9-]*",
        r"i[3579]-\d{4,5}[A-Z0-9-]*",
        r"i[3579]\s+\d{4,5}[A-Z0-9-]*",
        r"Ryzen\s+[3579]\s+\d{4}[A-Z0-9]*",
        r"Athlon\s+(?:Gold|Silver)\s+\d{4}U",
        r"Athlon\s+\d{4}U",
    ]
    for pattern in patterns:
        match = re.search(pattern, full_cpu or "", flags=re.IGNORECASE)
        if match:
            value = re.sub(r"^Intel\s+", "", match.group(0), flags=re.IGNORECASE)
            return re.sub(r"\s+", " ", value).strip()
    return " ".join((full_cpu or "").split()[:2]).strip() or full_cpu or "Unknown CPU"


def report_basename(snapshot: dict[str, object]) -> str:
    vendor = str(snapshot.get("vendor_short") or snapshot.get("vendor") or "Unknown").strip()
    cpu = str(snapshot.get("cpu_short") or get_cpu_short(str(snapshot.get("cpu") or ""))).strip()
    cpu = re.sub(r"^Intel\s+", "", cpu, flags=re.IGNORECASE)
    cpu = re.sub(r"\bi([3579])[-\s]+(\d{4,5}[A-Z0-9-]*)\b", r"i\1 \2", cpu, flags=re.IGNORECASE)
    return sanitize_filename(f"{vendor} {cpu}".strip())


def storage_family(value: str) -> str:
    token = normalize_generic_token(value)
    if "m.2sata" in token or "m2sata" in token or "ngff" in token:
        return "ssd"
    if "nvme" in token or token == "ssd":
        return "ssd"
    if "ssd" in token:
        return "ssd"
    if "hdd" in token:
        return "hdd"
    if "emmc" in token:
        return "emmc"
    return token


def clean_storage_model(model: object, vendor: object = "") -> str:
    text = re.sub(r"\s+", " ", str(model or "")).strip()
    vendor_text = re.sub(r"\s+", " ", str(vendor or "")).strip()
    if not text:
        return vendor_text

    generic_vendors = {"ata", "nvme", "usb", "scsi", "sata"}
    if vendor_text and vendor_text.lower() not in generic_vendors:
        if vendor_text.lower() not in text.lower():
            text = f"{vendor_text} {text}".strip()

    replacements = [
        (r"^SMI\s+", "Silicon Motion SMI "),
        (r"^WDC\s+", "Western Digital WDC "),
        (r"^WD\s+", "Western Digital WD "),
        (r"^SKHYNIX\s+", "SK hynix "),
        (r"^KBG", "Kioxia KBG"),
        (r"^ST(?=\d)", "Seagate ST"),
    ]
    for pattern, replacement in replacements:
        if re.search(pattern, text, flags=re.IGNORECASE):
            text = re.sub(pattern, replacement, text, count=1, flags=re.IGNORECASE)
            break
    if re.search(r"SSD_M\.2_512GB_In", text, flags=re.IGNORECASE):
        text = "Innovation IT 512GB SSD"
    text = text.replace("_", " ")
    return re.sub(r"\s+", " ", text).strip()


def same_or_empty(left: str, right: str) -> bool:
    if not left or not right:
        return True
    return normalize_generic_token(left) == normalize_generic_token(right)


def normalize_ram_layout_token(value: str) -> str:
    text = normalize_generic_token(value)
    parts: list[int] = []
    for count_text, size_text in re.findall(r"(\d+)x(\d+)", text):
        count = int(count_text)
        size = int(size_text)
        parts.extend([size] * max(0, min(count, 8)))
    if not parts:
        parts = [int(number) for number in re.findall(r"\d+", text)]
    return "+".join(str(size) for size in sorted(parts))


def same_ram_layout_or_empty(left: str, right: str) -> bool:
    if not left or not right:
        return True
    left_token = normalize_ram_layout_token(left)
    right_token = normalize_ram_layout_token(right)
    return bool(left_token and right_token and left_token == right_token)


def normalize_optical_drive(value: str) -> str:
    token = normalize_generic_token(value)
    if token in {"", "0", "none", "no", "notavailable", "n/a", "na", "kein", "keins", "ohne"}:
        return ""
    return token


def compare_inches(left: float | None, right: float | None) -> bool:
    if left is None or right is None:
        return False
    return abs(left - right) <= 0.25


def guess_ram_type_by_speed(max_mhz: int | None) -> str:
    if not max_mhz:
        return ""
    if max_mhz >= 6000:
        return "LPDDR5"
    if max_mhz >= 4800:
        return "DDR5"
    if max_mhz >= 3733:
        return "LPDDR4"
    if max_mhz >= 2666:
        return "DDR4"
    if max_mhz >= 1600:
        return "DDR3"
    return ""


def detect_display_type(resolution: str, oled: bool = False) -> str:
    width = to_int((resolution or "").split("x", 1)[0])
    base = ""
    if width:
        if width >= 3840:
            base = "4K"
        elif width >= 2560:
            base = "QHD"
        elif width >= 1920:
            base = "Full HD"
        elif width >= 1600:
            base = "HD+"
        elif width >= 1280:
            base = "HD"
    if oled and base:
        return f"{base} OLED"
    return base


def is_fallback_resolution(resolution: str) -> bool:
    parts = (resolution or "").strip().split()
    return bool(parts) and parts[0] in {"1024x768", "800x600", "640x480"}


def parse_resolution(value: str) -> tuple[int, int] | None:
    match = re.search(r"\b(\d{3,5})x(\d{3,5})\b", value or "")
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def xrandr_output_name(xrandr_text: str) -> str:
    for line in xrandr_text.splitlines():
        if " connected" in line:
            return line.split()[0]
    for line in xrandr_text.splitlines():
        if line.startswith(("default ", "None-")):
            return line.split()[0]
    return ""


def try_apply_native_xrandr_mode(snapshot: dict[str, object]) -> bool:
    expected = str(snapshot.get("resolution") or "")
    xorg_resolution = str(snapshot.get("xorg_resolution") or snapshot.get("resolution") or "")
    if not expected or expected == xorg_resolution:
        return False
    if not parse_resolution(expected) or expected not in XRANDR_MODELINES:
        return False

    xrandr_text = run_command("xrandr")
    output = xrandr_output_name(xrandr_text)
    if not output:
        return False

    mode = expected
    if re.search(rf"^\s+{re.escape(expected)}\s", xrandr_text, flags=re.MULTILINE):
        return run_quiet("xrandr", "--output", output, "--mode", mode)

    modeline = XRANDR_MODELINES[expected]
    mode = modeline[0]
    if mode not in xrandr_text:
        run_quiet("xrandr", "--newmode", *modeline)
    run_quiet("xrandr", "--addmode", output, mode)
    return run_quiet("xrandr", "--output", output, "--mode", mode)


def display_inches_number(value: object) -> float | None:
    if isinstance(value, (float, int)):
        return float(value)
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None


def normalize_display_type_for_size(display_type: str, inches: object) -> str:
    diagonal = display_inches_number(inches)
    if normalize_generic_token(display_type) == "hd" and diagonal is not None and diagonal >= 17.0:
        return "HD+"
    return display_type


def expected_resolution_from_display_type(display_type: str, inches: object = None) -> str:
    token = normalize_generic_token(display_type)
    if "4k" in token or "uhd" in token:
        return "3840x2160"
    if "qhd" in token or "wqhd" in token:
        return "2560x1440"
    if "fullhd" in token or token == "fhd":
        return "1920x1080"
    if "hd++" in display_type.lower() or "hdplusplus" in token:
        return "1600x900"
    if "hd+" in display_type.lower() or "hdplus" in token:
        return "1600x900"
    if token == "hd":
        diagonal = display_inches_number(inches)
        if diagonal is not None and diagonal >= 17.0:
            return "1600x900"
        return "1366x768"
    return ""


def nearest_disk_size_gb(size_bytes: int | None) -> int | None:
    if not size_bytes:
        return None
    value = size_bytes / 1_000_000_000
    return min(COMMON_DISK_SIZES, key=lambda candidate: abs(candidate - value))


def nearest_display_size(diagonal_inch: float | None) -> float | None:
    if diagonal_inch is None:
        return None
    nearest = min(COMMON_DISPLAY_SIZES, key=lambda candidate: abs(candidate - diagonal_inch))
    if abs(nearest - diagonal_inch) <= 0.7:
        return nearest
    return round(diagonal_inch, 1)


def get_cpu_name() -> str:
    cpu = run_command("lscpu")
    for line in cpu.splitlines():
        if "Model name:" in line:
            return line.split(":", 1)[1].replace("(R)", "").replace("(TM)", "").strip()

    for line in read_text("/proc/cpuinfo").splitlines():
        if line.lower().startswith("model name"):
            return line.split(":", 1)[1].replace("(R)", "").replace("(TM)", "").strip()

    dmi_cpu = run_command("dmidecode", "-s", "processor-version")
    return dmi_cpu.replace("(R)", "").replace("(TM)", "").strip()


def load_gpu_name_overrides() -> dict[str, str]:
    """Load exact display-driver names collected from the central INF corpus."""

    try:
        data = json.loads((SCRIPT_DIR / "gpu_names.json").read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return {}
    entries = data.get("entries") if isinstance(data, dict) else None
    if not isinstance(entries, dict):
        return {}
    return {
        str(key).upper(): str(value).strip()
        for key, value in entries.items()
        if re.fullmatch(r"[0-9A-F]{4}:[0-9A-F]{4}", str(key).upper()) and str(value).strip()
    }


def get_graphics_pci_ids() -> dict[str, str]:
    """Return ``lspci`` slot -> vendor/device ID for actual display adapters."""

    result: dict[str, str] = {}
    for line in run_command("lspci", "-nn").splitlines():
        # ``lspci -nn`` inserts the PCI class code between the type and colon,
        # e.g. ``3D controller [0302]:``.  Accept both that form and the
        # shorter normal ``lspci`` output.
        if not re.search(
            r"(?:VGA compatible controller|3D controller|Display controller)(?:\s*\[[0-9a-f]{4}\])?:",
            line,
            flags=re.IGNORECASE,
        ):
            continue
        slot = re.match(r"\s*([0-9a-f]{2}:[0-9a-f]{2}\.[0-7])\s", line, flags=re.IGNORECASE)
        device = re.search(r"\[([0-9a-f]{4}):([0-9a-f]{4})\]", line, flags=re.IGNORECASE)
        if slot and device:
            result[slot.group(1).lower()] = f"{device.group(1)}:{device.group(2)}".upper()
    return result


def compact_graphics_adapter_name(value: str) -> str:
    """Remove only redundant PCI vendor prefixes; never guess a GPU model."""

    cleaned = re.sub(r"^Advanced Micro Devices, Inc\.\s*\[AMD/ATI\]\s*", "AMD/ATI ", value, flags=re.IGNORECASE)
    cleaned = re.sub(r"^NVIDIA Corporation\s+", "NVIDIA ", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"^Intel Corporation\s+", "Intel ", cleaned, flags=re.IGNORECASE)
    return re.sub(r"\s+", " ", cleaned).strip()


def get_graphics_name() -> str:
    """Return up to two graphics adapters using the bundled PCI database.

    The live image's system ``pci.ids`` can be years old.  Prefer the snapshot
    shipped with HardwareCheck, then replace NVIDIA's chip codename with the
    official model name when the installed NVIDIA driver can provide one.
    """

    nvidia_driver_names: dict[str, str] = {}
    for line in run_command(
        "nvidia-smi", "--query-gpu=pci.bus_id,name", "--format=csv,noheader"
    ).splitlines():
        parts = [part.strip() for part in line.split(",", 1)]
        if len(parts) != 2:
            continue
        slot_match = re.search(r"([0-9a-f]{2}:[0-9a-f]{2}\.[0-7])$", parts[0], flags=re.IGNORECASE)
        if slot_match and parts[1]:
            nvidia_driver_names[slot_match.group(1).lower()] = parts[1]

    adapters: list[str] = []
    inf_driver_names = load_gpu_name_overrides()
    graphics_pci_ids = get_graphics_pci_ids()
    pci_ids = SCRIPT_DIR / "pci.ids"
    lspci_args = ("lspci", "-i", str(pci_ids)) if pci_ids.is_file() else ("lspci",)
    for line in run_command(*lspci_args).splitlines():
        marker = next(
            (
                token
                for token in (
                    "VGA compatible controller:",
                    "3D controller:",
                    "Display controller:",
                )
                if token in line
            ),
            "",
        )
        if not marker:
            continue
        adapter = line.split(marker, 1)[1].strip()
        slot_match = re.match(r"\s*([0-9a-f]{2}:[0-9a-f]{2}\.[0-7])\s", line, flags=re.IGNORECASE)
        if slot_match:
            slot = slot_match.group(1).lower()
            # A loaded NVIDIA driver is the strongest source.  Otherwise use
            # the official Windows display-INF name for the exact PCI ID, then
            # fall back to the bundled general PCI-ID database.
            adapter = nvidia_driver_names.get(slot) or inf_driver_names.get(graphics_pci_ids.get(slot, "")) or adapter
        adapter = compact_graphics_adapter_name(adapter)
        if adapter and adapter not in adapters:
            adapters.append(adapter)
    return " · ".join(adapters[:2])


@dataclass
class RamModule:
    locator: str
    size_gb: int
    speed_mhz: int | None
    configured_speed_mhz: int | None
    ram_type: str


def parse_dmidecode_memory() -> tuple[list[RamModule], int]:
    output = run_command("dmidecode", "-t", "memory")
    total_slots = 0
    slot_match = re.search(r"Number Of Devices:\s*(\d+)", output)
    if slot_match:
        total_slots = int(slot_match.group(1))

    blocks = output.split("Memory Device")
    modules: list[RamModule] = []
    for block in blocks:
        size_match = re.search(r"^\s*Size:\s*(.+)$", block, flags=re.MULTILINE)
        if not size_match:
            continue
        size_value = size_match.group(1).strip()
        if "No Module Installed" in size_value:
            continue

        size_number = to_int(size_value)
        if not size_number:
            continue
        size_gb = size_number if "GB" in size_value else math.ceil(size_number / 1024)
        locator = re.search(r"^\s*Locator:\s*(.+)$", block, flags=re.MULTILINE)
        speed = re.search(r"^\s*Speed:\s*(.+)$", block, flags=re.MULTILINE)
        configured = re.search(r"^\s*Configured Memory Speed:\s*(.+)$", block, flags=re.MULTILINE)
        ram_type = re.search(r"^\s*Type:\s*(.+)$", block, flags=re.MULTILINE)
        module = RamModule(
            locator=locator.group(1).strip() if locator else "",
            size_gb=size_gb,
            speed_mhz=to_int(speed.group(1)) if speed else None,
            configured_speed_mhz=to_int(configured.group(1)) if configured else None,
            ram_type=(ram_type.group(1).strip() if ram_type else ""),
        )
        modules.append(module)

    if total_slots <= 0:
        total_slots = len(modules)
    return modules, total_slots


def best_ram_type(modules: list[RamModule]) -> str:
    for module in modules:
        module_type = module.ram_type.upper()
        if "LPDDR5" in module_type:
            return "LPDDR5"
        if "LPDDR4" in module_type:
            return "LPDDR4"
        if "DDR5" in module_type:
            return "DDR5"
        if "DDR4" in module_type:
            return "DDR4"
        if "DDR3" in module_type:
            return "DDR3"
    max_mhz = max(
        [value for module in modules for value in (module.configured_speed_mhz, module.speed_mhz) if value],
        default=None,
    )
    return guess_ram_type_by_speed(max_mhz)


def build_ram_layout(modules: list[RamModule]) -> str:
    sizes = [module.size_gb for module in modules if module.size_gb]
    if not sizes:
        return ""
    if len(sizes) == 1:
        return f"1x{sizes[0]}"
    if len(sizes) == 2 and sizes[0] == sizes[1]:
        return f"2x{sizes[0]}"
    return " + ".join(f"1x{size}" for size in sizes[:4])


def infer_min_ram_slots(
    vendor: str,
    model: str,
    product_no: str,
    version: str,
    modules: list[RamModule],
    reported_total_slots: int,
) -> int:
    total_slots = max(reported_total_slots, len(modules))
    identity = " ".join([vendor, model, product_no, version]).upper()

    # Some ASUS VivoBook boards report only the soldered memory device via DMI,
    # even though the mainboard has one physical SO-DIMM expansion slot.
    asus_onboard_plus_sodimm_models = ("X712EA", "F712EA")
    if "ASUS" in identity and any(token in identity for token in asus_onboard_plus_sodimm_models):
        return max(total_slots, len(modules) + 1, 2)

    return total_slots


def get_drm_resolution() -> str:
    drm_root = pathlib.Path("/sys/class/drm")
    if not drm_root.exists():
        return ""
    status_files = sorted(drm_root.glob("card*-*/status"))
    internal_names = ("edp", "lvds", "dsi")
    ordered_status_files = [
        path for path in status_files if any(name in path.parent.name.lower() for name in internal_names)
    ]
    ordered_status_files.extend(path for path in status_files if path not in ordered_status_files)
    for status_file in ordered_status_files:
        if read_text(status_file) != "connected":
            continue
        modes_file = status_file.with_name("modes")
        modes = read_text(modes_file).splitlines()
        if modes:
            return modes[0].strip()
    return ""


def get_xrandr_resolution() -> str:
    xrandr = run_command("xrandr")
    for line in xrandr.splitlines():
        if "*" in line:
            return line.split()[0]
    return ""


def get_resolution() -> str:
    return get_drm_resolution() or get_xrandr_resolution()


def parse_edid_inches() -> float | None:
    drm_root = pathlib.Path("/sys/class/drm")
    if not drm_root.exists():
        return None
    for status_file in sorted(drm_root.glob("card*-*/status")):
        if read_text(status_file) != "connected":
            continue
        edid_data = read_bytes(status_file.with_name("edid"))
        if len(edid_data) < 23:
            continue
        width_cm = edid_data[21]
        height_cm = edid_data[22]
        if width_cm and height_cm:
            diagonal = math.sqrt(width_cm ** 2 + height_cm ** 2) / 2.54
            return diagonal
    return None


def infer_display_size_from_model(model: str, resolution: str) -> float | None:
    text = re.sub(r"[_/]+", " ", f"{model} {resolution}".lower())
    if re.search(r"\b(18|18t|18-|18s)\b", text):
        return 18.0
    if re.search(r"\b(17|17t|17z|17-|17s|470|670|730|770|8730)\b", text):
        return 17.3
    if re.search(r"\b(laptop|notebook|ideapad|vivo?book|aspire|thinkbook|probook|elitebook)\s+17\b", text):
        return 17.3
    if re.search(r"\b(18)\b", text):
        return 18.0
    if re.search(r"\b(v15|15|15s|15t|15z|15-|156|83gw|250|255|350|355|450|455|550|555|650|655)\b", text):
        return 15.6
    if re.search(r"\b(laptop|notebook|ideapad|vivo?book|aspire|thinkbook|probook|elitebook)\s+15\b", text):
        return 15.6
    if re.search(r"\b(14|14s|14t|14z|14-|440|640|840|1040|x1 carbon)\b", text):
        return 14.0
    if re.search(r"\b(13|13s|13t|13z|13-|330|430|830|1030)\b", text):
        return 13.3
    return None


def add_missing_optical_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    existing = {str(row.get("name") or row.get("kname") or "") for row in rows}
    sys_block = pathlib.Path("/sys/block")
    for device in sorted(sys_block.glob("sr*")) if sys_block.exists() else []:
        if device.name in existing:
            continue
        sectors = to_int(read_text(device / "size")) or 0
        rows.append(
            {
                "name": device.name,
                "type": "rom",
                "tran": "",
                "size": sectors * 512,
                "model": first_existing_text([device / "device/model", device / "device/name"]),
                "vendor": read_text(device / "device/vendor"),
                "rota": read_text(device / "queue/rotational") or "1",
            }
        )
    return rows


def get_storage_rows() -> list[dict[str, object]]:
    output = run_command("lsblk", "-J", "-b", "-o", "NAME,KNAME,TYPE,TRAN,SIZE,MODEL,VENDOR,ROTA")
    rows = []
    if output:
        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            data = {}
        for row in data.get("blockdevices", []):
            row_type = str(row.get("type") or "").lower()
            transport = str(row.get("tran") or "").lower()
            if row_type == "disk":
                if transport == "usb":
                    continue
                rows.append(row)
            elif row_type == "rom":
                rows.append(row)
        rows = add_missing_optical_rows(rows)
    if rows:
        return rows

    sys_block = pathlib.Path("/sys/block")
    for device in sorted(sys_block.iterdir()) if sys_block.exists() else []:
        name = device.name
        if re.match(r"^(loop|ram|fd|zram)", name):
            continue
        row_type = "rom" if name.startswith("sr") else "disk"
        if read_text(device / "removable") == "1":
            if row_type != "rom":
                continue
        sectors = to_int(read_text(device / "size")) or 0
        if not sectors and row_type != "rom":
            continue
        model = first_existing_text([device / "device/model", device / "device/name"])
        vendor = read_text(device / "device/vendor")
        rotational = read_text(device / "queue/rotational") or "0"
        transport = "nvme" if name.startswith("nvme") else "mmc" if name.startswith("mmcblk") else ""
        rows.append(
            {
                "name": name,
                "type": row_type,
                "tran": transport,
                "size": sectors * 512,
                "model": model,
                "vendor": vendor,
                "rota": rotational,
            }
        )
    return rows


def detect_optical_type(row: dict[str, object]) -> str:
    model = clean_storage_model(row.get("model"), row.get("vendor"))
    combined = f"{row.get('name') or ''} {model}".lower()
    if re.search(r"\b(bd|blu[ -]?ray)\b", combined):
        return "Blu-ray/DVD"
    if "dvd" in combined:
        if re.search(r"rw|ram|multi|writer|re", combined):
            return "DVD-RW"
        return "DVD-ROM"
    if "cd" in combined:
        return "CD/DVD-Laufwerk"
    return "Optisches Laufwerk"


def storage_rotational_value(value: object) -> bool | None:
    text = str(value if value is not None else "").strip().lower()
    if text in {"1", "true", "yes", "y", "rotational"}:
        return True
    if text in {"0", "false", "no", "n", "non-rotational"}:
        return False
    return None


def looks_like_25_hdd(model: str) -> bool:
    normalized = re.sub(r"[^a-z0-9]+", "", model.lower())
    if re.search(r"\bwd\d{2}sp[czx]", normalized):
        return True
    if re.search(r"\bwd\d{3,4}(lp|bp|jp|sp)", normalized):
        return True
    if re.search(r"\bst\d{3,4}lm", normalized):
        return True
    hdd_tokens = (
        "toshibamq",
        "toshibahd",
        "mq01",
        "mq02",
        "mq03",
        "mq04",
        "hitachihts",
        "hgsthts",
        "wd10jp",
        "wd5000lp",
        "wd5000bp",
        "wd7500bp",
        "wd5000sp",
        "wd7500sp",
        "wd10sp",
        "wd20sp",
        "wd30sp",
        "st500lm",
        "st750lm",
        "st1000lm",
        "st2000lm",
    )
    return any(token in normalized for token in hdd_tokens)


def looks_like_m2_sata_model(model: str) -> bool:
    text = str(model or "").lower().replace("_", " ")
    return bool(re.search(r"\b(m\.?\s*2|ngff|m2\s*ssd|sata\s*m\.?\s*2|2242|2260|2280|22110)\b", text))


def looks_like_25_ssd_model(model: str) -> bool:
    text = str(model or "").lower().replace(",", ".")
    return bool(re.search(r"\b2\.5\b|\b2\.5[ -]?(inch|zoll|ssd)\b", text))


def has_reliable_m2_sata_hint(name: str, transport: str, model: str) -> bool:
    combined = f"{name} {transport} {model}".lower()
    if name.startswith("nvme") or transport == "nvme":
        return False
    return looks_like_m2_sata_model(combined) or bool(re.search(r"\b(sd9|sd8|x400|x600|ngff)\b", combined))


def detect_disk_type(row: dict[str, object]) -> str:
    name = str(row.get("name") or "")
    transport = str(row.get("tran") or "").lower()
    raw_model = str(row.get("model") or "")
    model = clean_storage_model(row.get("model"), row.get("vendor"))
    rotational = storage_rotational_value(row.get("rota"))
    combined = f"{name} {transport} {raw_model} {model}".lower()
    if name.startswith("nvme") or transport == "nvme":
        return "NVMe M.2 SSD"
    if name.startswith("mmcblk") or transport in {"mmc", "sdio"}:
        return "eMMC Flash"
    if rotational is True or looks_like_25_hdd(model):
        return "SATA HDD 2.5"
    if has_reliable_m2_sata_hint(name, transport, combined):
        return "M.2 SATA SSD"
    if rotational is False:
        if looks_like_25_hdd(model):
            return "SATA HDD 2.5"
        if looks_like_25_ssd_model(combined):
            return "SATA SSD 2.5"
        return "SATA SSD" if transport in {"", "sata", "ata", "ahci"} else "SSD/Flash intern"
    if re.search(r"ssd|micron|sandisk|kingston|crucial|liteon|skhynix|spcc|silicon|samsung", model, re.I):
        if looks_like_25_ssd_model(combined):
            return "SATA SSD 2.5"
        return "SATA SSD"
    if transport in {"sata", "ata", "ahci"}:
        return "SATA Laufwerk 2.5"
    return "Unbekannter Datenträger"


def _smart_attribute_value(payload: dict[str, object], attribute_id: int) -> int | None:
    """Return a normalized ATA SMART raw value without assuming a vendor format."""
    ata = payload.get("ata_smart_attributes")
    table = ata.get("table") if isinstance(ata, dict) else None
    if not isinstance(table, list):
        return None
    for item in table:
        if not isinstance(item, dict) or item.get("id") != attribute_id:
            continue
        raw = item.get("raw")
        if isinstance(raw, dict):
            value = raw.get("value")
            if isinstance(value, (int, float)):
                return int(value)
        value = item.get("raw")
        if isinstance(value, (int, float)):
            return int(value)
    return None


def _storage_number(payload: dict[str, object], *keys: str) -> int | float | None:
    """Read nested SMART JSON values such as ``power_on_time.hours``."""
    current: object = payload
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current if isinstance(current, (int, float)) else None


def _storage_first(payload: dict[str, object], *paths: tuple[str, ...]) -> int | float | None:
    """Return the first numeric SMART value from compatible JSON paths."""
    for path in paths:
        value = _storage_number(payload, *path)
        if value is not None:
            return value
    return None


def _nvme_data_units_to_tb(value: object) -> float | None:
    """NVMe reports data units in blocks of 512,000 bytes."""
    if not isinstance(value, (int, float)):
        return None
    return float(value) * 512_000.0 / 1_000_000_000_000.0


def _smart_summary(device_path: str, row: dict[str, object]) -> dict[str, object]:
    """Read SMART data read-only and normalize the useful workshop metrics.

    ``smartctl`` supports both NVMe and SATA.  For NVMe, ``nvme smart-log``
    supplements smartctl: several controllers expose host I/O counters only
    through nvme-cli even when smartctl otherwise succeeds.
    Missing tools or unsupported controllers are deliberately represented as
    unavailable data; the UI must never turn an absent value into a warning.
    """
    payload: dict[str, object] = {}
    source = ""
    raw = run_command("smartctl", "-a", "-j", device_path)
    if raw:
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                payload = parsed
                source = "smartctl"
        except json.JSONDecodeError:
            pass

    is_nvme = str(row.get("name") or "").startswith("nvme") or str(row.get("tran") or "").lower() == "nvme"
    if is_nvme:
        controller = re.sub(r"n\d+$", "", device_path)
        raw = run_command("nvme", "smart-log", "-o", "json", controller)
        if raw:
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    if payload:
                        payload["_nvme_cli_smart_log"] = parsed
                        source = "smartctl + nvme-cli"
                    else:
                        payload = parsed
                        source = "nvme-cli"
            except json.JSONDecodeError:
                pass

    model = clean_storage_model(row.get("model"), row.get("vendor"))
    try:
        size_bytes = int(float(row.get("size") or 0))
    except (TypeError, ValueError):
        size_bytes = 0
    result: dict[str, object] = {
        "path": device_path,
        "name": str(row.get("name") or ""),
        "model": model,
        "type": detect_disk_type(row),
        "size_bytes": size_bytes,
        "available": bool(payload),
        "source": source,
        "serial": "",
        "firmware": "",
        "power_on_hours": None,
        "power_cycles": None,
        "temperature_c": None,
        "wear_percent": None,
        "written_tb": None,
        "read_tb": None,
        "read_commands": None,
        "write_commands": None,
        "critical_warning": 0,
        "reallocated_sectors": None,
        "status": "unknown",
        "note": "SMART-Daten nicht verfügbar",
    }
    if not payload:
        return result

    result["serial"] = str(payload.get("serial_number") or payload.get("serial") or "").strip()
    result["firmware"] = str(payload.get("firmware_version") or payload.get("firmware") or "").strip()
    nvme_cli_path = ("_nvme_cli_smart_log",)
    result["power_on_hours"] = _storage_first(payload, ("power_on_time", "hours"), ("power_on_hours",), nvme_cli_path + ("power_on_hours",)) or _smart_attribute_value(payload, 9)
    result["power_cycles"] = _storage_first(payload, ("power_cycle_count",), ("power_cycles",), nvme_cli_path + ("power_cycles",)) or _smart_attribute_value(payload, 12)
    result["temperature_c"] = _storage_first(payload, ("temperature", "current"), ("temperature",), nvme_cli_path + ("temperature",)) or _smart_attribute_value(payload, 194) or _smart_attribute_value(payload, 190)
    nvme_log_path = ("nvme_smart_health_information_log",)
    percentage_used = _storage_first(payload, ("percentage_used",), nvme_log_path + ("percentage_used",), nvme_cli_path + ("percentage_used",))
    if percentage_used is not None:
        result["wear_percent"] = max(0.0, min(100.0, 100.0 - float(percentage_used)))
    else:
        for attribute in (231, 233, 202):
            value = _smart_attribute_value(payload, attribute)
            if value is not None and 0 <= value <= 100:
                result["wear_percent"] = float(value)
                break
    result["written_tb"] = _nvme_data_units_to_tb(_storage_first(payload, ("data_units_written",), nvme_log_path + ("data_units_written",), nvme_cli_path + ("data_units_written",)))
    result["read_tb"] = _nvme_data_units_to_tb(_storage_first(payload, ("data_units_read",), nvme_log_path + ("data_units_read",), nvme_cli_path + ("data_units_read",)))
    result["read_commands"] = _storage_first(payload, ("host_read_commands",), nvme_log_path + ("host_read_commands",), nvme_cli_path + ("host_read_commands",))
    result["write_commands"] = _storage_first(payload, ("host_write_commands",), nvme_log_path + ("host_write_commands",), nvme_cli_path + ("host_write_commands",))
    if result["written_tb"] is None:
        written = _smart_attribute_value(payload, 241) or _smart_attribute_value(payload, 246)
        if written is not None:
            result["written_tb"] = float(written) * 512_000.0 / 1_000_000_000_000.0
    result["reallocated_sectors"] = _smart_attribute_value(payload, 5)
    warning = _storage_first(payload, ("critical_warning",), nvme_log_path + ("critical_warning",), nvme_cli_path + ("critical_warning",))
    result["critical_warning"] = int(warning) if warning is not None else 0

    temperature = result["temperature_c"]
    wear = result["wear_percent"]
    reallocated = result["reallocated_sectors"]
    if result["critical_warning"] or (isinstance(reallocated, int) and reallocated > 0):
        result["status"] = "bad"
        result["note"] = "Kritische SMART-Warnung"
    elif (isinstance(temperature, (int, float)) and temperature >= 70) or (isinstance(wear, (int, float)) and wear < 20):
        result["status"] = "warn"
        result["note"] = "Bitte SSD beobachten"
    else:
        result["status"] = "good"
        result["note"] = "SMART-Werte unauffällig"
    return result


def read_storage_health_details() -> list[dict[str, object]]:
    """Return read-only health details for all internal physical drives."""
    details: list[dict[str, object]] = []
    for row in get_storage_rows():
        if str(row.get("type") or "").lower() != "disk":
            continue
        name = str(row.get("kname") or row.get("name") or "").strip()
        if not name:
            continue
        details.append(_smart_summary(f"/dev/{name}", row))
    return details


def find_battery_dir() -> pathlib.Path | None:
    power_root = pathlib.Path("/sys/class/power_supply")
    if not power_root.exists():
        return None
    battery_dirs = sorted(path for path in power_root.glob("BAT*") if path.is_dir())
    if battery_dirs:
        return battery_dirs[0]
    for candidate in sorted(power_root.iterdir()):
        if candidate.is_dir() and (read_text(candidate / "type") or "").lower() == "battery":
            return candidate
    return None


def battery_sysfs_int(path: pathlib.Path) -> int | None:
    value = read_text(path)
    if not value:
        return None
    try:
        return int(float(value))
    except ValueError:
        return None


def battery_sysfs_float(path: pathlib.Path, divisor: float = 1.0) -> float | None:
    value = battery_sysfs_int(path)
    if value is None:
        return None
    return value / divisor


def battery_first_text(battery: pathlib.Path, names: tuple[str, ...]) -> str:
    for name in names:
        value = read_text(battery / name)
        if value:
            return value
    return ""


def battery_first_int(battery: pathlib.Path, names: tuple[str, ...]) -> int | None:
    for name in names:
        value = battery_sysfs_int(battery / name)
        if value is not None:
            return value
    return None


def battery_first_float(battery: pathlib.Path, names: tuple[str, ...], divisor: float = 1.0) -> float | None:
    value = battery_first_int(battery, names)
    if value is None:
        return None
    return value / divisor


def read_ac_adapter_status() -> tuple[bool | None, str]:
    base = pathlib.Path("/sys/class/power_supply")
    if not base.exists():
        return None, ""
    seen_adapter = False
    online_names: list[str] = []
    adapter_names: list[str] = []
    adapter_types = {
        "mains",
        "ac",
        "usb",
        "usbc",
        "usbpd",
        "usbcdp",
        "usbdcp",
        "usbaca",
    }
    try:
        supplies = list(base.iterdir())
    except OSError:
        return None, ""
    for supply in supplies:
        supply_type = normalize_generic_token(read_text(supply / "type"))
        supply_name = supply.name
        looks_like_adapter = supply_type in adapter_types or supply_name.upper().startswith(("AC", "ADP", "ACAD", "MAINS"))
        if not looks_like_adapter:
            continue
        seen_adapter = True
        adapter_names.append(supply_name)
        online = read_text(supply / "online").strip()
        if online == "1":
            online_names.append(supply_name)
    if online_names:
        return True, ", ".join(online_names)
    if seen_adapter:
        return False, ", ".join(adapter_names)
    return None, ""


def effective_battery_status(raw_status: str, ac_online: bool | None, capacity_percent: int | None) -> str:
    status = raw_status or "Unknown"
    normalized = normalize_generic_token(status)
    if ac_online is True and normalized in {"discharging", "unknown", ""}:
        if capacity_percent is not None and capacity_percent >= 98:
            return "Full"
        return "Charging"
    return status


def read_battery_details() -> dict[str, object]:
    timestamp = datetime.datetime.now().astimezone().replace(microsecond=0).isoformat()
    battery = find_battery_dir()
    if battery is None:
        return {
            "present": False,
            "timestamp": timestamp,
            "path": "",
            "name": "",
            "status": "Kein Akku erkannt",
            "capacity_percent": None,
        }

    capacity = battery_sysfs_int(battery / "capacity")
    energy_now = battery_first_int(battery, ("energy_now", "charge_now"))
    energy_full = battery_first_int(battery, ("energy_full", "charge_full"))
    energy_design = battery_first_int(battery, ("energy_full_design", "charge_full_design", "energy_design", "charge_design"))
    capacity_unit = ""
    if any((battery / name).exists() for name in ("energy_now", "energy_full", "energy_full_design", "energy_design")):
        capacity_unit = "uWh"
    elif any((battery / name).exists() for name in ("charge_now", "charge_full", "charge_full_design", "charge_design")):
        capacity_unit = "uAh"
    voltage_now = battery_first_float(battery, ("voltage_now",), 1_000_000.0)
    current_now = battery_first_float(battery, ("current_now",), 1_000_000.0)
    power_now = battery_first_float(battery, ("power_now",), 1_000_000.0)
    if power_now is None and current_now is not None and voltage_now is not None:
        power_now = abs(current_now * voltage_now)
    time_to_empty = battery_first_int(battery, ("time_to_empty_now", "time_to_empty_avg"))
    time_to_full = battery_first_int(battery, ("time_to_full_now", "time_to_full_avg"))
    health_percent = None
    if energy_full and energy_design:
        health_percent = round((float(energy_full) / float(energy_design)) * 100.0, 1)

    raw_status = read_text(battery / "status") or "Unknown"
    ac_online, ac_name = read_ac_adapter_status()
    status = effective_battery_status(raw_status, ac_online, capacity)

    return {
        "present": True,
        "timestamp": timestamp,
        "path": str(battery),
        "name": battery.name,
        "status": status,
        "status_raw": raw_status,
        "ac_online": ac_online,
        "ac_name": ac_name,
        "capacity_percent": capacity,
        "manufacturer": battery_first_text(battery, ("manufacturer", "oem")),
        "model_name": battery_first_text(battery, ("model_name", "model", "device")),
        "serial_number": battery_first_text(battery, ("serial_number", "serial")),
        "technology": battery_first_text(battery, ("technology",)),
        "cycle_count": battery_first_text(battery, ("cycle_count",)),
        "voltage_v": voltage_now,
        "current_a": current_now,
        "power_w": power_now,
        "time_to_empty_seconds": time_to_empty,
        "time_to_full_seconds": time_to_full,
        "energy_now": energy_now,
        "energy_full": energy_full,
        "energy_full_design": energy_design,
        "capacity_unit": capacity_unit,
        "health_percent": health_percent,
    }


def get_battery_info() -> tuple[str, str]:
    details = read_battery_details()
    if not details.get("present"):
        return ("Kein Akku erkannt", "")
    status = str(details.get("status") or "Unknown")
    capacity = details.get("capacity_percent")
    return (status, f"{capacity} %" if capacity is not None else "")


def battery_lang(language: str, de: str, en: str, cz: str) -> str:
    language = str(language or "DE").strip().upper()
    return {"DE": de, "EN": en, "CZ": cz}.get(language, de)


def battery_missing(language: str = "DE") -> str:
    return battery_lang(language, "nicht verfügbar", "not available", "není k dispozici")


def battery_status_label(status: object, language: str = "DE") -> str:
    normalized = normalize_generic_token(str(status or ""))
    labels = {
        "charging": battery_lang(language, "lädt", "Charging", "nabíjí se"),
        "discharging": battery_lang(language, "entlädt", "Discharging", "vybíjí se"),
        "notcharging": battery_lang(language, "lädt nicht", "Not charging", "nenabíjí se"),
        "full": battery_lang(language, "voll", "Full", "plně nabito"),
        "unknown": battery_lang(language, "unbekannt", "Unknown", "neznámý"),
        "keinakkuerkannt": battery_lang(language, "kein Akku erkannt", "No battery detected", "baterie nenalezena"),
    }
    return labels.get(normalized, str(status or battery_missing(language)))


def battery_report_value(value: object, suffix: str = "", language: str = "DE") -> str:
    if value in (None, ""):
        return battery_missing(language)
    if isinstance(value, float):
        text = f"{value:.1f}".rstrip("0").rstrip(".")
    else:
        text = str(value)
    return f"{text}{suffix}"


def battery_capacity_unit_label(unit: object) -> str:
    if unit == "uAh":
        return "mAh"
    if unit == "uWh":
        return "mWh"
    return ""


def battery_capacity_text(value: object, unit: object = "", language: str = "DE") -> str:
    if value in (None, ""):
        return battery_missing(language)
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)
    label = battery_capacity_unit_label(unit)
    if label:
        numeric = numeric / 1000.0
        return f"{numeric:,.0f} {label}".replace(",", ".")
    return f"{numeric:,.0f}".replace(",", ".")


def html_escape(value: object) -> str:
    return html_lib.escape(str(value if value not in (None, "") else "-"), quote=True)


def html_cell(value: object, class_name: str = "") -> str:
    class_attr = f' class="{class_name}"' if class_name else ""
    return f"<td{class_attr}>{html_escape(value)}</td>"


def html_label_row(label: str, value: object) -> str:
    return f"<tr>{html_cell(label, 'label')}{html_cell(value)}</tr>"


class BatteryHtmlTextExtractor(HTMLParser):
    BLOCK_TAGS = {"body", "section", "div", "p", "h1", "h2", "h3", "table", "tr", "ul", "ol", "li", "br"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._parts: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag in {"script", "style"}:
            self._skip_depth += 1
            return
        if self._skip_depth:
            return
        if tag in {"h1", "h2", "h3", "tr", "p", "div"}:
            self._parts.append("\n")
        elif tag == "li":
            self._parts.append("\n- ")
        elif tag in {"td", "th"}:
            self._parts.append("  ")
        elif tag == "br":
            self._parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style"} and self._skip_depth:
            self._skip_depth -= 1
            return
        if self._skip_depth:
            return
        if tag in {"h1", "h2", "h3", "tr", "p", "div", "li", "table", "ul", "ol"}:
            self._parts.append("\n")
        elif tag in {"td", "th"}:
            self._parts.append(" | ")

    def handle_data(self, data: str) -> None:
        if self._skip_depth:
            return
        text = re.sub(r"\s+", " ", data.strip())
        if text:
            self._parts.append(text)

    def text(self) -> str:
        raw = "".join(self._parts)
        lines = []
        for line in raw.splitlines():
            cleaned = re.sub(r"[ \t]+", " ", line).strip(" |")
            if cleaned:
                lines.append(cleaned)
        return "\n".join(lines)


def battery_html_to_text(markup: str) -> str:
    parser = BatteryHtmlTextExtractor()
    try:
        parser.feed(markup)
        parser.close()
    except Exception:
        without_scripts = re.sub(r"(?is)<(script|style).*?</\1>", "", markup)
        text = re.sub(r"(?s)<[^>]+>", " ", without_scripts)
        return html_lib.unescape(re.sub(r"\s+", " ", text)).strip()
    return parser.text()


def wrap_report_preview_lines(text: str, width: int = 104) -> str:
    wrapped: list[str] = []
    for line in text.splitlines():
        if len(line) <= width:
            wrapped.append(line)
            continue
        indent_match = re.match(r"^(\s*)", line)
        indent = indent_match.group(1) if indent_match else ""
        wrapped.extend(
            textwrap.wrap(
                line,
                width=width,
                subsequent_indent=f"{indent}    ",
                break_long_words=True,
                break_on_hyphens=False,
            )
        )
    return "\n".join(wrapped)


def battery_report_preview_text(path: pathlib.Path, width: int = 104) -> str:
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return f"Report konnte nicht gelesen werden: {exc}"
    if path.suffix.lower() in {".html", ".htm"}:
        text = battery_html_to_text(content)
        return wrap_report_preview_lines(text or "HTML-Report enthaelt keinen lesbaren Text.", width)
    return wrap_report_preview_lines(content, width)


def list_battery_report_files() -> list[pathlib.Path]:
    report_dir = get_battery_report_dir()
    if not report_dir.exists():
        return []
    grouped: dict[str, pathlib.Path] = {}
    for pattern in ("*.txt", "*.htm", "*.html"):
        for path in report_dir.glob(pattern):
            if path.is_file():
                grouped[path.stem.lower()] = path
    return sorted(grouped.values(), key=lambda p: p.stat().st_mtime, reverse=True)


def shorten_middle(text: str, max_len: int = 76) -> str:
    if len(text) <= max_len:
        return text
    if max_len <= 8:
        return text[:max_len]
    left = max(1, (max_len - 3) // 2)
    right = max(1, max_len - 3 - left)
    return f"{text[:left]}...{text[-right:]}"


def battery_report_basename(snapshot: dict[str, object] | None, mode: str) -> str:
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    if snapshot:
        base = report_basename(snapshot)
    else:
        base = "Akku"
    return sanitize_filename(f"{base}_{mode}_{stamp}")


def build_battery_demo_samples() -> list[dict[str, object]]:
    now = datetime.datetime.now().astimezone().replace(microsecond=0)
    base = {
        "present": True,
        "name": "BAT0",
        "path": "/sys/class/power_supply/BAT0",
        "manufacturer": "SMP",
        "model_name": "DEMO-BAT-51Wh",
        "serial_number": "DEMO123456",
        "technology": "Li-ion",
        "cycle_count": "44",
        "status_raw": "Discharging",
        "ac_online": False,
        "ac_name": "AC",
        "energy_full_design": 59000000,
        "energy_full": 51000000,
        "capacity_unit": "uWh",
        "voltage_v": 11.38,
        "current_a": 1.12,
        "power_w": 12.7,
        "health_percent": 86.4,
    }
    points = [
        (-90, 88, 44900000, 13.2),
        (-60, 82, 41800000, 12.9),
        (-30, 76, 38800000, 12.5),
        (0, 70, 35700000, 12.1),
    ]
    samples = []
    for minutes, capacity, energy_now, power_w in points:
        sample = dict(base)
        sample.update(
            {
                "timestamp": (now + datetime.timedelta(minutes=minutes)).isoformat(),
                "status": "Discharging",
                "capacity_percent": capacity,
                "energy_now": energy_now,
                "power_w": power_w,
            }
        )
        samples.append(sample)
    return samples


def battery_csv_header() -> str:
    return (
        "timestamp;mode;status;capacity_percent;health_percent;power_w;voltage_v;current_a;"
        "energy_now;energy_full;energy_full_design;capacity_unit;manufacturer;model_name;serial_number;technology;cycle_count;"
        "status_raw;ac_online;ac_name\n"
    )


def battery_csv_line(mode: str, sample: dict[str, object]) -> str:
    fields = [
        sample.get("timestamp", ""),
        mode,
        sample.get("status", ""),
        sample.get("capacity_percent", ""),
        sample.get("health_percent", ""),
        sample.get("power_w", ""),
        sample.get("voltage_v", ""),
        sample.get("current_a", ""),
        sample.get("energy_now", ""),
        sample.get("energy_full", ""),
        sample.get("energy_full_design", ""),
        sample.get("capacity_unit", ""),
        sample.get("manufacturer", ""),
        sample.get("model_name", ""),
        sample.get("serial_number", ""),
        sample.get("technology", ""),
        sample.get("cycle_count", ""),
        sample.get("status_raw", ""),
        sample.get("ac_online", ""),
        sample.get("ac_name", ""),
    ]
    escaped = [str(value).replace("\n", " ").replace(";", ",") for value in fields]
    return ";".join(escaped) + "\n"


def append_battery_csv(path: pathlib.Path, mode: str, sample: dict[str, object], include_header: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        if include_header:
            handle.write(battery_csv_header())
        handle.write(battery_csv_line(mode, sample))
        handle.flush()
        os.fsync(handle.fileno())


def parse_battery_timestamp(value: object) -> datetime.datetime | None:
    try:
        return datetime.datetime.fromisoformat(str(value))
    except ValueError:
        return None


def battery_current_session_samples(samples: list[dict[str, object]]) -> list[dict[str, object]]:
    if len(samples) < 2:
        return list(samples)
    current: list[dict[str, object]] = []
    last_time: datetime.datetime | None = None
    for sample in samples:
        stamp = parse_battery_timestamp(sample.get("timestamp"))
        if stamp is not None and last_time is not None:
            gap = (stamp - last_time).total_seconds()
            if gap > BATTERY_SESSION_MAX_GAP_SECONDS or gap < -60:
                current = []
        current.append(sample)
        if stamp is not None:
            last_time = stamp
    return current or list(samples)


def battery_energy_wh(sample: dict[str, object]) -> float | None:
    """Convert the controller's current energy/charge value to watt-hours."""
    try:
        value = float(sample.get("energy_now"))
    except (TypeError, ValueError):
        return None
    if not math.isfinite(value) or value <= 0:
        return None
    unit = str(sample.get("capacity_unit") or "").strip().lower()
    if unit == "uwh":
        return value / 1_000_000.0
    if unit == "uah":
        try:
            voltage = float(sample.get("voltage_v"))
        except (TypeError, ValueError):
            return None
        if math.isfinite(voltage) and voltage > 0:
            return value / 1_000_000.0 * voltage
    return None


def battery_instant_estimate_seconds(mode: str, sample: dict[str, object]) -> tuple[float | None, str]:
    """Return a controller/power based estimate while the measured trend matures."""
    direct_key = "time_to_full_seconds" if mode == "charge" else "time_to_empty_seconds"
    try:
        direct = float(sample.get(direct_key))
    except (TypeError, ValueError):
        direct = 0.0
    if math.isfinite(direct) and 60.0 <= direct <= 7 * 24 * 3600:
        return direct, "controller"

    if mode != "discharge":
        return None, ""
    energy_wh = battery_energy_wh(sample)
    try:
        power_w = abs(float(sample.get("power_w")))
    except (TypeError, ValueError):
        power_w = 0.0
    if energy_wh is not None and math.isfinite(power_w) and power_w >= 0.2:
        estimate = energy_wh / power_w * 3600.0
        if 60.0 <= estimate <= 7 * 24 * 3600:
            return estimate, "power"
    return None, ""


def battery_dashboard_metrics(mode: str, samples: list[dict[str, object]]) -> dict[str, object]:
    """Return robust live-test metrics for both battery interfaces."""
    current = battery_current_session_samples(samples)
    latest = current[-1] if current else {}
    effective_mode = mode if mode in {"charge", "discharge"} else ""
    if not effective_mode:
        normalized_status = normalize_generic_token(latest.get("status"))
        if normalized_status == "charging":
            effective_mode = "charge"
        elif normalized_status == "discharging":
            effective_mode = "discharge"
    instant_estimate, instant_source = (
        battery_instant_estimate_seconds(effective_mode, latest)
        if effective_mode
        else (None, "")
    )
    result: dict[str, object] = {
        "sample_count": len(current),
        "elapsed_seconds": 0.0,
        "delta_percent": None,
        "rate_percent_per_hour": None,
        "estimate_seconds": instant_estimate,
        "estimate_kind": "to_full" if effective_mode == "charge" and instant_estimate else "remaining" if instant_estimate else "",
        "estimate_source": instant_source,
        "full_runtime_seconds": None,
        "effective_mode": effective_mode,
        "drop_percent": 0.0,
        "drop_state": "",
    }
    if len(current) < 2:
        return result

    start = current[0]
    end = current[-1]
    start_time = parse_battery_timestamp(start.get("timestamp"))
    end_time = parse_battery_timestamp(end.get("timestamp"))
    try:
        start_percent = float(start.get("capacity_percent"))
        end_percent = float(end.get("capacity_percent"))
    except (TypeError, ValueError):
        return result
    if start_time is None or end_time is None:
        return result

    elapsed_seconds = max(0.0, (end_time - start_time).total_seconds())
    delta = end_percent - start_percent
    result["elapsed_seconds"] = elapsed_seconds
    result["delta_percent"] = delta
    if elapsed_seconds < 60.0 or abs(delta) < 0.01:
        return result

    effective_mode = str(result["effective_mode"])
    if not effective_mode:
        effective_mode = "charge" if delta > 0 else "discharge"
        result["effective_mode"] = effective_mode
    elapsed_hours = elapsed_seconds / 3600.0
    if effective_mode == "discharge" and delta < 0:
        drain = abs(delta)
        rate = drain / elapsed_hours
        result["rate_percent_per_hour"] = rate
        result["drop_percent"] = drain
        if elapsed_seconds >= BATTERY_ESTIMATE_MIN_SECONDS and drain >= 1.0:
            result["estimate_seconds"] = max(0.0, end_percent) / rate * 3600.0
            result["estimate_kind"] = "remaining"
            result["estimate_source"] = "measured"
            result["full_runtime_seconds"] = 100.0 / rate * 3600.0
        if elapsed_seconds >= BATTERY_RAPID_DROP_MIN_SECONDS and drain >= BATTERY_RAPID_DROP_WARN_PERCENT:
            if rate >= BATTERY_RAPID_DROP_CRITICAL_RATE:
                result["drop_state"] = "critical"
            elif rate >= BATTERY_RAPID_DROP_WARN_RATE:
                result["drop_state"] = "warn"
    elif effective_mode == "charge" and delta > 0:
        rate = delta / elapsed_hours
        result["rate_percent_per_hour"] = rate
        if elapsed_seconds >= BATTERY_ESTIMATE_MIN_SECONDS and delta >= 1.0:
            result["estimate_seconds"] = max(0.0, 100.0 - end_percent) / rate * 3600.0
            result["estimate_kind"] = "to_full"
            result["estimate_source"] = "measured"
    return result


def battery_test_completion(mode: str, samples: list[dict[str, object]]) -> dict[str, object]:
    """Describe progress and decide when the adaptive workshop test is complete."""
    current = battery_current_session_samples(samples)
    latest = current[-1] if current else {}
    metrics = battery_dashboard_metrics(mode, current)
    elapsed = float(metrics.get("elapsed_seconds") or 0.0)
    try:
        delta = float(metrics.get("delta_percent"))
    except (TypeError, ValueError):
        delta = 0.0
    directional_change = max(0.0, -delta if mode == "discharge" else delta if mode == "charge" else abs(delta))
    try:
        end_percent = float(latest.get("capacity_percent"))
    except (TypeError, ValueError):
        end_percent = None

    reason = ""
    if mode == "discharge" and latest.get("ac_online") is True:
        reason = "power_source_changed"
    elif mode == "charge" and latest.get("ac_online") is False:
        reason = "power_source_changed"
    elif mode == "discharge" and end_percent is not None and end_percent <= BATTERY_TEST_LOW_LEVEL_PERCENT:
        reason = "low_battery"
    elif mode == "charge" and end_percent is not None and end_percent >= BATTERY_TEST_CHARGE_STOP_PERCENT:
        reason = "charged"
    elif str(metrics.get("drop_state") or "") == "critical":
        reason = "rapid_drop"
    elif mode in {"charge", "discharge"} and str(battery_function_assessment(mode, current).get("class_name") or "") == "bad":
        reason = "functional_failure"
    elif elapsed >= BATTERY_TEST_MIN_SECONDS and directional_change >= BATTERY_TEST_TARGET_CHANGE_PERCENT:
        reason = "enough_data"
    elif elapsed >= BATTERY_TEST_MAX_SECONDS:
        reason = "max_duration"

    return {
        "should_finish": bool(reason),
        "reason": reason,
        "elapsed_seconds": elapsed,
        "directional_change_percent": directional_change,
        "end_percent": end_percent,
        "minimum_seconds": float(BATTERY_TEST_MIN_SECONDS),
        "maximum_seconds": float(BATTERY_TEST_MAX_SECONDS),
        "target_change_percent": float(BATTERY_TEST_TARGET_CHANGE_PERCENT),
        "time_goal_reached": elapsed >= BATTERY_TEST_MIN_SECONDS,
        "change_goal_reached": directional_change >= BATTERY_TEST_TARGET_CHANGE_PERCENT,
    }


def battery_test_result(
    mode: str,
    samples: list[dict[str, object]],
    language: str = "DE",
    completion_reason: str = "",
) -> dict[str, object]:
    """Return one understandable overall workshop verdict for a battery test."""
    current = battery_current_session_samples(samples)
    latest = current[-1] if current else {}
    metrics = battery_dashboard_metrics(mode, current)
    completion = battery_test_completion(mode, current)
    health = battery_health_assessment(latest, language)
    function = battery_function_assessment(mode, current, language)
    reason = completion_reason or str(completion.get("reason") or "manual")
    elapsed = float(metrics.get("elapsed_seconds") or 0.0)
    try:
        delta = float(metrics.get("delta_percent"))
    except (TypeError, ValueError):
        delta = None
    directional_change = float(completion.get("directional_change_percent") or 0.0)
    data_sufficient = (
        elapsed >= BATTERY_TEST_MIN_SECONDS
        and directional_change >= BATTERY_TEST_TARGET_CHANGE_PERCENT
    )

    power_values: list[float] = []
    for sample in current:
        try:
            value = abs(float(sample.get("power_w")))
        except (TypeError, ValueError):
            continue
        if math.isfinite(value) and value > 0:
            power_values.append(value)
    average_power = sum(power_values) / len(power_values) if power_values else None

    def L(de: str, en: str, cz: str) -> str:
        return battery_lang(language, de, en, cz)

    function_class = str(function.get("class_name") or "warn")
    health_class = str(health.get("class_name") or "warn")
    health_state = str(health.get("state") or "unknown")
    drop_state = str(metrics.get("drop_state") or "")
    if mode not in {"charge", "discharge"}:
        verdict = L("MOMENTAUFNAHME", "SNAPSHOT", "OKAMZITY STAV")
        class_name = "warn"
        summary = L(
            "Es wurde kein zeitlicher Lade- oder Entladeverlauf geprüft.",
            "No charging or discharging trend was measured over time.",
            "Nebyl meren prubeh nabijeni nebo vybijeni v case.",
        )
        recommendation = L(
            "Für ein belastbares Ergebnis einen Standardtest starten.",
            "Start a standard test for a reliable result.",
            "Pro spolehlivy vysledek spustte standardni test.",
        )
    elif reason == "power_source_changed" or function_class == "bad" or drop_state == "critical" or health_class == "bad":
        verdict = L("NICHT BESTANDEN", "FAILED", "NEVYHOVEL")
        class_name = "bad"
        summary = L(
            "Der Test hat ein Problem beim Akkuverhalten oder bei den gemeldeten Akkudaten erkannt.",
            "The test detected a problem in battery behaviour or reported battery data.",
            "Test zjistil problem v chovani baterie nebo v hlasenych udajich.",
        )
        recommendation = L(
            "Akku, Netzteil und Ladeelektronik prüfen; bei bestätigtem Fehler Akku ersetzen.",
            "Check the battery, adapter and charging electronics; replace the battery if confirmed.",
            "Zkontrolujte baterii, adapter a nabijeci elektroniku; pri potvrzeni baterii vymente.",
        )
    elif drop_state == "warn" or (health_class == "warn" and health_state != "unknown"):
        verdict = L("AUFFÃ„LLIG", "NOTICE", "UPOZORNENI")
        class_name = "warn"
        summary = L(
            "Mindestens ein Messwert sollte geprüft oder durch einen weiteren Test bestätigt werden.",
            "At least one value should be checked or confirmed by another test.",
            "Alespon jednu hodnotu je treba zkontrolovat nebo potvrdit dalsim testem.",
        )
        recommendation = L(
            "Test unter vergleichbarer Nutzung wiederholen und Ergebnis beobachten.",
            "Repeat the test under comparable use and observe the result.",
            "Opakujte test pri srovnatelnem pouziti a sledujte vysledek.",
        )
    elif not data_sufficient or health_state == "unknown":
        verdict = L("EINGESCHRÃ„NKT BEWERTBAR", "LIMITED RESULT", "OMEZENE HODNOCENI")
        class_name = "warn"
        summary = L(
            "Im Testzeitraum trat keine Auffälligkeit auf, die Änderung war für eine genaue Hochrechnung aber zu klein.",
            "No issue appeared during the test, but the change was too small for a precise projection.",
            "Behem testu se neprojevila zavada, ale zmena byla prilis mala pro presny odhad.",
        )
        recommendation = L(
            "Bei Bedarf den Test mit höherer Last oder längerer Laufzeit wiederholen.",
            "If needed, repeat the test with higher load or a longer duration.",
            "V pripade potreby test opakujte s vyssi zatezi nebo delsi dobou.",
        )
    else:
        verdict = L("BESTANDEN", "PASSED", "VYHOVEL")
        class_name = "ok"
        summary = L(
            "Im gemessenen Zeitraum wurden keine Auffälligkeiten beim Akkuverhalten festgestellt.",
            "No abnormal battery behaviour was detected during the measured period.",
            "V merenem obdobi nebylo zjisteno neobvykle chovani baterie.",
        )
        recommendation = L(
            "Kein weiterer Schritt erforderlich.",
            "No further action is required.",
            "Neni nutny zadny dalsi krok.",
        )

    reason_texts = {
        "enough_data": L("Messziel erreicht", "measurement target reached", "cil mereni dosazen"),
        "max_duration": L("Maximaldauer erreicht", "maximum duration reached", "dosazena maximalni doba"),
        "low_battery": L("Sicherheitsgrenze von 15 % erreicht", "15 % safety limit reached", "dosazena bezpecnostni hranice 15 %"),
        "charged": L("Ladeziel von 95 % erreicht", "95 % charge target reached", "dosazen cil nabiti 95 %"),
        "power_source_changed": L("Netzteilstatus während des Tests geändert", "power source changed during the test", "behem testu se zmenil zdroj napajeni"),
        "rapid_drop": L("kritisch schneller Akkuabfall erkannt", "critical battery drop detected", "zjisten kriticky rychly pokles baterie"),
        "functional_failure": L("Funktionsfehler erkannt", "functional failure detected", "zjistena funkcni chyba"),
        "manual": L("manuell beendet", "stopped manually", "ukonceno rucne"),
        "instant": L("Momentaufnahme", "snapshot", "okamzity stav"),
    }
    return {
        "verdict": verdict,
        "class_name": class_name,
        "summary": summary,
        "recommendation": recommendation,
        "completion_reason": reason,
        "completion_text": reason_texts.get(reason, reason_texts["manual"]),
        "data_sufficient": data_sufficient,
        "elapsed_seconds": elapsed,
        "delta_percent": delta,
        "directional_change_percent": directional_change,
        "rate_percent_per_hour": metrics.get("rate_percent_per_hour"),
        "remaining_runtime_seconds": metrics.get("estimate_seconds"),
        "full_runtime_seconds": metrics.get("full_runtime_seconds"),
        "average_power_w": average_power,
        "sample_count": len(current),
        "health": health,
        "function": function,
    }


def battery_level_color(value: object) -> str:
    try:
        percent = float(value)
    except (TypeError, ValueError):
        return "#667085"
    if percent < 20:
        return "#f04438"
    if percent < 50:
        return "#fdb022"
    return "#32d583"


def battery_health_color(value: object) -> str:
    try:
        percent = float(value)
    except (TypeError, ValueError):
        return "#667085"
    if percent < 60:
        return "#f04438"
    if percent < 80:
        return "#fdb022"
    return "#32d583"


def battery_elapsed_text(seconds: float, language: str = "DE") -> str:
    seconds = max(0, int(seconds))
    hours, rest = divmod(seconds, 3600)
    minutes, sec = divmod(rest, 60)
    if language == "EN":
        if hours:
            return f"{hours} h {minutes:02d} min"
        if minutes:
            return f"{minutes} min {sec:02d} sec"
        return f"{sec} sec"
    if language == "CZ":
        if hours:
            return f"{hours} h {minutes:02d} min"
        if minutes:
            return f"{minutes} min {sec:02d} s"
        return f"{sec} s"
    if hours:
        return f"{hours} Std. {minutes:02d} Min."
    if minutes:
        return f"{minutes} Min. {sec:02d} Sek."
    return f"{sec} Sek."


def battery_rate_summary(mode: str, samples: list[dict[str, object]], language: str = "DE") -> list[str]:
    if len(samples) < 2:
        return [
            battery_lang(
                language,
                "Noch nicht genug Messpunkte für eine Bewertung.",
                "Not enough samples for an evaluation yet.",
                "Zatím není dost měření pro vyhodnocení.",
            )
        ]
    start = samples[0]
    end = samples[-1]
    start_time = parse_battery_timestamp(start.get("timestamp"))
    end_time = parse_battery_timestamp(end.get("timestamp"))
    start_capacity = start.get("capacity_percent")
    end_capacity = end.get("capacity_percent")
    if not isinstance(start_capacity, int) or not isinstance(end_capacity, int) or start_time is None or end_time is None:
        return [
            battery_lang(
                language,
                "Noch nicht genug verwertbare Akkudaten für eine Bewertung.",
                "Not enough usable battery data for an evaluation yet.",
                "Zatím není dost použitelných dat baterie pro vyhodnocení.",
            )
        ]
    elapsed_seconds = max(0.0, (end_time - start_time).total_seconds())
    elapsed_hours = elapsed_seconds / 3600.0
    delta = end_capacity - start_capacity
    lines = [
        f"{battery_lang(language, 'Start', 'Start', 'Start')}: {format_battery_timestamp(start.get('timestamp'))} - {start_capacity} %",
        f"{battery_lang(language, 'Ende', 'End', 'Konec')}: {format_battery_timestamp(end.get('timestamp'))} - {end_capacity} %",
        f"{battery_lang(language, 'Dauer', 'Duration', 'Doba')}: {battery_elapsed_text(elapsed_seconds, language)}",
        f"{battery_lang(language, 'Änderung', 'Change', 'Změna')}: {delta:+d} %",
    ]
    if elapsed_hours <= 0 or delta == 0:
        lines.append(
            battery_lang(
                language,
                "Durchschnitt: noch keine messbare Prozent-Ã„nderung",
                "Average: no measurable percentage change yet",
                "Průměr: zatím žádná měřitelná změna procent",
            )
        )
        return lines
    effective_mode = mode
    if mode == "demo":
        effective_mode = "discharge" if delta < 0 else "charge"
    if effective_mode == "discharge":
        drain = start_capacity - end_capacity
        if drain <= 0:
            lines.append(
                battery_lang(
                    language,
                    "Bewertung: Akku hat sich im Entlade-Test nicht entladen.",
                    "Evaluation: Battery did not discharge during the discharge test.",
                    "Vyhodnocení: Baterie se během testu vybíjení nevybíjela.",
                )
            )
            return lines
        rate = drain / elapsed_hours
        runtime = 100.0 / rate if rate else 0
        remaining = end_capacity / rate if rate else 0
        lines.extend(
            [
                f"{battery_lang(language, 'Durchschnitt', 'Average', 'Průměr')}: {rate:.1f} % {battery_lang(language, 'pro Stunde Entladung', 'per hour discharge', 'za hodinu vybíjení')}",
                f"{battery_lang(language, 'Geschätzte Laufzeit von 100 %', 'Estimated runtime from 100 %', 'Odhadovaná výdrž ze 100 %')}: ca. {battery_elapsed_text(runtime * 3600, language)}",
                f"{battery_lang(language, 'Geschätzte Restlaufzeit ab Ende', 'Estimated remaining runtime from end', 'Odhadovaná zbývající výdrž od konce')}: ca. {battery_elapsed_text(remaining * 3600, language)}",
            ]
        )
        drop_state = str(battery_dashboard_metrics(effective_mode, samples).get("drop_state") or "")
        if drop_state:
            lines.append(
                battery_lang(
                    language,
                    "WARNUNG: ungewöhnlich schneller Kapazitätsabfall – Akku unter gleicher Last genauer prüfen.",
                    "WARNING: unusually rapid capacity drop – inspect the battery further under the same load.",
                    "VAROVÃNÃ: neobvykle rychlÃ½ pokles kapacity â€“ baterii dÃ¡le otestujte pÅ™i stejnÃ© zÃ¡tÄ›Å¾i.",
                )
            )
    else:
        gain = end_capacity - start_capacity
        if gain <= 0:
            lines.append(
                battery_lang(
                    language,
                    "Bewertung: Akku hat sich im Lade-Test nicht geladen.",
                    "Evaluation: Battery did not charge during the charge test.",
                    "Vyhodnocení: Baterie se během testu nabíjení nenabíjela.",
                )
            )
            return lines
        rate = gain / elapsed_hours
        to_full = max(0, 100 - end_capacity) / rate if rate else 0
        lines.extend(
            [
                f"{battery_lang(language, 'Durchschnitt', 'Average', 'Průměr')}: {rate:.1f} % {battery_lang(language, 'pro Stunde Ladung', 'per hour charge', 'za hodinu nabíjení')}",
                f"{battery_lang(language, 'GeschÃ¤tzte Zeit bis 100 % ab Ende', 'Estimated time to 100 % from end', 'OdhadovanÃ½ Äas do 100 % od konce')}: ca. {battery_elapsed_text(to_full * 3600, language)}",
            ]
        )
    return lines


def battery_health_rating(health: object, language: str = "DE") -> str:
    if not isinstance(health, (float, int)):
        return battery_missing(language)
    if health > 100:
        return battery_lang(
            language,
            "Über Nennkapazität",
            "Above design capacity",
            "Nad jmenovitou kapacitou",
        )
    if health >= 80:
        return "OK"
    if health >= 60:
        return battery_lang(language, "Prüfen", "Check", "Zkontrolovat")
    return battery_lang(language, "Schwach", "Weak", "Slabá")


def battery_health_assessment(details: dict[str, object], language: str = "DE") -> dict[str, object]:
    """Assess whether the controller-derived capacity health is plausible."""

    def number(value: object) -> float | None:
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            return None
        return numeric if math.isfinite(numeric) else None

    raw_health = number(details.get("health_percent"))
    raw_text = battery_percent_text(raw_health, language)
    reasons: list[str] = []
    voltage = number(details.get("voltage_v"))
    capacity = number(details.get("capacity_percent"))
    energy_now = number(details.get("energy_now"))
    energy_full = number(details.get("energy_full"))
    energy_design = number(details.get("energy_full_design"))

    if voltage is not None and voltage < BATTERY_MIN_PLAUSIBLE_VOLTAGE:
        reasons.append(
            battery_lang(
                language,
                f"unplausible Spannung ({battery_float_text(voltage, ' V', language)})",
                f"implausible voltage ({battery_float_text(voltage, ' V', language)})",
                f"nevěrohodné napětí ({battery_float_text(voltage, ' V', language)})",
            )
        )
    if capacity is not None and not 0 <= capacity <= 100:
        reasons.append(
            battery_lang(
                language,
                "unplausibler Akkustand",
                "implausible battery level",
                "nevěrohodný stav baterie",
            )
        )
    if energy_full is not None and energy_full <= 0:
        reasons.append(
            battery_lang(
                language,
                "Vollkapazität ist ungültig",
                "full capacity is invalid",
                "plná kapacita je neplatná",
            )
        )
    if energy_design is not None and energy_design <= 0:
        reasons.append(
            battery_lang(
                language,
                "Design-Kapazität ist ungültig",
                "design capacity is invalid",
                "konstrukÄnÃ­ kapacita je neplatnÃ¡",
            )
        )
    if energy_now is not None and energy_full and energy_now > energy_full * 1.15:
        reasons.append(
            battery_lang(
                language,
                "aktuelle Kapazität widerspricht der Vollkapazität",
                "current capacity conflicts with full capacity",
                "aktuální kapacita neodpovídá plné kapacitě",
            )
        )
    if raw_health is not None and not 0 < raw_health <= 150:
        reasons.append(
            battery_lang(
                language,
                "unplausibler Kapazitäts-Rohwert",
                "implausible capacity health value",
                "nevěrohodná hodnota zdraví kapacity",
            )
        )

    if raw_health is None:
        return {
            "raw_percent": None,
            "raw_text": raw_text,
            "reliable": False,
            "state": "unknown",
            "display": battery_missing(language),
            "note": battery_lang(
                language,
                "Controllerwert fehlt",
                "Controller value unavailable",
                "Hodnota Å™adiÄe nenÃ­ k dispozici",
            ),
            "detail": battery_lang(
                language,
                "Kapazitätsgesundheit kann nicht berechnet werden.",
                "Capacity health cannot be calculated.",
                "ZdravÃ­ kapacity nelze vypoÄÃ­tat.",
            ),
            "color": "#667085",
            "class_name": "warn",
        }

    if reasons:
        detail = "; ".join(reasons)
        return {
            "raw_percent": raw_health,
            "raw_text": raw_text,
            "reliable": False,
            "state": "unreliable",
            "display": battery_lang(
                language,
                "nicht zuverlässig",
                "unreliable",
                "nespolehlivé",
            ),
            "note": battery_lang(
                language,
                f"Rohwert {raw_text} · Rohdaten unplausibel",
                f"Raw value {raw_text} · implausible data",
                f"Nezpracovaná hodnota {raw_text} · nevěrohodná data",
            ),
            "detail": detail,
            "color": "#f04438",
            "class_name": "bad",
        }

    rating = battery_health_rating(raw_health, language)
    if raw_health > 100:
        state = "above_design"
        note = battery_lang(
            language,
            "über Nennkapazität; bei neuen Akkus möglich",
            "above design capacity; possible with new batteries",
            "nad jmenovitou kapacitou; možné u nových baterií",
        )
    else:
        state = "ok" if raw_health >= 80 else "warn" if raw_health >= 60 else "bad"
        note = battery_lang(
            language,
            f"{rating} · Controller-Kapazitätswert",
            f"{rating} · controller capacity value",
            f"{rating} Â· hodnota kapacity Å™adiÄe",
        )
    return {
        "raw_percent": raw_health,
        "raw_text": raw_text,
        "reliable": True,
        "state": state,
        "display": raw_text,
        "note": note,
        "detail": note,
        "color": battery_health_color(raw_health),
        "class_name": "ok" if raw_health >= 80 else "warn" if raw_health >= 60 else "bad",
    }


def battery_function_assessment(
    mode: str,
    samples: list[dict[str, object]],
    language: str = "DE",
) -> dict[str, object]:
    """Evaluate observed charging/discharging separately from BMS health."""

    def result(state: str, display: str, note: str, color: str, class_name: str) -> dict[str, object]:
        return {
            "state": state,
            "display": display,
            "note": note,
            "color": color,
            "class_name": class_name,
        }

    current = battery_current_session_samples(samples)
    if mode not in {"charge", "discharge"}:
        return result(
            "not_run",
            battery_lang(language, "nicht durchgeführt", "not performed", "neprovedeno"),
            battery_lang(language, "Lade- oder Entlade-Test starten", "Start a charge or discharge test", "Spusťte test nabíjení nebo vybíjení"),
            "#667085",
            "warn",
        )
    if not current:
        return result(
            "pending",
            battery_lang(language, "wird geprüft", "checking", "probíhá kontrola"),
            battery_lang(language, "noch keine Messpunkte", "no samples yet", "zatím žádná měření"),
            "#fdb022",
            "warn",
        )

    latest = current[-1]
    metrics = battery_dashboard_metrics(mode, current)
    elapsed = float(metrics.get("elapsed_seconds") or 0.0)
    delta_value = metrics.get("delta_percent")
    try:
        delta = float(delta_value)
    except (TypeError, ValueError):
        delta = None
    try:
        start_percent = float(current[0].get("capacity_percent"))
    except (TypeError, ValueError):
        start_percent = None

    if mode == "charge":
        if latest.get("ac_online") is False:
            return result(
                "bad",
                battery_lang(language, "Netzteil fehlt", "adapter missing", "chybí adaptér"),
                battery_lang(language, "für den Lade-Test Netzteil anschließen", "connect the adapter for the charge test", "pro test nabíjení připojte adaptér"),
                "#f04438",
                "bad",
            )
        if start_percent is not None and start_percent >= 95:
            return result(
                "limited",
                battery_lang(language, "nahezu voll", "nearly full", "téměř plná"),
                battery_lang(language, "Ladefunktion nahe 100 % nur eingeschränkt prüfbar", "charging near 100 % can only be checked to a limited extent", "nabíjení blízko 100 % lze ověřit jen omezeně"),
                "#32d583",
                "ok",
            )
        if delta is not None and delta > 0:
            return result(
                "ok",
                battery_lang(language, "lädt", "charging works", "nabíjení funguje"),
                f"+{delta:g} % · {battery_elapsed_text(elapsed, language)}",
                "#32d583",
                "ok",
            )
        if elapsed >= BATTERY_CHARGE_STALL_SECONDS:
            return result(
                "bad",
                battery_lang(language, "lädt nicht", "not charging", "nenabíjí se"),
                battery_lang(
                    language,
                    f"{battery_elapsed_text(elapsed, language)} ohne Anstieg",
                    f"no increase for {battery_elapsed_text(elapsed, language)}",
                    f"bez nárůstu po dobu {battery_elapsed_text(elapsed, language)}",
                ),
                "#f04438",
                "bad",
            )
        remaining = max(0.0, BATTERY_CHARGE_STALL_SECONDS - elapsed)
        return result(
            "pending",
            battery_lang(language, "wird geprüft", "checking", "probíhá kontrola"),
            battery_lang(
                language,
                f"noch {battery_elapsed_text(remaining, language)} bis zur Funktionsbewertung",
                f"{battery_elapsed_text(remaining, language)} until functional evaluation",
                f"{battery_elapsed_text(remaining, language)} do vyhodnocení funkce",
            ),
            "#fdb022",
            "warn",
        )

    if latest.get("ac_online") is True:
        return result(
            "bad",
            battery_lang(language, "Netzteil entfernen", "disconnect adapter", "odpojte adaptér"),
            battery_lang(language, "Entlade-Test benötigt Akkubetrieb", "discharge test requires battery power", "test vybíjení vyžaduje provoz na baterii"),
            "#f04438",
            "bad",
        )
    drop_state = str(metrics.get("drop_state") or "")
    if drop_state:
        rate = float(metrics.get("rate_percent_per_hour") or 0.0)
        return result(
            drop_state,
            battery_lang(language, "fällt sehr schnell", "dropping very quickly", "klesá velmi rychle"),
            battery_lang(
                language,
                f"hochgerechnet {rate:.0f} % pro Stunde",
                f"projected {rate:.0f} % per hour",
                f"odhad {rate:.0f} % za hodinu",
            ),
            "#f04438" if drop_state == "critical" else "#fdb022",
            "bad" if drop_state == "critical" else "warn",
        )
    if delta is not None and delta < 0:
        return result(
            "ok",
            battery_lang(language, "entlädt", "discharging works", "vybíjení funguje"),
            f"{delta:g} % · {battery_elapsed_text(elapsed, language)}",
            "#32d583",
            "ok",
        )
    return result(
        "pending",
        battery_lang(language, "wird geprüft", "checking", "probíhá kontrola"),
        battery_lang(language, "noch keine messbare Änderung", "no measurable change yet", "zatím žádná měřitelná změna"),
        "#fdb022",
        "warn",
    )


def battery_mode_report_label(mode: str, language: str = "DE") -> str:
    if mode == "demo":
        return "Demo-Report"
    if mode == "discharge":
        return battery_lang(language, "Entlade-Test", "Discharge test", "Test vybíjení")
    if mode == "charge":
        return battery_lang(language, "Lade-Test", "Charge test", "Test nabíjení")
    return battery_lang(language, "Sofort-Report", "Instant report", "Okamžitý report")


def battery_percent_text(value: object, language: str = "DE") -> str:
    if value in (None, ""):
        return battery_missing(language)
    if isinstance(value, float):
        return f"{value:.1f}".rstrip("0").rstrip(".") + " %"
    return f"{value} %"


def battery_float_text(value: object, suffix: str = "", language: str = "DE") -> str:
    if value in (None, ""):
        return battery_missing(language)
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)
    return f"{numeric:.2f}".rstrip("0").rstrip(".") + suffix


def battery_source_text(status: object, language: str = "DE") -> str:
    status_text = str(status or "").strip().lower()
    if status_text in {"charging", "full", "not charging"}:
        return battery_lang(language, "Netzteil", "Power adapter", "Napájecí adaptér")
    if status_text == "discharging":
        return battery_lang(language, "Akku", "Battery", "Baterie")
    return "-"


def battery_ac_text(details: dict[str, object], language: str = "DE") -> str:
    ac_online = details.get("ac_online")
    ac_name = str(details.get("ac_name") or "").strip()
    if ac_online is True:
        return f"online ({ac_name})" if ac_name else "online"
    if ac_online is False:
        return f"offline ({ac_name})" if ac_name else "offline"
    return battery_missing(language)


def format_battery_timestamp(value: object) -> str:
    stamp = parse_battery_timestamp(value)
    if stamp is None:
        return str(value or "-")
    return stamp.strftime("%d.%m.%Y %H:%M:%S")


def build_battery_test_report(
    mode: str,
    samples: list[dict[str, object]],
    snapshot: dict[str, object] | None = None,
    csv_path: pathlib.Path | None = None,
    language: str = "DE",
) -> str:
    latest = samples[-1] if samples else read_battery_details()
    session_samples = battery_current_session_samples(samples)
    ignored_samples = max(0, len(samples) - len(session_samples))
    mode_label = battery_mode_report_label(mode, language)
    capacity_unit = latest.get("capacity_unit", "")
    missing = battery_missing(language)

    def L(de: str, en: str, cz: str) -> str:
        return battery_lang(language, de, en, cz)

    health_assessment = battery_health_assessment(latest, language)
    function_assessment = battery_function_assessment(mode, session_samples, language)
    function_text = str(function_assessment["display"])
    if function_assessment.get("note"):
        function_text += f" ({function_assessment['note']})"

    lines = [
        f"HardwareCheck {APP_VERSION} - {L('Akku-Report', 'Battery report', 'Report baterie')}",
        f"{L('Testart', 'Test type', 'Typ testu')}: {mode_label}",
        "",
        f"{L('Gerät', 'Device', 'Zařízení')}:",
    ]
    if snapshot:
        lines.extend(
            [
                f"  {L('Hersteller', 'Manufacturer', 'Výrobce')}: {snapshot.get('vendor') or missing}",
                f"  {L('Modell', 'Model', 'Model')}: {snapshot.get('model_name') or missing}",
                f"  {L('Produktnummer', 'Product number', 'ProduktovÃ© ÄÃ­slo')}: {snapshot.get('product_no') or missing}",
                f"  {L('Seriennummer', 'Serial number', 'SÃ©riovÃ© ÄÃ­slo')}: {snapshot.get('serial') or missing}",
                f"  CPU: {snapshot.get('cpu') or missing}",
                f"  {L('Grafik', 'Graphics', 'Grafika')}: {snapshot.get('graphics') or missing}",
            ]
        )
    else:
        lines.append(f"  {missing}")
    lines.extend(
        [
            "",
            f"{L('Akku', 'Battery', 'Baterie')}:",
            f"  Sysfs: {latest.get('path') or missing}",
            f"  Name: {latest.get('name') or missing}",
            f"  {L('Status', 'Status', 'Stav')}: {battery_status_label(latest.get('status'), language)}",
            f"  {L('Rohstatus', 'Raw status', 'Původní stav')}: {battery_status_label(latest.get('status_raw') or latest.get('status'), language)}",
            f"  {L('Netzteil', 'Power adapter', 'Napájecí adaptér')}: {battery_ac_text(latest, language)}",
            f"  {L('Stand', 'Level', 'Stav nabití')}: {battery_report_value(latest.get('capacity_percent'), ' %', language)}",
            f"  {L('Akku-Art', 'Battery type', 'Typ baterie')}: {latest.get('technology') or missing}",
            f"  {L('Hersteller', 'Manufacturer', 'Výrobce')}: {latest.get('manufacturer') or missing}",
            f"  {L('Modell/Produkt', 'Model/product', 'Model/produkt')}: {latest.get('model_name') or missing}",
            f"  {L('Seriennummer', 'Serial number', 'SÃ©riovÃ© ÄÃ­slo')}: {latest.get('serial_number') or missing}",
            f"  {L('Zyklen', 'Cycles', 'Cykly')}: {latest.get('cycle_count') or missing}",
            f"  {L('Design-KapazitÃ¤t', 'Design capacity', 'KonstrukÄnÃ­ kapacita')}: {battery_capacity_text(latest.get('energy_full_design'), capacity_unit, language)}",
            f"  {L('Aktuelle Vollkapazität', 'Current full capacity', 'Aktuální plná kapacita')}: {battery_capacity_text(latest.get('energy_full'), capacity_unit, language)}",
            f"  {L('Aktuelle Kapazität', 'Current capacity', 'Aktuální kapacita')}: {battery_capacity_text(latest.get('energy_now'), capacity_unit, language)}",
            f"  {L('Akku-Gesundheit / KapazitÃ¤tswert (Controller-Rohwert)', 'Battery health / capacity value (controller raw value)', 'ZdravÃ­ baterie / hodnota kapacity (nezpracovanÃ¡ hodnota Å™adiÄe)')}: {health_assessment['raw_text']}",
            f"  {L('Bewertung der Gesundheitsdaten', 'Health data assessment', 'Vyhodnocení údajů o zdraví')}: {health_assessment['display']} ({health_assessment['detail']})",
            f"  {L('FunktionsprÃ¼fung', 'Functional test', 'FunkÄnÃ­ test')}: {function_text}",
            f"  {L('Spannung', 'Voltage', 'Napětí')}: {battery_report_value(latest.get('voltage_v'), ' V', language)}",
            f"  {L('Strom', 'Current', 'Proud')}: {battery_report_value(latest.get('current_a'), ' A', language)}",
            f"  {L('Leistung', 'Power', 'Výkon')}: {battery_report_value(latest.get('power_w'), ' W', language)}",
            "",
            f"{L('Auswertung', 'Evaluation', 'Vyhodnocení')}:",
        ]
    )
    lines.extend(f"  {line}" for line in battery_rate_summary(mode, session_samples, language))
    if ignored_samples:
        lines.append(
            "  "
            + L(
                f"Hinweis: {ignored_samples} alte Messpunkte wurden wegen einer langen Messpause ignoriert.",
                f"Note: {ignored_samples} old samples were ignored because of a long measurement gap.",
                f"Poznamka: {ignored_samples} starsich mereni bylo ignorovano kvuli dlouhe prestavce.",
            )
        )
    lines.extend(
        [
            "",
            f"{L('Messpunkte', 'Samples', 'Měření')}:",
            f"  {L('Anzahl', 'Count', 'PoÄet')}: {len(samples)}",
        ]
    )
    if ignored_samples and lines:
        lines[-1] = lines[-1].replace(f": {len(samples)}", f": {len(session_samples)}")
        lines.append(f"  {L('Ignoriert', 'Ignored', 'Ignorovano')}: {ignored_samples}")
    if csv_path is not None:
        lines.append(f"  CSV: {csv_path}")
    lines.append("")
    return "\n".join(lines)


def build_battery_workshop_report(
    mode: str,
    samples: list[dict[str, object]],
    snapshot: dict[str, object] | None = None,
    csv_path: pathlib.Path | None = None,
    language: str = "DE",
    completion_reason: str = "",
) -> str:
    """Build a concise, printer-friendly battery result for workshop use."""
    latest = samples[-1] if samples else read_battery_details()
    session_samples = battery_current_session_samples(samples)
    start = session_samples[0] if session_samples else latest
    result = battery_test_result(mode, session_samples, language, completion_reason)
    health = result["health"]
    function = result["function"]
    capacity_unit = latest.get("capacity_unit", "")
    missing = battery_missing(language)
    snapshot = snapshot or {}

    def L(de: str, en: str, cz: str) -> str:
        return battery_lang(language, de, en, cz)

    def duration(value: object) -> str:
        if not isinstance(value, (float, int)) or value <= 0:
            return missing
        return battery_elapsed_text(float(value), language)

    delta = result.get("delta_percent")
    delta_text = battery_report_value(delta, " %", language) if delta is not None else missing
    rate = result.get("rate_percent_per_hour")
    rate_text = battery_report_value(abs(float(rate)), " %/h", language) if isinstance(rate, (float, int)) else missing
    average_power = result.get("average_power_w")
    divider = "=" * 62
    lines = [
        L("HARDWARECHECK AKKU-TEST", "HARDWARECHECK BATTERY TEST", "HARDWARECHECK TEST BATERIE"),
        divider,
        f"{L('ERGEBNIS', 'RESULT', 'VYSLEDEK')}: {result['verdict']}",
        str(result["summary"]),
        f"{L('Empfehlung', 'Recommendation', 'Doporuceni')}: {result['recommendation']}",
        divider,
        "",
        L("TESTABLAUF", "TEST SUMMARY", "PRUBEH TESTU"),
        f"  {L('Test', 'Test', 'Test')}: {battery_mode_report_label(mode, language)}",
        f"  {L('Beendet', 'Completed', 'Ukonceni')}: {result['completion_text']}",
        f"  {L('Start', 'Start', 'Start')}: {format_battery_timestamp(start.get('timestamp'))}",
        f"  {L('Ende', 'End', 'Konec')}: {format_battery_timestamp(latest.get('timestamp'))}",
        f"  {L('Dauer', 'Duration', 'Doba')}: {battery_elapsed_text(float(result.get('elapsed_seconds') or 0.0), language)}",
        f"  {L('Messpunkte', 'Samples', 'Mereni')}: {result['sample_count']}",
        f"  {L('Akkustand', 'Battery level', 'Stav baterie')}: {battery_percent_text(start.get('capacity_percent'), language)} -> {battery_percent_text(latest.get('capacity_percent'), language)} ({delta_text})",
        f"  {L('Entlade-/Laderate', 'Discharge/charge rate', 'Rychlost vybijeni/nabijeni')}: {rate_text}",
        f"  {L('Geschaetzte Laufzeit ab 100 %', 'Estimated runtime from 100 %', 'Odhad vydrze od 100 %')}: {duration(result.get('full_runtime_seconds'))}",
        f"  {L('Restlaufzeit am Testende', 'Remaining runtime at test end', 'Zbyvajici vydrz na konci testu')}: {duration(result.get('remaining_runtime_seconds'))}",
        f"  {L('Durchschnittliche Leistung', 'Average power', 'Prumerny vykon')}: {battery_report_value(average_power, ' W', language)}",
        "",
        L("AKKUWERTE", "BATTERY VALUES", "HODNOTY BATERIE"),
        f"  {L('Kapazitaetsgesundheit', 'Capacity health', 'Zdravi kapacity')}: {health['display']}",
        f"  {L('Einordnung', 'Assessment', 'Hodnoceni')}: {health['note']}",
        f"  {L('Funktionspruefung', 'Functional test', 'Funkcni test')}: {function['display']} ({function['note']})",
        f"  {L('Design-Kapazitaet', 'Design capacity', 'Konstrukcni kapacita')}: {battery_capacity_text(latest.get('energy_full_design'), capacity_unit, language)}",
        f"  {L('Aktuelle Vollkapazitaet', 'Current full capacity', 'Aktualni plna kapacita')}: {battery_capacity_text(latest.get('energy_full'), capacity_unit, language)}",
        f"  {L('Spannung', 'Voltage', 'Napeti')}: {battery_report_value(latest.get('voltage_v'), ' V', language)}",
        f"  {L('Ladezyklen', 'Charge cycles', 'Nabijeci cykly')}: {latest.get('cycle_count') or missing}",
        "",
        L("GERAET", "DEVICE", "ZARIZENI"),
        f"  {L('Hersteller', 'Manufacturer', 'Vyrobce')}: {snapshot.get('vendor') or missing}",
        f"  {L('Modell', 'Model', 'Model')}: {snapshot.get('model_name') or missing}",
        f"  {L('Produktnummer', 'Product number', 'Produktove cislo')}: {snapshot.get('product_no') or missing}",
        f"  {L('Seriennummer', 'Serial number', 'Seriove cislo')}: {snapshot.get('serial') or missing}",
        "",
        L(
            "HINWEIS: Die Kapazitaetsgesundheit stammt vom Akku-Controller. Das Gesamtergebnis bewertet zusaetzlich das im Test beobachtete Verhalten.",
            "NOTE: Capacity health is reported by the battery controller. The overall result also evaluates behaviour observed during the test.",
            "POZNAMKA: Zdravi kapacity hlasi ridici jednotka baterie. Celkovy vysledek hodnoti take chovani pozorovane behem testu.",
        ),
    ]
    if csv_path is not None:
        lines.extend(["", f"{L('Messdaten', 'Raw measurements', 'Namerena data')}: {pathlib.Path(csv_path).name}"])
    lines.extend([f"HardwareCheck {APP_VERSION}", ""])
    return "\n".join(lines)


def battery_html_card(title: str, value: object, note: str = "", class_name: str = "") -> str:
    classes = f"card {class_name}".strip()
    note_html = f"<div class=\"note\">{html_escape(note)}</div>" if note else ""
    return (
        f"<div class=\"{classes}\">"
        f"<div class=\"card-title\">{html_escape(title)}</div>"
        f"<div class=\"card-value\">{html_escape(value)}</div>"
        f"{note_html}</div>"
    )


def battery_html_graph(samples: list[dict[str, object]], language: str = "DE") -> str:
    points: list[tuple[str, float]] = []
    for sample in samples:
        value = sample.get("capacity_percent")
        try:
            percent = float(value)
        except (TypeError, ValueError):
            continue
        points.append((format_battery_timestamp(sample.get("timestamp")), max(0.0, min(100.0, percent))))
    if len(points) < 2:
        return (
            f"<p class=\"muted\">{html_escape(battery_lang(language, 'Noch nicht genug Messpunkte für ein Diagramm.', 'Not enough samples for a chart yet.', 'Zatím není dost měření pro graf.'))}</p>"
        )

    width = 920
    height = 300
    pad_left = 52
    pad_right = 22
    pad_top = 24
    pad_bottom = 44
    plot_w = width - pad_left - pad_right
    plot_h = height - pad_top - pad_bottom
    coords: list[str] = []
    for index, (_label, percent) in enumerate(points):
        x = pad_left + (plot_w * index / max(1, len(points) - 1))
        y = pad_top + ((100.0 - percent) / 100.0) * plot_h
        coords.append(f"{x:.1f},{y:.1f}")

    grid_lines = []
    labels = []
    for value in (0, 25, 50, 75, 100):
        y = pad_top + ((100.0 - value) / 100.0) * plot_h
        grid_lines.append(
            f"<line class=\"grid\" x1=\"{pad_left}\" y1=\"{y:.1f}\" x2=\"{width - pad_right}\" y2=\"{y:.1f}\" />"
        )
        labels.append(f"<text class=\"axis\" x=\"12\" y=\"{y + 4:.1f}\">{value}%</text>")

    start_x, start_y = coords[0].split(",", maxsplit=1)
    end_x, end_y = coords[-1].split(",", maxsplit=1)
    start_label = html_escape(points[0][0])
    end_label = html_escape(points[-1][0])
    min_percent = min(percent for _label, percent in points)
    max_percent = max(percent for _label, percent in points)
    return (
        "<div class=\"graph\">"
        f"<svg viewBox=\"0 0 {width} {height}\" role=\"img\" aria-label=\"Akku-Verlauf\">"
        f"<rect x=\"0\" y=\"0\" width=\"{width}\" height=\"{height}\" rx=\"4\" class=\"graph-bg\" />"
        + "".join(grid_lines)
        + "".join(labels)
        + f"<polyline class=\"line\" points=\"{' '.join(coords)}\" />"
        + f"<circle class=\"dot\" cx=\"{start_x}\" cy=\"{start_y}\" r=\"4\" />"
        + f"<circle class=\"dot end\" cx=\"{end_x}\" cy=\"{end_y}\" r=\"4\" />"
        + f"<text class=\"axis\" x=\"{pad_left}\" y=\"{height - 12}\">{start_label}</text>"
        + f"<text class=\"axis end-label\" x=\"{width - pad_right}\" y=\"{height - 12}\">{end_label}</text>"
        + "</svg>"
        + f"<div class=\"graph-note\">{html_escape(battery_lang(language, 'Bereich', 'Range', 'Rozsah'))}: {min_percent:.0f} % {html_escape(battery_lang(language, 'bis', 'to', 'až'))} {max_percent:.0f} %</div>"
        + "</div>"
    )


def build_battery_test_html_report(
    mode: str,
    samples: list[dict[str, object]],
    snapshot: dict[str, object] | None = None,
    csv_path: pathlib.Path | None = None,
    txt_path: pathlib.Path | None = None,
    language: str = "DE",
    completion_reason: str = "",
) -> str:
    latest = samples[-1] if samples else read_battery_details()
    session_samples = battery_current_session_samples(samples)
    ignored_samples = max(0, len(samples) - len(session_samples))
    snapshot = snapshot or {}
    mode_label = battery_mode_report_label(mode, language)
    capacity_unit = latest.get("capacity_unit", "")
    generated = datetime.datetime.now().astimezone().replace(microsecond=0)
    health = latest.get("health_percent")
    missing = battery_missing(language)
    lang_attr = {"DE": "de", "EN": "en", "CZ": "cs"}.get(str(language or "DE").upper(), "de")

    def L(de: str, en: str, cz: str) -> str:
        return battery_lang(language, de, en, cz)

    health_assessment = battery_health_assessment(latest, language)
    function_assessment = battery_function_assessment(mode, session_samples, language)
    workshop_result = battery_test_result(mode, session_samples, language, completion_reason)
    health_class = str(health_assessment.get("class_name") or "")
    function_class = str(function_assessment.get("class_name") or "")

    device_rows = "".join(
        [
            html_label_row(L("Hersteller", "Manufacturer", "Výrobce"), snapshot.get("vendor") or missing),
            html_label_row(L("Modell", "Model", "Model"), snapshot.get("model_name") or missing),
            html_label_row(L("Produktnummer", "Product number", "ProduktovÃ© ÄÃ­slo"), snapshot.get("product_no") or missing),
            html_label_row(L("Seriennummer", "Serial number", "SÃ©riovÃ© ÄÃ­slo"), snapshot.get("serial") or missing),
            html_label_row("CPU", snapshot.get("cpu") or missing),
            html_label_row("HardwareCheck-Version", APP_VERSION),
            html_label_row(L("Berichtszeit", "Report time", "Čas reportu"), generated.strftime("%d.%m.%Y %H:%M:%S")),
        ]
    )
    battery_rows = "".join(
        [
            html_label_row("Sysfs", latest.get("path") or missing),
            html_label_row("Name", latest.get("name") or missing),
            html_label_row(L("Status", "Status", "Stav"), battery_status_label(latest.get("status"), language)),
            html_label_row(L("Rohstatus", "Raw status", "Původní stav"), battery_status_label(latest.get("status_raw") or latest.get("status"), language)),
            html_label_row(L("Netzteil", "Power adapter", "Napájecí adaptér"), battery_ac_text(latest, language)),
            html_label_row(L("Quelle", "Source", "Zdroj"), battery_source_text(latest.get("status"), language)),
            html_label_row(L("Akkustand", "Battery level", "Stav baterie"), battery_percent_text(latest.get("capacity_percent"), language)),
            html_label_row(L("Akku-Art", "Battery type", "Typ baterie"), latest.get("technology") or missing),
            html_label_row(L("Hersteller", "Manufacturer", "Výrobce"), latest.get("manufacturer") or missing),
            html_label_row(L("Modell/Produkt", "Model/product", "Model/produkt"), latest.get("model_name") or missing),
            html_label_row(L("Seriennummer", "Serial number", "SÃ©riovÃ© ÄÃ­slo"), latest.get("serial_number") or missing),
            html_label_row(L("Zyklen", "Cycles", "Cykly"), latest.get("cycle_count") or missing),
            html_label_row(L("Design-KapazitÃ¤t", "Design capacity", "KonstrukÄnÃ­ kapacita"), battery_capacity_text(latest.get("energy_full_design"), capacity_unit, language)),
            html_label_row(L("Aktuelle Vollkapazität", "Current full capacity", "Aktuální plná kapacita"), battery_capacity_text(latest.get("energy_full"), capacity_unit, language)),
            html_label_row(L("Aktuelle Kapazität", "Current capacity", "Aktuální kapacita"), battery_capacity_text(latest.get("energy_now"), capacity_unit, language)),
            html_label_row(
                L("Akku-Gesundheit / Controller-Rohwert", "Battery health / controller raw value", "ZdravÃ­ baterie / nezpracovanÃ¡ hodnota Å™adiÄe"),
                health_assessment["raw_text"],
            ),
            html_label_row(
                L("Bewertung der Gesundheitsdaten", "Health data assessment", "Vyhodnocení údajů o zdraví"),
                f"{health_assessment['display']} ({health_assessment['detail']})",
            ),
            html_label_row(
                L("FunktionsprÃ¼fung", "Functional test", "FunkÄnÃ­ test"),
                f"{function_assessment['display']} ({function_assessment['note']})",
            ),
            html_label_row(L("Spannung", "Voltage", "Napětí"), battery_float_text(latest.get("voltage_v"), " V", language)),
            html_label_row(L("Strom", "Current", "Proud"), battery_float_text(latest.get("current_a"), " A", language)),
            html_label_row(L("Leistung", "Power", "Výkon"), battery_float_text(latest.get("power_w"), " W", language)),
        ]
    )

    measurement_rows = []
    for sample in session_samples:
        sample_unit = sample.get("capacity_unit", capacity_unit)
        measurement_rows.append(
            "<tr>"
            + html_cell(format_battery_timestamp(sample.get("timestamp")))
            + html_cell(battery_status_label(sample.get("status"), language))
            + html_cell(battery_source_text(sample.get("status"), language))
            + html_cell(battery_percent_text(sample.get("capacity_percent"), language), "num")
            + html_cell(battery_float_text(sample.get("power_w"), " W", language), "num")
            + html_cell(battery_float_text(sample.get("voltage_v"), " V", language), "num")
            + html_cell(battery_float_text(sample.get("current_a"), " A", language), "num")
            + html_cell(battery_capacity_text(sample.get("energy_now"), sample_unit, language), "num")
            + html_cell(battery_capacity_text(sample.get("energy_full"), sample_unit, language), "num")
            + "</tr>"
        )
    if not measurement_rows:
        measurement_rows.append(
            f"<tr><td colspan=\"9\" class=\"muted\">{html_escape(L('Keine Messpunkte vorhanden.', 'No samples available.', 'Nejsou k dispozici žádná měření.'))}</td></tr>"
        )

    evaluation_lines = [
        f"{L('Gesamtergebnis', 'Overall result', 'Celkovy vysledek')}: {workshop_result['verdict']}",
        str(workshop_result["summary"]),
        f"{L('Empfehlung', 'Recommendation', 'Doporuceni')}: {workshop_result['recommendation']}",
        f"{L('FunktionsprÃ¼fung', 'Functional test', 'FunkÄnÃ­ test')}: "
        f"{function_assessment['display']} ({function_assessment['note']})",
        f"{L('Gesundheitsdaten', 'Health data', 'Údaje o zdraví')}: "
        f"{health_assessment['display']} ({health_assessment['detail']})",
    ]
    evaluation_lines.extend(battery_rate_summary(mode, session_samples, language))
    if ignored_samples:
        evaluation_lines.append(
            L(
                f"Hinweis: {ignored_samples} alte Messpunkte wurden wegen einer langen Messpause ignoriert.",
                f"Note: {ignored_samples} old samples were ignored because of a long measurement gap.",
                f"Poznamka: {ignored_samples} starsich mereni bylo ignorovano kvuli dlouhe prestavce.",
            )
        )
    evaluation_items = "".join(f"<li>{html_escape(line)}</li>" for line in evaluation_lines)
    file_rows = []
    if csv_path is not None:
        file_rows.append(html_label_row(L("CSV-Rohdaten", "CSV raw data", "CSV data"), csv_path))
    if txt_path is not None:
        file_rows.append(html_label_row("TXT-Report", txt_path))
    if not file_rows:
        file_rows.append(html_label_row(L("Ablage", "Storage", "Uložení"), missing))

    samples = session_samples
    return f"""<!DOCTYPE html>
<html lang="{html_escape(lang_attr)}">
<head>
<meta charset="utf-8">
<title>{html_escape(L('HardwareCheck Akku-Report', 'HardwareCheck battery report', 'HardwareCheck report baterie'))}</title>
<style>
body {{
    font-family: "Segoe UI", Arial, sans-serif;
    background: #181818;
    color: #f0f0f0;
    margin: 44px 60px;
    line-height: 1.35;
}}
h1 {{
    color: #11d8e8;
    font-size: 40pt;
    font-weight: 300;
    margin: 0 0 8px 0;
}}
h2 {{
    color: #11eef4;
    font-size: 15pt;
    letter-spacing: .08em;
    margin: 42px 0 8px 0;
    text-transform: uppercase;
}}
.subtitle, .muted, .note, .graph-note {{
    color: #9aa0a6;
}}
.cards {{
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin: 22px 0 30px 0;
}}
.card {{
    background: #272727;
    border-left: 4px solid #11d8e8;
    min-width: 180px;
    padding: 12px 16px;
}}
.card.ok {{ border-left-color: #7fd18b; }}
.card.warn {{ border-left-color: #ffd166; }}
.card.bad {{ border-left-color: #ff7b7b; }}
.card-title {{
    color: #bdbdbd;
    font-size: 10pt;
    text-transform: uppercase;
}}
.card-value {{
    color: #ffffff;
    font-size: 23pt;
    margin-top: 4px;
}}
table {{
    border-collapse: collapse;
    table-layout: fixed;
    min-width: 760px;
    max-width: 1180px;
    width: 100%;
}}
th, td {{
    padding: 7px 10px;
    text-align: left;
    vertical-align: top;
    overflow-wrap: anywhere;
}}
th {{
    color: #c9c9c9;
    font-weight: 600;
    background: #303030;
}}
tr:nth-child(even) td {{ background: #242424; }}
tr:nth-child(odd) td {{ background: #1e1e1e; }}
td.label {{
    color: #c2c2c2;
    font-weight: 600;
    width: 245px;
}}
td.num {{
    text-align: right;
    white-space: nowrap;
}}
.graph {{
    max-width: 980px;
    background: #111820;
    border: 1px solid #334155;
    padding: 14px 16px;
}}
.graph-bg {{
    fill: #101820;
}}
.grid {{
    stroke: #2f4152;
    stroke-width: 1;
}}
.axis {{
    fill: #a8b2be;
    font-size: 12px;
}}
.end-label {{
    text-anchor: end;
}}
.line {{
    fill: none;
    stroke: #11d8e8;
    stroke-width: 3;
}}
.dot {{
    fill: #ffd166;
}}
.dot.end {{
    fill: #7fd18b;
}}
li {{
    margin: 4px 0;
}}
</style>
</head>
<body>
<h1>{html_escape(L('Akku-Report', 'Battery report', 'Report baterie'))}</h1>
<div class="subtitle">HardwareCheck {html_escape(APP_VERSION)} · {html_escape(mode_label)} · {html_escape(generated.strftime("%d.%m.%Y %H:%M:%S"))}</div>
<div class="cards">
{battery_html_card(L("Gesamtergebnis", "Overall result", "Celkovy vysledek"), workshop_result["verdict"], workshop_result["summary"], workshop_result["class_name"])}
{battery_html_card(L("Akkustand", "Battery level", "Stav baterie"), battery_percent_text(latest.get("capacity_percent"), language), battery_status_label(latest.get("status"), language))}
{battery_html_card(L("Kapazitätsgesundheit", "Capacity health", "Zdraví kapacity"), health_assessment["display"], health_assessment["note"], health_class)}
{battery_html_card(L("FunktionsprÃ¼fung", "Functional test", "FunkÄnÃ­ test"), function_assessment["display"], function_assessment["note"], function_class)}
{battery_html_card(L("Leistung", "Power", "Výkon"), battery_float_text(latest.get("power_w"), " W", language), battery_source_text(latest.get("status"), language))}
{battery_html_card(L("Messpunkte", "Samples", "Měření"), len(samples), L("1 Messpunkt pro Minute", "1 sample per minute", "1 měření za minutu"))}
</div>
<h2>System</h2>
<table>{device_rows}</table>
<h2>{html_escape(L("Akku", "Battery", "Baterie"))}</h2>
<table>{battery_rows}</table>
<h2>{html_escape(L("Akku-Verlauf", "Battery usage", "Průběh baterie"))}</h2>
{battery_html_graph(session_samples, language)}
<h2>{html_escape(L("Auswertung", "Evaluation", "Vyhodnocení"))}</h2>
<ul>{evaluation_items}</ul>
<h2>{html_escape(L("Messpunkte", "Samples", "Měření"))}</h2>
<table>
<thead><tr><th>{html_escape(L("Zeit", "Time", "Čas"))}</th><th>{html_escape(L("Status", "Status", "Stav"))}</th><th>{html_escape(L("Quelle", "Source", "Zdroj"))}</th><th>{html_escape(L("Akkustand", "Battery level", "Stav baterie"))}</th><th>{html_escape(L("Leistung", "Power", "Výkon"))}</th><th>{html_escape(L("Spannung", "Voltage", "Napětí"))}</th><th>{html_escape(L("Strom", "Current", "Proud"))}</th><th>{html_escape(L("Kapazität", "Capacity", "Kapacita"))}</th><th>{html_escape(L("Vollkapazität", "Full capacity", "Plná kapacita"))}</th></tr></thead>
<tbody>{''.join(measurement_rows)}</tbody>
</table>
<h2>{html_escape(L("Dateien", "Files", "Soubory"))}</h2>
<table>{''.join(file_rows)}</table>
</body>
</html>
"""


def get_system_snapshot() -> dict[str, object]:
    vendor = read_text("/sys/class/dmi/id/sys_vendor")
    model = read_text("/sys/class/dmi/id/product_name")
    serial = read_text("/sys/class/dmi/id/product_serial")
    product_no = read_text("/sys/class/dmi/id/product_sku")
    version = read_text("/sys/class/dmi/id/product_version")
    cpu_name = get_cpu_name()
    graphics_name = get_graphics_name()

    modules, total_slots = parse_dmidecode_memory()
    total_slots = infer_min_ram_slots(vendor, model, product_no, version, modules, total_slots)
    installed_gb = sum(module.size_gb for module in modules)
    ram_type = best_ram_type(modules)
    max_speed = max(
        [value for module in modules for value in (module.configured_speed_mhz, module.speed_mhz) if value],
        default=None,
    )
    ram_layout = build_ram_layout(modules)

    drm_resolution = get_drm_resolution()
    xrandr_resolution = get_xrandr_resolution()
    resolution = drm_resolution or xrandr_resolution
    raw_inches = parse_edid_inches()
    display_size_source = "EDID" if raw_inches else "Fallback"
    model_hint = " ".join([model, version, product_no])
    inches = nearest_display_size(raw_inches) or infer_display_size_from_model(model_hint, resolution)
    oled = "OLED" in run_command("xrandr", "--prop").upper()
    display_type = detect_display_type(resolution, oled)

    storage_rows = get_storage_rows()
    primary_row = next((row for row in storage_rows if str(row.get("type") or "").lower() == "disk"), {})
    primary_type = detect_disk_type(primary_row) if primary_row else ""
    primary_size = nearest_disk_size_gb(int(primary_row.get("size") or 0)) if primary_row else None
    storage_lines = []
    disk_index = 0
    optical_index = 0
    for index, row in enumerate(storage_rows):
        row_type = str(row.get("type") or "").lower()
        model_name = clean_storage_model(row.get("model"), row.get("vendor"))
        if row_type == "rom":
            optical_type = detect_optical_type(row)
            suffix = f" ({model_name})" if model_name else ""
            storage_lines.append(f"DVD {optical_index}: {optical_type}{suffix}".strip())
            optical_index += 1
            continue

        disk_type = detect_disk_type(row)
        size_bytes = int(row.get("size") or 0)
        size_gb = nearest_disk_size_gb(size_bytes)
        size_text = f"{size_gb} GB" if size_gb else f"{round(size_bytes / (1024 ** 3), 1)} GiB"
        if disk_type == "SATA SSD 2.5" and size_gb and re.search(r"\bin+n?ovation\s*it\b", model_name, flags=re.IGNORECASE):
            model_name = f"Innovation IT {size_gb}GB SSD"
        suffix = f" ({model_name})" if model_name else ""
        storage_lines.append(f"Disk {disk_index}: {size_text} {disk_type}{suffix}".strip())
        disk_index += 1

    battery_status, battery_capacity = get_battery_info()

    snapshot: dict[str, object] = {
        "vendor": vendor,
        "vendor_short": vendor_short(vendor),
        "model_name": model,
        "product_version": version,
        "serial": serial,
        "product_no": product_no if product_no not in {"", "Not Specified", "Default string"} else "",
        "cpu": cpu_name or "Unbekannte CPU",
        "cpu_short": get_cpu_short(cpu_name or ""),
        "graphics": graphics_name,
        "ram_modules": modules,
        "ram_total_gb": installed_gb,
        "ram_slots_total": total_slots,
        "ram_type": ram_type,
        "ram_layout": ram_layout,
        "ram_max_mhz": max_speed,
        "resolution": resolution,
        "xorg_resolution": xrandr_resolution or resolution,
        "expected_resolution": "",
        "resolution_source": "DRM" if drm_resolution else ("Xorg" if xrandr_resolution else ""),
        "display_type": display_type,
        "display_inches": inches,
        "display_size_source": display_size_source if inches else "",
        "storage_lines": storage_lines,
        "primary_storage_type": primary_type,
        "primary_disk_gb": primary_size,
        "battery_status": battery_status,
        "battery_capacity": battery_capacity,
    }
    apply_resolution_label_fallback(snapshot)
    return snapshot


def load_model_db() -> list[dict[str, object]]:
    try:
        return json.loads(get_models_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []


def storage_sizes_equivalent(first: object, second: object) -> bool:
    try:
        first_size = int(round(float(first)))
        second_size = int(round(float(second)))
    except (TypeError, ValueError):
        return False
    if first_size == second_size:
        return True
    if first_size <= 0 or second_size <= 0:
        return False
    equivalent_groups = (
        {120, 128},
        {240, 250, 256},
        {480, 500, 512},
        {960, 1000, 1024},
        {1920, 2000, 2048},
        {3840, 4000, 4096},
    )
    return any(first_size in group and second_size in group for group in equivalent_groups)


def storage_types_equivalent(first: object, second: object) -> bool:
    first_token = normalize_generic_token(str(first or ""))
    second_token = normalize_generic_token(str(second or ""))
    if not first_token or not second_token:
        return False
    if first_token == second_token:
        return True

    def storage_kind(token: str) -> str:
        if "nvme" in token:
            return "nvme"
        if "emmc" in token:
            return "emmc"
        if "hdd" in token:
            return "hdd"
        if "sata" in token and "ssd" in token:
            return "sata-ssd"
        if "ssd" in token:
            return "ssd"
        return token

    return storage_kind(first_token) == storage_kind(second_token)


def ssd_size_match_score(hw: int | None, db: int | float | None) -> int:
    if hw is None or db is None:
        return 0
    if storage_sizes_equivalent(hw, db):
        return 12
    diff = abs(hw - int(float(db)))
    if diff <= 16:
        return 6
    if diff <= 32:
        return 2
    return -8


def apply_display_database_fallback(snapshot: dict[str, object], model_hint: str) -> None:
    resolution = str(snapshot.get("resolution") or "")
    inches = display_inches_number(snapshot.get("display_inches"))
    is_large_hd_panel = inches is not None and inches >= 17.0 and parse_resolution(resolution) == (1366, 768)
    if not is_fallback_resolution(resolution) and snapshot.get("display_type") and not is_large_hd_panel:
        return

    best_score = -1
    best_item: dict[str, object] | None = None
    for item in load_model_db():
        if normalize_generic_token(str(item.get("vendor") or "")) != normalize_generic_token(str(snapshot["vendor_short"])):
            continue

        cpu_db = normalize_cpu_token(str(item.get("cpu") or ""))
        cpu_hw = normalize_cpu_token(str(snapshot["cpu_short"]))
        if not cpu_db or not cpu_hw:
            continue
        if cpu_db == cpu_hw:
            score = 40
        elif cpu_db in cpu_hw or cpu_hw in cpu_db:
            score = 25
        else:
            continue

        if product_number_matches(snapshot, item):
            score += 35

        db_ram_total = item.get("ram_total")
        if db_ram_total not in (None, ""):
            if int(float(db_ram_total)) != int(snapshot["ram_total_gb"]):
                continue
            score += 8

        score += max(0, ssd_size_match_score(snapshot["primary_disk_gb"], item.get("ssd")))

        storage_type = str(snapshot["primary_storage_type"])
        db_storage = str(item.get("storage_type") or "")
        if storage_type and db_storage and storage_family(storage_type) == storage_family(db_storage):
            score += 6

        note_text = str(item.get("note") or "").lower()
        model_text = model_hint.lower()
        model_family = re.search(r"\b\d{2}-[a-z]{2}", model_text)
        if model_family and model_family.group(0) in note_text:
            score += 15

        db_inch = item.get("inch")
        hw_inch = snapshot.get("display_inches")
        if db_inch not in (None, "") and isinstance(hw_inch, (float, int)) and compare_inches(float(hw_inch), float(db_inch)):
            score += 10

        if score > best_score:
            best_score = score
            best_item = item

    if best_score >= 45 and best_item:
        db_type = str(best_item.get("display_type") or "").strip()
        db_inch = best_item.get("inch")
        changed = False
        if db_inch not in (None, "") and not snapshot.get("display_inches"):
            snapshot["display_inches"] = float(db_inch)
            changed = True
        effective_inches = snapshot.get("display_inches") or db_inch
        db_type = normalize_display_type_for_size(db_type, effective_inches)
        if db_type and (not snapshot.get("display_type") or is_large_hd_panel):
            snapshot["display_type"] = db_type
            changed = True
        expected_resolution = expected_resolution_from_display_type(db_type, effective_inches)
        if expected_resolution:
            snapshot["expected_resolution"] = expected_resolution
        if changed:
            snapshot["display_size_source"] = "Datenbank"

    if not snapshot.get("display_type") and is_fallback_resolution(resolution):
        inches = snapshot.get("display_inches")
        model_text = model_hint.lower()
        if (isinstance(inches, (float, int)) and float(inches) >= 17.0) or re.search(r"\b17[-\s]", model_text):
            snapshot["display_type"] = "Full HD"
            snapshot["expected_resolution"] = expected_resolution_from_display_type("Full HD")
            if not snapshot.get("display_size_source"):
                snapshot["display_size_source"] = "Fallback"


def apply_resolution_label_fallback(snapshot: dict[str, object]) -> None:
    resolution = str(snapshot.get("resolution") or "")
    if resolution and not snapshot.get("xorg_resolution"):
        snapshot["xorg_resolution"] = resolution
    if resolution and not snapshot.get("resolution_source"):
        snapshot["resolution_source"] = "System"


def translated_match_word(language: str) -> str:
    return {"DE": "Treffer", "EN": "Match", "CZ": "Shoda"}.get(language, "Match")


def translated_best_match(language: str) -> str:
    return {"DE": "BESTER TREFFER", "EN": "BEST MATCH", "CZ": "NEJLEPÅ Ã SHODA"}.get(language, "BEST MATCH")


def t_lang(language: str, de: str, en: str, cz: str) -> str:
    language = str(language or "DE").strip().upper()
    return {"DE": de, "EN": en, "CZ": cz}.get(language, de)


def translate_status_text(message: str, language: str) -> str:
    language = str(language or "DE").strip().upper()
    text = format_database_versions_in_text(message)
    if language == "DE":
        return (
            text.replace("verfuegbar", "verfügbar")
            .replace("ungültig", "ungültig")
            .replace("läuft", "läuft")
            .replace("Aufloesung", "Auflösung")
        )
    replacements = {
        "EN": [
            ("DB-Update verfuegbar", "DB update available"),
            ("DB-Update verfügbar", "DB update available"),
            ("DB-Update: verbinde", "DB update: connecting"),
            ("DB-Update: aktuell", "DB update: current"),
            ("Programm-Update verfuegbar", "Program update available"),
            ("Programm-Update verfügbar", "Program update available"),
            ("Programm-Update bereit", "Program update ready"),
            ("Programm-Update wartet auf WLAN-Verbindung", "Program update waits for Wi-Fi"),
            ("Programm-Update: verbinde", "Program update: connecting"),
            ("Programm-Update: aktuell", "Program update: current"),
            ("Programm aktuell", "Program current"),
            ("DB aktuell", "DB current"),
            ("Auto-Check: pruefe DB und Programm", "Auto-check: checking DB and program"),
            ("Auto-Check: DB und Programm aktuell", "Auto-check: DB and program current"),
            ("Auto-Check DB", "Auto-check DB"),
            ("Auto-Check Programm", "Auto-check program"),
            ("Model-Update", "DB update"),
            ("Treffer neu berechnet", "matches refreshed"),
            ("Status gemeldet", "Status reported"),
            ("Statusmeldung fehlgeschlagen", "Status report failed"),
            ("Manifest ungültig", "manifest invalid"),
            ("Manifest ungültig", "manifest invalid"),
            ("falsches Paket", "wrong package"),
            ("Version fehlt", "version missing"),
            ("Download-URL fehlt", "download URL missing"),
            ("SHA256 fehlt", "SHA256 missing"),
            ("SHA256 passt nicht", "SHA256 mismatch"),
            ("ZIP ungültig", "ZIP invalid"),
            ("ZIP ungültig", "ZIP invalid"),
            ("DNS-Aufloesung fehlgeschlagen", "DNS lookup failed"),
            ("DNS-Auflösung fehlgeschlagen", "DNS lookup failed"),
            ("Verbindung zu GitHub dauert zu lange", "GitHub connection timed out"),
            ("Uhrzeit/Zertifikat falsch", "clock/certificate wrong"),
            ("GitHub nicht erreichbar", "GitHub unreachable"),
            ("Netzwerk/Datei-Fehler", "network/file error"),
            ("kein beschreibbarer HardwareCheck-Ordner gefunden", "no writable HardwareCheck folder found"),
            ("Stick unter Windows reparieren oder neu erstellen", "repair the stick in Windows or recreate it"),
            ("Antwort von GitHub ungültig", "GitHub response invalid"),
            ("Antwort von GitHub ungültig", "GitHub response invalid"),
            ("Update läuft bereits", "Update already running"),
            ("Update läuft bereits", "Update already running"),
            ("Hardware-Scan abgeschlossen", "Hardware scan complete"),
            ("Scanne Hardware", "Scanning hardware"),
            ("pruefe Updates", "checking updates"),
            ("suche Netzwerk", "searching network"),
            ("lade Manifest", "loading manifest"),
            ("lade model.json", "loading model.json"),
            ("lade Programm-Manifest", "loading program manifest"),
            ("lade Programm-ZIP", "loading program ZIP"),
            ("pruefe Programm-ZIP", "checking program ZIP"),
            ("pruefe DB", "checking DB"),
            ("pruefe Programm", "checking program"),
            ("synchronisiere Uhr", "syncing clock"),
            ("scanne WLAN", "scanning Wi-Fi"),
            ("verbinde WLAN", "connecting Wi-Fi"),
            ("WLAN gespeichert", "Wi-Fi saved"),
            ("WLAN", "Wi-Fi"),
        ],
        "CZ": [
            ("DB-Update verfuegbar", "DB update k dispozici"),
            ("DB-Update verfügbar", "DB update k dispozici"),
            ("DB-Update: verbinde", "DB update: pripojuji"),
            ("DB-Update: aktuell", "DB update: aktualni"),
            ("Programm-Update verfuegbar", "Update programu k dispozici"),
            ("Programm-Update verfügbar", "Update programu k dispozici"),
            ("Programm-Update bereit", "Update programu pripraven"),
            ("Programm-Update wartet auf WLAN-Verbindung", "Update programu ceka na Wi-Fi"),
            ("Programm-Update: verbinde", "Update programu: pripojuji"),
            ("Programm-Update: aktuell", "Update programu: aktualni"),
            ("Programm aktuell", "Program aktualni"),
            ("DB aktuell", "DB aktualni"),
            ("Auto-Check: pruefe DB und Programm", "Auto-check: kontroluji DB a program"),
            ("Auto-Check: DB und Programm aktuell", "Auto-check: DB a program aktualni"),
            ("Auto-Check DB", "Auto-check DB"),
            ("Auto-Check Programm", "Auto-check program"),
            ("Model-Update", "DB update"),
            ("Treffer neu berechnet", "shoda pÅ™epoÄÃ­tÃ¡na"),
            ("Status gemeldet", "Status odeslán"),
            ("Statusmeldung fehlgeschlagen", "Odeslání statusu selhalo"),
            ("Manifest ungültig", "manifest neplatny"),
            ("Manifest ungültig", "manifest neplatny"),
            ("falsches Paket", "Å¡patnÃ½ balÃ­Äek"),
            ("Version fehlt", "chybí verze"),
            ("Download-URL fehlt", "chybí URL ke stažení"),
            ("SHA256 fehlt", "chybi SHA256"),
            ("SHA256 passt nicht", "SHA256 nesouhlasi"),
            ("ZIP ungültig", "ZIP neplatny"),
            ("ZIP ungültig", "ZIP neplatny"),
            ("DNS-Aufloesung fehlgeschlagen", "DNS selhalo"),
            ("DNS-Auflösung fehlgeschlagen", "DNS selhalo"),
            ("Verbindung zu GitHub dauert zu lange", "Spojeni na GitHub vyprselo"),
            ("Uhrzeit/Zertifikat falsch", "spatny cas/certifikat"),
            ("GitHub nicht erreichbar", "GitHub nedostupny"),
            ("Netzwerk/Datei-Fehler", "chyba sítě/souboru"),
            ("kein beschreibbarer HardwareCheck-Ordner gefunden", "nenalezena zapisovatelna slozka HardwareCheck"),
            ("Stick unter Windows reparieren oder neu erstellen", "opravte USB ve Windows nebo ho vytvorte znovu"),
            ("Antwort von GitHub ungültig", "neplatna odpoved GitHub"),
            ("Antwort von GitHub ungültig", "neplatna odpoved GitHub"),
            ("Update läuft bereits", "Update už běží"),
            ("Update läuft bereits", "Update už běží"),
            ("Hardware-Scan abgeschlossen", "Scan hotov"),
            ("Scanne Hardware", "Skenuji hardware"),
            ("pruefe Updates", "kontroluji update"),
            ("suche Netzwerk", "hledám síť"),
            ("lade Manifest", "naÄÃ­tÃ¡m manifest"),
            ("lade model.json", "naÄÃ­tÃ¡m model.json"),
            ("lade Programm-Manifest", "naÄÃ­tÃ¡m manifest programu"),
            ("lade Programm-ZIP", "naÄÃ­tÃ¡m ZIP programu"),
            ("pruefe Programm-ZIP", "kontroluji ZIP programu"),
            ("pruefe DB", "kontroluji DB"),
            ("pruefe Programm", "kontroluji program"),
            ("synchronisiere Uhr", "synchronizuji Äas"),
            ("scanne WLAN", "hledám Wi-Fi"),
            ("verbinde WLAN", "připojuji Wi-Fi"),
            ("WLAN gespeichert", "Wi-Fi uložena"),
            ("WLAN", "Wi-Fi"),
        ],
    }
    translated = text
    for source, target in replacements.get(language, []):
        translated = translated.replace(source, target)
    return translated


def translated_battery_line(status: str, capacity: str, language: str) -> str:
    return f"{t_lang(language, 'Akku', 'Battery', 'Baterie')}: {translated_battery_status_text(status, language)} {capacity}".strip()


def translated_battery_status_text(status: str, language: str) -> str:
    return battery_status_label(status, language)


def display_match_percent(score: object) -> int:
    try:
        value = int(round(float(score or 0)))
    except (TypeError, ValueError):
        value = 0
    return max(0, min(100, value))


def format_match_line(score: int, item: dict[str, object], best: bool, language: str = "DE") -> str:
    score = display_match_percent(score)
    line = str(item.get("model_id") or "Unknown")
    keyboard = str(item.get("keyboard_layout") or "").strip().upper()
    condition = str(item.get("condition") or "").strip().upper()
    color = str(item.get("color") or "").strip()
    suffixes = []
    if keyboard in {"DE", "FR", "IT", "EN", "CZ", "ES", "PT", "US", "UK", "BE", "NL", "PL", "SK"}:
        suffixes.append(keyboard)
    if condition in {"REF", "REFURB", "REFURBISHED", "RFB"}:
        suffixes.append("REF")
    if color and color.upper() != "NONE":
        suffixes.append(color)
    if suffixes:
        line += " (" + ", ".join(suffixes) + ")"
    line += f" ({score}% {translated_match_word(language)})"
    if best:
        return f"{translated_best_match(language)}: {line}"
    return line


def score_model_candidate(
    snapshot: dict[str, object],
    item: dict[str, object],
    include_exclusion_reason: bool = False,
) -> dict[str, object] | None:
    reasons: list[str] = []

    def excluded(reason: str) -> dict[str, object] | None:
        if not include_exclusion_reason:
            return None
        return {"score": 0, "item": item, "reasons": reasons + [reason], "excluded": reason}

    if normalize_generic_token(str(item.get("vendor") or "")) != normalize_generic_token(str(snapshot.get("vendor_short") or "")):
        return excluded("Hersteller passt nicht.")

    score = 0
    hw_products = snapshot_product_numbers(snapshot)
    db_products = row_product_numbers(item)
    matched_products = sorted(set(hw_products).intersection(db_products))
    product_match = bool(matched_products)
    if product_match:
        score += 45
        reasons.append(f"Produktkennung passt ({', '.join(matched_products)}): +45")
    else:
        reasons.append("Produktkennung: kein direkter Treffer")

    cpu_db = normalize_cpu_token(str(item.get("cpu") or ""))
    cpu_hw = normalize_cpu_token(str(snapshot.get("cpu_short") or ""))
    cpu_mismatch = False
    if cpu_db == cpu_hw:
        score += 40
        reasons.append("CPU exakt passend: +40")
    elif cpu_db and cpu_hw and (cpu_db in cpu_hw or cpu_hw in cpu_db):
        score += 25
        reasons.append("CPU aehnlich passend: +25")
    elif cpu_db and cpu_hw:
        cpu_mismatch = True
        reasons.append(f"CPU abweichend: Geraet {snapshot.get('cpu_short') or snapshot.get('cpu')}, DB {item.get('cpu')}")
        if not product_match:
            return excluded("CPU passt nicht und keine passende Produktkennung.")

    db_ram_total = item.get("ram_total")
    if db_ram_total not in (None, ""):
        try:
            db_ram_int = int(float(db_ram_total))
            hw_ram_int = int(snapshot.get("ram_total_gb") or 0)
        except (TypeError, ValueError):
            db_ram_int = hw_ram_int = -1
        if db_ram_int != hw_ram_int:
            return excluded(f"RAM gesamt passt nicht: DB {db_ram_total} GB, Geraet {snapshot.get('ram_total_gb')} GB.")
        reasons.append("RAM gesamt passend")

    if same_or_empty(str(snapshot.get("ram_type") or ""), str(item.get("ram_type") or "")):
        if snapshot.get("ram_type") and item.get("ram_type"):
            score += 10
            reasons.append("RAM-Typ passend: +10")
    elif item.get("ram_type"):
        reasons.append(f"RAM-Typ abweichend: Geraet {snapshot.get('ram_type')}, DB {item.get('ram_type')}")

    if same_ram_layout_or_empty(str(snapshot.get("ram_layout") or ""), str(item.get("ram_layout") or "")):
        if snapshot.get("ram_layout") and item.get("ram_layout"):
            score += 10
            reasons.append("RAM-Layout passend: +10")
    elif item.get("ram_layout"):
        reasons.append(f"RAM-Layout abweichend: Geraet {snapshot.get('ram_layout')}, DB {item.get('ram_layout')}")

    ssd_score = ssd_size_match_score(snapshot.get("primary_disk_gb"), item.get("ssd"))
    score += ssd_score
    if ssd_score:
        reasons.append(f"Speicher-Groesse passend: +{ssd_score}")
    ssd_mismatch = snapshot.get("primary_disk_gb") is not None and item.get("ssd") not in (None, "") and ssd_score < 12
    if ssd_mismatch:
        reasons.append(f"Speicher-Groesse abweichend: Geraet {snapshot.get('primary_disk_gb')} GB, DB {item.get('ssd')} GB")
    storage_type_mismatch = False

    storage_type = str(snapshot.get("primary_storage_type") or "")
    db_storage = str(item.get("storage_type") or "")
    if storage_type and db_storage:
        if normalize_generic_token(storage_type) == normalize_generic_token(db_storage):
            score += 10
            reasons.append("Speicher-Typ passend: +10")
        elif storage_family(storage_type) == storage_family(db_storage):
            score += 4
            reasons.append("Speicher-Familie passend: +4")
        else:
            score -= 8
            storage_type_mismatch = True
            reasons.append(f"Speicher-Typ abweichend: Geraet {storage_type}, DB {db_storage}: -8")

    if same_or_empty(str(snapshot.get("display_type") or ""), str(item.get("display_type") or "")):
        if snapshot.get("display_type") and item.get("display_type"):
            score += 10
            reasons.append("Display-Typ passend: +10")
    elif item.get("display_type"):
        reasons.append(f"Display-Typ abweichend: Geraet {snapshot.get('display_type')}, DB {item.get('display_type')}")

    db_optical = normalize_optical_drive(str(item.get("optical_drive") or ""))
    storage_lines = snapshot.get("storage_lines") or []
    hw_optical = "DVD-RW" if any(
        re.search(r"\b(DVD|CD|Blu-ray)\b", str(line), flags=re.IGNORECASE)
        for line in storage_lines
    ) else ""
    hw_optical = normalize_optical_drive(hw_optical)
    if db_optical and hw_optical:
        if normalize_generic_token(db_optical) == normalize_generic_token(hw_optical):
            score += 12
            reasons.append("Optisches Laufwerk passend: +12")
        else:
            score -= 12
            reasons.append(f"Optisches Laufwerk abweichend: Geraet {hw_optical}, DB {db_optical}: -12")
    elif db_optical or hw_optical:
        score -= 12
        reasons.append("Optisches Laufwerk nur auf einer Seite vorhanden: -12")

    db_inch = item.get("inch")
    hw_inch = snapshot.get("display_inches")
    if db_inch not in (None, ""):
        try:
            if compare_inches(hw_inch, float(db_inch)):
                score += 10
                reasons.append("Display-Groesse passend: +10")
            else:
                reasons.append(f"Display-Groesse abweichend: Geraet {hw_inch}\", DB {db_inch}\"")
        except (TypeError, ValueError):
            pass

    if ssd_mismatch:
        score = min(score, 90)
        reasons.append("Deckel: wegen Speicher-Groesse maximal 90")
    if storage_type_mismatch:
        score = min(score, 80)
        reasons.append("Deckel: wegen Speicher-Typ maximal 80")
    if cpu_mismatch:
        score = min(score, 65)
        reasons.append("Deckel: wegen abweichender CPU maximal 65")

    raw_score = score
    score = display_match_percent(score)
    if raw_score > score:
        reasons.append(f"Anzeige auf {score}% begrenzt")

    return {"score": score, "raw_score": raw_score, "item": item, "reasons": reasons, "excluded": ""}


def get_model_match_results(
    snapshot: dict[str, object],
    entries: list[dict[str, object]] | None = None,
) -> list[dict[str, object]]:
    entries = entries if entries is not None else load_model_db()
    results: list[dict[str, object]] = []
    for item in entries:
        result = score_model_candidate(snapshot, item)
        if result is not None:
            results.append(result)
    return sorted(results, key=lambda entry: int(entry.get("score") or 0), reverse=True)


def format_model_match_results(results: list[dict[str, object]], language: str = "DE", limit: int = 6) -> list[str]:
    if not results:
        return ["Kein Treffer in der Datenbank"]
    lines: list[str] = []
    for index, result in enumerate(results[:limit]):
        item = result.get("item") if isinstance(result.get("item"), dict) else {}
        lines.append(format_match_line(int(result.get("score") or 0), item, best=(index == 0), language=language))
    return lines


def get_model_matches(snapshot: dict[str, object], language: str = "DE", limit: int = 6) -> list[str]:
    entries = load_model_db()
    if not entries:
        return ["Keine model.json geladen"]
    return format_model_match_results(get_model_match_results(snapshot, entries), language, limit=limit)


def find_model_db_items(
    query: str,
    limit: int = 30,
    entries: list[dict[str, object]] | None = None,
) -> list[dict[str, object]]:
    entries = entries if entries is not None else load_model_db()
    query_norm = normalize_generic_token(query)
    terms: list[str] = []
    for part in re.split(r"[\s,;|/+]+", str(query or "")):
        term = normalize_generic_token(part)
        if term and term not in terms:
            terms.append(term)
    if query_norm and not terms:
        terms = [query_norm]
    if not terms:
        return entries[:limit]

    def add_unique(target: list[dict[str, object]], item: dict[str, object], seen: set[int]) -> None:
        key = id(item)
        if key not in seen:
            seen.add(key)
            target.append(item)

    def id_tokens(item: dict[str, object]) -> set[str]:
        tokens: set[str] = set()
        fields = [
            item.get("model_id", ""),
            item.get("base_model_id", ""),
            item.get("refurbished_ids", ""),
        ]
        for field in fields:
            for part in re.split(r"[\s,;|/+]+", str(field or "")):
                token = normalize_generic_token(part)
                if token:
                    tokens.add(token)
        return tokens

    def haystack(item: dict[str, object]) -> str:
        fields: list[object] = []
        for key, value in item.items():
            key_token = normalize_generic_token(str(key))
            if "serial" in key_token or key_token in {"seriennummer", "servicetag"}:
                continue
            fields.append(value)
        return normalize_generic_token(" ".join(str(field) for field in fields))

    exact: list[dict[str, object]] = []
    partial: list[dict[str, object]] = []
    exact_seen: set[int] = set()
    partial_seen: set[int] = set()

    for term in terms:
        for item in entries:
            if term in id_tokens(item):
                add_unique(exact, item, exact_seen)

    scored_partial: list[tuple[int, dict[str, object]]] = []
    for item in entries:
        if id(item) in exact_seen:
            continue
        text = haystack(item)
        hits = sum(1 for term in terms if term in text)
        if hits == len(terms):
            scored_partial.append((1000 + hits, item))
        elif hits and len(terms) > 1:
            scored_partial.append((hits, item))

    for _score, item in sorted(scored_partial, key=lambda pair: pair[0], reverse=True):
        add_unique(partial, item, partial_seen)

    return (exact + partial)[:limit]


def model_value_int(value: object) -> int:
    try:
        if value in (None, ""):
            return 0
        return int(float(str(value).replace(",", ".")))
    except (TypeError, ValueError):
        return 0


def model_is_refurbished(item: dict[str, object]) -> bool:
    text = f"{item.get('condition') or ''} {item.get('note') or ''}"
    return bool(re.search(r"\bREF(?:URBISHED|URB)?\b|\[REFURBISHED\]", text, flags=re.IGNORECASE))


def model_ram_summary(item: dict[str, object]) -> str:
    total = model_value_int(item.get("ram_total"))
    details: list[str] = []
    for key, label in (("ram_onboard", "Onboard"), ("ram_slot1", "Slot 1"), ("ram_slot2", "Slot 2")):
        value = model_value_int(item.get(key))
        if value:
            details.append(f"{label} = {value} GB")
    ram_type = str(item.get("ram_type") or "").strip()
    ram_layout = str(item.get("ram_layout") or "").strip()
    if ram_type:
        details.append(ram_type)
    if ram_layout:
        details.append(ram_layout)
    total_text = f"{total} GB" if total else "-"
    return f"{total_text} ({', '.join(details)})" if details else total_text


def model_storage_summary(item: dict[str, object]) -> str:
    drives: list[str] = []
    for size_key, type_key in (("ssd", "storage_type"), ("ssd_2", "storage_type_2")):
        size = model_value_int(item.get(size_key))
        storage_type = str(item.get(type_key) or "").strip()
        if normalize_generic_token(storage_type) in {"none", "no", "n/a", "na", "-"}:
            storage_type = ""
        if size or storage_type:
            drives.append(" ".join(part for part in (f"{size} GB" if size else "", storage_type) if part))
    optical = str(item.get("optical_drive") or "").strip()
    if optical and normalize_generic_token(optical) not in {"none", "no", "n/a", "na", "-", "kein", "keins"}:
        drives.append(optical)
    return " + ".join(drives) or "-"


def model_display_summary(item: dict[str, object]) -> str:
    inch = str(item.get("inch") or item.get("display_size") or item.get("display_inch") or "").strip()
    display_type = str(item.get("display_type") or "").strip()
    parts = [f'{inch}"' if inch and inch not in {"0", "0.0"} else "", display_type]
    return " ".join(part for part in parts if part) or "-"


def model_condition_summary(item: dict[str, object]) -> str:
    condition = str(item.get("condition") or "").strip()
    if re.fullmatch(r"(?i)(ref|refurb|refurbished|general[- ]?uberholt|general[- ]?ueberholt)", condition):
        condition = ""
    color = str(item.get("color") or "").strip()
    return " | ".join(part for part in (condition, color) if part) or "-"


def model_notebook_summary(item: dict[str, object]) -> str:
    refurbished = "(Refurbished)" if model_is_refurbished(item) else ""
    vendor = str(item.get("vendor") or "").strip()
    product = str(item.get("product_number") or item.get("product_number_2") or "").strip()
    cpu = str(item.get("cpu") or "").strip()
    return " - ".join(part for part in (refurbished, vendor, product, cpu) if part) or "-"


def model_compare_entries(item: dict[str, object], language: str = "DE") -> list[tuple[str, str, str]]:
    return [
        ("notebook", t_lang(language, "Notebook", "Notebook", "Notebook"), model_notebook_summary(item)),
        ("operating_system", t_lang(language, "Betriebssystem", "Operating system", "OperaÄnÃ­ systÃ©m"), str(item.get("operating_system") or "").strip() or "-"),
        ("ram", t_lang(language, "Arbeitsspeicher", "Memory", "OperaÄnÃ­ pamÄ›Å¥"), model_ram_summary(item)),
        ("storage", t_lang(language, "Festplatte", "Storage", "Úložiště"), model_storage_summary(item)),
        ("display", t_lang(language, "Display", "Display", "Displej"), model_display_summary(item)),
        ("condition", t_lang(language, "Zustand / Farbe", "Condition / Color", "Stav / Barva"), model_condition_summary(item)),
        ("software", t_lang(language, "Software", "Software", "Software"), str(item.get("software") or "").strip() or "-"),
    ]


def snapshot_compare_entries(snapshot: dict[str, object], language: str = "DE") -> list[tuple[str, str, str, bool]]:
    vendor = str(snapshot.get("vendor_short") or snapshot.get("vendor") or "").strip()
    product = str(snapshot.get("product_no") or snapshot.get("model_name") or "").strip()
    cpu = str(snapshot.get("cpu_short") or snapshot.get("cpu") or "").strip()
    notebook = " - ".join(part for part in (vendor, product, cpu) if part) or "-"
    ram_item: dict[str, object] = {
        "ram_total": snapshot.get("ram_total_gb"),
        "ram_type": snapshot.get("ram_type"),
        "ram_layout": snapshot.get("ram_layout"),
    }
    storage_parts = [
        f"{snapshot.get('primary_disk_gb')} GB" if snapshot.get("primary_disk_gb") not in (None, "") else "",
        str(snapshot.get("primary_storage_type") or "").strip(),
    ]
    inch = snapshot.get("display_inches")
    display_parts = [f'{inch}"' if inch not in (None, "") else "", str(snapshot.get("display_type") or "").strip()]
    unknown = t_lang(language, "Im Live-System nicht erkennbar", "Not detectable in the live system", "V live systému nelze zjistit")
    return [
        ("notebook", t_lang(language, "Notebook", "Notebook", "Notebook"), notebook, notebook != "-"),
        ("operating_system", t_lang(language, "Betriebssystem", "Operating system", "OperaÄnÃ­ systÃ©m"), unknown, False),
        ("ram", t_lang(language, "Arbeitsspeicher", "Memory", "OperaÄnÃ­ pamÄ›Å¥"), model_ram_summary(ram_item), bool(snapshot.get("ram_total_gb"))),
        ("storage", t_lang(language, "Festplatte", "Storage", "Úložiště"), " ".join(part for part in storage_parts if part) or "-", snapshot.get("primary_disk_gb") not in (None, "")),
        ("display", t_lang(language, "Display", "Display", "Displej"), " ".join(part for part in display_parts if part) or "-", bool(snapshot.get("display_type") or inch)),
        ("condition", t_lang(language, "Zustand / Farbe", "Condition / Color", "Stav / Barva"), unknown, False),
        ("software", t_lang(language, "Software", "Software", "Software"), unknown, False),
    ]


def model_similarity_score(base: dict[str, object], other: dict[str, object]) -> int:
    score = 0
    if normalize_generic_token(str(base.get("vendor") or "")) and normalize_generic_token(str(base.get("vendor") or "")) == normalize_generic_token(str(other.get("vendor") or "")):
        score += 15
    base_cpu = normalize_cpu_token(str(base.get("cpu") or ""))
    other_cpu = normalize_cpu_token(str(other.get("cpu") or ""))
    if base_cpu and base_cpu == other_cpu:
        score += 35
    if model_value_int(base.get("ram_total")) and model_value_int(base.get("ram_total")) == model_value_int(other.get("ram_total")):
        score += 15
    if model_value_int(base.get("ssd")) and model_value_int(base.get("ssd")) == model_value_int(other.get("ssd")):
        score += 8
    if model_value_int(base.get("ssd_2")) and model_value_int(base.get("ssd_2")) == model_value_int(other.get("ssd_2")):
        score += 4
    if normalize_generic_token(str(base.get("storage_type") or "")) and normalize_generic_token(str(base.get("storage_type") or "")) == normalize_generic_token(str(other.get("storage_type") or "")):
        score += 8
    if normalize_generic_token(str(base.get("storage_type_2") or "")) and normalize_generic_token(str(base.get("storage_type_2") or "")) == normalize_generic_token(str(other.get("storage_type_2") or "")):
        score += 4
    if normalize_generic_token(str(base.get("display_type") or "")) and normalize_generic_token(str(base.get("display_type") or "")) == normalize_generic_token(str(other.get("display_type") or "")):
        score += 10
    if normalize_generic_token(str(base.get("operating_system") or "")) and normalize_generic_token(str(base.get("operating_system") or "")) == normalize_generic_token(str(other.get("operating_system") or "")):
        score += 5
    if normalize_generic_token(str(base.get("keyboard_layout") or "")) and normalize_generic_token(str(base.get("keyboard_layout") or "")) == normalize_generic_token(str(other.get("keyboard_layout") or "")):
        score += 5
    return min(score, 100)


def snapshot_model_similarity_score(snapshot: dict[str, object], candidate: dict[str, object]) -> int:
    """Score only reliable live-device fields and normalize them to 100 percent."""
    matched_weight = 0
    available_weight = 0

    def add(weight: int, available: bool, matches: bool) -> None:
        nonlocal matched_weight, available_weight
        if not available:
            return
        available_weight += weight
        if matches:
            matched_weight += weight

    vendor = str(snapshot.get("vendor_short") or snapshot.get("vendor") or "").strip()
    add(
        15,
        bool(vendor),
        normalize_generic_token(vendor) == normalize_generic_token(str(candidate.get("vendor") or "")),
    )

    cpu = str(snapshot.get("cpu_short") or snapshot.get("cpu") or "").strip()
    cpu_token = normalize_cpu_token(cpu)
    add(35, bool(cpu_token), cpu_token == normalize_cpu_token(str(candidate.get("cpu") or "")))

    ram_total = snapshot.get("ram_total_gb")
    add(
        15,
        ram_total not in (None, ""),
        model_value_int(ram_total) == model_value_int(candidate.get("ram_total")),
    )

    disk_size = snapshot.get("primary_disk_gb")
    add(
        8,
        disk_size not in (None, ""),
        storage_sizes_equivalent(disk_size, candidate.get("ssd")),
    )

    storage_type = str(snapshot.get("primary_storage_type") or "").strip()
    add(
        8,
        bool(storage_type),
        storage_types_equivalent(storage_type, candidate.get("storage_type")),
    )

    display_type = str(snapshot.get("display_type") or "").strip()
    add(
        10,
        bool(display_type),
        normalize_generic_token(display_type)
        == normalize_generic_token(str(candidate.get("display_type") or "")),
    )

    operating_system = str(snapshot.get("operating_system") or "").strip()
    add(
        5,
        bool(operating_system),
        normalize_generic_token(operating_system)
        == normalize_generic_token(str(candidate.get("operating_system") or "")),
    )

    keyboard_layout = str(snapshot.get("keyboard_layout") or "").strip()
    add(
        5,
        bool(keyboard_layout),
        normalize_generic_token(keyboard_layout)
        == normalize_generic_token(str(candidate.get("keyboard_layout") or "")),
    )

    if available_weight <= 0:
        return 0
    return min(100, max(0, round((matched_weight / available_weight) * 100)))


def score_snapshot_model_for_finder(
    snapshot: dict[str, object],
    candidate: dict[str, object],
) -> dict[str, object]:
    """Build a finder result without changing HardwareCheck's established main matcher."""
    finder_score = snapshot_model_similarity_score(snapshot, candidate)
    legacy = score_model_candidate(snapshot, candidate, include_exclusion_reason=True) or {}
    reasons = [f"Finder-Vergleich der erkannten Hardwarefelder: {finder_score}%"]
    reasons.extend(str(reason) for reason in legacy.get("reasons", []) if str(reason).strip())
    return {
        "score": finder_score,
        "raw_score": finder_score,
        "item": candidate,
        "reasons": reasons,
        "excluded": "",
    }


def model_option_matches(candidate: dict[str, object], base: dict[str, object], key: str) -> bool:
    if key == "notebook":
        vendor = normalize_generic_token(str(base.get("vendor") or ""))
        cpu = normalize_cpu_token(str(base.get("cpu") or ""))
        if vendor and normalize_generic_token(str(candidate.get("vendor") or "")) != vendor:
            return False
        if cpu and normalize_cpu_token(str(candidate.get("cpu") or "")) != cpu:
            return False
        base_products = set(row_product_numbers(base))
        candidate_products = set(row_product_numbers(candidate))
        return not base_products or not candidate_products or bool(base_products.intersection(candidate_products))
    if key == "operating_system":
        base_value = normalize_generic_token(str(base.get("operating_system") or ""))
        return not base_value or normalize_generic_token(str(candidate.get("operating_system") or "")) == base_value
    if key == "ram":
        if model_value_int(candidate.get("ram_total")) != model_value_int(base.get("ram_total")):
            return False
        for field in ("ram_type", "ram_layout"):
            base_value = normalize_generic_token(str(base.get(field) or ""))
            if base_value and normalize_generic_token(str(candidate.get(field) or "")) != base_value:
                return False
        return True
    if key == "storage":
        return (
            storage_sizes_equivalent(candidate.get("ssd"), base.get("ssd"))
            and storage_types_equivalent(candidate.get("storage_type"), base.get("storage_type"))
            and storage_sizes_equivalent(candidate.get("ssd_2"), base.get("ssd_2"))
            and (
                not candidate.get("storage_type_2")
                and not base.get("storage_type_2")
                or storage_types_equivalent(candidate.get("storage_type_2"), base.get("storage_type_2"))
            )
        )
    if key == "display":
        candidate_inch = display_inches_number(candidate.get("inch"))
        base_inch = display_inches_number(base.get("inch"))
        inch_matches = candidate_inch is None or base_inch is None or compare_inches(candidate_inch, base_inch)
        return inch_matches and normalize_generic_token(str(candidate.get("display_type") or "")) == normalize_generic_token(str(base.get("display_type") or ""))
    if key == "condition":
        return normalize_generic_token(model_condition_summary(candidate)) == normalize_generic_token(model_condition_summary(base))
    if key == "software":
        return normalize_generic_token(str(candidate.get("software") or "")) == normalize_generic_token(str(base.get("software") or ""))
    return True


def model_matches_snapshot_option(candidate: dict[str, object], snapshot: dict[str, object], key: str) -> bool | None:
    if key == "notebook":
        vendor_matches = normalize_generic_token(str(candidate.get("vendor") or "")) == normalize_generic_token(str(snapshot.get("vendor_short") or snapshot.get("vendor") or ""))
        cpu_db = normalize_cpu_token(str(candidate.get("cpu") or ""))
        cpu_hw = normalize_cpu_token(str(snapshot.get("cpu_short") or snapshot.get("cpu") or ""))
        cpu_matches = bool(cpu_db and cpu_hw and (cpu_db == cpu_hw or cpu_db in cpu_hw or cpu_hw in cpu_db))
        hw_products = set(snapshot_product_numbers(snapshot))
        db_products = set(row_product_numbers(candidate))
        product_matches = not hw_products or not db_products or bool(hw_products.intersection(db_products))
        return vendor_matches and cpu_matches and product_matches
    if key == "operating_system":
        return None
    if key == "ram":
        if snapshot.get("ram_total_gb") in (None, ""):
            return None
        if model_value_int(candidate.get("ram_total")) != model_value_int(snapshot.get("ram_total_gb")):
            return False
        ram_type = normalize_generic_token(str(snapshot.get("ram_type") or ""))
        ram_layout = normalize_generic_token(str(snapshot.get("ram_layout") or ""))
        type_matches = not ram_type or not candidate.get("ram_type") or normalize_generic_token(str(candidate.get("ram_type") or "")) == ram_type
        layout_matches = not ram_layout or not candidate.get("ram_layout") or normalize_generic_token(str(candidate.get("ram_layout") or "")) == ram_layout
        return type_matches and layout_matches
    if key == "storage":
        if snapshot.get("primary_disk_gb") in (None, ""):
            return None
        size_matches = ssd_size_match_score(model_value_int(snapshot.get("primary_disk_gb")), model_value_int(candidate.get("ssd"))) >= 6
        hw_type = str(snapshot.get("primary_storage_type") or "")
        db_type = str(candidate.get("storage_type") or "")
        type_matches = not hw_type or not db_type or storage_types_equivalent(hw_type, db_type)
        return size_matches and type_matches
    if key == "display":
        hw_inch = display_inches_number(snapshot.get("display_inches"))
        db_inch = display_inches_number(candidate.get("inch"))
        hw_type = normalize_generic_token(str(snapshot.get("display_type") or ""))
        db_type = normalize_generic_token(str(candidate.get("display_type") or ""))
        if hw_inch is None and not hw_type:
            return None
        inch_matches = hw_inch is None or db_inch is None or compare_inches(hw_inch, db_inch)
        type_matches = not hw_type or not db_type or hw_type == db_type
        return inch_matches and type_matches
    if key in {"condition", "software"}:
        return None
    return None


def model_relation_signature(item: dict[str, object]) -> tuple[object, ...]:
    return (
        normalize_generic_token(str(item.get("vendor") or "")),
        normalize_generic_token(str(item.get("product_number") or "")),
        normalize_generic_token(str(item.get("product_number_2") or "")),
        normalize_cpu_token(str(item.get("cpu") or "")),
        model_value_int(item.get("ram_total")),
        normalize_generic_token(str(item.get("ram_type") or "")),
        normalize_generic_token(str(item.get("ram_layout") or "")),
        model_value_int(item.get("ssd")),
        normalize_generic_token(str(item.get("storage_type") or "")),
        model_value_int(item.get("ssd_2")),
        normalize_generic_token(str(item.get("storage_type_2") or "")),
        str(item.get("inch") or "").strip(),
        normalize_generic_token(str(item.get("display_type") or "")),
        normalize_generic_token(str(item.get("operating_system") or "")),
        normalize_generic_token(str(item.get("keyboard_layout") or "")),
        normalize_generic_token(str(item.get("color") or "")),
    )


def build_model_relation_map(entries: list[dict[str, object]]) -> dict[str, tuple[list[str], list[str]]]:
    grouped: dict[tuple[tuple[object, ...], bool], list[str]] = {}
    for item in entries:
        model_id = str(item.get("model_id") or "").strip()
        if not model_id:
            continue
        grouped.setdefault((model_relation_signature(item), model_is_refurbished(item)), []).append(model_id)
    for values in grouped.values():
        values.sort(key=lambda value: (model_value_int(value), value))
    relations: dict[str, tuple[list[str], list[str]]] = {}
    for item in entries:
        model_id = str(item.get("model_id") or "").strip()
        if not model_id:
            continue
        signature = model_relation_signature(item)
        if model_is_refurbished(item):
            base_ids = [value for value in grouped.get((signature, False), []) if value != model_id]
            refurb_ids = [model_id]
        else:
            base_ids = [model_id]
            refurb_ids = [value for value in grouped.get((signature, True), []) if value != model_id]
        relations[model_id] = (base_ids, refurb_ids)
    return relations


def format_model_database_detail(item: dict[str, object], language: str = "DE", percent: int | None = None) -> str:
    model_id = str(item.get("model_id") or "-").strip()
    title = f"{model_id} {model_notebook_summary(item)}".strip()
    if percent is not None:
        title += f" - {t_lang(language, 'Ã„hnlichkeit', 'Similarity', 'Podobnost')}: {display_match_percent(percent)}%"
    lines = [
        title,
        "",
        f"CPU: {str(item.get('cpu') or '-').strip()}",
        f"RAM: {model_ram_summary(item)}",
        f"{t_lang(language, 'Speicher', 'Storage', 'Úložiště')}: {model_storage_summary(item)}",
        f"{t_lang(language, 'Anzeige', 'Display', 'Displej')}: {model_display_summary(item)}",
        f"OS: {str(item.get('operating_system') or '-').strip()}",
        f"{t_lang(language, 'Tastatur', 'Keyboard', 'Klávesnice')}: {str(item.get('keyboard_layout') or '-').strip()}",
        f"{t_lang(language, 'Produktnummer', 'Product number', 'ProduktovÃ© ÄÃ­slo')}: {str(item.get('product_number') or '-').strip()}",
        f"{t_lang(language, 'Produktnummer 2', 'Product number 2', 'ProduktovÃ© ÄÃ­slo 2')}: {str(item.get('product_number_2') or '-').strip()}",
        f"Info: {str(item.get('info') or '-').strip()}",
        f"Software: {str(item.get('software') or '-').strip()}",
    ]
    note = str(item.get("note") or "").strip()
    if note:
        lines.extend(["", f"{t_lang(language, 'Notiz', 'Note', 'Poznámka')}: {note}"])
    return "\n".join(lines)


def format_model_detail_text(
    snapshot: dict[str, object],
    result: dict[str, object],
    language: str = "DE",
) -> str:
    item = result.get("item") if isinstance(result.get("item"), dict) else {}
    score = int(result.get("score") or 0)
    shown_score = display_match_percent(score)
    raw_score = result.get("raw_score")
    raw_score_note = ""
    if isinstance(raw_score, (int, float)) and int(raw_score) > shown_score:
        raw_score_note = f" (Rohwert {int(raw_score)})"
    excluded = str(result.get("excluded") or "").strip()
    hw_product_keys = ", ".join(snapshot_product_numbers(snapshot)) or "-"
    serial_note = {
        "DE": "Seriennummer wird bewusst ignoriert.",
        "EN": "Serial number is intentionally ignored.",
        "CZ": "Seriove cislo se zamerne ignoruje.",
    }.get(str(language).upper(), "Seriennummer wird bewusst ignoriert.")

    def val(key: str) -> str:
        value = item.get(key, "")
        return str(value).strip() if value not in (None, "") else "-"

    lines = [
        f"Modell {val('model_id')} - {shown_score}% {translated_match_word(language)}{raw_score_note}",
        f"Hinweis: {excluded}" if excluded else "",
        "",
        "Datenbank:",
        f"  Hersteller: {val('vendor')}",
        f"  CPU: {val('cpu')}",
        f"  RAM: {val('ram_total')} GB | {val('ram_type')} | {val('ram_layout')}",
        f"  Speicher: {val('ssd')} GB {val('storage_type')}",
        f"  Anzeige: {val('inch')}\" {val('display_type')}",
        f"  Tastatur/Farbe/Zustand: {val('keyboard_layout')} | {val('color')} | {val('condition')}",
        f"  Produktnummer: {val('product_number')}",
        f"  Produktnummer 2: {val('product_number_2')}",
        f"  Refurbished/Basis: {val('refurbished_ids')} | {val('base_model_id')}",
        f"  Info/Software: {val('info')} | {val('software')}",
        "",
        "Geraet:",
        f"  Hersteller: {snapshot.get('vendor_short') or snapshot.get('vendor') or '-'}",
        f"  CPU: {snapshot.get('cpu_short') or snapshot.get('cpu') or '-'}",
        f"  RAM: {snapshot.get('ram_total_gb') or '-'} GB | {snapshot.get('ram_type') or '-'} | {snapshot.get('ram_layout') or '-'}",
        f"  Speicher: {snapshot.get('primary_disk_gb') or '-'} GB {snapshot.get('primary_storage_type') or '-'}",
        f"  Anzeige: {snapshot.get('display_inches') or '-'}\" {snapshot.get('display_type') or '-'}",
        f"  Produktnummer: {snapshot.get('product_no') or '-'}",
        f"  Produktkennungen: {hw_product_keys}",
        f"  Modellname: {snapshot.get('model_name') or '-'}",
        "",
        "Bewertung:",
        f"  - {serial_note}",
    ]
    reasons = result.get("reasons")
    if isinstance(reasons, list) and reasons:
        lines.extend(f"  - {reason}" for reason in reasons)
    else:
        lines.append("  - Keine Detailgruende vorhanden.")
    note = val("note")
    if note != "-":
        lines.extend(["", "Notiz:", textwrap.fill(note, width=90)])
    return "\n".join(line for line in lines if line is not None)


def build_report(snapshot: dict[str, object], matches: list[str], language: str = "DE") -> str:
    unknown = t_lang(language, "Unbekannt", "Unknown", "Neznámé")
    identity = load_device_identity()
    device_name = str(identity.get("display_name") or identity.get("device_name") or identity.get("device_id") or "").strip()
    lines = [
        f"{APP_TITLE}",
        f"{t_lang(language, 'Stick', 'Stick', 'Stick')}: {device_name}" if device_name else "",
        "",
        f"CPU: {snapshot['cpu']}",
        f"{t_lang(language, 'Grafik', 'Graphics', 'Grafika')}: {snapshot.get('graphics') or unknown}",
        "",
        "RAM:",
    ]
    modules: list[RamModule] = snapshot["ram_modules"]  # type: ignore[assignment]
    for index, module in enumerate(modules, start=1):
        speed = module.configured_speed_mhz or module.speed_mhz or "?"
        rtype = module.ram_type or snapshot["ram_type"] or "Unknown"
        lines.append(f"  Slot {index}: {module.size_gb} GB, {speed} MT/s, {rtype}")
    if snapshot["ram_slots_total"] and snapshot["ram_slots_total"] > len(modules):
        for index in range(len(modules) + 1, int(snapshot["ram_slots_total"]) + 1):
            lines.append(f"  Slot {index}: {t_lang(language, 'LEER', 'EMPTY', 'PRÃZDNÃ')}")
    lines.extend(
        [
            f"  {t_lang(language, 'Installiert', 'Installed', 'Instalováno')}: {snapshot['ram_total_gb']} GB",
            f"  {t_lang(language, 'Typ', 'Type', 'Typ')}: {snapshot['ram_type'] or unknown}",
            f"  Layout: {snapshot['ram_layout'] or unknown}",
            "",
            f"{t_lang(language, 'Anzeige', 'Display', 'Displej')}:",
            f"  {t_lang(language, 'Auflösung', 'Resolution', 'Rozlišení')}: {snapshot['resolution'] or unknown}",
            f"  {t_lang(language, 'Typ', 'Type', 'Typ')}: {snapshot['display_type'] or unknown}",
            f"  {t_lang(language, 'Größe', 'Size', 'Velikost')}: {snapshot['display_inches'] or unknown}\"",
            "",
            f"{t_lang(language, 'Datenträger', 'Storage', 'Úložiště')}:",
        ]
    )
    lines.extend(f"  {line}" for line in snapshot["storage_lines"])
    lines.extend(
        [
            "",
            f"{t_lang(language, 'Identifikation', 'Identification', 'Identifikace')}:",
            f"  {t_lang(language, 'Hersteller', 'Vendor', 'Výrobce')}: {snapshot['vendor'] or unknown}",
            f"  {t_lang(language, 'Modell', 'Model', 'Model')}: {snapshot['model_name'] or unknown}",
            f"  {t_lang(language, 'Seriennummer', 'Serial', 'SÃ©riovÃ© ÄÃ­slo')}: {snapshot['serial'] or unknown}",
            f"  {t_lang(language, 'Produktnummer', 'Product number', 'ProduktovÃ© ÄÃ­slo')}: {snapshot['product_no'] or unknown}",
            "",
            f"{t_lang(language, 'Modellvorschläge', 'Model suggestions', 'Návrhy modelu')}:",
        ]
    )
    lines.extend(f"  {line}" for line in matches)
    lines.extend(
        [
            "",
            translated_battery_line(str(snapshot["battery_status"]), str(snapshot["battery_capacity"]), language),
        ]
    )
    return "\n".join(lines).strip() + "\n"


def write_report_save_debug(target: pathlib.Path, ok: bool, error: str = "") -> None:
    if os.environ.get("HC_DEBUG") != "1":
        return

    lines = [
        f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
        f"target={target}",
        f"ok={ok}",
        f"exists={target.exists()}",
        f"size={target.stat().st_size if target.exists() else 0}",
        f"error={error}",
        "",
        "=== report dir ===",
        run_command("sh", "-c", f"ls -la {str(target.parent)!r} 2>&1 || true"),
        "",
        "=== mount media ===",
        run_command("sh", "-c", "mount | grep -E '/media|/mnt|modloop|loop' || true"),
        "",
        "=== df ===",
        run_command("df", "-h", str(target.parent)),
    ]
    for root in find_debug_roots():
        debug_dir = root / "hardwarecheck-debug"
        try:
            debug_dir.mkdir(parents=True, exist_ok=True)
            write_text_durable(debug_dir / "last-report-save.txt", "\n".join(lines) + "\n")
        except OSError:
            pass


class HardwareCheckApp:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title(APP_TITLE)
        self.root.configure(bg="#12161b")

        # If Xorg starts in a safe 4:3 fallback mode, try the native panel mode
        # before the main window is sized. Failure is harmless and keeps fallback.
        initial_snapshot: dict[str, object] = {}
        if os.environ.get("HC_APPLY_NATIVE_MODE") == "1":
            initial_snapshot = get_system_snapshot()
            if try_apply_native_xrandr_mode(initial_snapshot):
                time.sleep(0.4)
                self.root.update_idletasks()

        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        self.compact_ui = self.screen_width <= 1100 or self.screen_height <= 800
        if self.compact_ui:
            inset = 4
            safe_width = max(800, self.screen_width - (inset * 2))
            safe_height = max(560, self.screen_height - (inset * 2))
            self.root.geometry(f"{safe_width}x{safe_height}+{inset}+{inset}")
            self.root.minsize(min(800, safe_width), min(560, safe_height))
        else:
            self.root.geometry(f"{self.screen_width}x{self.screen_height}+0+0")
            self.root.minsize(self.screen_width, self.screen_height)
            self.root.attributes("-fullscreen", True)
        self.root.overrideredirect(True)

        self.snapshot: dict[str, object] = initial_snapshot
        self.matches: list[str] = []
        self.model_match_results: list[dict[str, object]] = []
        self.language_index = load_language_index()
        self.action_buttons: list[tk.Button] = []
        self._language_button: tk.Button | None = None
        self._language_popup: tk.Frame | None = None
        self._language_popup_buttons: list[tk.Button] = []
        self._language_flag_images: dict[str, tk.PhotoImage] = {}
        self.panel_title_vars: dict[str, tk.StringVar] = {}
        self.raw_input_seen = False
        self.raw_pointer_x = self.screen_width // 2
        self.raw_pointer_y = self.screen_height // 2
        self.raw_pointer: tk.Label | None = None
        self.raw_input_queue: queue.Queue[tuple[str, object]] = queue.Queue()
        self.raw_input_errors: list[str] = []
        self._raw_shift_down = False
        self._raw_altgr_down = False
        self._virtual_keyboard: tk.Frame | None = None
        self._virtual_keyboard_parent: tk.Widget | None = None
        self._virtual_keyboard_target: tk.Entry | None = None
        self._virtual_keyboard_shift = False
        self._virtual_keyboard_altgr = False
        self._virtual_keyboard_hooks_installed = False
        self._scan_busy = False
        self._report_busy = False
        self._print_busy = False
        self._printer_search_busy = False
        self._model_update_busy = False
        self._wifi_busy = False
        self._pending_model_update = False
        self._pending_program_update = False
        self._auto_update_check_busy = False
        self._auto_update_check_done = False
        self._auto_update_messages: list[str] = []
        self._color_theme_index = 0
        self._last_language_toggle = 0.0
        self._last_status_raw = ""
        self._last_status_important = False
        self._marquee_text = ""
        self._marquee_offset = 0
        self._marquee_job: str | None = None
        self._marquee_color_index = -1
        self.footer_label: tk.Label | None = None
        self._battery_test_active = False
        self._battery_test_mode = ""
        self._battery_test_samples: list[dict[str, object]] = []
        self._battery_test_csv_path: pathlib.Path | None = None
        self._battery_test_report_path: pathlib.Path | None = None
        self._battery_test_after_id: str | None = None
        self._battery_dialog_after_id: str | None = None
        self._battery_test_status_var = tk.StringVar(value="")
        self._battery_test_details_var = tk.StringVar(value="")
        self._battery_test_details_widget: tk.Text | None = None
        self._battery_visual_canvas: tk.Canvas | None = None
        self._battery_visual_details: dict[str, object] = {}
        self.match_label: tk.Label | None = None

        self.header_var = tk.StringVar(value=APP_TITLE)
        self.status_var = tk.StringVar(value="")
        self.system_lines_var = tk.StringVar(value="")
        self.ram_lines_var = tk.StringVar(value="")
        self.display_lines_var = tk.StringVar(value="")
        self.storage_lines_var = tk.StringVar(value="")
        self.match_lines_var = tk.StringVar(value="")
        self.battery_var = tk.StringVar(value="")
        self.db_var = tk.StringVar(value="")
        self.internet_var = tk.StringVar(value="")
        self.internet_state = "offline"
        self.internet_message = ""
        self.internet_light_canvas: tk.Canvas | None = None

        self._build_ui()
        self._bind_keys()
        raw_input_default = "1" if sys.platform.startswith("linux") else "0"
        if os.environ.get("HC_RAW_INPUT", raw_input_default) == "1":
            self._start_raw_input_listener()
        self.root.after(50, self._poll_raw_input_queue)
        self.root.after(250, self._force_focus)
        self.root.after(1500, self._force_focus)
        if os.environ.get("HC_DEBUG") == "1":
            self.root.after(4000, lambda: self._write_gui_debug("delayed"))
        self.refresh()
        self._schedule_battery_refresh()
        self.root.after(4500, self.auto_check_updates)
        if sys.platform.startswith("linux"):
            self.root.after(2200, self.connect_saved_wifi)

    @property
    def language(self) -> str:
        return LANGUAGES[self.language_index]

    def _t(self, de: str, en: str, cz: str) -> str:
        return {"DE": de, "EN": en, "CZ": cz}[self.language]

    def _make_panel(self, parent: tk.Widget, title_key: str) -> tk.Frame:
        frame = tk.Frame(parent, bg="#1a2028", bd=0, highlightthickness=1, highlightbackground="#2a3440")
        title_var = tk.StringVar(value="")
        self.panel_title_vars[title_key] = title_var
        heading = tk.Label(
            frame,
            textvariable=title_var,
            bg="#1a2028",
            fg="#f7d37c",
            font=("Segoe UI", 11 if self.compact_ui else 16, "bold"),
            anchor="w",
            padx=8 if self.compact_ui else 16,
            pady=5 if self.compact_ui else 12,
        )
        heading.pack(fill="x")
        return frame

    def _make_text_label(self, parent: tk.Widget, variable: tk.StringVar) -> tk.Label:
        label = tk.Label(
            parent,
            textvariable=variable,
            justify="left",
            anchor="nw",
            bg="#1a2028",
            fg="#f3f6f9",
            font=("Consolas", 9 if self.compact_ui else 13),
            padx=7 if self.compact_ui else 16,
            pady=4 if self.compact_ui else 8,
        )
        label.pack(fill="both", expand=True)
        return label

    def _build_ui(self) -> None:
        top = tk.Frame(self.root, bg="#101418")
        top.pack(fill="x")
        tk.Label(
            top,
            textvariable=self.header_var,
            bg="#101418",
            fg="#ffffff",
            font=("Segoe UI", 14 if self.compact_ui else 26, "bold"),
            padx=8 if self.compact_ui else 18,
            pady=4 if self.compact_ui else 16,
            anchor="w",
        ).pack(side="left")
        top_status = tk.Frame(top, bg="#101418")
        top_status.pack(side="right", padx=8 if self.compact_ui else 18, pady=4 if self.compact_ui else 12)

        internet_row = tk.Frame(top_status, bg="#101418")
        internet_row.pack(anchor="e")
        light_size = 10 if self.compact_ui else 14
        self.internet_light_canvas = tk.Canvas(
            internet_row,
            width=light_size,
            height=light_size,
            bg="#101418",
            highlightthickness=0,
            bd=0,
        )
        self.internet_light_canvas.pack(side="left", padx=(0, 5))
        tk.Label(
            internet_row,
            textvariable=self.internet_var,
            bg="#101418",
            fg="#8d9aa6",
            font=("Segoe UI", 8 if self.compact_ui else 12, "bold"),
            anchor="e",
        ).pack(side="left")
        tk.Label(
            top_status,
            textvariable=self.db_var,
            bg="#101418",
            fg="#f7d37c",
            font=("Segoe UI", 8 if self.compact_ui else 12, "bold"),
            anchor="e",
        ).pack(anchor="e")
        tk.Label(
            top_status,
            textvariable=self.battery_var,
            bg="#101418",
            fg="#9ad3a8",
            font=("Segoe UI", 9 if self.compact_ui else 14, "bold"),
            anchor="e",
        ).pack(anchor="e")
        self._set_internet_indicator("offline")
        self._update_db_indicator()

        body = tk.Frame(self.root, bg="#12161b")
        body.pack(fill="both", expand=True, padx=4 if self.compact_ui else 16, pady=(0, 4 if self.compact_ui else 12))
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.columnconfigure(2, weight=3)
        body.rowconfigure(0, weight=1)
        body.rowconfigure(1, weight=1)

        system_panel = self._make_panel(body, "system")
        system_panel.grid(row=0, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(system_panel, self.system_lines_var)

        ram_panel = self._make_panel(body, "ram")
        ram_panel.grid(row=1, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(ram_panel, self.ram_lines_var)

        display_panel = self._make_panel(body, "display")
        display_panel.grid(row=0, column=1, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(display_panel, self.display_lines_var)

        storage_panel = self._make_panel(body, "storage")
        storage_panel.grid(row=1, column=1, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self._make_text_label(storage_panel, self.storage_lines_var)

        right = tk.Frame(body, bg="#12161b")
        right.grid(row=0, column=2, rowspan=2, sticky="nsew")
        right.rowconfigure(0, weight=3)
        right.rowconfigure(1, weight=2)

        match_panel = self._make_panel(right, "match")
        match_panel.grid(row=0, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        self.match_label = self._make_text_label(match_panel, self.match_lines_var)
        self.match_label.configure(cursor="hand2")
        self.match_label.bind("<Button-1>", self.open_model_match_details)
        match_panel.configure(cursor="hand2")
        match_panel.bind("<Button-1>", self.open_model_match_details)

        action_panel = self._make_panel(right, "actions")
        action_panel.grid(row=1, column=0, sticky="nsew", padx=4 if self.compact_ui else 8, pady=4 if self.compact_ui else 8)
        button_area = tk.Frame(action_panel, bg="#1a2028")
        button_area.pack(fill="both", expand=True, padx=8 if self.compact_ui else 16, pady=4 if self.compact_ui else 8)

        actions = [
            ("language", self.toggle_language_selector),
            ("settings", self.open_settings_menu),
            ("report", self.save_report),
            ("print", self.print_report),
            ("update", self.update_model_database),
            ("appupdate", self.check_hardwarecheck_update),
            ("poweroff", lambda: self._system_action("poweroff", confirm=False)),
        ]
        if (SCRIPT_DIR / "hardwarecheck_v5_gui.py").is_file():
            actions.insert(0, ("v5", self.restart_v5_interface))
        for key, command in actions:
            button = self._button(button_area, "", command)
            button._hc_action_key = key  # type: ignore[attr-defined]
            button.pack(fill="x", pady=2 if self.compact_ui else 4)
            self.action_buttons.append(button)
            if key == "language":
                self._language_button = button
                self._update_language_button()

        self.footer_label = tk.Label(
            self.root,
            textvariable=self.status_var,
            bg="#0e1216",
            fg="#9fb4c7",
            font=("Segoe UI", 8 if self.compact_ui else 11),
            anchor="w",
            padx=8 if self.compact_ui else 16,
            pady=4 if self.compact_ui else 10,
        )
        self.footer_label.pack(fill="x")

    def set_status(self, message: str, important: bool = False) -> None:
        self._last_status_raw = str(message or "")
        self._last_status_important = important
        translated = translate_status_text(self._last_status_raw, self.language)
        if important:
            self._start_status_marquee(translated)
        else:
            self._stop_status_marquee()
            self.status_var.set(translated)

    def append_status(self, message: str) -> None:
        base = self._last_status_raw or self.status_var.get()
        combined = f"{base} | {message}" if base else message
        self.set_status(combined, self._last_status_important)

    def _start_status_marquee(self, text: str) -> None:
        self._marquee_color_index = -1
        self._marquee_offset = 0
        self._apply_marquee_color(force=True)
        self._marquee_text = f">>> {text.strip()} <<<"
        if self._marquee_job is not None:
            try:
                self.root.after_cancel(self._marquee_job)
            except tk.TclError:
                pass
            self._marquee_job = None
        self._tick_status_marquee()

    def _apply_marquee_color(self, force: bool = False) -> None:
        if self.footer_label is None:
            return
        palette = [
            ("#ffe08a", "#101418"),
            ("#c62828", "#ffffff"),
            ("#1f8f45", "#ffffff"),
            ("#ffe08a", "#101418"),
        ]
        index = (self._marquee_offset // 6) % len(palette)
        if force or index != self._marquee_color_index:
            self._marquee_color_index = index
            bg, fg = palette[index]
            self.footer_label.configure(
                bg=bg,
                fg=fg,
                font=("Segoe UI", 8 if self.compact_ui else 12, "bold"),
            )

    def _tick_status_marquee(self) -> None:
        if not self._last_status_important or not self._marquee_text:
            return
        self._apply_marquee_color()
        width = 70
        if self.footer_label is not None:
            pixel_width = max(1, self.footer_label.winfo_width())
            width = max(48, pixel_width // (7 if self.compact_ui else 9))
        gap = " " * max(12, width // 3)
        loop = self._marquee_text + gap
        repeated = loop * ((width // max(1, len(loop))) + 3)
        start = self._marquee_offset % len(loop)
        visible = repeated[start : start + width]
        self._marquee_offset += 1
        self.status_var.set(visible)
        self._marquee_job = self.root.after(140, self._tick_status_marquee)

    def _stop_status_marquee(self) -> None:
        self._last_status_important = False
        if self._marquee_job is not None:
            try:
                self.root.after_cancel(self._marquee_job)
            except tk.TclError:
                pass
            self._marquee_job = None
        self._marquee_text = ""
        self._marquee_color_index = -1
        if self.footer_label is not None:
            self.footer_label.configure(bg="#0e1216", fg="#9fb4c7", font=("Segoe UI", 8 if self.compact_ui else 11))

    def _refresh_status_translation(self) -> None:
        if self._last_status_raw:
            self.set_status(self._last_status_raw, self._last_status_important)

    def _button(self, parent: tk.Widget, text: str, command) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg="#d4a84d",
            fg="#101418",
            activebackground="#e4bc69",
            activeforeground="#101418",
            font=("Segoe UI", 9 if self.compact_ui else 12, "bold"),
            relief="flat",
            padx=6 if self.compact_ui else 12,
            pady=4 if self.compact_ui else 10,
            cursor="hand2",
        )

    def _ensure_language_flag_images(self) -> None:
        if self._language_flag_images:
            return
        width, height = ((34, 21) if self.compact_ui else (44, 27))
        for language in LANGUAGES:
            image = tk.PhotoImage(width=width, height=height)
            pixels = language_flag_pixels(language, width, height)
            image.put(" ".join("{" + " ".join(row) + "}" for row in pixels))
            self._language_flag_images[language] = image

    def _update_language_button(self) -> None:
        button = self._language_button
        if button is None:
            return
        self._ensure_language_flag_images()
        try:
            button.configure(
                text=self.language,
                image=self._language_flag_images[self.language],
                compound="left",
                anchor="center",
            )
        except tk.TclError:
            pass

    def _close_language_selector(self) -> None:
        popup = self._language_popup
        self._language_popup = None
        self._language_popup_buttons = []
        if popup is not None:
            try:
                popup.destroy()
            except tk.TclError:
                pass

    def _select_language(self, language_index: int) -> None:
        if not 0 <= int(language_index) < len(LANGUAGES):
            return
        changed = self.language_index != int(language_index)
        self.language_index = int(language_index)
        save_language(self.language)
        self._close_language_selector()
        self._update_language_button()
        if changed:
            self.refresh(rescan=False)

    def toggle_language_selector(self) -> None:
        if self._language_popup is not None:
            self._close_language_selector()
            return
        button = self._language_button
        if button is None:
            return
        self._ensure_language_flag_images()
        try:
            panel_bg = str(button.master.cget("bg"))
            button_bg = str(button.cget("bg"))
            button_fg = str(button.cget("fg"))
            active_bg = str(button.cget("activebackground"))
            active_fg = str(button.cget("activeforeground"))
        except tk.TclError:
            return

        popup = tk.Frame(
            self.root,
            bg=panel_bg,
            highlightthickness=2,
            highlightbackground=button_bg,
            bd=0,
        )
        self._language_popup = popup
        self._language_popup_buttons = []
        for language in LANGUAGE_SELECTOR_ORDER:
            language_index = LANGUAGES.index(language)
            option = self._button(popup, language, lambda index=language_index: self._select_language(index))
            selected = language_index == self.language_index
            option.configure(
                image=self._language_flag_images[language],
                compound="left",
                anchor="w",
                bg=active_bg if selected else button_bg,
                fg=button_fg,
                activebackground=active_bg,
                activeforeground=active_fg,
                relief="sunken" if selected else "flat",
                bd=2 if selected else 0,
                padx=12 if self.compact_ui else 18,
            )
            option.pack(fill="x", padx=4, pady=3)
            self._language_popup_buttons.append(option)

        try:
            self.root.update_idletasks()
            popup.update_idletasks()
            root_x = self.root.winfo_rootx()
            root_y = self.root.winfo_rooty()
            x = button.winfo_rootx() - root_x
            button_y = button.winfo_rooty() - root_y
            width = max(button.winfo_width(), popup.winfo_reqwidth())
            height = popup.winfo_reqheight()
            y_below = button_y + button.winfo_height() + 2
            root_height = max(self.screen_height, self.root.winfo_height())
            y = y_below if y_below + height <= root_height - 8 else max(8, button_y - height - 2)
            popup.place(x=x, y=y, width=width, height=height)
            popup.lift()
            popup.focus_set()
            popup.bind("<Escape>", lambda _event: self._close_language_selector())
        except tk.TclError:
            self._close_language_selector()

    def _bind_dialog_escape(self, widget: tk.Widget, close_command) -> None:
        def close_on_escape(_event=None):
            self._hide_virtual_keyboard()
            close_command()
            try:
                self.root.focus_set()
            except tk.TclError:
                pass
            return "break"

        def bind_tree(node: tk.Widget) -> None:
            try:
                node.bind("<Escape>", close_on_escape, add="+")
            except tk.TclError:
                return
            for child in node.winfo_children():
                bind_tree(child)

        bind_tree(widget)

    def _internet_default_text(self, state: str) -> str:
        if state == "online":
            return self._t("Internet: online", "Internet: online", "Internet: online")
        if state == "searching":
            return self._t("Internet: suche", "Internet: searching", "Internet: hledám")
        if state == "error":
            return self._t("Internet: Fehler", "Internet: error", "Internet: chyba")
        return self._t("Internet: aus", "Internet: off", "Internet: vyp.")

    def _set_internet_indicator(self, state: str, message: str = "") -> None:
        self.internet_state = state
        self.internet_message = message
        colors = {
            "online": "#4fd16a",
            "searching": "#d4a84d",
            "error": "#d85b5b",
            "offline": "#65717d",
        }
        color = colors.get(state, colors["offline"])
        label = message or self._internet_default_text(state)
        if message and not message.startswith("Internet"):
            label = f"Internet: {message}"
        max_len = 34 if self.compact_ui else 52
        label = translate_status_text(label, self.language)
        if len(label) > max_len:
            label = label[: max_len - 3] + "..."
        self.internet_var.set(label)
        if self.internet_light_canvas is not None:
            self.internet_light_canvas.delete("all")
            size = 10 if self.compact_ui else 14
            self.internet_light_canvas.create_oval(1, 1, size - 2, size - 2, fill=color, outline=color)

    def _update_db_indicator(self) -> None:
        version, count = local_model_database_info()
        version = format_database_version(version)
        model_word = self._t("Modelle", "models", "modelu")
        self.db_var.set(f"DB: {version} | {count} {model_word}" if count else f"DB: {version}")

    def _force_focus(self) -> None:
        self.root.lift()
        self.root.focus_force()
        self.root.focus_set()

    def _install_virtual_keyboard_hooks(self) -> None:
        if self._virtual_keyboard_hooks_installed:
            return
        self._virtual_keyboard_hooks_installed = True
        self.root.bind_class("Entry", "<FocusIn>", self._on_entry_focus_in, add="+")
        self.root.bind_class("Entry", "<FocusOut>", self._on_entry_focus_out, add="+")
        self.root.bind_all("<KeyPress>", self._handle_tk_key_press, add="+")

    def _on_entry_focus_in(self, event: tk.Event) -> None:
        widget = getattr(event, "widget", None)
        if isinstance(widget, tk.Entry):
            if bool(getattr(widget, "_hc_suppress_virtual_keyboard", False)):
                self._hide_virtual_keyboard()
                return
            self.root.after(80, lambda entry=widget: self._show_virtual_keyboard(entry))

    def _on_entry_focus_out(self, _event: tk.Event) -> None:
        self.root.after(250, self._hide_virtual_keyboard_if_idle)

    def _virtual_keyboard_parent_for(self, widget: tk.Widget) -> tk.Widget:
        parent: tk.Widget = widget
        while getattr(parent, "master", None) is not None and parent.master is not self.root:
            parent = parent.master  # type: ignore[assignment]
        if getattr(parent, "master", None) is self.root:
            return parent
        return self.root

    def _show_virtual_keyboard(self, target: tk.Entry) -> None:
        if bool(getattr(target, "_hc_suppress_virtual_keyboard", False)):
            self._hide_virtual_keyboard()
            return
        try:
            if not target.winfo_exists():
                return
        except tk.TclError:
            return
        parent = self._virtual_keyboard_parent_for(target)
        if self._virtual_keyboard is not None and self._virtual_keyboard_parent is not parent:
            self._destroy_virtual_keyboard()
        self._virtual_keyboard_target = target
        if self._virtual_keyboard is None:
            self._virtual_keyboard_parent = parent
            self._virtual_keyboard = self._build_virtual_keyboard(parent)
        self._place_virtual_keyboard(target)
        try:
            self._virtual_keyboard.lift()
            target.focus_set()
        except tk.TclError:
            pass

    def _build_virtual_keyboard(self, parent: tk.Widget) -> tk.Frame:
        keyboard = tk.Frame(parent, bg="#0b1118", highlightthickness=2, highlightbackground="#d4a84d")
        title = tk.Label(
            keyboard,
            text=self._t("Bildschirmtastatur", "On-screen keyboard", "Klavesnice"),
            bg="#0b1118",
            fg="#f7d37c",
            font=("Segoe UI", 9 if self.compact_ui else 11, "bold"),
            anchor="w",
            padx=10,
            pady=3,
        )
        title.grid(row=0, column=0, columnspan=13, sticky="ew")

        rows = [
            ["^", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "ß", "´"],
            ["q", "w", "e", "r", "t", "z", "u", "i", "o", "p", "ü", "+"],
            ["a", "s", "d", "f", "g", "h", "j", "k", "l", "ö", "ä", "#"],
            ["<", "y", "x", "c", "v", "b", "n", "m", ",", ".", "-"],
        ]
        for row_index, keys in enumerate(rows, start=1):
            for col_index, key in enumerate(keys):
                button = self._vk_button(keyboard, key, lambda value=key: self._vk_insert(value))
                button.grid(row=row_index, column=col_index, sticky="nsew", padx=2, pady=2)

        special_row = len(rows) + 1
        self._vk_button(keyboard, "Shift", self._vk_toggle_shift).grid(row=special_row, column=0, columnspan=2, sticky="nsew", padx=2, pady=2)
        self._vk_button(keyboard, "AltGr", self._vk_toggle_altgr).grid(row=special_row, column=2, columnspan=2, sticky="nsew", padx=2, pady=2)
        self._vk_button(keyboard, self._t("Leer", "Space", "Mezera"), lambda: self._vk_insert(" ")).grid(
            row=special_row, column=4, columnspan=4, sticky="nsew", padx=2, pady=2
        )
        self._vk_button(keyboard, self._t("<- 1 Zeichen", "<- 1 char", "<- 1 znak"), self._vk_backspace).grid(
            row=special_row, column=8, columnspan=2, sticky="nsew", padx=2, pady=2
        )
        self._vk_button(keyboard, self._t("Alles weg", "Clear all", "Smazat vse"), self._vk_clear).grid(
            row=special_row, column=10, columnspan=2, sticky="nsew", padx=2, pady=2
        )
        self._vk_button(keyboard, "OK", self._hide_virtual_keyboard).grid(
            row=special_row, column=12, columnspan=1, sticky="nsew", padx=2, pady=2
        )

        for column in range(13):
            keyboard.columnconfigure(column, weight=1, uniform="vk")
        for row in range(special_row + 1):
            keyboard.rowconfigure(row, weight=1)
        return keyboard

    def _vk_button(self, parent: tk.Widget, text: str, command) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            takefocus=0,
            bg="#1f2937",
            fg="#f3f6f9",
            activebackground="#d4a84d",
            activeforeground="#101418",
            relief="flat",
            font=("Segoe UI", 8 if self.compact_ui else 10, "bold"),
            padx=4,
            pady=4,
        )

    def _place_virtual_keyboard(self, target: tk.Entry) -> None:
        if self._virtual_keyboard is None or self._virtual_keyboard_parent is None:
            return
        try:
            parent = self._virtual_keyboard_parent
            parent.update_idletasks()
            target.update_idletasks()
            parent_height = max(parent.winfo_height(), self.screen_height)
            parent_width = max(parent.winfo_width(), self.screen_width)
            keyboard_height = 184 if self.compact_ui else 224
            margin = 10
            entry_top = target.winfo_rooty() - parent.winfo_rooty()
            entry_bottom = entry_top + target.winfo_height()
            if parent_height - entry_bottom >= keyboard_height + margin:
                y_pos = parent_height - keyboard_height - margin
            elif entry_top >= keyboard_height + margin:
                y_pos = margin
            else:
                y_pos = max(margin, min(parent_height - keyboard_height - margin, entry_bottom + margin))
            self._virtual_keyboard.place(x=margin, y=y_pos, width=parent_width - (margin * 2), height=keyboard_height)
        except tk.TclError:
            self._destroy_virtual_keyboard()

    def _vk_target(self) -> tk.Entry | None:
        target = self._virtual_keyboard_target
        try:
            if target is None or not target.winfo_exists():
                return None
        except tk.TclError:
            return None
        return target

    def _is_text_input_widget(self, widget) -> bool:
        if widget is None:
            return False
        if isinstance(widget, (tk.Entry, tk.Text, tk.Spinbox)):
            return True
        try:
            widget_class = str(widget.winfo_class())
        except tk.TclError:
            return False
        return widget_class in {"Entry", "TEntry", "Text", "Spinbox", "TSpinbox"}

    def _vk_insert(self, value: str) -> None:
        target = self._vk_target()
        if target is None:
            return
        if self._virtual_keyboard_altgr:
            value = VIRTUAL_KEY_ALTGR_VALUES.get(value, value)
            self._virtual_keyboard_altgr = False
        elif self._virtual_keyboard_shift:
            value = RAW_TEXT_SHIFT_KEYS.get(value, value.upper() if len(value) == 1 and value.isalpha() else value)
            self._virtual_keyboard_shift = False
        try:
            target.focus_set()
            try:
                target.selection_clear()
            except tk.TclError:
                pass
            target.insert("insert", value)
            self._place_virtual_keyboard(target)
        except tk.TclError:
            pass

    def _vk_backspace(self) -> None:
        target = self._vk_target()
        if target is None:
            return
        try:
            target.focus_set()
            try:
                target.selection_clear()
            except tk.TclError:
                pass
            cursor = int(target.index("insert"))
            if cursor <= 0 and int(target.index("end")) > 0:
                cursor = int(target.index("end"))
            if cursor > 0:
                target.delete(cursor - 1, cursor)
                target.icursor(cursor - 1)
        except tk.TclError:
            pass

    def _vk_clear(self) -> None:
        target = self._vk_target()
        if target is None:
            return
        try:
            target.focus_set()
            target.delete(0, "end")
        except tk.TclError:
            pass

    def _vk_toggle_shift(self) -> None:
        self._virtual_keyboard_shift = not self._virtual_keyboard_shift
        if self._virtual_keyboard_shift:
            self._virtual_keyboard_altgr = False
        target = self._vk_target()
        if target is not None:
            try:
                target.focus_set()
            except tk.TclError:
                pass

    def _vk_toggle_altgr(self) -> None:
        self._virtual_keyboard_altgr = not self._virtual_keyboard_altgr
        if self._virtual_keyboard_altgr:
            self._virtual_keyboard_shift = False
        target = self._vk_target()
        if target is not None:
            try:
                target.focus_set()
            except tk.TclError:
                pass

    def _hide_virtual_keyboard_if_idle(self) -> None:
        try:
            focus = self.root.focus_get()
        except tk.TclError:
            focus = None
        if isinstance(focus, tk.Entry):
            return
        self._hide_virtual_keyboard()

    def _hide_virtual_keyboard(self) -> None:
        if self._virtual_keyboard is not None:
            try:
                self._virtual_keyboard.place_forget()
            except tk.TclError:
                self._destroy_virtual_keyboard()

    def _destroy_virtual_keyboard(self) -> None:
        if self._virtual_keyboard is not None:
            try:
                self._virtual_keyboard.destroy()
            except tk.TclError:
                pass
        self._virtual_keyboard = None
        self._virtual_keyboard_parent = None
        self._virtual_keyboard_target = None

    def _start_raw_input_listener(self) -> None:
        if os.environ.get("HC_RAW_POINTER") == "1":
            self.raw_pointer = tk.Label(
                self.root,
                text="+",
                bg="#12161b",
                fg="#ffe08a",
                font=("Consolas", 18, "bold"),
                padx=2,
                pady=0,
            )
            self._set_raw_pointer(self.raw_pointer_x, self.raw_pointer_y)
        thread = threading.Thread(target=self._raw_input_loop, name="raw-input-listener", daemon=True)
        thread.start()

    def _poll_raw_input_queue(self) -> None:
        while True:
            try:
                event, payload = self.raw_input_queue.get_nowait()
            except queue.Empty:
                break
            if event == "mark":
                self._mark_raw_input_seen()
            elif event == "rawkey":
                code, value = payload  # type: ignore[misc]
                self._handle_raw_key_event(int(code), int(value))
            elif event == "click":
                self._raw_click()
            elif event == "move":
                x, y = payload  # type: ignore[misc]
                self._set_raw_pointer(int(x), int(y))
            elif event == "error":
                self.raw_input_errors.append(str(payload))
                self.raw_input_errors = self.raw_input_errors[-8:]
        self.root.after(30, self._poll_raw_input_queue)

    def _raw_input_loop(self) -> None:
        devices: dict[int, str] = {}
        abs_ranges: dict[int, dict[int, tuple[int, int]]] = {}
        pointer_x = self.raw_pointer_x
        pointer_y = self.raw_pointer_y
        last_scan = 0.0
        pointer_enabled = self.raw_pointer is not None

        while True:
            now = time.monotonic()
            if now - last_scan > 2.0:
                last_scan = now
                for path in sorted(pathlib.Path("/dev/input").glob("event*")):
                    path_text = str(path)
                    if path_text in devices.values():
                        continue
                    try:
                        fd = os.open(path_text, os.O_RDONLY | os.O_NONBLOCK)
                    except OSError as exc:
                        self.raw_input_queue.put(("error", f"open {path_text}: {exc}"))
                        continue
                    devices[fd] = path_text
                    abs_ranges[fd] = self._read_abs_ranges(fd)
                    self.raw_input_queue.put(("error", f"opened {path_text}"))

            if not devices:
                time.sleep(1)
                continue

            try:
                readable, _, _ = select.select(list(devices), [], [], 1.0)
            except OSError:
                readable = []

            for fd in readable:
                try:
                    data = os.read(fd, INPUT_EVENT.size * 64)
                except BlockingIOError:
                    continue
                except OSError:
                    devices.pop(fd, None)
                    abs_ranges.pop(fd, None)
                    try:
                        os.close(fd)
                    except OSError:
                        pass
                    continue

                moved = False
                for offset in range(0, len(data) - INPUT_EVENT.size + 1, INPUT_EVENT.size):
                    _sec, _usec, event_type, code, value = INPUT_EVENT.unpack_from(data, offset)
                    if event_type == EV_KEY:
                        self.raw_input_queue.put(("rawkey", (code, value)))
                        if value == 1:
                            self.raw_input_queue.put(("mark", ""))
                            if pointer_enabled and code == BTN_LEFT:
                                self.raw_input_queue.put(("click", ""))
                            elif pointer_enabled and code == BTN_TOUCH:
                                self.raw_input_queue.put(("click", ""))
                    elif pointer_enabled and event_type == EV_REL:
                        if code == REL_X:
                            pointer_x += int(value * 1.8)
                            moved = True
                        elif code == REL_Y:
                            pointer_y += int(value * 1.8)
                            moved = True
                    elif pointer_enabled and event_type == EV_ABS:
                        ranges = abs_ranges.get(fd, {})
                        if code in (ABS_X, ABS_MT_POSITION_X):
                            pointer_x = self._scale_abs(value, ranges.get(code), self.screen_width)
                            moved = True
                        elif code in (ABS_Y, ABS_MT_POSITION_Y):
                            pointer_y = self._scale_abs(value, ranges.get(code), self.screen_height)
                            moved = True
                    elif event_type == EV_SYN and moved:
                        pointer_x = max(0, min(self.screen_width - 1, pointer_x))
                        pointer_y = max(0, min(self.screen_height - 1, pointer_y))
                        self.raw_input_queue.put(("move", (pointer_x, pointer_y)))
                        moved = False

                if moved:
                    pointer_x = max(0, min(self.screen_width - 1, pointer_x))
                    pointer_y = max(0, min(self.screen_height - 1, pointer_y))
                    self.raw_input_queue.put(("move", (pointer_x, pointer_y)))

    def _read_abs_ranges(self, fd: int) -> dict[int, tuple[int, int]]:
        ranges: dict[int, tuple[int, int]] = {}
        if fcntl is None:
            return ranges
        for code in (ABS_X, ABS_Y, ABS_MT_POSITION_X, ABS_MT_POSITION_Y):
            buffer = bytearray(24)
            try:
                fcntl.ioctl(fd, 0x80184540 + code, buffer, True)
            except OSError:
                continue
            _value, minimum, maximum, _fuzz, _flat, _resolution = struct.unpack("iiiiii", buffer)
            if maximum > minimum:
                ranges[code] = (minimum, maximum)
        return ranges

    def _scale_abs(self, value: int, range_pair: tuple[int, int] | None, target_size: int) -> int:
        if not range_pair:
            return max(0, min(target_size - 1, value))
        minimum, maximum = range_pair
        ratio = (value - minimum) / max(1, maximum - minimum)
        return max(0, min(target_size - 1, int(ratio * (target_size - 1))))

    def _set_raw_pointer(self, x: int, y: int) -> None:
        self.raw_pointer_x = max(0, min(self.screen_width - 1, int(x)))
        self.raw_pointer_y = max(0, min(self.screen_height - 1, int(y)))
        if self.raw_pointer is not None:
            self.raw_pointer.place(x=self.raw_pointer_x - 8, y=self.raw_pointer_y - 12)

    def _raw_click(self) -> None:
        self._mark_raw_input_seen()
        root_x = self.root.winfo_rootx()
        root_y = self.root.winfo_rooty()
        buttons = list(self._language_popup_buttons) + list(self.action_buttons)
        for button in buttons:
            try:
                if not button.winfo_exists() or not button.winfo_ismapped():
                    continue
                left = button.winfo_rootx() - root_x
                top = button.winfo_rooty() - root_y
                right = left + button.winfo_width()
                bottom = top + button.winfo_height()
                if left <= self.raw_pointer_x <= right and top <= self.raw_pointer_y <= bottom:
                    button.invoke()
                    return
            except tk.TclError:
                continue
        self.set_status("Roh-Maus erkannt. Gelbes + auf einen Aktionsbutton bewegen und klicken.")

    def _mark_raw_input_seen(self) -> None:
        if self.raw_input_seen:
            return
        self.raw_input_seen = True
        self.set_status("Physische Tastatur erkannt: Eingabe funktioniert in Textfeldern.")

    def _show_input_status(self) -> None:
        self.set_status(f"{get_input_summary()} | Debug/Reports: {get_report_dir()}")
        self._write_gui_debug("input-status")

    def _handle_raw_key_event(self, code: int, value: int) -> None:
        if code in RAW_SHIFT_CODES:
            self._raw_shift_down = value != 0
            return
        if code in RAW_ALTGR_CODES:
            self._raw_altgr_down = value != 0
            return
        if value not in (1, 2) or not self._focus_is_text_input():
            return
        self._raw_text_input(code)

    def _raw_text_input(self, code: int) -> None:
        try:
            focus = self.root.focus_get()
        except tk.TclError:
            return
        target = focus if isinstance(focus, tk.Entry) else self._vk_target()
        if target is None:
            return
        try:
            if code == 14:  # Backspace
                cursor = int(target.index("insert"))
                if cursor > 0:
                    target.delete(cursor - 1, cursor)
                return
            if code == 15:  # Tab
                next_widget = target.tk_focusNext()
                if next_widget is not None:
                    next_widget.focus_set()
                return
            if code == 28:  # Enter
                target.event_generate("<Return>")
                return
            if self._raw_altgr_down:
                char = RAW_TEXT_ALTGR_KEYS.get(code)
                if not char:
                    return
            else:
                char = RAW_TEXT_KEYS.get(code)
                if not char:
                    return
                if self._raw_shift_down:
                    char = RAW_TEXT_SHIFT_KEYS.get(char, char.upper())
            target.focus_set()
            target.insert("insert", char)
        except tk.TclError:
            return

    def _focus_is_text_input(self) -> bool:
        try:
            focus = self.root.focus_get()
        except tk.TclError:
            return False
        return self._is_text_input_widget(focus) or self._vk_target() is not None

    def _handle_tk_key_press(self, event: tk.Event):
        widget = getattr(event, "widget", None)
        if self._is_text_input_widget(widget):
            return None
        target = self._vk_target()
        if target is None:
            return None
        keysym = str(getattr(event, "keysym", "") or "")
        char = str(getattr(event, "char", "") or "")
        try:
            target.focus_set()
            if keysym == "BackSpace":
                cursor = int(target.index("insert"))
                if cursor > 0:
                    target.delete(cursor - 1, cursor)
                return "break"
            if keysym in {"Return", "KP_Enter"}:
                target.event_generate("<Return>")
                return "break"
            if keysym == "Tab":
                next_widget = target.tk_focusNext()
                if next_widget is not None:
                    next_widget.focus_set()
                return "break"
            if len(char) == 1 and char >= " ":
                target.insert("insert", char)
                return "break"
        except tk.TclError:
            return None
        return None

    def _run_input_action(self, action: str | None) -> None:
        if action == "language":
            self.toggle_language_selector()
        elif action == "v5":
            self.restart_v5_interface()
        elif action == "settings":
            self.open_settings_menu()
        elif action == "scan":
            self.refresh()
        elif action == "report":
            self.save_report()
        elif action == "print":
            self.print_report()
        elif action == "printer":
            self.open_printer_manager()
        elif action == "wifi":
            self.open_wifi_manager()
        elif action == "color":
            self.cycle_color_theme()
        elif action == "update":
            self.update_model_database()
        elif action == "appupdate":
            self.check_hardwarecheck_update()
        elif action == "shell":
            self.run_shell_fallback()
        elif action == "reboot":
            self._system_action("reboot", confirm=False)
        elif action == "poweroff":
            self._system_action("poweroff", confirm=False)

    def _write_gui_debug(self, reason: str) -> None:
        if os.environ.get("HC_DEBUG") != "1":
            return

        input_entries = []
        input_root = pathlib.Path("/dev/input")
        if input_root.exists():
            for path in sorted(input_root.iterdir()):
                try:
                    stat = path.stat()
                    input_entries.append(f"{path}: mode={oct(stat.st_mode)} size={stat.st_size}")
                except OSError as exc:
                    input_entries.append(f"{path}: {exc}")

        lines = [
            f"reason={reason}",
            f"date={time.strftime('%Y-%m-%dT%H:%M:%S')}",
            f"display={os.environ.get('DISPLAY', '')}",
            f"screen={self.screen_width}x{self.screen_height}",
            f"model_path={get_models_path()}",
            f"report_dir={get_report_dir()}",
            f"input_summary={get_input_summary()}",
            f"debug_roots={', '.join(str(path) for path in find_debug_roots())}",
            f"raw_input_seen={self.raw_input_seen}",
            f"raw_input_errors={self.raw_input_errors}",
            "",
            "=== /proc/cmdline ===",
            read_text("/proc/cmdline"),
            "",
            "=== /dev/input ===",
            "\n".join(input_entries) or "no /dev/input entries",
            "",
            "=== /proc/bus/input/devices ===",
            read_text("/proc/bus/input/devices"),
            "",
            "=== lsmod input ===",
            run_command("sh", "-c", "lsmod | grep -E 'hid|input|mouse|psmouse|i2c' || true"),
            "",
            "=== mount media ===",
            run_command("sh", "-c", "mount | grep -E '/media|/mnt|modloop|loop' || true"),
            "",
            "=== drm modes ===",
            run_command("sh", "-c", "for s in /sys/class/drm/card*-*/status; do [ -e \"$s\" ] || continue; echo \"$s: $(cat \"$s\" 2>/dev/null)\"; m=${s%/*}/modes; [ -r \"$m\" ] && head -n 8 \"$m\"; done"),
            "",
        ]
        for root in find_debug_roots():
            debug_dir = root / "hardwarecheck-debug"
            try:
                debug_dir.mkdir(parents=True, exist_ok=True)
                (debug_dir / "gui-input.txt").write_text("\n".join(lines), encoding="utf-8")
            except OSError:
                continue

            for source, target in [
                (pathlib.Path("/root/.local/share/xorg/Xorg.0.log"), debug_dir / "Xorg.0.log"),
                (pathlib.Path("/var/log/Xorg.0.log"), debug_dir / "Xorg-var.log"),
            ]:
                data = read_text(source)
                if data:
                    try:
                        target.write_text(data, encoding="utf-8")
                    except OSError:
                        pass

    def _bind_keys(self) -> None:
        self._install_virtual_keyboard_hooks()

    def toggle_language(self) -> None:
        self.toggle_language_selector()

    def _update_static_texts(self) -> None:
        titles = {
            "system": self._t("System", "System", "System"),
            "ram": self._t("RAM", "RAM", "RAM"),
            "display": self._t("Anzeige", "Display", "Displej"),
            "storage": self._t("Datenträger", "Storage", "Úložiště"),
            "match": self._t("Modelltreffer", "Model Match", "Shoda modelu"),
            "actions": self._t("Aktionen", "Actions", "Akce"),
        }
        for key, value in titles.items():
            if key in self.panel_title_vars:
                self.panel_title_vars[key].set(value)

        button_texts = {
            "v5": self._t("Zurück zu v5", "Back to v5", "Zpět do v5"),
            "language": self.language,
            "settings": self._t("Einstellung", "Settings", "Nastavení"),
            "wifi": self._t("WLAN", "Wi-Fi", "Wi-Fi"),
            "color": self._t("Layout", "Layout", "Vzhled"),
            "report": self._t("Text", "Text", "Text"),
            "print": self._t("Drucken", "Print", "Tisk"),
            "printer": self._t("Drucker", "Printer", "Tiskárna"),
            "update": self._t("DB-Update", "DB update", "DB update"),
            "appupdate": self._t("Programm-Update", "App update", "Update programu"),
            "poweroff": self._t("Aus", "Power off", "Vypnout"),
        }
        for button in self.action_buttons:
            key = getattr(button, "_hc_action_key", "")
            if key in button_texts:
                button.configure(text=button_texts[key])
        self._update_language_button()
        self._set_internet_indicator(self.internet_state, self.internet_message)
        self._update_db_indicator()
        self._refresh_status_translation()
        status, capacity = get_battery_info()
        self.battery_var.set(self._translated_battery(status, capacity))

    def _translated_battery(self, status: str, capacity: str) -> str:
        return translated_battery_line(status, capacity, self.language)

    def _system_action(self, action: str, confirm: bool = True) -> None:
        prompt = self._t(f"Wirklich {action} ausführen?", f"Really run {action}?", f"Opravdu spustit {action}?")
        if confirm and not messagebox.askyesno(APP_TITLE, prompt):
            return
        subprocess.Popen([action])

    def restart_v5_interface(self) -> None:
        if not (SCRIPT_DIR / "hardwarecheck_v5_gui.py").is_file():
            self.set_status(self._t("v5-Oberfläche nicht gefunden.", "v5 interface not found.", "Rozhraní v5 nebylo nalezeno."), important=True)
            return
        env = os.environ.copy()
        env.pop("HC_USE_LEGACY_UI", None)
        os.execve(sys.executable, [sys.executable, str(pathlib.Path(__file__).resolve())], env)

    def run_shell_fallback(self) -> None:
        shell_script = SCRIPT_DIR / "HardwareCheck.sh"
        if shell_script.exists():
            self.set_status("Starte Shell-Fallback ...")
            self.root.destroy()
            os.execv("/bin/bash", ["/bin/bash", str(shell_script)])
        messagebox.showerror(APP_TITLE, "HardwareCheck.sh wurde nicht gefunden.")

    def _schedule_battery_refresh(self) -> None:
        details = read_battery_details()
        status = str(details.get("status") or "Unknown")
        capacity_value = details.get("capacity_percent")
        capacity = f"{capacity_value} %" if capacity_value is not None else ""
        self.battery_var.set(self._translated_battery(status, capacity))
        if self._battery_test_active:
            self._refresh_battery_test_dialog(details)
            if not self._last_status_important:
                self._last_status_raw = self._battery_test_footer_text(details)
                self.status_var.set(self._last_status_raw)
        self.root.after(1500, self._schedule_battery_refresh)

    def refresh(self, rescan: bool = True) -> None:
        self._update_static_texts()
        if rescan or not self.snapshot:
            if self._scan_busy:
                self.set_status(self._t("Hardware-Scan läuft ...", "Hardware scan running ...", "Scan hardwaru běží ..."))
                return
            self._scan_busy = True
            self.set_status(self._t("Scanne Hardware ...", "Scanning hardware ...", "Skenuji hardware ..."))
            self.root.update_idletasks()

            def worker() -> None:
                try:
                    snapshot = get_system_snapshot()
                except Exception as exc:  # pragma: no cover - visible status is better than a dead UI.
                    error = str(exc)
                    self.root.after(0, lambda error=error: self._finish_scan(None, error))
                    return
                self.root.after(0, lambda snapshot=snapshot: self._finish_scan(snapshot, None))

            threading.Thread(target=worker, name="hardware-scan", daemon=True).start()
            return

        self.set_status(
            self._t("Scanne Hardware ...", "Scanning hardware ...", "Skenuji hardware ...")
            if rescan or not self.snapshot
            else self._t("Aktualisiere Sprache ...", "Updating language ...", "Aktualizuji jazyk ...")
        )
        self.root.update_idletasks()
        model_entries = load_model_db()
        if model_entries:
            self.model_match_results = get_model_match_results(self.snapshot, model_entries)
            match_limit = 5 if self.compact_ui else 7
            self.matches = format_model_match_results(self.model_match_results, self.language, limit=match_limit)
        else:
            self.model_match_results = []
            self.matches = ["Keine model.json geladen"]

        self.header_var.set(
            f"{APP_TITLE}   {self.snapshot['vendor_short']} {self.snapshot['cpu_short']}   ({self.language})".strip()
        )
        self.system_lines_var.set(
            "\n".join(
                [
                    f"{self._t('CPU', 'CPU', 'CPU')}: {self.snapshot['cpu']}",
                    f"{self._t('Grafik', 'Graphics', 'Grafika')}: {self.snapshot.get('graphics') or self._t('Unbekannt', 'Unknown', 'Neznámé')}",
                    f"{self._t('Hersteller', 'Vendor', 'Výrobce')}: {self.snapshot['vendor'] or self._t('Unbekannt', 'Unknown', 'Neznámé')}",
                    f"{self._t('Modell', 'Model', 'Model')}: {self.snapshot['model_name'] or self._t('Unbekannt', 'Unknown', 'Neznámé')}",
                    f"{self._t('Produkt-Nr', 'Product No', 'Produkt')}: {self.snapshot['product_no'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
                    f"{self._t('Seriennummer', 'Serial', 'Seriove cislo')}: {self.snapshot['serial'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
                ]
            )
        )

        ram_lines = []
        modules: list[RamModule] = self.snapshot["ram_modules"]  # type: ignore[assignment]
        for index, module in enumerate(modules, start=1):
            speed = module.configured_speed_mhz or module.speed_mhz or "?"
            ram_type = module.ram_type or self.snapshot["ram_type"] or "Unknown"
            ram_lines.append(f"Slot {index}: {module.size_gb} GB | {speed} MT/s | {ram_type}")
        if self.snapshot["ram_slots_total"] and int(self.snapshot["ram_slots_total"]) > len(modules):
            for index in range(len(modules) + 1, int(self.snapshot["ram_slots_total"]) + 1):
                ram_lines.append(f"{self._t('Slot', 'Slot', 'Slot')} {index}: {self._t('LEER', 'EMPTY', 'PRÃZDNÃ')}")
        ram_lines.extend(
            [
                "",
                f"{self._t('Installiert', 'Installed', 'Instalovano')}: {self.snapshot['ram_total_gb']} GB",
                f"{self._t('Typ', 'Type', 'Typ')}: {self.snapshot['ram_type'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
                f"Layout: {self.snapshot['ram_layout'] or self._t('Unbekannt', 'Unknown', 'Nezname')}",
            ]
        )
        self.ram_lines_var.set("\n".join(ram_lines))

        display_lines = [
            f"{self._t('Auflösung', 'Resolution', 'Rozlišení')}: {self.snapshot['resolution'] or self._t('Unbekannt', 'Unknown', 'Neznámé')}",
        ]
        display_lines.extend(
            [
                f"{self._t('Typ', 'Type', 'Typ')}: {self.snapshot['display_type'] or self._t('Unbekannt', 'Unknown', 'Neznámé')}",
                f"{self._t('Größe', 'Size', 'Velikost')}: {self.snapshot['display_inches'] or self._t('Unbekannt', 'Unknown', 'Neznámé')}\"",
            ]
        )
        self.display_lines_var.set("\n".join(display_lines))
        storage_width = 38 if self.compact_ui else 46
        self.storage_lines_var.set(
            "\n".join(textwrap.fill(line, width=storage_width) for line in self.snapshot["storage_lines"])
            or self._t("Keine internen Datenträger erkannt", "No internal disks detected", "Nenalezen interní disk")
        )
        self.match_lines_var.set("\n\n".join(textwrap.fill(line, width=42 if self.compact_ui else 58) for line in self.matches))
        scan_message = (
            f"{self._t('Hardware-Scan abgeschlossen', 'Hardware scan complete', 'Scan hotov')} | "
            f"{self.db_var.get()} | model.json: {get_models_path()}"
        )
        if self._auto_update_messages:
            self.set_status(" | ".join(self._auto_update_messages), important=True)
        else:
            self.set_status(scan_message)
        self._write_gui_debug("refresh")

    def _finish_scan(self, snapshot: dict[str, object] | None, error: str | None) -> None:
        self._scan_busy = False
        if error or snapshot is None:
            self.set_status(
                f"{self._t('Hardware-Scan fehlgeschlagen', 'Hardware scan failed', 'Scan hardwaru selhal')}: {error}"
            )
            return
        self.snapshot = snapshot
        self.refresh(rescan=False)

    def _open_model_match_details_legacy(self, _event=None) -> None:
        snapshot = self.snapshot or get_system_snapshot()
        current_results: list[dict[str, object]] = list(self.model_match_results or get_model_match_results(snapshot))

        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()

        dialog_width = min(1760, max(1180, self.screen_width - 2))
        dialog_height = min(1080, max(760, self.screen_height - 2))
        dialog = tk.Frame(overlay, bg="#111821", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)
        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(2, weight=1)

        title = tk.Frame(dialog, bg="#111821")
        title.grid(row=0, column=0, sticky="ew", padx=18, pady=(14, 6))
        title.columnconfigure(0, weight=1)
        tk.Label(
            title,
            text=self._t("Modell-Details", "Model details", "Detaily modelu"),
            bg="#111821",
            fg="#f7d37c",
            font=("Segoe UI", 18 if self.compact_ui else 24, "bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew")

        def close() -> None:
            self._hide_virtual_keyboard()
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            overlay.destroy()

        tk.Button(
            title,
            text="X",
            command=close,
            bg="#263342",
            fg="#f7f4e8",
            activebackground="#3a4d60",
            activeforeground="#ffffff",
            bd=0,
            font=("Segoe UI", 10 if self.compact_ui else 12, "bold"),
            width=4,
        ).grid(row=0, column=1, padx=(10, 0))

        search_row = tk.Frame(dialog, bg="#111821")
        search_row.grid(row=1, column=0, sticky="ew", padx=18, pady=(0, 10))
        search_row.columnconfigure(1, weight=1)
        tk.Label(
            search_row,
            text=self._t("Suche", "Search", "Hledat"),
            bg="#111821",
            fg="#dce7f4",
            font=("Segoe UI", 11 if self.compact_ui else 14, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))
        search_var = tk.StringVar(value="")
        search_entry = tk.Entry(
            search_row,
            textvariable=search_var,
            bg="#202733",
            fg="#ffffff",
            insertbackground="#ffffff",
            relief="solid",
            bd=1,
            font=("Consolas", 10 if self.compact_ui else 12),
        )
        search_entry.grid(row=0, column=1, sticky="ew", padx=(0, 8))

        content = tk.Frame(dialog, bg="#111821")
        content.grid(row=2, column=0, sticky="nsew", padx=18, pady=(0, 14))
        content.columnconfigure(0, weight=1)
        content.rowconfigure(0, weight=3)
        content.rowconfigure(1, weight=2)

        table_frame = tk.Frame(content, bg="#111821")
        table_frame.grid(row=0, column=0, sticky="nsew", pady=(0, 10))
        table_frame.rowconfigure(1, weight=1)
        table_frame.columnconfigure(0, weight=1)

        result_count_var = tk.StringVar(value="")
        tk.Label(
            table_frame,
            textvariable=result_count_var,
            bg="#111821",
            fg="#dce7f4",
            font=("Segoe UI", 9 if self.compact_ui else 11, "bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew", pady=(0, 4))

        tree_style = "HCModel.Treeview"
        heading_style = "HCModel.Treeview.Heading"
        try:
            style = ttk.Style(dialog)
            try:
                style.theme_use("clam")
            except tk.TclError:
                pass
            style.configure(
                tree_style,
                background="#0f1722",
                foreground="#f3f7ff",
                fieldbackground="#0f1722",
                borderwidth=0,
                rowheight=29 if self.compact_ui else 34,
                font=("Segoe UI", 9 if self.compact_ui else 11),
            )
            style.configure(
                heading_style,
                background="#e5e1d8",
                foreground="#000000",
                borderwidth=0,
                font=("Segoe UI", 9 if self.compact_ui else 11, "bold"),
            )
            style.map(tree_style, background=[("selected", "#b17300")], foreground=[("selected", "#ffffff")])
        except tk.TclError:
            pass

        columns = ("score", "model", "ref", "vendor", "cpu", "ram", "storage", "display", "info")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse", style=tree_style)
        headings = {
            "score": "%",
            "model": "ID",
            "ref": self._t("Refurbished", "Refurbished", "Repasovane"),
            "vendor": self._t("Hersteller", "Vendor", "Vyrobce"),
            "cpu": "CPU",
            "ram": "RAM",
            "storage": self._t("Speicher", "Storage", "Uloziste"),
            "display": self._t("Anzeige", "Display", "Displej"),
            "info": "Info",
        }
        widths = {
            "score": 58,
            "model": 82,
            "ref": 130,
            "vendor": 110,
            "cpu": 220,
            "ram": 80,
            "storage": 160,
            "display": 170,
            "info": 150,
        }
        anchors = {"score": "center", "model": "center", "ram": "center"}
        for column in columns:
            tree.heading(column, text=headings[column], anchor="center")
            tree.column(column, width=widths[column], minwidth=48, anchor=anchors.get(column, "w"), stretch=column in {"cpu", "storage", "display", "info"})
        tree.grid(row=1, column=0, sticky="nsew")
        tree_scroll = tk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree_scroll.grid(row=1, column=1, sticky="ns")
        tree.configure(yscrollcommand=tree_scroll.set)
        tree.tag_configure("even", background="#101822", foreground="#f3f7ff")
        tree.tag_configure("odd", background="#141d28", foreground="#f3f7ff")
        tree.tag_configure("best", background="#a86d00", foreground="#ffffff")
        tree.tag_configure("excluded", background="#7e2020", foreground="#ffffff")

        detail_frame = tk.Frame(content, bg="#111821")
        detail_frame.grid(row=1, column=0, sticky="nsew")
        detail_frame.rowconfigure(1, weight=1)
        detail_frame.columnconfigure(0, weight=1)
        detail_title_var = tk.StringVar(value="")
        tk.Label(
            detail_frame,
            textvariable=detail_title_var,
            bg="#111821",
            fg="#f7d37c",
            font=("Segoe UI", 10 if self.compact_ui else 12, "bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew", pady=(0, 4))
        detail_text = tk.Text(
            detail_frame,
            bg="#0f1722",
            fg="#eef6ff",
            insertbackground="#ffffff",
            relief="solid",
            bd=1,
            wrap="word",
            font=("Consolas", 9 if self.compact_ui else 11),
        )
        detail_text.grid(row=1, column=0, sticky="nsew")
        detail_scroll = tk.Scrollbar(detail_frame, orient="vertical", command=detail_text.yview)
        detail_scroll.grid(row=1, column=1, sticky="ns")
        detail_text.configure(yscrollcommand=detail_scroll.set)

        def item_text(item: dict[str, object], key: str, default: str = "-") -> str:
            value = str(item.get(key) or "").strip()
            return value or default

        def refs_text(item: dict[str, object]) -> str:
            values = []
            for key in ("base_model_id", "refurbished_ids"):
                value = str(item.get(key) or "").strip()
                if value and value not in values:
                    values.append(value)
            return ", ".join(values) or "-"

        def storage_text(item: dict[str, object]) -> str:
            size = str(item.get("ssd") or item.get("storage_gb") or "").strip()
            storage_type = str(item.get("storage_type") or "").strip()
            if size and storage_type:
                return f"{size} GB {storage_type}"
            return storage_type or (f"{size} GB" if size else "-")

        def display_text(item: dict[str, object]) -> str:
            inch = str(item.get("inch") or item.get("display_size") or item.get("display_inch") or "").strip()
            display_type = str(item.get("display_type") or "").strip()
            parts = []
            if inch and inch not in {"0", "0.0"}:
                parts.append(f'{inch}"')
            if display_type:
                parts.append(display_type)
            return " ".join(parts) or "-"

        def info_text(item: dict[str, object]) -> str:
            values = []
            for key in ("info", "software"):
                value = str(item.get(key) or "").strip()
                if value and value not in {"-", "None"} and value not in values:
                    values.append(value)
            return " + ".join(values) or "-"

        def table_values(result: dict[str, object]) -> tuple[str, str, str, str, str, str, str, str, str]:
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            score = display_match_percent(result.get("score"))
            return (
                f"{score}%",
                item_text(item, "model_id"),
                refs_text(item),
                item_text(item, "vendor"),
                item_text(item, "cpu"),
                item_text(item, "ram_total"),
                storage_text(item),
                display_text(item),
                info_text(item),
            )

        def set_detail(result: dict[str, object]) -> None:
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            detail_title_var.set(
                self._t("Details", "Details", "Detaily")
                + f": {item_text(item, 'model_id')} - {display_match_percent(result.get('score'))}%"
            )
            detail_text.configure(state="normal")
            detail_text.delete("1.0", "end")
            detail_text.insert("1.0", format_model_detail_text(snapshot, result, self.language))
            detail_text.configure(state="disabled")

        def set_empty_detail(message: str) -> None:
            detail_title_var.set(self._t("Keine Treffer", "No matches", "Zadne shody"))
            detail_text.configure(state="normal")
            detail_text.delete("1.0", "end")
            detail_text.insert("1.0", message)
            detail_text.configure(state="disabled")

        def populate(results: list[dict[str, object]]) -> None:
            nonlocal current_results
            current_results = results
            for iid in tree.get_children():
                tree.delete(iid)
            result_count_var.set(
                self._t("Treffer", "Matches", "Shody") + f": {len(current_results)}"
            )
            for index, result in enumerate(current_results):
                tags: list[str] = ["odd" if index % 2 else "even"]
                if index == 0 and not result.get("excluded"):
                    tags.append("best")
                if result.get("excluded"):
                    tags.append("excluded")
                tree.insert("", "end", iid=str(index), values=table_values(result), tags=tuple(tags))
            if current_results:
                tree.selection_set("0")
                tree.focus("0")
                tree.see("0")
                set_detail(current_results[0])
            else:
                set_empty_detail(
                    self._t(
                        "Keine Suchergebnisse. Bitte Modell-ID, Produktnummer, Hersteller, CPU oder Speicherbegriff eingeben.",
                        "No search results. Enter model ID, product number, vendor, CPU or storage term.",
                        "Zadne vysledky. Zadejte ID modelu, produktove cislo, vyrobce, CPU nebo uloziste.",
                    )
                )

        def show_selected(_event=None) -> None:
            selection = tree.selection()
            if not selection:
                return
            index = int(selection[0])
            if 0 <= index < len(current_results):
                set_detail(current_results[index])

        def search_models() -> None:
            query = search_var.get().strip()
            if not query:
                populate(list(self.model_match_results or get_model_match_results(snapshot)))
                return
            found = find_model_db_items(query, limit=50)
            scored: list[dict[str, object]] = []
            for item in found:
                result = score_model_candidate(snapshot, item, include_exclusion_reason=True)
                if result is None:
                    result = {
                        "score": 0,
                        "item": item,
                        "reasons": [self._t("Nicht passend zum aktuellen Geraet.", "Does not match the current device.", "Neodpovida aktualnimu zarizeni.")],
                        "excluded": self._t("Nicht passend", "No match", "Neshoda"),
                    }
                scored.append(result)
            scored.sort(key=lambda entry: float(entry.get("score") or 0), reverse=True)
            populate(scored)

        tree.bind("<<TreeviewSelect>>", show_selected)
        tree.bind("<Double-Button-1>", show_selected)
        search_entry.bind("<Return>", lambda _event: search_models())

        self._button(search_row, self._t("Suchen", "Search", "Hledat"), search_models).grid(row=0, column=2, padx=(0, 6))
        self._button(
            search_row,
            self._t("Aktuelle Treffer", "Current matches", "Aktualni shody"),
            lambda: populate(list(self.model_match_results or get_model_match_results(snapshot))),
        ).grid(row=0, column=3, padx=(0, 6))
        self._button(search_row, self._t("Schliessen", "Close", "Zavrit"), close).grid(row=0, column=4)

        populate(current_results)
        self._bind_dialog_escape(overlay, close)
        overlay.bind("<Button-3>", lambda _event: close())

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
                search_entry.focus_set()
            except tk.TclError:
                pass

        overlay.after(80, bring_to_front)

    def open_model_match_details(self, _event=None) -> None:
        snapshot = dict(self.snapshot or get_system_snapshot())
        model_entries = load_model_db()
        if not model_entries:
            messagebox.showwarning(
                self._t("Modell-Details", "Model details", "Detaily modelu"),
                self._t("Keine model.json geladen.", "No model.json loaded.", "Soubor model.json nenÃ­ naÄten."),
                parent=self.root,
            )
            return

        entry_by_id = {
            str(item.get("model_id") or "").strip(): item
            for item in model_entries
            if str(item.get("model_id") or "").strip()
        }
        relation_map = build_model_relation_map(model_entries)
        established_results = list(self.model_match_results or get_model_match_results(snapshot, model_entries))
        initial_results: list[dict[str, object]] = [
            score_snapshot_model_for_finder(snapshot, result["item"])
            for result in established_results
            if isinstance(result.get("item"), dict)
        ]
        initial_results.sort(
            key=lambda result: (
                -int(result.get("score") or 0),
                model_value_int((result.get("item") or {}).get("model_id")),
            )
        )
        compare_models: list[dict[str, object]] = [
            result["item"]
            for result in initial_results[:2]
            if isinstance(result.get("item"), dict)
        ]
        current_results: list[dict[str, object]] = []
        option_bindings: list[dict[str, object]] = []
        result_state: dict[str, object] = {"mode": "device", "base": None}
        live_after: str | None = None

        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()

        available_width = max(760, self.screen_width - 12)
        available_height = max(520, self.screen_height - 12)
        dialog_width = min(1760, available_width)
        dialog_height = min(1040, available_height)
        min_width = min(900, max(720, self.screen_width - 80))
        min_height = min(620, max(500, self.screen_height - 80))
        geometry_state: dict[str, object] = {
            "x": max(0, (self.screen_width - dialog_width) // 2),
            "y": max(0, (self.screen_height - dialog_height) // 2),
            "width": dialog_width,
            "height": dialog_height,
            "maximized": True,
            "restore": None,
        }

        dialog = tk.Frame(overlay, bg="#111821", highlightthickness=2, highlightbackground="#d4a84d")

        def apply_dialog_geometry() -> None:
            dialog.place(
                x=int(geometry_state["x"]),
                y=int(geometry_state["y"]),
                width=int(geometry_state["width"]),
                height=int(geometry_state["height"]),
            )

        apply_dialog_geometry()
        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(2, weight=1)

        title = tk.Frame(dialog, bg="#111821", cursor="fleur")
        title.grid(row=0, column=0, sticky="ew", padx=14, pady=(10, 5))
        title.columnconfigure(0, weight=1)
        title_label = tk.Label(
            title,
            text=self._t("Modell-Finder und Vergleich", "Model finder and comparison", "VyhledÃ¡vaÄ a porovnÃ¡nÃ­ modelÅ¯"),
            bg="#111821",
            fg="#f7d37c",
            font=("Segoe UI", 16 if self.compact_ui else 21, "bold"),
            anchor="w",
            cursor="fleur",
        )
        title_label.grid(row=0, column=0, sticky="ew")

        def close() -> None:
            nonlocal live_after
            if live_after:
                try:
                    dialog.after_cancel(live_after)
                except tk.TclError:
                    pass
                live_after = None
            self._hide_virtual_keyboard()
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            overlay.destroy()

        maximize_button = tk.Button(
            title,
            text="□",
            bg="#263342",
            fg="#f7f4e8",
            activebackground="#3a4d60",
            activeforeground="#ffffff",
            bd=0,
            font=("Segoe UI", 11, "bold"),
            width=4,
        )
        maximize_button.grid(row=0, column=1, padx=(8, 4))
        tk.Button(
            title,
            text="X",
            command=close,
            bg="#263342",
            fg="#f7f4e8",
            activebackground="#7e2020",
            activeforeground="#ffffff",
            bd=0,
            font=("Segoe UI", 10 if self.compact_ui else 12, "bold"),
            width=4,
        ).grid(row=0, column=2)

        search_panel = tk.Frame(dialog, bg="#171f2a", highlightthickness=1, highlightbackground="#36475a")
        search_panel.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 8))
        search_panel.columnconfigure(1, weight=1)
        tk.Label(
            search_panel,
            text=self._t("Suche", "Search", "Hledat"),
            bg="#171f2a",
            fg="#f4f7fb",
            font=("Segoe UI", 10 if self.compact_ui else 12, "bold"),
        ).grid(row=0, column=0, padx=(10, 7), pady=(8, 4), sticky="w")
        search_var = tk.StringVar(value="")
        search_entry = tk.Entry(
            search_panel,
            textvariable=search_var,
            bg="#202733",
            fg="#ffffff",
            insertbackground="#ffffff",
            relief="solid",
            bd=1,
            font=("Consolas", 10 if self.compact_ui else 12),
        )
        search_entry.grid(row=0, column=1, sticky="ew", padx=(0, 8), pady=(8, 4))
        search_entry._hc_suppress_virtual_keyboard = True  # type: ignore[attr-defined]

        finder_keyboard_var = tk.BooleanVar(value=False)

        def toggle_finder_keyboard() -> None:
            enabled = bool(finder_keyboard_var.get())
            search_entry._hc_suppress_virtual_keyboard = not enabled  # type: ignore[attr-defined]
            if enabled:
                search_entry.focus_set()
                self._show_virtual_keyboard(search_entry)
            else:
                self._hide_virtual_keyboard()

        tk.Checkbutton(
            search_panel,
            text=self._t("Bildschirmtastatur", "On-screen keyboard", "Klávesnice na obrazovce"),
            variable=finder_keyboard_var,
            command=toggle_finder_keyboard,
            bg="#171f2a",
            fg="#f4f7fb",
            activebackground="#171f2a",
            activeforeground="#ffffff",
            selectcolor="#263342",
        ).grid(row=0, column=2, padx=(0, 10), pady=(8, 4), sticky="e")

        show_device_var = tk.BooleanVar(value=True)
        live_var = tk.BooleanVar(value=True)
        min_percent_var = tk.IntVar(value=15)
        controls = tk.Frame(search_panel, bg="#171f2a")
        controls.grid(row=1, column=0, columnspan=3, sticky="ew", padx=8, pady=(2, 7))
        controls.columnconfigure(8, weight=1)
        tk.Label(
            controls,
            text=self._t("Min %", "Min %", "Min %"),
            bg="#171f2a",
            fg="#dce7f4",
        ).grid(row=0, column=0, padx=(0, 4))
        min_spin = tk.Spinbox(
            controls,
            from_=1,
            to=100,
            textvariable=min_percent_var,
            width=5,
            bg="#202733",
            fg="#ffffff",
            buttonbackground="#263342",
            insertbackground="#ffffff",
        )
        min_spin.grid(row=0, column=1, padx=(0, 10))
        show_device_check = tk.Checkbutton(
            controls,
            text=self._t("Aktuelles Gerät anzeigen", "Show current device", "Zobrazit aktuální zařízení"),
            variable=show_device_var,
            bg="#171f2a",
            fg="#f4f7fb",
            activebackground="#171f2a",
            activeforeground="#ffffff",
            selectcolor="#263342",
        )
        show_device_check.grid(row=0, column=2, padx=(0, 10))
        tk.Checkbutton(
            controls,
            text=self._t("Live", "Live", "Živě"),
            variable=live_var,
            bg="#171f2a",
            fg="#f4f7fb",
            activebackground="#171f2a",
            activeforeground="#ffffff",
            selectcolor="#263342",
        ).grid(row=0, column=3, padx=(0, 10))

        body = tk.PanedWindow(
            dialog,
            orient="vertical",
            bg="#2d3a49",
            bd=0,
            sashwidth=7,
            sashrelief="flat",
            opaqueresize=True,
        )
        body.grid(row=2, column=0, sticky="nsew", padx=14, pady=(0, 14))

        compare_panel = tk.Frame(body, bg="#111821")
        compare_panel.columnconfigure(0, weight=1)
        compare_panel.rowconfigure(1, weight=1)
        body.add(compare_panel, minsize=230, height=390 if self.screen_height >= 800 else 320)

        compare_header = tk.Frame(compare_panel, bg="#171f2a")
        compare_header.grid(row=0, column=0, sticky="ew", pady=(0, 4))
        compare_header.columnconfigure(0, weight=1)
        compare_title_var = tk.StringVar(value="")
        tk.Label(
            compare_header,
            textvariable=compare_title_var,
            bg="#171f2a",
            fg="#f4f7fb",
            font=("Segoe UI", 10 if self.compact_ui else 12, "bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew", padx=8, pady=6)

        compare_area = tk.Frame(compare_panel, bg="#111821")
        compare_area.grid(row=1, column=0, sticky="nsew")
        compare_area.columnconfigure(1, weight=1)
        compare_area.rowconfigure(0, weight=1)
        left_grid = tk.Frame(compare_area, bg="#111821")
        left_grid.grid(row=0, column=0, sticky="nsw")
        right_frame = tk.Frame(compare_area, bg="#111821")
        right_frame.grid(row=0, column=1, sticky="nsew")
        right_frame.columnconfigure(0, weight=1)
        right_frame.rowconfigure(0, weight=1)
        compare_canvas = tk.Canvas(right_frame, bg="#111821", highlightthickness=0)
        compare_canvas.grid(row=0, column=0, sticky="nsew")
        compare_scroll = tk.Scrollbar(right_frame, orient="horizontal", command=compare_canvas.xview)
        compare_scroll.grid(row=1, column=0, sticky="ew")
        compare_canvas.configure(xscrollcommand=compare_scroll.set)
        compare_inner = tk.Frame(compare_canvas, bg="#111821")
        compare_window = compare_canvas.create_window((0, 0), window=compare_inner, anchor="nw")

        lower = tk.PanedWindow(
            body,
            orient="vertical",
            bg="#2d3a49",
            bd=0,
            sashwidth=7,
            sashrelief="flat",
            opaqueresize=True,
        )
        body.add(lower, minsize=220)

        result_frame = tk.Frame(lower, bg="#111821")
        result_frame.columnconfigure(0, weight=1)
        result_frame.rowconfigure(1, weight=1)
        lower.add(result_frame, minsize=120, height=230)
        result_count_var = tk.StringVar(value="")
        tk.Label(
            result_frame,
            textvariable=result_count_var,
            bg="#111821",
            fg="#dce7f4",
            font=("Segoe UI", 9 if self.compact_ui else 11, "bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew", pady=(0, 4))

        tree_style = "HCModelFinder.Treeview"
        heading_style = "HCModelFinder.Treeview.Heading"
        try:
            style = ttk.Style(dialog)
            try:
                style.theme_use("clam")
            except tk.TclError:
                pass
            style.configure(
                tree_style,
                background="#0f1722",
                foreground="#f3f7ff",
                fieldbackground="#0f1722",
                borderwidth=0,
                rowheight=28 if self.compact_ui else 32,
                font=("Segoe UI", 9 if self.compact_ui else 10),
            )
            style.configure(
                heading_style,
                background="#e5e1d8",
                foreground="#000000",
                borderwidth=0,
                font=("Segoe UI", 9 if self.compact_ui else 10, "bold"),
            )
            style.map(tree_style, background=[("selected", "#b17300")], foreground=[("selected", "#ffffff")])
        except tk.TclError:
            pass

        tree_box = tk.Frame(result_frame, bg="#111821")
        tree_box.grid(row=1, column=0, sticky="nsew")
        tree_box.columnconfigure(0, weight=1)
        tree_box.rowconfigure(0, weight=1)
        columns = ("score", "base", "ref", "vendor", "cpu", "ram", "storage", "display", "info")
        tree = ttk.Treeview(tree_box, columns=columns, show="headings", selectmode="browse", style=tree_style)
        tree.grid(row=0, column=0, sticky="nsew")
        tree_y = tk.Scrollbar(tree_box, orient="vertical", command=tree.yview)
        tree_y.grid(row=0, column=1, sticky="ns")
        tree_x = tk.Scrollbar(tree_box, orient="horizontal", command=tree.xview)
        tree_x.grid(row=1, column=0, sticky="ew")
        tree.configure(yscrollcommand=tree_y.set, xscrollcommand=tree_x.set)
        headings = {
            "score": "%",
            "base": self._t("Basis ID", "Base ID", "Základní ID"),
            "ref": self._t("Refurbished", "Refurbished", "Repasované"),
            "vendor": self._t("Hersteller", "Vendor", "Výrobce"),
            "cpu": "CPU",
            "ram": "RAM",
            "storage": self._t("Speicher", "Storage", "Úložiště"),
            "display": self._t("Anzeige", "Display", "Displej"),
            "info": "Info",
        }
        widths = {"score": 76, "base": 90, "ref": 135, "vendor": 100, "cpu": 205, "ram": 70, "storage": 145, "display": 175, "info": 220}
        for column in columns:
            tree.heading(column, text=headings[column], anchor="center")
            tree.column(column, width=widths[column], minwidth=55, anchor="center", stretch=column in {"cpu", "info"})
        tree.tag_configure("even", background="#101822", foreground="#f3f7ff")
        tree.tag_configure("odd", background="#141d28", foreground="#f3f7ff")
        tree.tag_configure("best", background="#a86d00", foreground="#ffffff")
        tree.tag_configure("excluded", background="#7e2020", foreground="#ffffff")

        detail_frame = tk.Frame(lower, bg="#111821")
        detail_frame.columnconfigure(0, weight=1)
        detail_frame.rowconfigure(1, weight=1)
        lower.add(detail_frame, minsize=100, height=190)
        detail_title_var = tk.StringVar(value="")
        tk.Label(
            detail_frame,
            textvariable=detail_title_var,
            bg="#111821",
            fg="#f7d37c",
            font=("Segoe UI", 9 if self.compact_ui else 11, "bold"),
            anchor="w",
        ).grid(row=0, column=0, sticky="ew", pady=(0, 4))
        detail_text = tk.Text(
            detail_frame,
            bg="#0f1722",
            fg="#eef6ff",
            insertbackground="#ffffff",
            relief="solid",
            bd=1,
            wrap="word",
            font=("Consolas", 8 if self.compact_ui else 10),
        )
        detail_text.grid(row=1, column=0, sticky="nsew")
        detail_scroll = tk.Scrollbar(detail_frame, orient="vertical", command=detail_text.yview)
        detail_scroll.grid(row=1, column=1, sticky="ns")
        detail_text.configure(yscrollcommand=detail_scroll.set)

        def set_detail_message(title_text: str, message: str) -> None:
            detail_title_var.set(title_text)
            detail_text.configure(state="normal")
            detail_text.delete("1.0", "end")
            detail_text.insert("1.0", message)
            detail_text.configure(state="disabled")

        def fit_compare_canvas(_event=None) -> None:
            try:
                compare_inner.update_idletasks()
                required_width = compare_inner.winfo_reqwidth()
                viewport_width = max(1, compare_canvas.winfo_width())
                width = max(required_width, viewport_width)
                compare_canvas.itemconfigure(compare_window, width=width)
                compare_canvas.configure(scrollregion=(0, 0, width, compare_inner.winfo_reqheight()))
            except tk.TclError:
                pass

        compare_inner.bind("<Configure>", fit_compare_canvas)
        compare_canvas.bind("<Configure>", fit_compare_canvas)

        def score_item_for_mode(item: dict[str, object], mode: str, base: dict[str, object] | None) -> dict[str, object]:
            if mode == "device":
                return score_snapshot_model_for_finder(snapshot, item)
            percent = model_similarity_score(base or item, item)
            return {"score": percent, "item": item, "reasons": [], "excluded": "", "raw_score": percent}

        def score_items(
            items: list[dict[str, object]],
            mode: str,
            base: dict[str, object] | None = None,
            sort_results: bool = True,
        ) -> list[dict[str, object]]:
            scored = [score_item_for_mode(item, mode, base) for item in items]
            if sort_results:
                scored.sort(key=lambda entry: (-float(entry.get("score") or 0), model_value_int((entry.get("item") or {}).get("model_id") if isinstance(entry.get("item"), dict) else 0)))
            return scored

        def result_values(result: dict[str, object]) -> tuple[str, ...]:
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            model_id = str(item.get("model_id") or "-").strip()
            base_ids, refurb_ids = relation_map.get(model_id, ([], []))
            compared_ids = {str(model.get("model_id") or "").strip() for model in compare_models}
            compared_marker = " ★" if model_id in compared_ids else ""
            if model_is_refurbished(item):
                base_text = ", ".join(base_ids[:2]) or "-"
                refurb_text = model_id + compared_marker
            else:
                base_text = model_id + compared_marker
                refurb_text = ", ".join(refurb_ids[:3]) or "-"
            info_values = []
            for key in ("info", "software"):
                value = str(item.get(key) or "").strip()
                if value and value not in info_values:
                    info_values.append(value)
            return (
                f"{display_match_percent(result.get('score'))}%",
                base_text,
                refurb_text,
                str(item.get("vendor") or "-").strip(),
                str(item.get("cpu") or "-").strip(),
                str(model_value_int(item.get("ram_total")) or "-"),
                model_storage_summary(item),
                model_display_summary(item),
                " + ".join(info_values) or "-",
            )

        def set_detail(result: dict[str, object]) -> None:
            item = result.get("item") if isinstance(result.get("item"), dict) else {}
            model_id = str(item.get("model_id") or "-").strip()
            score = display_match_percent(result.get("score"))
            mode = str(result_state.get("mode") or "device")
            score_name = self._t("Gerät", "Device", "Zařízení") if mode == "device" else self._t("Ähnlichkeit", "Similarity", "Podobnost")
            detail_title_var.set(f"{model_id} - {score_name}: {score}%")
            if show_device_var.get():
                text = format_model_detail_text(snapshot, result, self.language)
            else:
                text = format_model_database_detail(item, self.language, score if mode == "similarity" else None)
            detail_text.configure(state="normal")
            detail_text.delete("1.0", "end")
            detail_text.insert("1.0", text)
            detail_text.configure(state="disabled")

        def populate(
            results: list[dict[str, object]],
            mode: str,
            base: dict[str, object] | None = None,
        ) -> None:
            nonlocal current_results
            current_results = results
            result_state["mode"] = mode
            result_state["base"] = base
            for iid in tree.get_children():
                tree.delete(iid)
            percent_heading = self._t("% Gerät", "% Device", "% Zařízení") if mode == "device" else self._t("% Ähnl.", "% Similar", "% Podob.")
            tree.heading("score", text=percent_heading, anchor="center")
            result_count_var.set(
                self._t("Treffer", "Matches", "Výsledky")
                + f": {len(results)} | "
                + self._t(
                    "Treffer anklicken = direkt vergleichen",
                    "Click a match = compare directly",
                    "Kliknutím na výsledek jej přímo porovnáte",
                )
            )
            for index, result in enumerate(results):
                tags: list[str] = ["odd" if index % 2 else "even"]
                if index == 0 and not result.get("excluded"):
                    tags.append("best")
                if result.get("excluded"):
                    tags.append("excluded")
                tree.insert("", "end", iid=str(index), values=result_values(result), tags=tuple(tags))
            if results:
                tree.selection_set("0")
                tree.focus("0")
                tree.see("0")
                set_detail(results[0])
            else:
                set_detail_message(
                    self._t("Keine Treffer", "No matches", "Žádné výsledky"),
                    self._t(
                        "Keine passenden Modelle gefunden. Bitte weniger Optionen auswählen oder den Mindestwert senken.",
                        "No matching models found. Select fewer options or lower the minimum value.",
                        "Nebyl nalezen žádný odpovídající model. Vyberte méně možností nebo snižte minimální hodnotu.",
                    ),
                )

        def refresh_result_markers() -> None:
            for index, iid in enumerate(tree.get_children()):
                if index < len(current_results):
                    tree.item(iid, values=result_values(current_results[index]))

        def selected_result() -> dict[str, object] | None:
            selection = tree.selection()
            if not selection:
                return None
            index = int(selection[0])
            return current_results[index] if 0 <= index < len(current_results) else None

        def show_selected(_event=None) -> None:
            result = selected_result()
            if result:
                set_detail(result)

        def remember_option_states() -> dict[tuple[str, str], bool]:
            saved: dict[tuple[str, str], bool] = {}
            for binding in option_bindings:
                var = binding.get("var")
                if isinstance(var, tk.BooleanVar):
                    saved[(str(binding.get("source_id") or ""), str(binding.get("key") or ""))] = bool(var.get())
            return saved

        def render_compare() -> None:
            saved_states = remember_option_states()
            option_bindings.clear()
            for child in left_grid.winfo_children():
                child.destroy()
            for child in compare_inner.winfo_children():
                child.destroy()

            sources: list[tuple[str, dict[str, object] | None]] = []
            if show_device_var.get():
                sources.append(("device", None))
            sources.extend((str(item.get("model_id") or ""), item) for item in compare_models)

            if show_device_var.get() and compare_models:
                compare_title_var.set(self._t("Modellvergleich mit aktuellem Gerät", "Model comparison with current device", "Porovnání modelů s aktuálním zařízením"))
            elif len(compare_models) > 1:
                base = compare_models[0]
                scores = [model_similarity_score(base, item) for item in compare_models[1:]]
                compare_title_var.set(f"{self._t('Modellvergleich', 'Model comparison', 'Porovnání modelů')} - {self._t('Match', 'Match', 'Shoda')}: {min(scores)}%")
            else:
                compare_title_var.set(self._t("Modell-Optionen suchen", "Search model options", "Hledat možnosti modelu"))

            snapshot_rows = snapshot_compare_entries(snapshot, self.language)
            labels = [(key, label) for key, label, _value, _available in snapshot_rows]
            if compare_models:
                labels = [(key, label) for key, label, _value in model_compare_entries(compare_models[0], self.language)]

            header_bg = "#e5e1d8"
            header_fg = "#000000"
            row_height = 34 if self.compact_ui else 37
            header_height = 40
            left_grid.grid_columnconfigure(0, minsize=42)
            left_grid.grid_columnconfigure(1, minsize=142 if self.compact_ui else 160)
            for row_index in range(len(labels) + 1):
                height = header_height if row_index == 0 else row_height
                left_grid.grid_rowconfigure(row_index, minsize=height, weight=0)
                compare_inner.grid_rowconfigure(row_index, minsize=height, weight=0)
                number_text = "#" if row_index == 0 else str(row_index)
                category_text = self._t("Kategorie", "Category", "Kategorie") if row_index == 0 else labels[row_index - 1][1]
                for col, text, width in ((0, number_text, 42), (1, category_text, 142 if self.compact_ui else 160)):
                    frame = tk.Frame(
                        left_grid,
                        width=width,
                        height=height,
                        bg=header_bg if row_index == 0 else "#111a25",
                        highlightthickness=1,
                        highlightbackground="#334253",
                    )
                    frame.grid(row=row_index, column=col, sticky="nsew")
                    frame.grid_propagate(False)
                    tk.Label(
                        frame,
                        text=text,
                        bg=frame.cget("bg"),
                        fg=header_fg if row_index == 0 else "#f4f7fb",
                        font=("Segoe UI", 9 if self.compact_ui else 10, "bold" if row_index == 0 else "normal"),
                        anchor="center" if col == 0 else "w",
                    ).pack(fill="both", expand=True, padx=5)

            if not sources:
                fit_compare_canvas()
                return
            try:
                compare_canvas.update_idletasks()
                viewport = max(300, compare_canvas.winfo_width())
            except tk.TclError:
                viewport = max(300, dialog_width - 230)
            column_width = max(300, viewport // max(1, len(sources)))
            base_model = compare_models[0] if compare_models else None
            model_entry_maps = {
                str(item.get("model_id") or ""): {key: value for key, _label, value in model_compare_entries(item, self.language)}
                for item in compare_models
            }
            snapshot_entry_map = {key: (value, available) for key, _label, value, available in snapshot_rows}

            for source_index, (source_id, item) in enumerate(sources):
                header = tk.Frame(
                    compare_inner,
                    width=column_width,
                    height=header_height,
                    bg=header_bg,
                    highlightthickness=1,
                    highlightbackground="#334253",
                )
                header.grid(row=0, column=source_index, sticky="nsew")
                header.grid_propagate(False)
                header.columnconfigure(0, weight=1)
                header.rowconfigure(0, weight=1)
                if source_id == "device":
                    header_text = self._t("Aktuelles Gerät", "Current device", "Aktuální zařízení")
                else:
                    model_id = str(item.get("model_id") or "") if item else ""
                    if show_device_var.get() and item:
                        device_score = snapshot_model_similarity_score(snapshot, item)
                        header_text = f"{self._t('Modell', 'Model', 'Model')} {model_id} ★ - {self._t('Gerät', 'Device', 'Zařízení')} {device_score}%"
                    elif item is base_model:
                        header_text = f"{self._t('Basis', 'Base', 'Základ')} - {self._t('Modell', 'Model', 'Model')} {model_id} ★"
                    else:
                        header_text = f"{self._t('Modell', 'Model', 'Model')} {model_id} ★ - {model_similarity_score(base_model or item, item)}%"
                tk.Label(
                    header,
                    text=header_text,
                    bg=header_bg,
                    fg=header_fg,
                    font=("Segoe UI", 9 if self.compact_ui else 10, "bold"),
                    anchor="center",
                ).grid(row=0, column=0, sticky="nsew", padx=4)
                if source_id != "device":
                    tk.Button(
                        header,
                        text="×",
                        command=lambda model_id=source_id: remove_compare_model(model_id),
                        bg="#d8d2c8",
                        fg="#7e2020",
                        activebackground="#7e2020",
                        activeforeground="#ffffff",
                        bd=0,
                        width=3,
                        font=("Segoe UI", 10, "bold"),
                    ).grid(row=0, column=1, sticky="nse")

                for row_index, (key, _label) in enumerate(labels, start=1):
                    if source_id == "device":
                        value, available = snapshot_entry_map.get(key, ("-", False))
                        same: bool | None = None
                    else:
                        value = model_entry_maps.get(source_id, {}).get(key, "-")
                        available = value not in {"", "-"}
                        if show_device_var.get() and item:
                            same = model_matches_snapshot_option(item, snapshot, key)
                        elif item is base_model:
                            same = None
                        elif item and base_model:
                            same = model_option_matches(item, base_model, key)
                        else:
                            same = None

                    state_key = (source_id, key)
                    if state_key in saved_states:
                        selected = saved_states[state_key]
                    elif source_id == "device":
                        selected = False
                    elif show_device_var.get():
                        selected = bool(available and same is True)
                    elif len(compare_models) == 1:
                        selected = key == "notebook" and available
                    else:
                        selected = bool(available and (item is base_model or same is True))

                    if source_id == "device":
                        background, foreground = "#183047", "#eef6ff"
                    elif same is False:
                        background, foreground = "#8f2020", "#ffffff"
                    elif selected:
                        background, foreground = "#117f77", "#ffffff"
                    elif same is True:
                        background, foreground = "#111a25", "#22c55e"
                    else:
                        background, foreground = "#111a25", "#f4f7fb"
                    if not available:
                        background, foreground = "#18202b", "#7f8b99"

                    cell = tk.Frame(
                        compare_inner,
                        width=column_width,
                        height=row_height,
                        bg=background,
                        highlightthickness=1,
                        highlightbackground="#334253",
                    )
                    cell.grid(row=row_index, column=source_index, sticky="nsew")
                    cell.grid_propagate(False)
                    variable = tk.BooleanVar(value=selected)
                    check = tk.Checkbutton(
                        cell,
                        text=str(value),
                        variable=variable,
                        state="normal" if available else "disabled",
                        bg=background,
                        fg=foreground,
                        disabledforeground=foreground,
                        activebackground=background,
                        activeforeground=foreground,
                        selectcolor=background,
                        anchor="w",
                        justify="left",
                        font=("Segoe UI", 9 if self.compact_ui else 10),
                        padx=5,
                    )
                    check.pack(fill="both", expand=True)
                    option_bindings.append({
                        "var": variable,
                        "key": key,
                        "source_id": source_id,
                        "source": "device" if source_id == "device" else "model",
                        "item": item,
                        "available": available,
                    })
            fit_compare_canvas()

        def add_selected_to_compare(_event=None) -> None:
            result = selected_result()
            item = result.get("item") if isinstance(result, dict) and isinstance(result.get("item"), dict) else None
            if not item:
                return
            model_id = str(item.get("model_id") or "").strip()
            if any(str(existing.get("model_id") or "").strip() == model_id for existing in compare_models):
                return
            if len(compare_models) >= 4:
                set_detail_message(
                    self._t("Vergleich voll", "Comparison full", "Porovnání je plné"),
                    self._t("Es kÃ¶nnen hÃ¶chstens vier Datenbankmodelle gleichzeitig verglichen werden.", "A maximum of four database models can be compared at once.", "SouÄasnÄ› lze porovnat nejvÃ½Å¡e ÄtyÅ™i databÃ¡zovÃ© modely."),
                )
                return
            compare_models.append(item)
            render_compare()
            refresh_result_markers()

        def remove_compare_model(model_id: str) -> None:
            compare_models[:] = [item for item in compare_models if str(item.get("model_id") or "").strip() != model_id]
            render_compare()
            refresh_result_markers()

        def compare_result_from_list(event) -> None:
            row_id = tree.identify_row(event.y)
            if not row_id:
                return
            try:
                result_index = int(row_id)
            except (TypeError, ValueError):
                return
            if result_index < 0 or result_index >= len(current_results):
                return
            tree.selection_set(row_id)
            tree.focus(row_id)
            result = current_results[result_index]
            item = result.get("item") if isinstance(result.get("item"), dict) else None
            if not isinstance(item, dict):
                return

            fixed_models = [entry_by_id[model_id] for model_id in query_model_ids(search_var.get())[:4]]
            if not fixed_models:
                fixed_models = compare_models[:1]
            selected_id = str(item.get("model_id") or "").strip()
            fixed_ids = {str(model.get("model_id") or "").strip() for model in fixed_models}
            if selected_id and selected_id not in fixed_ids:
                if len(fixed_models) >= 4:
                    fixed_models = fixed_models[:3] + [item]
                else:
                    fixed_models.append(item)
            compare_models[:] = fixed_models or [item]
            render_compare()
            refresh_result_markers()
            set_detail(result)

        def query_model_ids(query: str) -> list[str]:
            values: list[str] = []
            for model_id in re.findall(r"\b\d{4,6}\b", query):
                if model_id in entry_by_id and model_id not in values:
                    values.append(model_id)
            return values

        def current_mode() -> str:
            return "device" if show_device_var.get() else "similarity"

        def search_models() -> None:
            nonlocal live_after
            live_after = None
            query = search_var.get().strip()
            if not query:
                show_current_matches()
                return
            exact_ids = query_model_ids(query)
            if exact_ids:
                compare_models[:] = [entry_by_id[model_id] for model_id in exact_ids[:4]]
                render_compare()
                items = [entry_by_id[model_id] for model_id in exact_ids]
            else:
                items = find_model_db_items(query, limit=80, entries=model_entries)
            mode = current_mode()
            base = compare_models[0] if compare_models else (items[0] if items else None)
            results = score_items(items, mode, base, sort_results=not bool(exact_ids))
            if not exact_ids:
                try:
                    minimum = max(1, min(100, int(min_percent_var.get())))
                except (TypeError, ValueError, tk.TclError):
                    minimum = 15
                results = [result for result in results if display_match_percent(result.get("score")) >= minimum]
            populate(results, mode, base)
            if len(exact_ids) > 4:
                result_count_var.set(result_count_var.get() + " | " + self._t("Vergleich: erste 4 Modelle", "Comparison: first 4 models", "Porovnání: první 4 modely"))

        def show_current_matches() -> None:
            if not compare_models:
                compare_models[:] = [
                    result["item"]
                    for result in initial_results[:2]
                    if isinstance(result.get("item"), dict)
                ]
            render_compare()
            populate(list(initial_results), "device", compare_models[0] if compare_models else None)

        def reset_search() -> None:
            search_var.set("")
            compare_models[:] = [
                result["item"]
                for result in initial_results[:2]
                if isinstance(result.get("item"), dict)
            ]
            show_current_matches()

        def search_selected_options() -> None:
            filters: dict[str, list[dict[str, object]]] = {}
            for binding in option_bindings:
                variable = binding.get("var")
                if not isinstance(variable, tk.BooleanVar) or not variable.get() or not binding.get("available"):
                    continue
                filters.setdefault(str(binding.get("key") or ""), []).append(binding)
            filters.pop("", None)
            if not filters:
                set_detail_message(
                    self._t("Keine Optionen gewählt", "No options selected", "Nejsou vybrány žádné možnosti"),
                    self._t("Bitte mindestens eine Vergleichsoption markieren.", "Select at least one comparison option.", "Vyberte alespoň jednu možnost porovnání."),
                )
                return

            matched: list[dict[str, object]] = []
            for candidate in model_entries:
                all_categories_match = True
                for key, bindings in filters.items():
                    category_match = False
                    for binding in bindings:
                        if binding.get("source") == "device":
                            category_match = model_matches_snapshot_option(candidate, snapshot, key) is True
                        else:
                            source_item = binding.get("item")
                            category_match = isinstance(source_item, dict) and model_option_matches(candidate, source_item, key)
                        if category_match:
                            break
                    if not category_match:
                        all_categories_match = False
                        break
                if all_categories_match:
                    matched.append(candidate)

            mode = current_mode()
            base = compare_models[0] if compare_models else (matched[0] if matched else None)
            populate(score_items(matched, mode, base), mode, base)

        def rescore_visible_results() -> None:
            items = [
                result["item"]
                for result in current_results
                if isinstance(result.get("item"), dict)
            ]
            mode = current_mode()
            base = compare_models[0] if compare_models else (items[0] if items else None)
            render_compare()
            populate(score_items(items, mode, base), mode, base)

        def schedule_live_search(*_args) -> None:
            nonlocal live_after
            if not live_var.get():
                return
            if live_after:
                try:
                    dialog.after_cancel(live_after)
                except tk.TclError:
                    pass
            live_after = dialog.after(450, search_models)

        selected_options_button = self._button(
            compare_header,
            self._t("Mit gewählten Optionen suchen", "Search selected options", "Hledat vybrané možnosti"),
            search_selected_options,
        )
        selected_options_button.grid(row=0, column=1, padx=8, pady=4)
        self._button(controls, self._t("Suchen", "Search", "Hledat"), search_models).grid(row=0, column=4, padx=(0, 6))
        self._button(controls, self._t("Zurücksetzen", "Reset", "Resetovat"), reset_search).grid(row=0, column=5, padx=(0, 6))
        self._button(controls, self._t("Aktuelle Treffer", "Current matches", "Aktuální výsledky"), show_current_matches).grid(row=0, column=6, padx=(0, 6))
        self._button(controls, self._t("Zum Vergleich", "Add to comparison", "Přidat k porovnání"), add_selected_to_compare).grid(row=0, column=7, padx=(0, 6))
        self._button(controls, self._t("Schließen", "Close", "Zavřít"), close).grid(row=0, column=9)

        tree.bind("<<TreeviewSelect>>", show_selected)
        tree.bind("<ButtonRelease-1>", compare_result_from_list, add="+")
        search_entry.bind("<Return>", lambda _event: search_models())
        search_var.trace_add("write", schedule_live_search)
        show_device_check.configure(command=rescore_visible_results)

        drag_state: dict[str, int] = {}

        def start_drag(event) -> None:
            if geometry_state.get("maximized"):
                return
            drag_state.update({"mouse_x": event.x_root, "mouse_y": event.y_root, "x": int(geometry_state["x"]), "y": int(geometry_state["y"])})

        def move_dialog(event) -> None:
            if "mouse_x" not in drag_state or geometry_state.get("maximized"):
                return
            new_x = drag_state["x"] + event.x_root - drag_state["mouse_x"]
            new_y = drag_state["y"] + event.y_root - drag_state["mouse_y"]
            geometry_state["x"] = max(0, min(new_x, self.screen_width - int(geometry_state["width"])))
            geometry_state["y"] = max(0, min(new_y, self.screen_height - int(geometry_state["height"])))
            apply_dialog_geometry()

        for widget in (title, title_label):
            widget.bind("<ButtonPress-1>", start_drag)
            widget.bind("<B1-Motion>", move_dialog)

        resize_state: dict[str, int] = {}

        def start_resize(event) -> None:
            if geometry_state.get("maximized"):
                geometry_state["maximized"] = False
                maximize_button.configure(text="□")
            resize_state.update({"mouse_x": event.x_root, "mouse_y": event.y_root, "width": int(geometry_state["width"]), "height": int(geometry_state["height"])})

        def resize_dialog(event) -> None:
            if "mouse_x" not in resize_state:
                return
            max_width = self.screen_width - int(geometry_state["x"])
            max_height = self.screen_height - int(geometry_state["y"])
            geometry_state["width"] = max(min_width, min(max_width, resize_state["width"] + event.x_root - resize_state["mouse_x"]))
            geometry_state["height"] = max(min_height, min(max_height, resize_state["height"] + event.y_root - resize_state["mouse_y"]))
            apply_dialog_geometry()

        def finish_resize(_event=None) -> None:
            resize_state.clear()
            dialog.after_idle(render_compare)

        resize_grip = tk.Label(
            dialog,
            text="◢",
            bg="#263342",
            fg="#f7d37c",
            font=("Segoe UI", 14, "bold"),
            cursor="sizing",
            padx=4,
            pady=1,
        )
        resize_grip.place(relx=1.0, rely=1.0, anchor="se")
        resize_grip.bind("<ButtonPress-1>", start_resize)
        resize_grip.bind("<B1-Motion>", resize_dialog)
        resize_grip.bind("<ButtonRelease-1>", finish_resize)

        def toggle_maximize() -> None:
            if geometry_state.get("maximized"):
                restore = geometry_state.get("restore")
                if isinstance(restore, tuple) and len(restore) == 4:
                    geometry_state["x"], geometry_state["y"], geometry_state["width"], geometry_state["height"] = restore
                else:
                    width = min(1320, available_width)
                    height = min(820, available_height)
                    geometry_state.update({"x": (self.screen_width - width) // 2, "y": (self.screen_height - height) // 2, "width": width, "height": height})
                geometry_state["maximized"] = False
                maximize_button.configure(text="□")
            else:
                geometry_state["restore"] = (geometry_state["x"], geometry_state["y"], geometry_state["width"], geometry_state["height"])
                geometry_state.update({"x": 6, "y": 6, "width": self.screen_width - 12, "height": self.screen_height - 12, "maximized": True})
                maximize_button.configure(text="▣")
            apply_dialog_geometry()
            dialog.after_idle(render_compare)

        maximize_button.configure(command=toggle_maximize, text="▣")

        show_current_matches()
        self._bind_dialog_escape(overlay, close)

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
                search_entry.focus_set()
            except tk.TclError:
                pass

        overlay.after(80, bring_to_front)

    def update_model_database(self) -> None:
        if self._model_update_busy:
            self.set_status("Update läuft bereits ...")
            return
        if self._wifi_busy:
            self._pending_model_update = True
            self.set_status("DB-Update wartet auf WLAN-Verbindung ...")
            return
        self._model_update_busy = True
        self._pending_model_update = False
        self._set_internet_indicator("searching", "suche Netzwerk")
        self.set_status(self._t("DB-Update: verbinde ...", "DB update: connecting ...", "DB update: pripojuji ..."))

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._finish_model_update_progress(state, message))

        def worker() -> None:
            ok, message = run_model_database_update(progress)
            self.root.after(0, lambda ok=ok, message=message: self._finish_model_database_update(ok, message))

        threading.Thread(target=worker, name="model-json-update", daemon=True).start()

    def _finish_model_update_progress(self, state: str, message: str) -> None:
        self._set_internet_indicator(state, message)
        self.set_status(f"DB-Update: {message}")

    def _finish_model_database_update(self, ok: bool, message: str) -> None:
        self._model_update_busy = False
        self._update_db_indicator()
        if ok and self.snapshot:
            self.refresh(rescan=False)
        self._set_internet_indicator("online" if ok else "error")
        suffix = self._t("Treffer neu berechnet", "matches refreshed", "shoda prepocitana") if ok and self.snapshot else self.db_var.get()
        self.set_status(f"{message} | {suffix}" if suffix else message)
        self.report_status_async("db_update", {"db_update_ok": ok, "db_update_message": message})

    def report_status_async(self, event: str, extra: dict[str, object] | None = None) -> None:
        def worker() -> None:
            try:
                ok, message = publish_hardwarecheck_status(event, extra)
            except Exception as exc:
                ok, message = False, f"Statusmeldung fehlgeschlagen: {exc}"
            if ok:
                self.root.after(0, lambda message=message: self.append_status(message))

        threading.Thread(target=worker, name="hardwarecheck-status-report", daemon=True).start()

    def auto_check_updates(self, force: bool = False) -> None:
        if self._auto_update_check_busy or self._model_update_busy:
            return
        if self._wifi_busy:
            if force or not self._auto_update_check_done:
                self.root.after(1200, lambda: self.auto_check_updates(force))
            return
        if self._auto_update_check_done and not force:
            return
        self._auto_update_check_busy = True
        self._auto_update_messages = []
        self._set_internet_indicator("searching", "pruefe Updates")
        self.set_status("Auto-Check: pruefe DB und Programm ...")

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._set_internet_indicator(state, message))

        def worker() -> None:
            db_ok, db_message, db_available = check_model_database_update_available(progress)
            app_ok, app_message, app_available = check_hardwarecheck_update_available(progress)
            self.root.after(
                0,
                lambda db_ok=db_ok, db_message=db_message, db_available=db_available, app_ok=app_ok, app_message=app_message, app_available=app_available: self._finish_auto_check_updates(
                    db_ok,
                    db_message,
                    db_available,
                    app_ok,
                    app_message,
                    app_available,
                ),
            )

        threading.Thread(target=worker, name="hardwarecheck-auto-update-check", daemon=True).start()

    def _finish_auto_check_updates(
        self,
        db_ok: bool,
        db_message: str,
        db_available: bool,
        app_ok: bool,
        app_message: str,
        app_available: bool,
    ) -> None:
        self._auto_update_check_busy = False
        self._auto_update_check_done = True
        messages = [message for message, available in ((db_message, db_available), (app_message, app_available)) if available]
        if messages:
            self._auto_update_messages = messages
            self._set_internet_indicator("online")
            self.set_status(" | ".join(messages), important=True)
            self.report_status_async(
                "auto_check",
                {
                    "db_update_available": db_available,
                    "program_update_available": app_available,
                    "db_message": db_message,
                    "program_message": app_message,
                },
            )
            return
        if db_ok or app_ok:
            self._set_internet_indicator("online")
            self.set_status("Auto-Check: DB und Programm aktuell")
            self.report_status_async(
                "auto_check",
                {
                    "db_update_available": db_available,
                    "program_update_available": app_available,
                    "db_message": db_message,
                    "program_message": app_message,
                },
            )
            return
        self._set_internet_indicator("error")
        self.set_status(f"{db_message} | {app_message}")

    def check_hardwarecheck_update(self) -> None:
        if self._model_update_busy:
            self.set_status("Update läuft bereits ...")
            return
        if self._wifi_busy:
            self._pending_program_update = True
            self.set_status("Programm-Update wartet auf WLAN-Verbindung ...")
            return
        self._model_update_busy = True
        self._pending_program_update = False
        self._set_internet_indicator("searching", "suche Netzwerk")
        self.set_status(
            self._t(
                "Programm-Update: verbinde ...",
                "App update: connecting ...",
                "Update programu: pripojuji ...",
            )
        )

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._finish_model_update_progress(state, message))

        def worker() -> None:
            ok, message, install_request = run_hardwarecheck_update_check(progress)
            self.root.after(
                0,
                lambda ok=ok, message=message, install_request=install_request: self._finish_hardwarecheck_update_check(
                    ok,
                    message,
                    install_request,
                ),
            )

        threading.Thread(target=worker, name="hardwarecheck-update-check", daemon=True).start()

    def _finish_hardwarecheck_update_check(
        self,
        ok: bool,
        message: str,
        install_request: dict[str, str] | None = None,
    ) -> None:
        self._model_update_busy = False
        self._set_internet_indicator("online" if ok else "error")
        self.set_status(message, important=bool(install_request))
        self.report_status_async(
            "program_update_check",
            {
                "program_update_ok": ok,
                "program_update_message": message,
                "program_update_ready": bool(install_request),
                "target_version": (install_request or {}).get("target_version", ""),
            },
        )
        if not ok or not install_request:
            return
        self._show_update_install_prompt(install_request)

    def _show_update_install_prompt(self, install_request: dict[str, str]) -> None:
        target_version = install_request.get("target_version", "?")
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        dialog_width = min(760, max(420, self.screen_width - 80))
        dialog_height = min(420, max(320, self.screen_height - 80))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("Programm-Update bereit", "App update ready", "Update programu pripraven"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 16, "bold"),
            anchor="w",
            padx=18,
            pady=16,
        ).place(relx=0, rely=0, relwidth=1, relheight=0.22)
        tk.Label(
            dialog,
            text=self._t(
                f"Version {target_version} wurde heruntergeladen und geprüft.",
                f"Version {target_version} has been downloaded and verified.",
                f"Verze {target_version} byla stazena a overena.",
            ),
            bg="#12161b",
            fg="#f3f6f9",
            font=("Segoe UI", 12),
            anchor="w",
            justify="left",
            padx=18,
            pady=6,
            wraplength=dialog_width - 36,
        ).place(relx=0, rely=0.23, relwidth=1, relheight=0.18)
        tk.Label(
            dialog,
            text=self._t(
                "Zum Installieren: gelben Button anklicken.\nHardwareCheck schließt kurz, der Installer zeigt danach den Fortschritt.",
                "To install: click the yellow button.\nHardwareCheck closes briefly, then the installer shows progress.",
                "Pro instalaci klikni na zlute tlacitko.\nHardwareCheck se kratce zavre, potom instalator ukaze prubeh.",
            ),
            bg="#12161b",
            fg="#d8e2ea",
            font=("Segoe UI", 10),
            anchor="w",
            justify="left",
            padx=18,
            pady=6,
            wraplength=dialog_width - 36,
        ).place(relx=0, rely=0.42, relwidth=1, relheight=0.24)

        def close_prompt() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            self.root.unbind_all("<Escape>")
            overlay.destroy()
            self.set_status(f"Programm-Update bereit: {target_version}", important=True)
            self._bind_keys()

        def install_now() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            self.root.unbind_all("<Escape>")
            overlay.destroy()
            self._start_hardwarecheck_update_installer(install_request)

        install_button = tk.Button(
            dialog,
            text=self._t("Jetzt installieren", "Install now", "Instalovat nyni"),
            command=install_now,
            bg="#d4a84d",
            fg="#101418",
            relief="flat",
            padx=18,
            pady=10,
            font=("Segoe UI", 14, "bold"),
        )
        install_button.place(relx=0.06, rely=0.73, relwidth=0.52, relheight=0.18)
        later_button = tk.Button(
            dialog,
            text=self._t("Später", "Later", "Pozdeji"),
            command=close_prompt,
            bg="#2a3440",
            fg="#f3f6f9",
            relief="flat",
            padx=18,
            pady=10,
            font=("Segoe UI", 14, "bold"),
        )
        later_button.place(relx=0.64, rely=0.73, relwidth=0.30, relheight=0.18)

        overlay.bind("<Escape>", lambda _event: close_prompt())
        self.root.bind_all("<Escape>", lambda _event: close_prompt())

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
                dialog.lift()
                install_button.focus_set()
            except tk.TclError:
                pass

        bring_to_front()
        overlay.after(100, bring_to_front)
        overlay.after(500, bring_to_front)

    def _start_hardwarecheck_update_installer(self, install_request: dict[str, str]) -> None:
        config_path = install_request.get("config_path", "")
        if not config_path:
            self.set_status("Programm-Update: Installer fehlt")
            return
        try:
            config = json.loads(pathlib.Path(config_path).read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            self.set_status(f"Programm-Update: Installer-Konfig fehlt ({exc})")
            return
        if not isinstance(config, dict):
            self.set_status("Programm-Update: Installer-Konfig ungültig")
            return
        self._run_inprocess_update_installer(config)

    def _run_inprocess_update_installer(self, config: dict[str, object]) -> None:
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        dialog_width = min(680, max(380, self.screen_width - 80))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=230)
        title_var = tk.StringVar(value="Programm-Update wird installiert")
        detail_var = tk.StringVar(value="Vorbereitung ...")
        percent_var = tk.StringVar(value="0%")

        tk.Label(
            dialog,
            textvariable=title_var,
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 15, "bold"),
            anchor="w",
            padx=18,
            pady=12,
        ).place(relx=0, rely=0, relwidth=1, relheight=0.28)
        tk.Label(
            dialog,
            textvariable=detail_var,
            bg="#12161b",
            fg="#f3f6f9",
            font=("Segoe UI", 11),
            anchor="w",
            justify="left",
            padx=18,
            pady=6,
            wraplength=dialog_width - 36,
        ).place(relx=0, rely=0.30, relwidth=1, relheight=0.26)
        bar_frame = tk.Frame(dialog, bg="#2a3440")
        bar_frame.place(relx=0.05, rely=0.62, relwidth=0.72, relheight=0.13)
        bar_fill = tk.Frame(bar_frame, bg="#d4a84d")
        bar_fill.place(relx=0, rely=0, relwidth=0.01, relheight=1)
        tk.Label(
            dialog,
            textvariable=percent_var,
            bg="#12161b",
            fg="#f3f6f9",
            font=("Segoe UI", 12, "bold"),
            anchor="e",
            padx=12,
        ).place(relx=0.78, rely=0.60, relwidth=0.17, relheight=0.17)
        tk.Label(
            dialog,
            text="Bitte nicht ausschalten.",
            bg="#12161b",
            fg="#d8e2ea",
            font=("Segoe UI", 10),
            anchor="w",
            padx=18,
        ).place(relx=0, rely=0.80, relwidth=1, relheight=0.14)

        def set_progress(percent: int, message: str) -> None:
            value = max(0, min(100, int(percent)))

            def apply_progress() -> None:
                detail_var.set(message)
                percent_var.set(f"{value}%")
                bar_fill.place_configure(relwidth=max(0.01, value / 100))
                self.set_status(f"Programm-Update: {message}")

            self.root.after(0, apply_progress)

        def append_log(log_path: pathlib.Path, message: str) -> None:
            try:
                log_path.parent.mkdir(parents=True, exist_ok=True)
                with log_path.open("a", encoding="utf-8", newline="\n") as handle:
                    handle.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {message}\n")
            except OSError:
                pass

        def safe_relative(value: object) -> pathlib.PurePosixPath:
            text = str(value or "").replace("\\", "/").strip().strip("/")
            path = pathlib.PurePosixPath(text)
            if not text or path.is_absolute() or ".." in path.parts:
                raise ValueError(f"Unsicherer Pfad: {value}")
            return path

        def worker() -> None:
            try:
                tool_root = pathlib.Path(str(config["tool_root"])).resolve()
                payload_dir = pathlib.Path(str(config["payload_dir"])).resolve()
                backup_dir = pathlib.Path(str(config["backup_dir"])).resolve()
                log_path = pathlib.Path(str(config["log_path"])).resolve()
                replace_paths = [str(item) for item in config.get("replace_paths", [])]
                app_file = str(config.get("app_file") or "hardwarecheck_fast_gui.py")
                if not replace_paths:
                    raise ValueError("replace_paths leer")

                append_log(log_path, "HardwareCheck In-Process-Update gestartet")
                set_progress(10, "Backup wird erstellt ...")
                backup_dir.mkdir(parents=True, exist_ok=True)
                rel_paths = [safe_relative(path) for path in replace_paths]
                for rel in rel_paths:
                    source_current = tool_root.joinpath(*rel.parts)
                    backup_target = backup_dir.joinpath(*rel.parts)
                    if source_current.is_file():
                        backup_target.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(source_current, backup_target)
                        append_log(log_path, f"Backup {source_current} -> {backup_target}")

                set_progress(42, "Neue Dateien werden kopiert ...")
                copied: list[pathlib.PurePosixPath] = []
                try:
                    for rel in rel_paths:
                        source_new = payload_dir.joinpath(*rel.parts)
                        target_file = tool_root.joinpath(*rel.parts)
                        if not source_new.is_file():
                            raise FileNotFoundError(f"Payload fehlt: {source_new}")
                        write_bytes_atomic(target_file, source_new.read_bytes())
                        copied.append(rel)
                        append_log(log_path, f"Kopiere {source_new} -> {target_file}")

                    set_progress(72, "Installation wird geprüft ...")
                    for rel in rel_paths:
                        target_file = tool_root.joinpath(*rel.parts)
                        if not target_file.is_file() or target_file.stat().st_size <= 0:
                            raise RuntimeError(f"Zieldatei ungültig: {target_file}")
                except Exception:
                    set_progress(82, "Fehler - alte Version wird wiederhergestellt ...")
                    for rel in copied:
                        backup_file = backup_dir.joinpath(*rel.parts)
                        target_file = tool_root.joinpath(*rel.parts)
                        if backup_file.is_file():
                            write_bytes_atomic(target_file, backup_file.read_bytes())
                    raise

                set_progress(90, "Daten werden geschrieben ...")
                if hasattr(os, "sync"):
                    try:
                        os.sync()
                    except OSError:
                        pass
                append_log(log_path, "Update erfolgreich")
                set_progress(100, "Neustart ...")
                app_path = tool_root / app_file
                self.root.after(900, lambda: self._exec_restart_after_update(config, app_path))
            except Exception as exc:
                log_path = pathlib.Path(str(config.get("log_path") or (SCRIPT_DIR / "updates" / "logs" / "update_install.log")))
                append_log(log_path, "Update fehlgeschlagen: " + repr(exc))
                append_log(log_path, traceback.format_exc())

                def show_error() -> None:
                    title_var.set("Programm-Update fehlgeschlagen")
                    detail_var.set(f"{exc}\nLog: {log_path}")
                    percent_var.set("!")
                    bar_fill.configure(bg="#b94a48")
                    bar_fill.place_configure(relwidth=1)
                    self.set_status("Programm-Update fehlgeschlagen")

                self.root.after(0, show_error)

        threading.Thread(target=worker, name="hardwarecheck-inprocess-update", daemon=True).start()

    def _exec_restart_after_update(self, config: dict[str, object], app_path: pathlib.Path) -> None:
        python_exe = str(config.get("python_exe") or sys.executable or "python3")
        argv = [python_exe, str(app_path)]
        try:
            os.chdir(str(app_path.parent))
        except OSError:
            pass
        if os.path.sep in python_exe or (os.path.altsep and os.path.altsep in python_exe):
            os.execv(python_exe, argv)
        os.execvp(python_exe, argv)

    def open_settings_menu(self) -> None:
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        dialog_width = min(520, max(390, self.screen_width - 24))
        dialog_height = min(430, max(320, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("Einstellung", "Settings", "Nastavení"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 15 if self.compact_ui else 18, "bold"),
            anchor="w",
            padx=16,
            pady=14,
        ).pack(fill="x")
        tk.Label(
            dialog,
            text=self._t(
                "Seltene Optionen für Layout, Netzwerk und Drucker.",
                "Occasional options for layout, network and printer.",
                "MÃ©nÄ› ÄastÃ© volby pro vzhled, sÃ­Å¥ a tiskÃ¡rnu.",
            ),
            bg="#12161b",
            fg="#cbd5e1",
            font=("Segoe UI", 9 if self.compact_ui else 11),
            anchor="w",
            padx=16,
            pady=0,
        ).pack(fill="x")

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="both", expand=True, padx=16, pady=(4, 12))

        def close() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            overlay.destroy()

        def run_then_close(command) -> None:
            close()
            self.root.after(40, command)

        items = [
            (self._t("Layout", "Layout", "Vzhled"), self.cycle_color_theme),
            (self._t("WLAN", "Wi-Fi", "Wi-Fi"), self.open_wifi_manager),
            (self._t("Drucker", "Printer", "Tiskárna"), self.open_printer_manager),
            (self._t("Akku-Test", "Battery test", "Test baterie"), self.open_battery_test_dialog),
        ]
        for text, command in items:
            self._button(buttons, text, lambda command=command: run_then_close(command)).pack(fill="x", pady=6)
        self._button(buttons, self._t("Schließen", "Close", "Zavřít"), close).pack(fill="x", pady=(14, 0))

        self._bind_dialog_escape(overlay, close)
        overlay.bind("<BackSpace>", lambda _event: close())
        overlay.bind("<Button-3>", lambda _event: close())
        dialog.bind("<Button-3>", lambda _event: close())

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
            except tk.TclError:
                pass

        overlay.after(80, bring_to_front)

    def _battery_mode_label(self, mode: str) -> str:
        if mode == "discharge":
            return self._t("Entlade-Test", "Discharge test", "Test vybíjení")
        if mode == "charge":
            return self._t("Lade-Test", "Charge test", "Test nabíjení")
        return self._t("Akku-Test", "Battery test", "Test baterie")

    def _battery_live_samples(self, details: dict[str, object]) -> list[dict[str, object]]:
        if not self._battery_test_active:
            return [details] if details.get("present") else []
        samples = list(self._battery_test_samples)
        if not details.get("present"):
            return samples
        if not samples or details.get("timestamp") != samples[-1].get("timestamp"):
            samples.append(details)
        return samples

    def _battery_details_text(self, details: dict[str, object] | None = None) -> str:
        details = details or read_battery_details()
        if not details.get("present"):
            return self._t("Kein Akku erkannt.", "No battery detected.", "Baterie nenalezena.")
        mode = self._battery_test_mode if self._battery_test_active else "instant"
        samples = self._battery_live_samples(details)
        snapshot = self.snapshot or get_system_snapshot()
        csv_path = self._battery_test_csv_path if self._battery_test_active else None
        report = build_battery_test_report(mode, samples, snapshot, csv_path, self.language)
        if self._battery_test_active:
            return wrap_report_preview_lines(report, 92 if self.compact_ui else 112)
        elif self._battery_test_report_path:
            report = (
                f"{report}\n"
                f"{self._t('Letzter Report', 'Last report', 'Poslední report')}: {self._battery_test_report_path}"
            )
        return wrap_report_preview_lines(report, 92 if self.compact_ui else 112)

    def _battery_test_footer_text(self, details: dict[str, object]) -> str:
        status = str(details.get("status") or "-")
        capacity = battery_report_value(details.get("capacity_percent"), " %", self.language)
        sample_count = len(battery_current_session_samples(self._battery_test_samples))
        if sample_count != len(self._battery_test_samples):
            self._battery_test_samples = battery_current_session_samples(self._battery_test_samples)
        return (
            f"{self._battery_mode_label(self._battery_test_mode)} {self._t('läuft', 'running', 'běží')}: "
            f"{len(self._battery_test_samples)} {self._t('Messpunkte', 'samples', 'měření')} | "
            f"{self._translated_battery(status, capacity)}"
        )

    def _draw_battery_test_dashboard(self, details: dict[str, object] | None = None) -> None:
        canvas = self._battery_visual_canvas
        if canvas is None:
            return
        try:
            if not canvas.winfo_exists():
                return
        except tk.TclError:
            return

        details = details or self._battery_visual_details or read_battery_details()
        self._battery_visual_details = dict(details)
        try:
            canvas.delete("all")
            width = max(620, canvas.winfo_width())
            requested_height = int(float(canvas.cget("height")))
            height = max(requested_height, canvas.winfo_height())
        except (tk.TclError, TypeError, ValueError):
            return

        compact = self.compact_ui
        pad = 12 if compact else 18
        title_font = ("Segoe UI", 8 if compact else 10, "bold")
        value_font = ("Segoe UI", 15 if compact else 20, "bold")
        note_font = ("Segoe UI", 7 if compact else 9)
        background = "#101720"
        panel = "#18232f"
        border = "#334155"
        muted = "#9fb0c1"
        foreground = "#f8fafc"
        cyan = "#11d8e8"
        canvas.configure(bg=background)

        if not details.get("present"):
            canvas.create_rectangle(pad, pad, width - pad, height - pad, fill=panel, outline=border)
            canvas.create_text(
                width / 2,
                height / 2,
                text=self._t("Kein Akku erkannt", "No battery detected", "Baterie nenalezena"),
                fill="#f97066",
                font=("Segoe UI", 14 if compact else 20, "bold"),
            )
            return

        try:
            capacity = max(0.0, min(100.0, float(details.get("capacity_percent"))))
        except (TypeError, ValueError):
            capacity = None
        health = details.get("health_percent")
        level_color = battery_level_color(capacity)
        health_assessment = battery_health_assessment(details, self.language)
        health_color = str(health_assessment["color"])
        status = str(details.get("status") or "Unknown")
        normalized_status = normalize_generic_token(status)
        charging = normalized_status == "charging"
        full = normalized_status == "full"
        live_samples = self._battery_live_samples(details)
        current_samples = battery_current_session_samples(live_samples)
        metrics = battery_dashboard_metrics(self._battery_test_mode, current_samples)
        function_assessment = battery_function_assessment(self._battery_test_mode, current_samples, self.language)

        top = 12 if compact else 14
        battery_y = 30 if compact else 36
        battery_h = 58 if compact else 76
        left_width = min(300, max(235, int(width * 0.36)))
        battery_x = pad
        battery_w = max(175, left_width - 48)
        terminal_w = 12 if compact else 15
        health_label_y = battery_y + battery_h + (16 if compact else 18)
        health_bar_y = health_label_y + (13 if compact else 17)
        health_bar_h = 9 if compact else 12
        top_section_bottom = health_bar_y + health_bar_h + (8 if compact else 10)

        canvas.create_text(
            battery_x,
            top,
            text=self._t("Akkustand", "Battery level", "Stav baterie"),
            fill=muted,
            font=title_font,
            anchor="nw",
        )
        canvas.create_rectangle(
            battery_x,
            battery_y,
            battery_x + battery_w,
            battery_y + battery_h,
            fill="#0d131b",
            outline="#d7e0e8",
            width=2,
        )
        canvas.create_rectangle(
            battery_x + battery_w + 2,
            battery_y + battery_h * 0.30,
            battery_x + battery_w + terminal_w,
            battery_y + battery_h * 0.70,
            fill="#d7e0e8",
            outline="#d7e0e8",
        )
        if capacity is not None and capacity > 0:
            inner_w = max(0.0, (battery_w - 10) * capacity / 100.0)
            canvas.create_rectangle(
                battery_x + 5,
                battery_y + 5,
                battery_x + 5 + inner_w,
                battery_y + battery_h - 5,
                fill=level_color,
                outline="",
            )
        level_text = battery_percent_text(capacity, self.language) if capacity is not None else battery_missing(self.language)
        canvas.create_text(
            battery_x + battery_w / 2,
            battery_y + battery_h / 2,
            text=level_text,
            fill=foreground,
            font=("Segoe UI", 16 if compact else 23, "bold"),
        )
        if charging:
            bolt_x = battery_x + battery_w + terminal_w + (11 if compact else 15)
            bolt_y = battery_y + battery_h / 2
            canvas.create_polygon(
                bolt_x,
                bolt_y - 18,
                bolt_x - 7,
                bolt_y + 1,
                bolt_x,
                bolt_y + 1,
                bolt_x - 4,
                bolt_y + 18,
                bolt_x + 10,
                bolt_y - 4,
                bolt_x + 3,
                bolt_y - 4,
                fill=cyan,
                outline="",
            )

        if details.get("ac_online") is True:
            source_note = self._t("Netzteil angeschlossen", "Power adapter connected", "Napájecí adaptér připojen")
        elif details.get("ac_online") is False:
            source_note = self._t("Akkubetrieb", "On battery", "Provoz na baterii")
        else:
            source_note = battery_source_text(status, self.language)
        status_note = f"{battery_status_label(status, self.language)} · {source_note}"
        canvas.create_text(
            battery_x,
            battery_y + battery_h + 3,
            text=status_note,
            fill=cyan if charging or full else muted,
            font=note_font,
            anchor="nw",
        )

        health_text = str(health_assessment["display"])
        canvas.create_text(
            battery_x,
            health_label_y,
            text=f"{self._t('Kapazitätsgesundheit', 'Capacity health', 'Zdraví kapacity')}: {health_text}",
            fill=muted,
            font=title_font,
            anchor="nw",
        )
        canvas.create_rectangle(
            battery_x,
            health_bar_y,
            battery_x + battery_w,
            health_bar_y + health_bar_h,
            fill="#263545",
            outline="",
        )
        try:
            health_percent = (
                max(0.0, min(100.0, float(health)))
                if health_assessment.get("reliable")
                else None
            )
        except (TypeError, ValueError):
            health_percent = None
        if health_percent is not None:
            canvas.create_rectangle(
                battery_x,
                health_bar_y,
                battery_x + battery_w * health_percent / 100.0,
                health_bar_y + health_bar_h,
                fill=health_color,
                outline="",
            )

        rate = metrics.get("rate_percent_per_hour")
        estimate_seconds = metrics.get("estimate_seconds")
        estimate_kind = str(metrics.get("estimate_kind") or "")
        estimate_accent = level_color

        if estimate_kind == "to_full":
            estimate_title = self._t("Bis 100 %", "Until 100 %", "Do 100 %")
        else:
            estimate_title = self._t("Restzeit", "Time remaining", "ZbÃ½vajÃ­cÃ­ Äas")
        if full:
            estimate_value = self._t("voll", "Full", "Plně nabito")
            estimate_note = ""
        elif isinstance(estimate_seconds, (float, int)):
            estimate_value = battery_elapsed_text(float(estimate_seconds), self.language)
            estimate_note = (
                f"{float(rate):.1f} % / {self._t('Stunde', 'hour', 'hodinu')}"
                if isinstance(rate, (float, int))
                else ""
            )
        elif self._battery_test_active:
            estimate_value = self._t("wird berechnet", "Calculating", "PoÄÃ­tÃ¡ se")
            estimate_note = self._t(
                "nach messbarer Ã„nderung",
                "after a measurable change",
                "po měřitelné změně",
            )
        else:
            estimate_value = self._t("Test starten", "Start a test", "Spustit test")
            estimate_note = ""

        function_state = str(function_assessment.get("state") or "")
        if self._battery_test_active and (
            function_state in {"bad", "limited"}
            or (function_state == "pending" and not isinstance(estimate_seconds, (float, int)))
        ):
            estimate_title = self._t("FunktionsprÃ¼fung", "Functional test", "FunkÄnÃ­ test")
            estimate_value = str(function_assessment["display"])
            estimate_note = str(function_assessment["note"])
            estimate_accent = str(function_assessment["color"])

        power_text = battery_float_text(details.get("power_w"), " W", self.language)
        cycles_text = str(details.get("cycle_count") or battery_missing(self.language))
        health_note = str(health_assessment["note"])
        cards_x = left_width + pad * 2
        cards_width = max(280, width - cards_x - pad)
        card_gap = 8 if compact else 10
        card_width = (cards_width - card_gap) / 2
        card_height = max(54, (top_section_bottom - top - card_gap) / 2)

        def draw_card(
            x: float,
            y: float,
            card_title: str,
            card_value: str,
            card_note: str,
            accent: str,
        ) -> None:
            canvas.create_rectangle(
                x,
                y,
                x + card_width,
                y + card_height,
                fill=panel,
                outline=border,
                width=1,
            )
            canvas.create_rectangle(x, y, x + 4, y + card_height, fill=accent, outline="")
            canvas.create_text(
                x + 13,
                y + 8,
                text=card_title,
                fill=muted,
                font=title_font,
                anchor="nw",
                width=max(80, card_width - 22),
            )
            canvas.create_text(
                x + 13,
                y + card_height * 0.48,
                text=card_value,
                fill=foreground,
                font=value_font,
                anchor="w",
                width=max(80, card_width - 22),
            )
            if card_note:
                canvas.create_text(
                    x + 13,
                    y + card_height - 7,
                    text=card_note,
                    fill=accent,
                    font=note_font,
                    anchor="sw",
                    width=max(80, card_width - 22),
                )

        draw_card(
            cards_x,
            top,
            self._t("Gesundheit", "Health", "Zdraví"),
            health_text,
            health_note,
            health_color,
        )
        draw_card(
            cards_x + card_width + card_gap,
            top,
            self._t("Leistung", "Power", "Výkon"),
            power_text,
            battery_source_text(status, self.language),
            cyan,
        )
        second_row_y = top + card_height + card_gap
        draw_card(
            cards_x,
            second_row_y,
            self._t("Zyklen", "Cycles", "Cykly"),
            cycles_text,
            self._t("Ladezyklen", "Charge cycles", "Nabíjecí cykly"),
            "#a78bfa",
        )
        draw_card(
            cards_x + card_width + card_gap,
            second_row_y,
            estimate_title,
            estimate_value,
            estimate_note,
            estimate_accent,
        )

        graph_top = top_section_bottom + (20 if compact else 24)
        graph_left = pad + (28 if compact else 34)
        graph_right = width - pad
        graph_bottom = height - (14 if compact else 18)
        graph_height = max(30, graph_bottom - graph_top)
        canvas.create_text(
            pad,
            graph_top - (16 if compact else 19),
            text=self._t("Akku-Verlauf", "Battery trend", "Průběh baterie"),
            fill=muted,
            font=title_font,
            anchor="nw",
        )
        delta = metrics.get("delta_percent")
        if isinstance(delta, (float, int)):
            canvas.create_text(
                graph_right,
                graph_top - (16 if compact else 19),
                text=f"{self._t('Änderung', 'Change', 'Změna')}: {float(delta):+.0f} %",
                fill=cyan,
                font=note_font,
                anchor="ne",
            )
        canvas.create_rectangle(
            graph_left,
            graph_top,
            graph_right,
            graph_bottom,
            fill="#0d141d",
            outline=border,
        )
        for percent in (0, 50, 100):
            y = graph_top + (100 - percent) / 100.0 * graph_height
            canvas.create_line(graph_left, y, graph_right, y, fill="#26394a", width=1)
            canvas.create_text(
                graph_left - 5,
                y,
                text=f"{percent}",
                fill="#718096",
                font=("Segoe UI", 6 if compact else 8),
                anchor="e",
            )

        points: list[tuple[datetime.datetime | None, float]] = []
        for sample in current_samples[-120:]:
            try:
                percent = max(0.0, min(100.0, float(sample.get("capacity_percent"))))
            except (TypeError, ValueError):
                continue
            points.append((parse_battery_timestamp(sample.get("timestamp")), percent))
        if len(points) >= 2:
            first_time = points[0][0]
            last_time = points[-1][0]
            duration = (
                max(0.0, (last_time - first_time).total_seconds())
                if first_time is not None and last_time is not None
                else 0.0
            )
            coordinates: list[float] = []
            for index, (stamp, percent) in enumerate(points):
                if duration > 0 and first_time is not None and stamp is not None:
                    fraction = max(0.0, min(1.0, (stamp - first_time).total_seconds() / duration))
                else:
                    fraction = index / max(1, len(points) - 1)
                x = graph_left + fraction * (graph_right - graph_left)
                y = graph_top + (100.0 - percent) / 100.0 * graph_height
                coordinates.extend((x, y))
            canvas.create_line(*coordinates, fill=cyan, width=3 if not compact else 2)
            canvas.create_oval(
                coordinates[0] - 3,
                coordinates[1] - 3,
                coordinates[0] + 3,
                coordinates[1] + 3,
                fill="#fdb022",
                outline="",
            )
            canvas.create_oval(
                coordinates[-2] - 3,
                coordinates[-1] - 3,
                coordinates[-2] + 3,
                coordinates[-1] + 3,
                fill=level_color,
                outline="",
            )
        else:
            canvas.create_text(
                (graph_left + graph_right) / 2,
                (graph_top + graph_bottom) / 2,
                text=self._t(
                    "Verlauf erscheint nach dem zweiten Messpunkt.",
                    "The trend appears after the second sample.",
                    "Průběh se zobrazí po druhém měření.",
                ),
                fill=muted,
                font=note_font,
            )

    def _refresh_battery_test_dialog(self, details: dict[str, object] | None = None) -> None:
        details = details or read_battery_details()
        self._battery_visual_details = dict(details)
        self._draw_battery_test_dashboard(details)
        self._set_battery_details_text(self._battery_details_text(details))
        if self._battery_test_active:
            self._battery_test_status_var.set(self._battery_test_footer_text(details))
        else:
            status = str(details.get("status") or "-")
            capacity_value = details.get("capacity_percent")
            capacity = f"{capacity_value} %" if capacity_value is not None else ""
            self._battery_test_status_var.set(
                f"{self._t('Kein Akku-Test aktiv', 'No battery test active', 'Žádný test baterie není aktivní')} | "
                f"{self._translated_battery(status, capacity)}"
            )

    def _set_battery_details_text(self, text: str) -> None:
        self._battery_test_details_var.set(text)
        widget = self._battery_test_details_widget
        if widget is None:
            return
        try:
            if not widget.winfo_exists():
                return
            try:
                first_fraction = widget.yview()[0]
            except tk.TclError:
                first_fraction = 0.0
            widget.configure(state="normal")
            widget.delete("1.0", "end")
            widget.insert("1.0", text)
            widget.yview_moveto(first_fraction)
            widget.configure(state="disabled")
        except tk.TclError:
            pass

    def _cancel_battery_dialog_refresh(self) -> None:
        if self._battery_dialog_after_id is not None:
            try:
                self.root.after_cancel(self._battery_dialog_after_id)
            except tk.TclError:
                pass
            self._battery_dialog_after_id = None

    def _schedule_battery_dialog_refresh(self, overlay: tk.Widget) -> None:
        self._cancel_battery_dialog_refresh()

        def tick() -> None:
            self._battery_dialog_after_id = None
            try:
                if not overlay.winfo_exists():
                    return
            except tk.TclError:
                return
            self._refresh_battery_test_dialog()
            self._battery_dialog_after_id = self.root.after(60_000, tick)

        self._battery_dialog_after_id = self.root.after(60_000, tick)

    def open_battery_test_dialog(self) -> None:
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        dialog_width = min(1040, max(680, self.screen_width - 24))
        dialog_height = min(820, max(560, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        def close() -> None:
            self._cancel_battery_dialog_refresh()
            self._battery_test_details_widget = None
            self._battery_visual_canvas = None
            self._battery_visual_details = {}
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            overlay.destroy()

        header = tk.Frame(dialog, bg="#12161b")
        header.pack(fill="x", padx=0, pady=0)
        tk.Label(
            header,
            text=self._t("Akku-Test", "Battery test", "Test baterie"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 15 if self.compact_ui else 18, "bold"),
            anchor="w",
            padx=16,
            pady=12,
        ).pack(side="left", fill="x", expand=True)
        tk.Button(
            header,
            text="X",
            command=close,
            bg="#263141",
            fg="#f8fafc",
            activebackground="#3b4a62",
            activeforeground="#ffffff",
            relief="flat",
            font=("Segoe UI", 11, "bold"),
            width=3,
            cursor="hand2",
        ).pack(side="right", padx=(0, 12), pady=10)
        tk.Label(
            dialog,
            text=self._t(
                "Entlade-Test: Netzteil entfernen. Lade-Test: Netzteil anschließen. Messpunkte werden jede Minute gespeichert.",
                "Discharge test: unplug power. Charge test: plug in power. Samples are saved every minute.",
                "Test vybíjení: odpojit napájení. Test nabíjení: připojit napájení. Měření se ukládá každou minutu.",
            ),
            bg="#12161b",
            fg="#cbd5e1",
            font=("Segoe UI", 9 if self.compact_ui else 11),
            anchor="w",
            justify="left",
            wraplength=max(440, dialog_width - 36),
            padx=16,
            pady=0,
        ).pack(fill="x")

        tk.Label(
            dialog,
            textvariable=self._battery_test_status_var,
            bg="#12161b",
            fg="#9ad3a8",
            font=("Segoe UI", 10 if self.compact_ui else 12, "bold"),
            anchor="w",
            padx=16,
            pady=10,
        ).pack(fill="x")

        dashboard_height = 210 if self.compact_ui else 300
        dashboard = tk.Canvas(
            dialog,
            bg="#101720",
            highlightthickness=1,
            highlightbackground="#2a3a4a",
            height=dashboard_height,
        )
        dashboard.pack(fill="x", padx=16, pady=(0, 10))
        self._battery_visual_canvas = dashboard
        dashboard.bind("<Configure>", lambda _event: self._draw_battery_test_dashboard(), add="+")

        details_frame = tk.Frame(dialog, bg="#1a2028")
        details_frame.pack(fill="both", expand=True, padx=16, pady=(0, 10))
        details = tk.Text(
            details_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            insertbackground="#f3f6f9",
            relief="flat",
            wrap="word",
            font=("Consolas", 8 if self.compact_ui else 10),
            padx=12,
            pady=10,
            height=7 if self.compact_ui else 12,
        )
        details_scroll = tk.Scrollbar(details_frame, orient="vertical", command=details.yview)
        details.configure(yscrollcommand=details_scroll.set, state="disabled")
        details.pack(side="left", fill="both", expand=True)
        details_scroll.pack(side="right", fill="y")
        self._battery_test_details_widget = details

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="x", padx=16, pady=(0, 14))
        for column in range(5):
            buttons.columnconfigure(column, weight=1, uniform="battery_buttons")

        button_specs = [
            (self._t("Entladen starten", "Start discharge", "Spustit vybíjení"), lambda: self.start_battery_test("discharge")),
            (self._t("Laden starten", "Start charge", "Spustit nabíjení"), lambda: self.start_battery_test("charge")),
            (self._t("Stop + Report", "Stop + report", "Stop + report"), self.stop_battery_test),
            (self._t("Sofort-Report", "Instant report", "Okamžitý report"), self.save_battery_instant_report),
            (self._t("Drucken", "Print", "Tisk"), self.print_battery_test_report),
            (self._t("Reports anzeigen", "Show reports", "Zobrazit reporty"), self.open_battery_report_viewer),
            (self._t("Demo-Report", "Demo report", "Demo report"), self.create_battery_demo_report),
            (self._t("Aktualisieren", "Refresh", "Obnovit"), self._refresh_battery_test_dialog),
            (self._t("Zurück", "Back", "Zpět"), close),
        ]
        for index, (label, command) in enumerate(button_specs):
            row = index // 5
            column = index % 5
            self._button(buttons, label, command).grid(row=row, column=column, sticky="ew", padx=5, pady=4)

        self._refresh_battery_test_dialog()
        self._schedule_battery_dialog_refresh(overlay)
        self._bind_dialog_escape(overlay, close)
        overlay.bind("<BackSpace>", lambda _event: close())
        overlay.bind("<Button-3>", lambda _event: close())
        dialog.bind("<Button-3>", lambda _event: close())

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
            except tk.TclError:
                pass

        overlay.after(80, bring_to_front)

    def open_battery_report_viewer(self, initial_path: pathlib.Path | None = None) -> None:
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()
        dialog_width = max(680, self.screen_width - 24)
        dialog_height = max(520, self.screen_height - 24)
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        def close() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            overlay.destroy()

        header = tk.Frame(dialog, bg="#12161b")
        header.pack(fill="x")
        tk.Label(
            header,
            text=self._t("Akku-Reports", "Battery reports", "Reporty baterie"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 15 if self.compact_ui else 18, "bold"),
            anchor="w",
            padx=16,
            pady=12,
        ).pack(side="left", fill="x", expand=True)
        tk.Button(
            header,
            text="X",
            command=close,
            bg="#263141",
            fg="#f8fafc",
            activebackground="#3b4a62",
            activeforeground="#ffffff",
            relief="flat",
            font=("Segoe UI", 11, "bold"),
            width=3,
            cursor="hand2",
        ).pack(side="right", padx=(0, 12), pady=10)

        body = tk.Frame(dialog, bg="#12161b")
        body.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        body.columnconfigure(0, weight=0)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        list_frame = tk.Frame(body, bg="#12161b")
        list_frame.grid(row=0, column=0, sticky="nsw", padx=(0, 10))
        report_list = tk.Listbox(
            list_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            selectbackground="#d4a84d",
            selectforeground="#111827",
            activestyle="none",
            exportselection=False,
            width=26 if self.compact_ui else 32,
            font=("Consolas", 8 if self.compact_ui else 10),
        )
        report_scroll = tk.Scrollbar(list_frame, orient="vertical", command=report_list.yview)
        report_list.configure(yscrollcommand=report_scroll.set)
        report_list.pack(side="left", fill="both", expand=True)
        report_scroll.pack(side="right", fill="y")

        text_frame = tk.Frame(body, bg="#12161b")
        text_frame.grid(row=0, column=1, sticky="nsew")
        report_text = tk.Text(
            text_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            insertbackground="#f3f6f9",
            relief="flat",
            wrap="char",
            font=("Consolas", 8 if self.compact_ui else 10),
            padx=12,
            pady=10,
        )
        text_scroll = tk.Scrollbar(text_frame, orient="vertical", command=report_text.yview)
        report_text.configure(yscrollcommand=text_scroll.set)
        report_text.pack(side="left", fill="both", expand=True)
        text_scroll.pack(side="right", fill="y")

        footer = tk.Frame(dialog, bg="#12161b")
        footer.pack(fill="x", padx=16, pady=(0, 14))
        path_var = tk.StringVar(value="")
        tk.Label(
            footer,
            textvariable=path_var,
            bg="#12161b",
            fg="#cbd5e1",
            font=("Segoe UI", 8 if self.compact_ui else 10),
            anchor="w",
        ).pack(side="left", fill="x", expand=True)

        report_files: list[pathlib.Path] = []

        def display_path(path: pathlib.Path) -> str:
            try:
                stamp = datetime.datetime.fromtimestamp(path.stat().st_mtime).strftime("%d.%m.%Y %H:%M")
            except OSError:
                stamp = "--.--.---- --:--"
            return f"{stamp}  {path.name}"

        def show_index(index: int) -> None:
            if index < 0 or index >= len(report_files):
                report_text.configure(state="normal")
                report_text.delete("1.0", "end")
                report_text.insert("1.0", self._t("Keine Akku-Reports gefunden.", "No battery reports found.", "Žádné reporty baterie nenalezeny."))
                report_text.configure(state="disabled")
                path_var.set("")
                return
            path = report_files[index]
            report_text.configure(state="normal")
            report_text.delete("1.0", "end")
            preview_width = 86 if self.compact_ui else 112
            report_text.insert("1.0", battery_report_preview_text(path, preview_width))
            report_text.configure(state="disabled")
            path_var.set(shorten_middle(str(path), 70 if self.compact_ui else 110))

        def selected_index() -> int:
            selection = report_list.curselection()
            if not selection:
                return -1
            return int(selection[0])

        def refresh_reports() -> None:
            nonlocal report_files
            report_files = list_battery_report_files()
            report_list.delete(0, "end")
            for path in report_files:
                report_list.insert("end", display_path(path))
            target_index = 0
            if initial_path is not None:
                try:
                    target = initial_path.resolve()
                    for idx, path in enumerate(report_files):
                        if path.resolve() == target:
                            target_index = idx
                            break
                except OSError:
                    pass
            if report_files:
                report_list.selection_clear(0, "end")
                report_list.selection_set(target_index)
                report_list.see(target_index)
                show_index(target_index)
            else:
                show_index(-1)

        report_list.bind("<<ListboxSelect>>", lambda _event: show_index(selected_index()))

        self._button(footer, self._t("Neu laden", "Reload", "Obnovit"), refresh_reports).pack(side="right", padx=(8, 0))
        self._button(footer, self._t("Schließen", "Close", "Zavřít"), close).pack(side="right", padx=(8, 0))

        refresh_reports()
        self._bind_dialog_escape(overlay, close)
        overlay.bind("<BackSpace>", lambda _event: close())
        overlay.bind("<Button-3>", lambda _event: close())
        dialog.bind("<Button-3>", lambda _event: close())

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
            except tk.TclError:
                pass

        overlay.after(80, bring_to_front)

    def create_battery_demo_report(self) -> None:
        snapshot = self.snapshot or get_system_snapshot()
        if not snapshot:
            snapshot = {
                "vendor": "Demo",
                "model_name": "HardwareCheck Demo",
                "product_no": "DEMO",
                "serial": "DEMO",
                "cpu": "Demo CPU",
            }
        samples = build_battery_demo_samples()
        report_dir = get_battery_report_dir()
        basename = battery_report_basename(snapshot, "demo")
        csv_path = report_dir / f"{basename}.csv"
        report_path = report_dir / f"{basename}.txt"
        html_path = report_dir / f"{basename}.html"
        try:
            for index, sample in enumerate(samples):
                append_battery_csv(csv_path, "demo", sample, include_header=(index == 0))
            report = build_battery_test_report("demo", samples, snapshot, csv_path, self.language)
            html_report = build_battery_test_html_report("demo", samples, snapshot, csv_path, report_path, self.language)
            write_text_durable(report_path, report)
            write_text_durable(html_path, html_report)
        except OSError as exc:
            self.set_status(f"{self._t('Demo-Report konnte nicht gespeichert werden', 'Demo report could not be saved', 'Demo report nelze uložit')}: {exc}")
            return
        self._battery_test_report_path = html_path
        self.set_status(f"{self._t('Demo-Report gespeichert', 'Demo report saved', 'Demo report uložen')}: {html_path}")
        self._refresh_battery_test_dialog()
        self.open_battery_report_viewer(html_path)

    def start_battery_test(self, mode: str) -> None:
        if self._battery_test_active:
            self.set_status(self._t("Akku-Test läuft bereits", "Battery test already running", "Test baterie už běží"))
            self._refresh_battery_test_dialog()
            return
        details = read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Akku-Test: kein Akku erkannt", "Battery test: no battery detected", "Test baterie: baterie nenalezena"))
            self._refresh_battery_test_dialog()
            return
        report_dir = get_battery_report_dir()
        basename = battery_report_basename(self.snapshot or get_system_snapshot(), mode)
        csv_path = report_dir / f"{basename}.csv"
        try:
            append_battery_csv(csv_path, mode, details, include_header=True)
        except OSError as exc:
            self.set_status(f"{self._t('Akku-Test konnte nicht gestartet werden', 'Battery test could not start', 'Test baterie nelze spustit')}: {exc}")
            return
        self._battery_test_active = True
        self._battery_test_mode = mode
        self._battery_test_samples = [details]
        self._battery_test_csv_path = csv_path
        self._battery_test_report_path = None
        self.set_status(
            f"{self._battery_mode_label(mode)} {self._t('gestartet', 'started', 'spuštěn')} | CSV: {csv_path}"
        )
        self._refresh_battery_test_dialog()
        self._schedule_battery_test_sample()

    def _schedule_battery_test_sample(self) -> None:
        if not self._battery_test_active:
            return
        try:
            if self._battery_test_after_id:
                self.root.after_cancel(self._battery_test_after_id)
        except tk.TclError:
            pass
        self._battery_test_after_id = self.root.after(60_000, self._record_battery_test_sample)

    def _record_battery_test_sample(self) -> None:
        self._battery_test_after_id = None
        if not self._battery_test_active:
            return
        sample = read_battery_details()
        self._battery_test_samples.append(sample)
        if self._battery_test_csv_path is not None:
            try:
                append_battery_csv(self._battery_test_csv_path, self._battery_test_mode, sample)
            except OSError as exc:
                self.set_status(f"{self._t('Akku-Test Schreibfehler', 'Battery test write error', 'Chyba zápisu testu baterie')}: {exc}")
        self._last_status_raw = self._battery_test_footer_text(sample)
        if not self._last_status_important:
            self.status_var.set(self._last_status_raw)
        self._refresh_battery_test_dialog(sample)
        self._schedule_battery_test_sample()

    def stop_battery_test(self) -> None:
        if not self._battery_test_active:
            self.set_status(self._t("Kein Akku-Test aktiv", "No battery test active", "Žádný test baterie není aktivní"))
            self._refresh_battery_test_dialog()
            return
        if self._battery_test_after_id:
            try:
                self.root.after_cancel(self._battery_test_after_id)
            except tk.TclError:
                pass
        self._battery_test_after_id = None
        mode = self._battery_test_mode
        if len(self._battery_test_samples) == 1:
            sample = read_battery_details()
            self._battery_test_samples.append(sample)
            if self._battery_test_csv_path is not None:
                try:
                    append_battery_csv(self._battery_test_csv_path, mode, sample)
                except OSError:
                    pass
        report_dir = get_battery_report_dir()
        basename = battery_report_basename(self.snapshot or get_system_snapshot(), mode)
        report_path = report_dir / f"{basename}.txt"
        html_path = report_dir / f"{basename}.html"
        snapshot = self.snapshot or get_system_snapshot()
        report = build_battery_test_report(mode, self._battery_test_samples, snapshot, self._battery_test_csv_path, self.language)
        html_report = build_battery_test_html_report(
            mode,
            self._battery_test_samples,
            snapshot,
            self._battery_test_csv_path,
            report_path,
            self.language,
        )
        try:
            write_text_durable(report_path, report)
            write_text_durable(html_path, html_report)
        except OSError as exc:
            self._battery_test_active = False
            self.set_status(f"{self._t('Akku-Report konnte nicht gespeichert werden', 'Battery report could not be saved', 'Report baterie nelze uložit')}: {exc}")
            self._refresh_battery_test_dialog()
            return
        self._battery_test_active = False
        self._battery_test_report_path = html_path
        self.set_status(f"{self._t('Akku-Report gespeichert', 'Battery report saved', 'Report baterie uložen')}: {html_path}")
        self._refresh_battery_test_dialog()

    def save_battery_instant_report(self) -> None:
        details = read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Akku-Report: kein Akku erkannt", "Battery report: no battery detected", "Report baterie: baterie nenalezena"))
            self._refresh_battery_test_dialog()
            return
        snapshot = self.snapshot or get_system_snapshot()
        report_dir = get_battery_report_dir()
        basename = battery_report_basename(snapshot, "instant")
        report_path = report_dir / f"{basename}.txt"
        html_path = report_dir / f"{basename}.html"
        csv_path = report_dir / f"{basename}.csv"
        try:
            append_battery_csv(csv_path, "instant", details, include_header=True)
            report = build_battery_test_report("instant", [details], snapshot, csv_path, self.language)
            html_report = build_battery_test_html_report("instant", [details], snapshot, csv_path, report_path, self.language)
            write_text_durable(report_path, report)
            write_text_durable(html_path, html_report)
        except OSError as exc:
            self.set_status(f"{self._t('Akku-Report konnte nicht gespeichert werden', 'Battery report could not be saved', 'Report baterie nelze uložit')}: {exc}")
            return
        self._battery_test_report_path = html_path
        self.set_status(f"{self._t('Akku-Report gespeichert', 'Battery report saved', 'Report baterie uložen')}: {html_path}")
        self._refresh_battery_test_dialog()

    def print_battery_test_report(self) -> None:
        if self._print_busy:
            self.set_status(self._t("Druck läuft bereits", "Print already running", "Tisk již běží"))
            return
        details = read_battery_details()
        if not details.get("present"):
            self.set_status(self._t("Akku-Druck: kein Akku erkannt", "Battery print: no battery detected", "Tisk baterie: baterie nenalezena"))
            self._refresh_battery_test_dialog()
            return
        snapshot = self.snapshot or get_system_snapshot()
        report_dir = get_battery_report_dir()
        mode = self._battery_test_mode if self._battery_test_active else "instant"
        samples = self._battery_live_samples(details)
        basename = battery_report_basename(snapshot, f"{mode}_print")
        report_path = report_dir / f"{basename}.txt"
        html_path = report_dir / f"{basename}.html"
        csv_path = self._battery_test_csv_path
        try:
            if csv_path is None:
                csv_path = report_dir / f"{basename}.csv"
                append_battery_csv(csv_path, mode, details, include_header=True)
            report = build_battery_test_report(mode, samples, snapshot, csv_path, self.language)
            html_report = build_battery_test_html_report(mode, samples, snapshot, csv_path, report_path, self.language)
            write_text_durable(report_path, report)
            write_text_durable(html_path, html_report)
        except OSError as exc:
            self.set_status(f"{self._t('Akku-Report konnte nicht gespeichert werden', 'Battery report could not be saved', 'Report baterie nelze uložit')}: {exc}")
            return
        self._battery_test_report_path = html_path
        self._refresh_battery_test_dialog(details)
        self._print_report_async(report_path)

    def cycle_color_theme(self) -> None:
        themes = [
            {"name": "Standard", "root": "#12161b", "panel": "#1a2028", "footer": "#0e1216", "accent": "#d4a84d", "text": "#f3f6f9"},
            {"name": "Grün", "root": "#101711", "panel": "#1a2a1f", "footer": "#0b120d", "accent": "#74c476", "text": "#eff8ef"},
            {"name": "Blau", "root": "#101620", "panel": "#1a2638", "footer": "#0b1018", "accent": "#7fb3ff", "text": "#eef5ff"},
            {"name": "Kontrast", "root": "#070707", "panel": "#141414", "footer": "#050505", "accent": "#f4d35e", "text": "#ffffff"},
            {"name": "Magenta", "root": "#180f1f", "panel": "#25172f", "footer": "#100916", "accent": "#f28bdc", "text": "#fff4fc"},
            {"name": "Cyan", "root": "#07191d", "panel": "#102930", "footer": "#061114", "accent": "#63dce4", "text": "#effcff"},
            {"name": "Hell", "root": "#e9edf2", "panel": "#f8fafc", "footer": "#d8dee8", "accent": "#315d8c", "text": "#111827"},
        ]
        self._color_theme_index = (self._color_theme_index + 1) % len(themes)
        theme = themes[self._color_theme_index]

        def apply(widget: tk.Widget) -> None:
            try:
                if isinstance(widget, tk.Button):
                    widget.configure(
                        bg=theme["accent"],
                        fg=theme["root"],
                        activebackground=theme["accent"],
                        activeforeground=theme["root"],
                    )
                elif isinstance(widget, (tk.Frame, tk.Canvas)):
                    widget.configure(bg=theme["panel"])
                elif isinstance(widget, tk.Label):
                    current_fg = str(widget.cget("fg"))
                    widget.configure(bg=theme["panel"], fg=theme["accent"] if current_fg.lower() == "#f7d37c" else theme["text"])
            except tk.TclError:
                pass
            for child in widget.winfo_children():
                apply(child)

        try:
            self.root.configure(bg=theme["root"])
        except tk.TclError:
            pass
        apply(self.root)
        self.set_status(f"Layout: {theme['name']}")

    def open_new_printer_dialog(self) -> None:
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        dialog_width = min(680, max(480, self.screen_width - 24))
        dialog_height = min(520, max(410, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("Neuen Drucker hinzufügen", "Add new printer", "Pridat novou tiskarnu"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
            padx=14,
            pady=12,
        ).pack(fill="x")

        form = tk.Frame(dialog, bg="#12161b")
        form.pack(fill="x", padx=14, pady=(0, 8))
        form.columnconfigure(1, weight=1)

        name_var = tk.StringVar(value="Neuer Drucker")
        host_var = tk.StringVar()
        method_var = tk.StringVar(value="RAW/PCL LaserJet")
        saved_networks = load_wifi_networks()
        wifi_options = [self._t("Kein WLAN-Wechsel", "No Wi-Fi switch", "Bez zmeny Wi-Fi")]
        wifi_options.extend(network["ssid"] for network in saved_networks)
        wifi_var = tk.StringVar(value=wifi_options[0])
        password_var = tk.StringVar()

        def label(row: int, text: str) -> None:
            tk.Label(form, text=text, bg="#12161b", fg="#f3f6f9", anchor="w").grid(row=row, column=0, sticky="w", pady=5)

        label(0, self._t("Name", "Name", "Nazev"))
        tk.Entry(form, textvariable=name_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9").grid(row=0, column=1, sticky="ew", padx=(10, 0), pady=5)
        label(1, self._t("IP / Hostname", "IP / hostname", "IP / hostname"))
        tk.Entry(form, textvariable=host_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9").grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=5)
        label(2, self._t("Methode", "Method", "Metoda"))
        method_menu = tk.OptionMenu(form, method_var, "RAW/PCL LaserJet", "IPP/PWG Raster", "IPP/PDF")
        method_menu.configure(bg="#1f2937", fg="#f3f6f9", activebackground="#d4a84d", activeforeground="#101418", highlightthickness=0)
        method_menu.grid(row=2, column=1, sticky="ew", padx=(10, 0), pady=5)
        label(3, "WLAN")
        wifi_menu = tk.OptionMenu(form, wifi_var, *wifi_options)
        wifi_menu.configure(bg="#1f2937", fg="#f3f6f9", activebackground="#d4a84d", activeforeground="#101418", highlightthickness=0)
        wifi_menu.grid(row=3, column=1, sticky="ew", padx=(10, 0), pady=5)
        label(4, self._t("WLAN Passwort", "Wi-Fi password", "Heslo Wi-Fi"))
        tk.Entry(form, textvariable=password_var, show="*", bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9").grid(row=4, column=1, sticky="ew", padx=(10, 0), pady=5)

        hint = tk.Label(
            dialog,
            text=self._t(
                "Tipp: Für HP/LaserJet zuerst RAW/PCL testen. IPP/PWG ist für AirPrint/Epson sinnvoll.",
                "Tip: Try RAW/PCL first for HP/LaserJet. IPP/PWG is useful for AirPrint/Epson.",
                "Tip: Pro HP/LaserJet nejdrive RAW/PCL. IPP/PWG je pro AirPrint/Epson.",
            ),
            bg="#12161b",
            fg="#cbd5e1",
            anchor="w",
            justify="left",
            padx=14,
            wraplength=max(360, dialog_width - 40),
        )
        hint.pack(fill="x", pady=(4, 8))

        def on_wifi_change(*_args) -> None:
            selected = wifi_var.get()
            for network in saved_networks:
                if network.get("ssid") == selected and network.get("password"):
                    password_var.set(str(network.get("password") or ""))
                    return
            password_var.set("")

        wifi_var.trace_add("write", on_wifi_change)

        def build_profile() -> dict[str, object] | None:
            name = name_var.get().strip()
            host = host_var.get().strip()
            method = method_var.get().strip()
            if not name or not host:
                messagebox.showerror(APP_TITLE, self._t("Name und IP/Hostname fehlen", "Name and IP/hostname are required", "Chybi nazev a IP/hostname"))
                return None
            profile_id = sanitize_filename(name).lower().replace(" ", "-")
            connect_wifi = wifi_var.get() != wifi_options[0]
            wifi_config: dict[str, object] = {}
            if connect_wifi:
                ssid = wifi_var.get().strip()
                password = password_var.get().strip()
                if password:
                    save_wifi_network(ssid, password)
                wifi_config = {"ssid": ssid}
            base: dict[str, object] = {
                "enabled": True,
                "connect_wifi": connect_wifi,
                "disconnect_after_print": False,
                "use_cups": False,
                "printer_name": safe_printer_name(name),
                "printer_uri": f"ipp://{host}:631/ipp/print",
                "raw_host": host,
                "raw_port": 9100,
                "media": "iso_a4_210x297mm",
                "media_source": "auto",
                "wifi": wifi_config,
            }
            if method == "RAW/PCL LaserJet":
                base.update({
                    "direct_ipp_fallback": False,
                    "raw_socket_fallback": True,
                    "document_format": "application/vnd.hp-PCL",
                    "raw_job_control": "pcl",
                    "model": "raw-pcl",
                })
            elif method == "IPP/PDF":
                base.update({
                    "direct_ipp_fallback": True,
                    "raw_socket_fallback": False,
                    "document_format": "application/pdf",
                    "raw_job_control": "plain",
                    "model": "everywhere",
                })
            else:
                base.update({
                    "direct_ipp_fallback": True,
                    "raw_socket_fallback": False,
                    "document_format": "image/pwg-raster",
                    "pwg_raster_type": "sgray_8",
                    "raster_resolution": 600,
                    "raster_font_scale": 10,
                    "raw_job_control": "plain",
                    "model": "everywhere",
                })
            return {"id": profile_id, "name": name, "config": base}

        def save_profile(print_after: bool = False) -> None:
            profile = build_profile()
            if profile is None:
                return
            try:
                upsert_printer_profile(profile)
                save_active_printer_profile(profile, manual_selected=True)
            except OSError as exc:
                messagebox.showerror(APP_TITLE, f"{self._t('Drucker konnte nicht gespeichert werden', 'Printer could not be saved', 'Tiskárnu nelze uložit')}: {exc}")
                return
            overlay.destroy()
            self.set_status(f"{self._t('Drucker aktiv', 'Printer active', 'Tiskárna aktivní')}: {printer_profile_name(profile)}")
            if print_after:
                self.print_report()

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="x", padx=14, pady=(8, 14))
        self._button(buttons, self._t("Speichern", "Save", "Uložit"), lambda: save_profile(False)).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Speichern + Drucken", "Save + print", "Uložit + tisk"), lambda: save_profile(True)).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Abbrechen", "Cancel", "Zrušit"), overlay.destroy).pack(side="right")
        self._bind_dialog_escape(overlay, overlay.destroy)
        overlay.bind("<BackSpace>", lambda _event: overlay.destroy())

    def _current_saved_wifi_ssid(self) -> str:
        known_passwords = saved_wifi_passwords()
        if not known_passwords:
            return ""
        for iface in list_network_interfaces(wifi=True):
            if not interface_has_ipv4(iface):
                continue
            ssid = current_wifi_ssid(iface).strip()
            if ssid and ssid in known_passwords:
                return ssid
        return ""

    def open_printer_discovery(self) -> None:
        if self._printer_search_busy:
            return
        self._printer_search_busy = True
        search_token = object()
        self._printer_search_token = search_token
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        dialog_width = min(760, max(500, self.screen_width - 24))
        dialog_height = min(520, max(360, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)
        state = {"closed": False}
        printers: list[dict[str, object]] = []
        save_buttons: list[tk.Button] = []
        status_var = tk.StringVar(value=self._t("Drucker-Suche läuft ...", "Printer search running ...", "Hledání tiskáren běží ..."))
        tk.Label(
            dialog,
            text=self._t("Gefundene Drucker", "Found printers", "Nalezené tiskárny"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
            padx=14,
            pady=12,
        ).pack(fill="x")
        tk.Label(
            dialog,
            textvariable=status_var,
            bg="#12161b",
            fg="#cbd5e1",
            anchor="w",
            padx=14,
            pady=2,
            wraplength=max(360, dialog_width - 40),
        ).pack(fill="x")

        list_frame = tk.Frame(dialog, bg="#12161b")
        list_frame.pack(fill="both", expand=True, padx=14, pady=(8, 8))
        listbox = tk.Listbox(
            list_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            selectbackground="#d4a84d",
            selectforeground="#101418",
            height=8,
            activestyle="none",
            font=("Consolas", 10 if self.compact_ui else 11),
        )
        listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
        scrollbar.pack(side="right", fill="y")
        listbox.configure(yscrollcommand=scrollbar.set)

        detail_var = tk.StringVar(
            value=self._t(
                "Suche läuft. Sobald ein Drucker erscheint, kann er sofort ausgewählt werden.",
                "Search running. As soon as a printer appears, it can be selected immediately.",
                "Hledání běží. Jakmile se tiskárna objeví, lze ji hned vybrat.",
            )
        )
        detail = tk.Label(
            dialog,
            textvariable=detail_var,
            bg="#12161b",
            fg="#cbd5e1",
            anchor="w",
            justify="left",
            padx=14,
            pady=4,
            font=("Segoe UI", 9 if self.compact_ui else 10),
        )
        detail.pack(fill="x")

        alias_frame = tk.Frame(dialog, bg="#12161b")
        alias_frame.pack(fill="x", padx=14, pady=(2, 4))
        tk.Label(
            alias_frame,
            text=self._t("Name im Stick", "Name on stick", "Nazev na USB"),
            bg="#12161b",
            fg="#f3f6f9",
            anchor="w",
        ).pack(side="left")
        alias_var = tk.StringVar()
        alias_entry = tk.Entry(
            alias_frame,
            textvariable=alias_var,
            bg="#1a2028",
            fg="#f3f6f9",
            insertbackground="#f3f6f9",
        )
        alias_entry.pack(side="left", fill="x", expand=True, padx=(10, 0))

        def printer_key(printer: dict[str, object]) -> tuple[str, str]:
            return (str(printer.get("host") or "").strip(), str(printer.get("name") or "").strip())

        def set_save_state() -> None:
            enabled = bool(printers)
            for button in save_buttons:
                try:
                    button.configure(state="normal" if enabled else "disabled")
                except tk.TclError:
                    pass

        def selected_printer() -> dict[str, object] | None:
            if not printers:
                return None
            selection = listbox.curselection()
            index = int(selection[0]) if selection else 0
            if index < 0 or index >= len(printers):
                return None
            return printers[index]

        def update_detail(_event=None) -> None:
            printer = selected_printer()
            if not printer:
                detail_var.set(
                    self._t(
                        "Suche läuft. Sobald ein Drucker erscheint, kann er sofort ausgewählt werden.",
                        "Search running. As soon as a printer appears, it can be selected immediately.",
                        "Hledání běží. Jakmile se tiskárna objeví, lze ji hned vybrat.",
                    )
                )
                set_save_state()
                return
            wifi_ssid = self._current_saved_wifi_ssid()
            wifi_line = f"\nWLAN-Profil: {wifi_ssid}" if wifi_ssid else ""
            detail_var.set(f"{printer.get('name')}\n{printer.get('method')} | {printer.get('host')} | {printer.get('ports')}{wifi_line}")
            alias_var.set(str(printer.get("name") or printer.get("host") or "").strip())
            set_save_state()

        def add_found_printer(printer: dict[str, object]) -> None:
            if state["closed"]:
                return
            if printer_key(printer) in {printer_key(existing) for existing in printers}:
                return
            printers.append(printer)
            listbox.insert("end", f"{printer.get('name')} | {printer.get('method')} | {printer.get('host')} | {printer.get('ports')}")
            if len(printers) == 1:
                listbox.selection_set(0)
                listbox.activate(0)
                update_detail()
            else:
                set_save_state()
            status_var.set(f"{self._t('Drucker gefunden', 'Printer found', 'TiskÃ¡rna nalezena')}: {printer.get('name')} - {self._t('Suche lÃ¤uft weiter', 'search continues', 'hledÃ¡nÃ­ pokraÄuje')}")

        def release_search_busy() -> None:
            if getattr(self, "_printer_search_token", None) is search_token:
                self._printer_search_busy = False

        def close() -> None:
            state["closed"] = True
            release_search_busy()
            try:
                overlay.destroy()
            except tk.TclError:
                pass

        def save_selected(print_after: bool = False) -> None:
            printer = selected_printer()
            if not printer:
                self.set_status(self._t("Kein Drucker ausgewählt", "No printer selected", "Není vybrána tiskárna"))
                return
            profile = discovered_printer_profile(printer, self._current_saved_wifi_ssid(), alias_var.get().strip())
            try:
                upsert_printer_profile(profile)
                save_active_printer_profile(profile, manual_selected=True)
            except OSError as exc:
                messagebox.showerror(APP_TITLE, f"{self._t('Drucker konnte nicht gespeichert werden', 'Printer could not be saved', 'Tiskárnu nelze uložit')}: {exc}")
                return
            close()
            self.set_status(f"{self._t('Drucker aktiv', 'Printer active', 'Tiskárna aktivní')}: {printer_profile_name(profile)}")
            if print_after:
                self.print_report()

        listbox.bind("<<ListboxSelect>>", update_detail)
        listbox.bind("<Double-Button-1>", lambda _event: save_selected(False))

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="x", padx=14, pady=(8, 14))
        save_button = self._button(buttons, self._t("Speichern", "Save", "Uložit"), lambda: save_selected(False))
        save_button.pack(side="left", padx=(0, 8))
        save_print_button = self._button(buttons, self._t("Speichern + Drucken", "Save + print", "Uložit + tisk"), lambda: save_selected(True))
        save_print_button.pack(side="left", padx=(0, 8))
        save_buttons.extend([save_button, save_print_button])
        self._button(buttons, self._t("Neu suchen", "Search again", "Hledat znovu"), lambda: (close(), self.open_printer_discovery())).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Manuell", "Manual", "RuÄnÄ›"), lambda: (close(), self.open_new_printer_dialog())).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Schließen", "Close", "Zavřít"), close).pack(side="right")
        set_save_state()
        self._bind_dialog_escape(overlay, close)
        overlay.bind("<BackSpace>", lambda _event: close())

        def progress(progress_state: str, message: str) -> None:
            def apply_progress() -> None:
                if state["closed"]:
                    return
                status_var.set(message)
                self._set_internet_indicator(progress_state, message)
                self.set_status(message)
            self.root.after(0, apply_progress)

        def found_callback(printer: dict[str, object]) -> None:
            self.root.after(0, lambda printer=printer: add_found_printer(printer))

        def finish(printers_final: list[dict[str, object]], message: str) -> None:
            release_search_busy()
            if state["closed"]:
                return
            for printer in printers_final:
                add_found_printer(printer)
            status_var.set(message)
            self.set_status(message)
            if not printers:
                detail_var.set(self._t("Keine Netzwerkdrucker gefunden. IP manuell eingeben oder Netzwerk prÃ¼fen.", "No network printers found. Enter IP manually or check network.", "Nenalezena sÃ­Å¥ovÃ¡ tiskÃ¡rna. Zadejte IP ruÄnÄ› nebo zkontrolujte sÃ­Å¥."))
            set_save_state()

        def worker() -> None:
            try:
                printers_final, message = discover_network_printers(progress, found_callback)
            except Exception as exc:
                printers_final = []
                message = f"{self._t('Drucker-Suche fehlgeschlagen', 'Printer search failed', 'Hledání tiskárny selhalo')}: {exc}"
            self.root.after(0, lambda printers_final=printers_final, message=message: finish(printers_final, message))

        threading.Thread(target=worker, name="printer-discovery", daemon=True).start()

    def _show_discovered_printers(self, progress_overlay: tk.Widget, printers: list[dict[str, object]], message: str) -> None:
        self._printer_search_busy = False
        try:
            progress_overlay.destroy()
        except tk.TclError:
            pass
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        dialog_width = min(760, max(500, self.screen_width - 24))
        dialog_height = min(520, max(360, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("Gefundene Drucker", "Found printers", "Nalezené tiskárny"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
            padx=14,
            pady=12,
        ).pack(fill="x")
        tk.Label(
            dialog,
            text=message,
            bg="#12161b",
            fg="#cbd5e1",
            anchor="w",
            padx=14,
            pady=2,
        ).pack(fill="x")

        list_frame = tk.Frame(dialog, bg="#12161b")
        list_frame.pack(fill="both", expand=True, padx=14, pady=(8, 8))
        listbox = tk.Listbox(
            list_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            selectbackground="#d4a84d",
            selectforeground="#101418",
            height=8,
            activestyle="none",
            font=("Consolas", 10 if self.compact_ui else 11),
        )
        listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
        scrollbar.pack(side="right", fill="y")
        listbox.configure(yscrollcommand=scrollbar.set)
        for printer in printers:
            listbox.insert("end", f"{printer.get('name')} | {printer.get('method')} | {printer.get('host')} | {printer.get('ports')}")
        if printers:
            listbox.selection_set(0)
            listbox.activate(0)

        detail_var = tk.StringVar(value="")
        detail = tk.Label(
            dialog,
            textvariable=detail_var,
            bg="#12161b",
            fg="#cbd5e1",
            anchor="w",
            justify="left",
            padx=14,
            pady=4,
            font=("Segoe UI", 9 if self.compact_ui else 10),
        )
        detail.pack(fill="x")

        alias_frame = tk.Frame(dialog, bg="#12161b")
        alias_frame.pack(fill="x", padx=14, pady=(2, 4))
        tk.Label(
            alias_frame,
            text=self._t("Name im Stick", "Name on stick", "Nazev na USB"),
            bg="#12161b",
            fg="#f3f6f9",
            anchor="w",
        ).pack(side="left")
        alias_var = tk.StringVar()
        alias_entry = tk.Entry(
            alias_frame,
            textvariable=alias_var,
            bg="#1a2028",
            fg="#f3f6f9",
            insertbackground="#f3f6f9",
        )
        alias_entry.pack(side="left", fill="x", expand=True, padx=(10, 0))

        def selected_printer() -> dict[str, object] | None:
            if not printers:
                return None
            selection = listbox.curselection()
            index = int(selection[0]) if selection else 0
            return printers[index]

        def update_detail(_event=None) -> None:
            printer = selected_printer()
            if not printer:
                detail_var.set(self._t("Keine Drucker gefunden. IP manuell eingeben oder Netzwerk prÃ¼fen.", "No printers found. Enter IP manually or check network.", "Nenalezena tiskÃ¡rna. Zadejte IP ruÄnÄ› nebo zkontrolujte sÃ­Å¥."))
                return
            wifi_ssid = self._current_saved_wifi_ssid()
            wifi_line = f"\nWLAN-Profil: {wifi_ssid}" if wifi_ssid else ""
            detail_var.set(f"{printer.get('name')}\n{printer.get('method')} | {printer.get('host')} | {printer.get('ports')}{wifi_line}")
            alias_var.set(str(printer.get("name") or printer.get("host") or "").strip())

        def close() -> None:
            overlay.destroy()

        def save_selected(print_after: bool = False) -> None:
            printer = selected_printer()
            if not printer:
                self.set_status(self._t("Kein Drucker ausgewählt", "No printer selected", "Není vybrána tiskárna"))
                return
            profile = discovered_printer_profile(printer, self._current_saved_wifi_ssid(), alias_var.get().strip())
            try:
                upsert_printer_profile(profile)
                save_active_printer_profile(profile, manual_selected=True)
            except OSError as exc:
                messagebox.showerror(APP_TITLE, f"{self._t('Drucker konnte nicht gespeichert werden', 'Printer could not be saved', 'Tiskárnu nelze uložit')}: {exc}")
                return
            close()
            self.set_status(f"{self._t('Drucker aktiv', 'Printer active', 'Tiskárna aktivní')}: {printer_profile_name(profile)}")
            if print_after:
                self.print_report()

        listbox.bind("<<ListboxSelect>>", update_detail)
        listbox.bind("<Double-Button-1>", lambda _event: save_selected(False))
        update_detail()

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="x", padx=14, pady=(8, 14))
        self._button(buttons, self._t("Speichern", "Save", "Uložit"), lambda: save_selected(False)).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Speichern + Drucken", "Save + print", "Uložit + tisk"), lambda: save_selected(True)).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Neu suchen", "Search again", "Hledat znovu"), lambda: (close(), self.open_printer_discovery())).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Manuell", "Manual", "RuÄnÄ›"), lambda: (close(), self.open_new_printer_dialog())).pack(side="left", padx=(0, 8))
        self._button(buttons, self._t("Schließen", "Close", "Zavřít"), close).pack(side="right")
        self._bind_dialog_escape(overlay, close)
        overlay.bind("<BackSpace>", lambda _event: close())

    def open_printer_manager(self) -> None:
        profiles = load_printer_profiles()
        if not profiles:
            self.set_status(self._t("Keine Druckerprofile gefunden - starte Suche", "No printer profiles found - starting search", "Profily tiskáren nenalezeny - hledám"))
            self.open_printer_discovery()
            return
        active_config, _config_path = load_printer_config()
        active_index = active_printer_profile_index(profiles, active_config)
        saved_networks = load_wifi_networks()
        wifi_none = self._t("Kein WLAN-Wechsel", "No Wi-Fi switch", "Bez zmeny Wi-Fi")
        wifi_options = [wifi_none]
        for network in saved_networks:
            ssid = str(network.get("ssid") or "").strip()
            if ssid and ssid not in wifi_options:
                wifi_options.append(ssid)

        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        dialog_width = min(860, max(480, self.screen_width - 24))
        dialog_height = min(650, max(460, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("Drucker auswählen", "Select printer", "Vyber tiskarnu"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
            padx=14,
            pady=12,
        ).pack(fill="x")

        list_frame = tk.Frame(dialog, bg="#12161b")
        list_frame.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        listbox = tk.Listbox(
            list_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            selectbackground="#d4a84d",
            selectforeground="#101418",
            height=5,
            activestyle="none",
            font=("Consolas", 10 if self.compact_ui else 11),
        )
        listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
        scrollbar.pack(side="right", fill="y")
        listbox.configure(yscrollcommand=scrollbar.set)

        def profile_label(profile: dict[str, object], index: int) -> str:
            config = printer_profile_config(profile)
            method = "RAW" if printer_config_bool(config, "raw_socket_fallback", False) else "IPP"
            host = str(config.get("raw_host") or urllib.parse.urlparse(printer_uri(config)).hostname or "").strip()
            active = "* " if index == active_index else "  "
            return f"{active}{printer_profile_name(profile)} | {method} | {host}"

        for index, profile in enumerate(profiles):
            listbox.insert("end", profile_label(profile, index))
        listbox.selection_set(active_index)
        listbox.activate(active_index)
        listbox.see(active_index)

        detail_var = tk.StringVar(value="")
        detail = tk.Label(
            dialog,
            textvariable=detail_var,
            bg="#12161b",
            fg="#cbd5e1",
            anchor="w",
            justify="left",
            padx=14,
            pady=4,
            font=("Segoe UI", 9 if self.compact_ui else 10),
        )
        detail.pack(fill="x")

        name_frame = tk.Frame(dialog, bg="#12161b")
        name_frame.pack(fill="x", padx=14, pady=(2, 4))
        name_var = tk.StringVar(value="")
        tk.Label(
            name_frame,
            text=self._t("Name im Stick", "Name on stick", "Nazev na USB"),
            bg="#12161b",
            fg="#f3f6f9",
            anchor="w",
            font=("Segoe UI", 9 if self.compact_ui else 10),
        ).pack(side="left", padx=(0, 10))
        name_entry = tk.Entry(
            name_frame,
            textvariable=name_var,
            bg="#1a2028",
            fg="#f3f6f9",
            insertbackground="#f3f6f9",
        )
        name_entry.pack(side="left", fill="x", expand=True)

        settings_frame = tk.Frame(dialog, bg="#12161b")
        settings_frame.pack(fill="x", padx=14, pady=(2, 4))
        settings_frame.columnconfigure(1, weight=1)
        settings_frame.columnconfigure(3, weight=1)
        host_var = tk.StringVar(value="")
        raw_port_var = tk.StringVar(value=str(DEFAULT_PRINTER_RAW_PORT))
        uri_var = tk.StringVar(value="")
        method_var = tk.StringVar(value="RAW/PCL LaserJet")
        media_var = tk.StringVar(value="iso_a4_210x297mm")
        media_source_var = tk.StringVar(value="auto")
        wifi_var = tk.StringVar(value=wifi_none)

        def settings_label(row: int, column: int, text: str) -> None:
            tk.Label(
                settings_frame,
                text=text,
                bg="#12161b",
                fg="#f3f6f9",
                anchor="w",
                font=("Segoe UI", 8 if self.compact_ui else 9),
            ).grid(row=row, column=column, sticky="w", padx=(0 if column == 0 else 12, 8), pady=3)

        settings_label(0, 0, self._t("IP / Host", "IP / host", "IP / host"))
        tk.Entry(settings_frame, textvariable=host_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9").grid(row=0, column=1, sticky="ew", pady=3)
        settings_label(0, 2, "RAW-Port")
        tk.Entry(settings_frame, textvariable=raw_port_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9", width=8).grid(row=0, column=3, sticky="ew", pady=3)
        settings_label(1, 0, self._t("Methode", "Method", "Metoda"))
        method_menu = tk.OptionMenu(settings_frame, method_var, "RAW/PCL LaserJet", "IPP/PWG Raster", "IPP/PDF")
        method_menu.configure(bg="#1f2937", fg="#f3f6f9", activebackground="#d4a84d", activeforeground="#101418", highlightthickness=0)
        method_menu.grid(row=1, column=1, sticky="ew", pady=3)
        settings_label(1, 2, self._t("WLAN", "Wi-Fi", "Wi-Fi"))
        wifi_menu = tk.OptionMenu(settings_frame, wifi_var, *wifi_options)
        wifi_menu.configure(bg="#1f2937", fg="#f3f6f9", activebackground="#d4a84d", activeforeground="#101418", highlightthickness=0)
        wifi_menu.grid(row=1, column=3, sticky="ew", pady=3)
        settings_label(2, 0, "IPP-URI")
        tk.Entry(settings_frame, textvariable=uri_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9").grid(row=2, column=1, columnspan=3, sticky="ew", pady=3)
        settings_label(3, 0, self._t("Papier", "Paper", "Papir"))
        tk.Entry(settings_frame, textvariable=media_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9").grid(row=3, column=1, sticky="ew", pady=3)
        settings_label(3, 2, self._t("Fach", "Tray", "Zasobnik"))
        tk.Entry(settings_frame, textvariable=media_source_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9").grid(row=3, column=3, sticky="ew", pady=3)

        def selected_index() -> int:
            selection = listbox.curselection()
            return int(selection[0]) if selection else active_index

        def update_detail(_event=None) -> None:
            profile = profiles[selected_index()]
            config = printer_profile_config(profile)
            method_parts: list[str] = []
            raw_host = str(config.get("raw_host") or config.get("printer_host") or "").strip()
            uri_host = str(urllib.parse.urlparse(printer_uri(config)).hostname or "").strip()
            host_value = raw_host or uri_host
            if printer_config_bool(config, "raw_socket_fallback", False):
                host, port = printer_raw_target(config)
                method_parts.append(f"RAW {host}:{port}")
            if printer_config_bool(config, "direct_ipp_fallback", False):
                method_parts.append(f"IPP {printer_uri(config)}")
            if printer_config_bool(config, "connect_wifi", False):
                network = printer_wifi_network(config)
                if network:
                    method_parts.append(f"WLAN {network['ssid']}")
            media = str(config.get("media") or "A4")
            detail_var.set(f"{printer_profile_name(profile)}\n{'; '.join(method_parts) or 'Drucker'}\nPapier: {media}")
            if name_var.get() != printer_profile_name(profile):
                name_var.set(printer_profile_name(profile))
            host_var.set(host_value)
            try:
                _raw_host, raw_port = printer_raw_target(config)
                raw_port_var.set(str(raw_port))
            except Exception:
                raw_port_var.set(str(DEFAULT_PRINTER_RAW_PORT))
            uri_var.set(printer_uri(config))
            method_var.set(printer_profile_method(config))
            media_var.set(str(config.get("media") or "iso_a4_210x297mm"))
            media_source_var.set(str(config.get("media_source") or "auto"))
            network = printer_wifi_network(config) if printer_config_bool(config, "connect_wifi", False) else None
            ssid = str((network or {}).get("ssid") or "").strip()
            wifi_var.set(ssid if ssid in wifi_options else wifi_none)

        def close() -> None:
            overlay.destroy()

        def activate(print_after: bool = False) -> None:
            profile = profiles[selected_index()]
            try:
                save_active_printer_profile(profile, manual_selected=True)
            except OSError as exc:
                messagebox.showerror(APP_TITLE, f"{self._t('Drucker konnte nicht gespeichert werden', 'Printer could not be saved', 'Tiskárnu nelze uložit')}: {exc}")
                return
            name = printer_profile_name(profile)
            close()
            self.set_status(f"{self._t('Drucker aktiv', 'Printer active', 'Tiskárna aktivní')}: {name}")
            if print_after:
                self.print_report()

        def save_profile_settings() -> None:
            index = selected_index()
            new_name = name_var.get().strip()
            if not new_name:
                self.set_status(self._t("Druckername fehlt", "Printer name missing", "Název tiskárny chybí"))
                return
            host = host_var.get().strip()
            uri_value = uri_var.get().strip()
            if not host and uri_value:
                host = str(urllib.parse.urlparse(uri_value).hostname or "").strip()
            if not host:
                self.set_status(self._t("IP/Hostname fehlt", "IP/hostname missing", "Chybi IP/hostname"))
                return
            try:
                raw_port = int(raw_port_var.get().strip() or str(DEFAULT_PRINTER_RAW_PORT))
                if raw_port < 1 or raw_port > 65535:
                    raise ValueError
            except ValueError:
                self.set_status(self._t("RAW-Port ungültig", "RAW port invalid", "RAW port neplatny"))
                return
            if not uri_value:
                uri_value = f"ipp://{host}:631/ipp/print"
            profile = dict(profiles[index])
            config = printer_profile_config(profile)
            config["printer_name"] = safe_printer_name(new_name)
            config["printer_uri"] = uri_value
            config["raw_host"] = host
            config["raw_port"] = raw_port
            config["media"] = media_var.get().strip() or "iso_a4_210x297mm"
            config["media_source"] = media_source_var.get().strip() or "auto"
            selected_wifi = wifi_var.get().strip()
            if selected_wifi and selected_wifi != wifi_none:
                config["connect_wifi"] = True
                config["wifi"] = {"ssid": selected_wifi}
            else:
                config["connect_wifi"] = False
                config["wifi"] = {}
            method = method_var.get().strip()
            if method == "RAW/PCL LaserJet":
                config.update({
                    "direct_ipp_fallback": False,
                    "raw_socket_fallback": True,
                    "document_format": "application/vnd.hp-PCL",
                    "raw_job_control": "pcl",
                    "model": "raw-pcl",
                })
            elif method == "IPP/PDF":
                config.update({
                    "direct_ipp_fallback": True,
                    "raw_socket_fallback": False,
                    "document_format": "application/pdf",
                    "raw_job_control": "plain",
                    "model": "everywhere",
                })
            else:
                config.update({
                    "direct_ipp_fallback": True,
                    "raw_socket_fallback": False,
                    "document_format": "image/pwg-raster",
                    "pwg_raster_type": str(config.get("pwg_raster_type") or "sgray_8"),
                    "raster_resolution": printer_config_int(config, "raster_resolution", 600),
                    "raster_font_scale": printer_config_int(config, "raster_font_scale", 10),
                    "raw_job_control": "plain",
                    "model": "everywhere",
                })
            profile["name"] = new_name
            profile["config"] = config
            profiles[index] = profile
            try:
                save_printer_profiles(profiles)
                if index == active_index:
                    save_active_printer_profile(profile, manual_selected=True)
            except OSError as exc:
                messagebox.showerror(APP_TITLE, f"{self._t('Drucker konnte nicht gespeichert werden', 'Printer could not be saved', 'Tiskárnu nelze uložit')}:\n{exc}")
                return
            listbox.delete(0, "end")
            for profile_index, item in enumerate(profiles):
                listbox.insert("end", profile_label(item, profile_index))
            listbox.selection_set(index)
            listbox.activate(index)
            listbox.see(index)
            update_detail()
            self.set_status(f"{self._t('Drucker gespeichert', 'Printer saved', 'Tiskárna uložena')}: {new_name}")

        def delete_selected_profile() -> None:
            index = selected_index()
            profile = profiles[index]
            name = printer_profile_name(profile)
            remaining = [item for profile_index, item in enumerate(profiles) if profile_index != index]
            try:
                save_printer_profiles(remaining)
                if index == active_index:
                    if remaining:
                        save_active_printer_profile(remaining[0])
                    else:
                        clear_active_printer_profile()
            except OSError as exc:
                messagebox.showerror(APP_TITLE, f"{self._t('Drucker konnte nicht gelöscht werden', 'Printer could not be deleted', 'Tiskárnu nelze smazat')}:\n{exc}")
                return
            close()
            self.set_status(f"{self._t('Drucker gelöscht', 'Printer deleted', 'Tiskárna smazána')}: {name}")
            if remaining:
                self.root.after(80, self.open_printer_manager)

        listbox.bind("<<ListboxSelect>>", update_detail)
        listbox.bind("<Double-Button-1>", lambda _event: activate(False))
        update_detail()

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="x", padx=14, pady=(6, 14))
        primary_buttons = tk.Frame(buttons, bg="#12161b")
        primary_buttons.pack(fill="x", pady=(0, 6))
        secondary_buttons = tk.Frame(buttons, bg="#12161b")
        secondary_buttons.pack(fill="x")
        self._button(primary_buttons, self._t("Aktivieren", "Activate", "Aktivovat"), lambda: activate(False)).pack(side="left", padx=(0, 8))
        self._button(primary_buttons, self._t("Aktivieren + Drucken", "Activate + print", "Aktivovat + tisk"), lambda: activate(True)).pack(side="left", padx=(0, 8))
        self._button(primary_buttons, self._t("Speichern", "Save", "Uložit"), save_profile_settings).pack(side="left", padx=(0, 8))
        self._button(secondary_buttons, self._t("Drucker suchen", "Search printers", "Hledat tiskárny"), lambda: (close(), self.open_printer_discovery())).pack(side="left", padx=(0, 8))
        self._button(secondary_buttons, self._t("Neuer Drucker", "New printer", "Nová tiskárna"), lambda: (close(), self.open_new_printer_dialog())).pack(side="left", padx=(0, 8))
        self._button(secondary_buttons, self._t("Löschen", "Delete", "Smazat"), delete_selected_profile).pack(side="left", padx=(0, 8))
        self._button(secondary_buttons, self._t("Schließen", "Close", "Zavřít"), close).pack(side="right")
        self._bind_dialog_escape(overlay, close)
        overlay.bind("<BackSpace>", lambda _event: close())

    def open_wifi_manager(self, force_scan: bool = False) -> None:
        if self._wifi_busy:
            return
        self._wifi_busy = True
        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        dialog_width = min(560, max(420, self.screen_width - 24))
        dialog_height = min(220, max(180, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)
        status_var = tk.StringVar(value=self._t("WLAN-Scan startet ...", "Wi-Fi scan starting ...", "Scan Wi-Fi startuje ..."))
        tk.Label(
            dialog,
            text=self._t("WLAN suchen", "Search Wi-Fi", "Hledat Wi-Fi"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
            padx=14,
            pady=12,
        ).pack(fill="x")
        tk.Label(
            dialog,
            textvariable=status_var,
            bg="#12161b",
            fg="#f3f6f9",
            anchor="w",
            justify="left",
            padx=14,
            pady=12,
            wraplength=max(360, dialog_width - 40),
        ).pack(fill="both", expand=True)
        overlay.lift()

        self._set_internet_indicator("searching", "scanne WLAN")
        self.set_status(self._t("WLAN: scanne ...", "Wi-Fi: scanning ...", "Wi-Fi: hledám ..."))

        def progress(state: str, message: str) -> None:
            def apply_progress() -> None:
                self._finish_wifi_progress(state, message)
                status_var.set(message)
            self.root.after(0, apply_progress)

        def worker() -> None:
            debug_lines: list[str] = []
            networks, message = scan_wifi_networks(progress, debug_lines)
            saved_networks = load_wifi_networks()
            seen = {network.get("ssid") for network in networks}
            for saved in saved_networks:
                ssid = saved.get("ssid")
                if ssid and ssid not in seen:
                    saved_item = {"ssid": ssid, "signal": self._t("gespeichert", "saved", "uloženo"), "saved_only": True}
                    if saved.get("security_mode"):
                        saved_item["security_mode"] = saved["security_mode"]
                    networks.append(saved_item)
            if saved_networks and not networks:
                message = self._t("keine sichtbaren WLANs; gespeicherte Netze geladen", "no visible Wi-Fi; saved networks loaded", "Å¾Ã¡dnÃ¡ viditelnÃ¡ Wi-Fi; naÄteny uloÅ¾enÃ© sÃ­tÄ›")
            elif saved_networks and networks:
                message = f"{message} + {self._t('gespeicherte Netze', 'saved networks', 'uložené sítě')}"
            def show_result() -> None:
                try:
                    overlay.destroy()
                except tk.TclError:
                    pass
                self._show_wifi_manager(networks, message)
            self.root.after(0, show_result)

        threading.Thread(target=worker, name="wifi-scan", daemon=True).start()

    def _finish_wifi_progress(self, state: str, message: str) -> None:
        self._set_internet_indicator(state, message)
        self.set_status(f"WLAN: {message}")

    def _show_wifi_manager(self, networks: list[dict[str, str]], message: str) -> None:
        self._wifi_busy = False
        self._set_internet_indicator("offline")
        self.set_status(f"WLAN: {message}")

        overlay = tk.Frame(self.root, bg="#080b0f")
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        dialog_width = min(560, max(420, self.screen_width - 24))
        dialog_height = min(460, max(360, self.screen_height - 24))
        dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
        dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)

        tk.Label(
            dialog,
            text=self._t("WLAN auswählen oder SSID eingeben", "Select Wi-Fi or enter SSID", "Vyber Wi-Fi nebo zadej SSID"),
            bg="#12161b",
            fg="#f7d37c",
            font=("Segoe UI", 13, "bold"),
            anchor="w",
            padx=14,
            pady=12,
        ).pack(fill="x")

        list_frame = tk.Frame(dialog, bg="#12161b")
        list_frame.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        listbox = tk.Listbox(
            list_frame,
            bg="#1a2028",
            fg="#f3f6f9",
            selectbackground="#d4a84d",
            selectforeground="#101418",
            height=8,
            activestyle="none",
            font=("Consolas", 11),
        )
        listbox.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=listbox.yview)
        scrollbar.pack(side="right", fill="y")
        listbox.configure(yscrollcommand=scrollbar.set)

        for network in networks:
            label = network["ssid"]
            security = normalize_wifi_security(network.get("security_mode"))
            if security and security != "OPEN":
                label = f"{label}   {security}"
            if network.get("signal"):
                label = f"{label}   {network['signal']}"
            listbox.insert("end", label)

        form = tk.Frame(dialog, bg="#12161b")
        form.pack(fill="x", padx=14, pady=4)
        ssid_var = tk.StringVar(value=networks[0]["ssid"] if networks else "")
        password_var = tk.StringVar()
        known_passwords = saved_wifi_passwords()
        if ssid_var.get() in known_passwords:
            password_var.set(known_passwords[ssid_var.get()])

        tk.Label(form, text="SSID", bg="#12161b", fg="#f3f6f9", anchor="w").grid(row=0, column=0, sticky="w", pady=4)
        ssid_entry = tk.Entry(form, textvariable=ssid_var, bg="#1a2028", fg="#f3f6f9", insertbackground="#f3f6f9")
        ssid_entry.grid(row=0, column=1, sticky="ew", padx=(10, 0), pady=4)
        tk.Label(form, text=self._t("Passwort", "Password", "Heslo"), bg="#12161b", fg="#f3f6f9", anchor="w").grid(row=1, column=0, sticky="w", pady=4)
        password_entry = tk.Entry(
            form,
            textvariable=password_var,
            show="*",
            bg="#1a2028",
            fg="#f3f6f9",
            insertbackground="#f3f6f9",
        )
        password_entry.grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=4)
        form.columnconfigure(1, weight=1)

        def on_select(_event=None) -> None:
            selection = listbox.curselection()
            if not selection:
                return
            ssid = networks[selection[0]]["ssid"]
            ssid_var.set(ssid)
            password_var.set(known_passwords.get(ssid, ""))
            password_entry.focus_set()

        listbox.bind("<<ListboxSelect>>", on_select)
        if networks:
            listbox.selection_set(0)

        def selected_wifi_network() -> dict[str, str]:
            ssid = ssid_var.get().strip()
            selection = listbox.curselection()
            if selection:
                try:
                    selected = networks[int(selection[0])]
                    if selected.get("ssid") == ssid:
                        return dict(selected)
                except (IndexError, ValueError):
                    pass
            for network in networks:
                if network.get("ssid") == ssid:
                    return dict(network)
            return {"ssid": ssid}

        buttons = tk.Frame(dialog, bg="#12161b")
        buttons.pack(fill="x", padx=14, pady=(8, 14))

        def close_dialog() -> None:
            try:
                overlay.grab_release()
            except tk.TclError:
                pass
            overlay.destroy()

        def save_selected() -> None:
            ssid = ssid_var.get().strip()
            password = password_var.get().strip()
            selected_network = selected_wifi_network()
            security_mode = normalize_wifi_security(selected_network.get("security_mode"))
            try:
                save_wifi_network(ssid, password, security_mode)
            except (OSError, ValueError) as exc:
                messagebox.showerror(APP_TITLE, f"WLAN konnte nicht gespeichert werden:\n{exc}")
                return
            self.set_status(f"WLAN gespeichert: {ssid}")
            close_dialog()
            connect_network = {"ssid": ssid, "password": password}
            if security_mode:
                connect_network["security_mode"] = security_mode
            if selected_network.get("security_source"):
                connect_network["security_source"] = selected_network["security_source"]
            self.connect_saved_wifi(show_overlay=True, networks_override=[connect_network])

        def delete_selected_wifi() -> None:
            ssid = ssid_var.get().strip()
            if not ssid or ssid not in known_passwords:
                self.set_status(self._t("WLAN ist nicht gespeichert", "Wi-Fi is not saved", "Wi-Fi není uložena"))
                return
            try:
                deleted = delete_wifi_network(ssid)
            except OSError as exc:
                messagebox.showerror(APP_TITLE, f"{self._t('WLAN konnte nicht gelöscht werden', 'Wi-Fi could not be deleted', 'Wi-Fi nelze smazat')}:\n{exc}")
                return
            if not deleted:
                self.set_status(self._t("WLAN war nicht gespeichert", "Wi-Fi was not saved", "Wi-Fi nebyla uložena"))
                return
            known_passwords.pop(ssid, None)
            password_var.set("")
            selection = listbox.curselection()
            selected = int(selection[0]) if selection else -1
            for index in range(len(networks) - 1, -1, -1):
                if networks[index].get("ssid") == ssid and networks[index].get("saved_only"):
                    del networks[index]
                    listbox.delete(index)
                    if selected >= index:
                        selected -= 1
            if networks:
                selected = max(0, min(selected, len(networks) - 1))
                listbox.selection_clear(0, "end")
                listbox.selection_set(selected)
                listbox.activate(selected)
                ssid_var.set(str(networks[selected].get("ssid") or ""))
            else:
                ssid_var.set("")
            self.set_status(f"{self._t('WLAN gelöscht', 'Wi-Fi deleted', 'Wi-Fi smazána')}: {ssid}")

        def change_selected_password() -> None:
            """Make replacing a remembered password explicit and immediate."""
            ssid = ssid_var.get().strip()
            if not ssid:
                self.set_status(self._t("Bitte zuerst ein WLAN auswählen", "Choose a Wi-Fi network first", "Nejprve vyberte síť Wi-Fi"))
                return
            password_var.set("")
            password_entry.focus_set()
            self.set_status(self._t("Neues WLAN-Passwort eingeben und speichern", "Enter the new Wi-Fi password and save", "Zadejte nové heslo Wi-Fi a uložte"))

        def rescan_networks() -> None:
            self._set_internet_indicator("searching", "scanne WLAN")
            self.set_status(self._t("WLAN: scanne ...", "Wi-Fi: scanning ...", "Wi-Fi: hledám ..."))
            listbox.delete(0, "end")
            listbox.insert("end", self._t("scanne WLAN ...", "scanning Wi-Fi ...", "hledám Wi-Fi ..."))
            ssid_var.set("")
            password_var.set("")
            for child in buttons.winfo_children():
                try:
                    child.configure(state="disabled")
                except tk.TclError:
                    pass

            def progress(state: str, message: str) -> None:
                self.root.after(0, lambda state=state, message=message: self._finish_wifi_progress(state, message))

            def worker() -> None:
                debug_lines: list[str] = []
                next_networks, next_message = scan_wifi_networks(progress, debug_lines)
                saved_networks = load_wifi_networks()
                seen = {network.get("ssid") for network in next_networks}
                for saved in saved_networks:
                    ssid = saved.get("ssid")
                    if ssid and ssid not in seen:
                        saved_item = {"ssid": ssid, "signal": self._t("gespeichert", "saved", "uloženo"), "saved_only": True}
                        if saved.get("security_mode"):
                            saved_item["security_mode"] = saved["security_mode"]
                        next_networks.append(saved_item)
                if saved_networks and not next_networks:
                    next_message = self._t("keine sichtbaren WLANs; gespeicherte Netze geladen", "no visible Wi-Fi; saved networks loaded", "Å¾Ã¡dnÃ¡ viditelnÃ¡ Wi-Fi; naÄteny uloÅ¾enÃ© sÃ­tÄ›")
                elif saved_networks and next_networks:
                    next_message = f"{next_message} + {self._t('gespeicherte Netze', 'saved networks', 'uložené sítě')}"
                self.root.after(0, lambda: (close_dialog(), self._show_wifi_manager(next_networks, next_message)))

            threading.Thread(target=worker, name="wifi-rescan", daemon=True).start()

        tk.Button(
            buttons,
            text=self._t("Speichern", "Save", "Uložit"),
            command=save_selected,
            bg="#d4a84d",
            fg="#101418",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left", padx=(0, 8))
        tk.Button(
            buttons,
            text=self._t("Passwort ändern", "Change password", "Změnit heslo"),
            command=change_selected_password,
            bg="#2a3440",
            fg="#f3f6f9",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left", padx=(0, 8))
        tk.Button(
            buttons,
            text=self._t("Löschen", "Delete", "Smazat"),
            command=delete_selected_wifi,
            bg="#5f2630",
            fg="#f8fafc",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left", padx=(0, 8))
        tk.Button(
            buttons,
            text=self._t("Neu suchen", "Search again", "Hledat znovu"),
            command=rescan_networks,
            bg="#2a3440",
            fg="#f3f6f9",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left")
        tk.Button(
            buttons,
            text=self._t("Abbrechen", "Cancel", "Zrušit"),
            command=close_dialog,
            bg="#2a3440",
            fg="#f3f6f9",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        ).pack(side="right")
        self._bind_dialog_escape(overlay, close_dialog)
        overlay.bind("<BackSpace>", lambda _event: close_dialog())

        def bring_to_front() -> None:
            try:
                overlay.lift()
                overlay.focus_force()
                overlay.grab_set()
                dialog.lift()
                if ssid_var.get():
                    password_entry.focus_set()
                    password_entry.icursor("end")
                else:
                    ssid_entry.focus_set()
            except tk.TclError:
                pass

        bring_to_front()
        overlay.after(100, bring_to_front)
        overlay.after(500, bring_to_front)

    def connect_saved_wifi(self, show_overlay: bool = False, networks_override: list[dict[str, str]] | None = None) -> None:
        if self._wifi_busy:
            return
        self._wifi_busy = True
        overlay: tk.Frame | None = None
        status_var: tk.StringVar | None = None
        if show_overlay:
            overlay = tk.Frame(self.root, bg="#080b0f")
            overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
            dialog_width = min(560, max(420, self.screen_width - 24))
            dialog_height = min(220, max(180, self.screen_height - 24))
            dialog = tk.Frame(overlay, bg="#12161b", highlightthickness=2, highlightbackground="#d4a84d")
            dialog.place(relx=0.5, rely=0.5, anchor="center", width=dialog_width, height=dialog_height)
            status_var = tk.StringVar(value=self._t("WLAN wird verbunden ...", "Connecting Wi-Fi ...", "Pripojuji Wi-Fi ..."))
            tk.Label(
                dialog,
                text=self._t("WLAN verbinden", "Connect Wi-Fi", "Pripojit Wi-Fi"),
                bg="#12161b",
                fg="#f7d37c",
                font=("Segoe UI", 13, "bold"),
                anchor="w",
                padx=14,
                pady=12,
            ).pack(fill="x")
            tk.Label(
                dialog,
                textvariable=status_var,
                bg="#12161b",
                fg="#f3f6f9",
                anchor="w",
                justify="left",
                padx=14,
                pady=12,
                wraplength=max(360, dialog_width - 40),
            ).pack(fill="both", expand=True)
            overlay.lift()
        self._set_internet_indicator("searching", "verbinde WLAN")
        self.set_status("WLAN: verbinde ...")

        def progress(state: str, message: str) -> None:
            def apply_progress() -> None:
                self._finish_wifi_progress(state, message)
                if status_var is not None:
                    status_var.set(message)
            self.root.after(0, apply_progress)

        def worker() -> None:
            debug_lines: list[str] = []
            ok, message, cleanup = connect_temporary_network(progress, debug_lines, networks_override=networks_override)
            if not ok:
                cleanup()
            self.root.after(0, lambda ok=ok, message=message: self._finish_saved_wifi_connect(ok, message, overlay))

        threading.Thread(target=worker, name="wifi-connect", daemon=True).start()

    def _finish_saved_wifi_connect(self, ok: bool, message: str, overlay: tk.Widget | None = None) -> None:
        self._wifi_busy = False
        if overlay is not None:
            try:
                overlay.destroy()
            except tk.TclError:
                pass
        self._set_internet_indicator("online" if ok else "error", message)
        self.set_status(f"WLAN: {message}")
        if self._pending_model_update:
            self._pending_model_update = False
            self.root.after(250, self.update_model_database)
        elif self._pending_program_update:
            self._pending_program_update = False
            self.root.after(250, self.check_hardwarecheck_update)
        elif ok:
            self.root.after(800, self.auto_check_updates)

    def save_report(self) -> None:
        self._save_report_async()
        return
        report_dir = get_report_dir()
        report_dir.mkdir(parents=True, exist_ok=True)
        snapshot = self.snapshot or get_system_snapshot()
        matches = self.matches or get_model_matches(snapshot, self.language)
        report = build_report(snapshot, matches, self.language)
        filename = f"{report_basename(snapshot)}.txt"
        target = report_dir / filename
        try:
            write_text_durable(target, report)
            write_report_save_debug(target, ok=True)
        except OSError as exc:
            write_report_save_debug(target, ok=False, error=str(exc))
            self.set_status(
                f"{self._t('Bericht konnte nicht gespeichert werden', 'Report could not be saved', 'Zprávu se nepodařilo uložit')}: {exc}"
            )
            return
        self.set_status(
            f"{self._t('Bericht gespeichert', 'Report saved', 'Zpráva uložena')}: {target} ({target.stat().st_size} Bytes)"
        )

    def print_report(self) -> None:
        if self._print_busy:
            self.set_status(self._t("Druck läuft bereits ...", "Print already running ...", "Tisk již běží ..."))
            return
        self._save_report_async(print_after=True)

    def _save_report_async(self, print_after: bool = False) -> None:
        if getattr(self, "_report_busy", False):
            return
        self._report_busy = True
        language = self.language
        snapshot = dict(self.snapshot) if self.snapshot else {}
        matches = list(self.matches)
        self.set_status(
            self._t(
                "Speichere Bericht für Druck ...",
                "Saving report for print ...",
                "Ukladam zpravu pro tisk ...",
            )
            if print_after
            else self._t("Speichere Bericht ...", "Saving report ...", "Ukladam zpravu ...")
        )

        def worker() -> None:
            target: pathlib.Path | None = None
            try:
                report_dir = get_report_dir()
                report_dir.mkdir(parents=True, exist_ok=True)
                local_snapshot = snapshot or get_system_snapshot()
                local_matches = matches or get_model_matches(local_snapshot, language)
                report = build_report(local_snapshot, local_matches, language)
                target = report_dir / f"{report_basename(local_snapshot)}.txt"
                write_text_durable(target, report)
                write_report_save_debug(target, ok=True)
                size = target.stat().st_size
                self.root.after(0, lambda target=target, size=size: self._finish_report_save(target, size, None, print_after))
            except OSError as exc:
                error = str(exc)
                if target is not None:
                    write_report_save_debug(target, ok=False, error=error)
                self.root.after(0, lambda target=target, error=error: self._finish_report_save(target, 0, error, print_after))

        threading.Thread(target=worker, name="report-save", daemon=True).start()

    def _finish_report_save(self, target: pathlib.Path | None, size: int, error: str | None, print_after: bool = False) -> None:
        self._report_busy = False
        if error:
            self.set_status(
                f"{self._t('Bericht konnte nicht gespeichert werden', 'Report could not be saved', 'Zprávu se nepodařilo uložit')}: {error}"
            )
            return
        self.set_status(
            f"{self._t('Bericht gespeichert', 'Report saved', 'Zpráva uložena')}: {target} ({size} Bytes)"
        )
        if print_after and target is not None:
            self._print_report_async(target)

    def _print_report_async(self, target: pathlib.Path) -> None:
        if self._print_busy:
            return
        self._print_busy = True
        self.set_status(self._t("Druck: vorbereiten ...", "Print: preparing ...", "Tisk: pripravuji ..."))

        def progress(state: str, message: str) -> None:
            self.root.after(0, lambda state=state, message=message: self._finish_print_progress(state, message))

        def worker() -> None:
            ok, message = run_report_print(target, progress)
            self.root.after(0, lambda ok=ok, message=message: self._finish_report_print(ok, message))

        threading.Thread(target=worker, name="report-print", daemon=True).start()

    def _finish_print_progress(self, state: str, message: str) -> None:
        self._set_internet_indicator("searching" if state == "searching" else state, message)
        self.set_status(f"{self._t('Druck', 'Print', 'Tisk')}: {message}")

    def _finish_report_print(self, ok: bool, message: str) -> None:
        self._print_busy = False
        self._set_internet_indicator("offline" if ok else "error", message)
        self.set_status(
            f"{self._t('Druck erfolgreich', 'Print successful', 'Tisk uspesny')}: {message}"
            if ok
            else f"{self._t('Druck fehlgeschlagen', 'Print failed', 'Tisk selhal')}: {message}"
        )

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    if sys.platform.startswith("linux") and os.environ.get("HC_USE_LEGACY_UI") != "1":
        try:
            module_ok, module_message = install_v53_magic_image_module_from_staging()
            if not module_ok:
                raise RuntimeError(module_message)
            sync_ok, sync_message = install_config_server_sync_module_from_staging()
            if not sync_ok:
                raise RuntimeError(sync_message)
            pci_db_ok, pci_db_message = install_pci_database_from_staging()
            if not pci_db_ok:
                raise RuntimeError(pci_db_message)
            gpu_db_ok, gpu_db_message = install_gpu_name_database_from_staging()
            if not gpu_db_ok:
                raise RuntimeError(gpu_db_message)
            if get_workshop_start_mode() == "magic" and (SCRIPT_DIR / "magic_image_solo_gui.py").is_file():
                import magic_image_solo_gui

                return magic_image_solo_gui.run(sys.modules[__name__])
            import hardwarecheck_v5_gui

            return hardwarecheck_v5_gui.run(sys.modules[__name__])
        except Exception:
            try:
                debug_root = find_external_root() or SCRIPT_DIR
                debug_dir = pathlib.Path(debug_root) / "hardwarecheck-debug"
                debug_dir.mkdir(parents=True, exist_ok=True)
                write_text_durable(debug_dir / "v5-startup-error.txt", traceback.format_exc())
            except OSError:
                pass
    app = HardwareCheckApp()
    app.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
