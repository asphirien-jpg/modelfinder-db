#!/usr/bin/env python3
"""Non-destructive foundation for the HardwareCheck Magic-Image workflow.

HardwareCheck owns all user decisions.  This module only discovers media,
validates the selected configuration and prepares a *simulation* of a restore
job.  It deliberately does not run Clonezilla or mount/write a Windows disk.

Drive letters (for example D:, F: or G:) and volatile Linux names (for example
/dev/sda2) are never configuration.  A role is instead identified by mounted
marker files, a manifest and the physical parent disk reported by ``lsblk``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import time
import uuid
from typing import Callable, Iterable


MANIFEST_FILE = "magic-image-manifest.json"
HARDWARECHECK_MARKERS = (
    ".hardwarecheck-portable",
    "hardwarecheck_v5_gui.py",
    "HardwareCheck/.hardwarecheck-portable",
    "HardwareCheck/hardwarecheck_v5_gui.py",
)
CLONEZILLA_MARKERS = ("Clonezilla-Live-Version", ".disk", "live")
REPOSITORY_MARKERS = ("#configs", "Treiber", "image-deploy.bat")
LSBLK_COLUMNS = (
    "NAME,KNAME,PATH,PKNAME,TYPE,TRAN,SIZE,MODEL,SERIAL,WWN,RM,HOTPLUG,"
    "MOUNTPOINTS,LABEL,UUID,PARTUUID,FSTYPE"
)
READONLY_MOUNT_ROOT = pathlib.Path("/run/hardwarecheck-magic-media")
CLONEZILLA_RUNTIME_ROOT = pathlib.Path("/run/hardwarecheck-clonezilla-runtime")
CLONEZILLA_SQUASHFS_RELATIVE_PATH = pathlib.Path("live") / "filesystem.squashfs"
HANDOFF_WINDOWS_PATH = r"C:\MagicImage\hardwarecheck-config.txt"


def _text(value: object) -> str:
    return str(value or "").strip()


def _mountpoints(value: object) -> tuple[str, ...]:
    if isinstance(value, list):
        candidates = value
    else:
        candidates = [value]
    return tuple(item for item in (_text(candidate) for candidate in candidates) if item)


def _safe_name(value: object, fallback: str = "") -> str:
    value = _text(value)
    return value if re.fullmatch(r"[A-Za-z0-9._+-]+", value) else fallback


def _format_size(size_bytes: int) -> str:
    if size_bytes <= 0:
        return "unbekannt"
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    value = float(size_bytes)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return "unbekannt"


@dataclass(frozen=True)
class BlockDevice:
    """One lsblk node, including its stable association with a physical disk."""

    path: str
    name: str
    parent_disk: str
    type: str
    transport: str
    size_bytes: int
    model: str
    serial: str
    wwn: str
    removable: bool
    hotplug: bool
    mountpoints: tuple[str, ...]
    label: str
    uuid: str
    partuuid: str
    filesystem: str = ""

    @property
    def is_disk(self) -> bool:
        return self.type == "disk"

    @property
    def is_usb(self) -> bool:
        return self.transport == "usb" or self.removable or self.hotplug

    @property
    def stable_identity(self) -> str:
        parts = [part for part in (self.wwn, self.serial, self.partuuid, self.uuid) if part]
        return " | ".join(parts) or "keine stabile Kennung"

    @property
    def description(self) -> str:
        model = " ".join(part for part in (self.model, self.serial) if part).strip() or "unbekanntes Modell"
        bus = self.transport.upper() if self.transport else "unbekannter Bus"
        return f"{self.path} · {model} · {_format_size(self.size_bytes)} · {bus}"


@dataclass(frozen=True)
class MediaRole:
    role: str
    mountpoint: str
    parent_disk: str
    label: str
    reason: str


@dataclass(frozen=True)
class MagicImage:
    image_id: str
    display_name: str
    version: str
    image_path: str
    minimum_target_bytes: int
    description: str
    managed: bool

    @property
    def display_text(self) -> str:
        version = f" · {self.version}" if self.version else ""
        source = "Manifest" if self.managed else "Image ohne Manifest"
        return f"{self.display_name}{version} ({source})"


@dataclass(frozen=True)
class ConfigValidation:
    config: str
    valid: bool
    score: int
    message: str
    model: dict[str, object] | None = None
    details: tuple[str, ...] = ()


@dataclass(frozen=True)
class ClonezillaProbe:
    available: bool
    executable: str
    message: str
    source_path: str = ""
    usage_verified: bool = False
    log_excerpt: str = ""


@dataclass(frozen=True)
class RestoreProofPlan:
    """A reviewable restore job; building it never changes a disk."""

    ready: bool
    message: str
    config: str = ""
    image_name: str = ""
    image_path: str = ""
    repository_path: str = ""
    target_path: str = ""
    target_selector: str = ""
    target_model: str = ""
    target_size_bytes: int = 0
    confirmation_text: str = ""
    command: tuple[str, ...] = ()


@dataclass(frozen=True)
class RestoreProofResult:
    success: bool
    phase: str
    message: str
    clonezilla_exit_code: int | None = None
    log_path: str = ""
    handoff_path: str = ""
    output_excerpt: str = ""


@dataclass
class MediaInspection:
    devices: list[BlockDevice] = field(default_factory=list)
    roles: list[MediaRole] = field(default_factory=list)
    images: list[MagicImage] = field(default_factory=list)
    safe_targets: list[BlockDevice] = field(default_factory=list)
    protected_disks: set[str] = field(default_factory=set)
    mounted_read_only: list[str] = field(default_factory=list)
    available_configs: set[str] = field(default_factory=set)
    config_repository_paths: tuple[str, ...] = ()
    clonezilla: ClonezillaProbe = field(
        default_factory=lambda: ClonezillaProbe(False, "", "Clonezilla wurde noch nicht geprüft.")
    )
    warnings: list[str] = field(default_factory=list)


def parse_lsblk(payload: str) -> list[BlockDevice]:
    """Parse lsblk JSON while preserving each partition's physical parent disk."""

    try:
        data = json.loads(payload)
    except (TypeError, json.JSONDecodeError):
        return []
    roots = data.get("blockdevices") if isinstance(data, dict) else None
    if not isinstance(roots, list):
        return []

    result: list[BlockDevice] = []

    def visit(raw: object, parent_disk: str = "") -> None:
        if not isinstance(raw, dict):
            return
        name = _safe_name(raw.get("name"))
        path = _text(raw.get("path")) or (f"/dev/{name}" if name else "")
        node_type = _text(raw.get("type")).lower()
        current_parent = path if node_type == "disk" else parent_disk
        if path and node_type in {"disk", "part"}:
            try:
                size_bytes = int(raw.get("size") or 0)
            except (TypeError, ValueError):
                size_bytes = 0
            removable = _text(raw.get("rm")).lower() in {"1", "true", "yes"}
            hotplug = _text(raw.get("hotplug")).lower() in {"1", "true", "yes"}
            result.append(
                BlockDevice(
                    path=path,
                    name=name,
                    parent_disk=current_parent or path,
                    type=node_type,
                    transport=_text(raw.get("tran")).lower(),
                    size_bytes=size_bytes,
                    model=_text(raw.get("model")),
                    serial=_text(raw.get("serial")),
                    wwn=_text(raw.get("wwn")),
                    removable=removable,
                    hotplug=hotplug,
                    mountpoints=_mountpoints(raw.get("mountpoints")),
                    label=_text(raw.get("label")),
                    uuid=_text(raw.get("uuid")),
                    partuuid=_text(raw.get("partuuid")),
                    filesystem=_text(raw.get("fstype")).lower(),
                )
            )
        children = raw.get("children")
        if isinstance(children, list):
            for child in children:
                visit(child, current_parent)

    for root in roots:
        visit(root)
    return result


def collect_lsblk(runner: Callable[..., object] = subprocess.run) -> list[BlockDevice]:
    """Read only the running system's block-device metadata.  Never writes."""

    try:
        completed = runner(
            ["lsblk", "--json", "--bytes", "--output", LSBLK_COLUMNS],
            check=False,
            capture_output=True,
            text=True,
            timeout=8,
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return []
    if int(getattr(completed, "returncode", 1)) != 0:
        return []
    return parse_lsblk(_text(getattr(completed, "stdout", "")))


def external_unmounted_partitions(devices: Iterable[BlockDevice]) -> list[BlockDevice]:
    """Return only unmounted partitions whose *physical* parent is external."""

    external_disks = {
        device.path
        for device in devices
        if device.is_disk and device.is_usb
    }
    return [
        device
        for device in devices
        if device.type == "part"
        and not device.mountpoints
        and device.parent_disk in external_disks
    ]


def _run_read_only_mount(command: list[str], runner: Callable[..., object]) -> tuple[bool, str]:
    try:
        completed = runner(command, check=False, capture_output=True, text=True, timeout=12)
    except (FileNotFoundError, OSError, subprocess.SubprocessError) as exc:
        return False, str(exc)
    output = "\n".join(
        value for value in (_text(getattr(completed, "stdout", "")), _text(getattr(completed, "stderr", ""))) if value
    )
    return int(getattr(completed, "returncode", 1)) == 0, output


def mount_external_partitions_read_only(
    devices: Iterable[BlockDevice], runner: Callable[..., object] = subprocess.run
) -> tuple[list[str], list[str]]:
    """Mount external, previously unmounted partitions read-only for inspection.

    This is intentionally limited to USB/removable parent disks.  It never
    mounts or modifies an internal target disk and never executes files from a
    mounted medium.  The mounts stay available while HardwareCheck prepares a
    later job, so a selected Clonezilla image path cannot silently disappear.
    """

    if not sys.platform.startswith("linux"):
        return [], []
    mounted: list[str] = []
    warnings: list[str] = []
    try:
        READONLY_MOUNT_ROOT.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return [], [f"Schreibgeschützter Medienordner kann nicht angelegt werden: {exc}"]
    for partition in external_unmounted_partitions(devices):
        target = READONLY_MOUNT_ROOT / _safe_name(partition.name, "external")
        try:
            target.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            warnings.append(f"{partition.path} konnte nicht vorbereitet werden: {exc}")
            continue
        # udisksctl works on most desktop/live environments without assuming
        # that HardwareCheck itself runs as root.
        if shutil.which("udisksctl"):
            ok, output = _run_read_only_mount(
                ["udisksctl", "mount", "-b", partition.path, "--options", "ro,nosuid,nodev,noexec"], runner
            )
            if ok:
                mounted.append(partition.path)
                continue
        else:
            output = "udisksctl nicht vorhanden"
        # The image repository is commonly NTFS.  Current Linux kernels
        # expose their in-kernel NTFS driver as ``ntfs3``; asking simply for
        # ``ntfs`` can therefore fail even though safe read-only NTFS access
        # is available.  If this is not an NTFS partition, the attempt is
        # harmless and the generic read-only mount below remains the fallback.
        ok, ntfs3_output = _run_read_only_mount(
            ["mount", "-t", "ntfs3", "-o", "ro,nosuid,nodev,noexec", partition.path, str(target)], runner
        )
        if ok:
            mounted.append(partition.path)
            continue
        # Clonezilla-style live sessions commonly run with sufficient rights;
        # direct mount is the fallback and remains read-only.
        ok, fallback_output = _run_read_only_mount(
            ["mount", "-o", "ro,nosuid,nodev,noexec", partition.path, str(target)], runner
        )
        if ok:
            mounted.append(partition.path)
        else:
            detail = fallback_output or ntfs3_output or output
            warnings.append(f"{partition.path} konnte nicht schreibgeschützt eingehängt werden: {detail}")
    return mounted, warnings


def _marker_exists(root: pathlib.Path, marker: str) -> bool:
    try:
        return (root / marker).exists()
    except OSError:
        return False


def _is_hardwarecheck_root(root: pathlib.Path) -> bool:
    return any(_marker_exists(root, marker) for marker in HARDWARECHECK_MARKERS)


def _is_clonezilla_root(root: pathlib.Path) -> bool:
    return all(_marker_exists(root, marker) for marker in CLONEZILLA_MARKERS)


def _is_repository_root(root: pathlib.Path) -> bool:
    if _marker_exists(root, MANIFEST_FILE):
        return True
    # Compatibility with the already prepared TEST media.  A production
    # repository is later made explicit with magic-image-manifest.json.
    return all(_marker_exists(root, marker) for marker in REPOSITORY_MARKERS[:2])


def discover_media_roles(
    devices: Iterable[BlockDevice], tool_root: pathlib.Path | None = None
) -> list[MediaRole]:
    roles: list[MediaRole] = []
    seen: set[tuple[str, str]] = set()
    for device in devices:
        for mountpoint in device.mountpoints:
            root = pathlib.Path(mountpoint)
            candidates = (
                (
                    "hardwarecheck",
                    lambda candidate: _is_hardwarecheck_root(candidate)
                    or (tool_root is not None and _inside(candidate, tool_root)),
                    "HardwareCheck-Marker beziehungsweise laufender Programmordner gefunden",
                ),
                ("clonezilla", _is_clonezilla_root, "Clonezilla-Live-Marker gefunden"),
                ("repository", _is_repository_root, "Magic-Image-Repository-Marker gefunden"),
            )
            for role, predicate, reason in candidates:
                key = (role, device.parent_disk)
                if key not in seen and predicate(root):
                    roles.append(
                        MediaRole(
                            role=role,
                            mountpoint=mountpoint,
                            parent_disk=device.parent_disk,
                            label=device.label,
                            reason=reason,
                        )
                    )
                    seen.add(key)
    return roles


def _inside(root: pathlib.Path, candidate: pathlib.Path) -> bool:
    try:
        candidate.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def _manifest_images(root: pathlib.Path) -> list[MagicImage]:
    manifest_path = root / MANIFEST_FILE
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return []
    entries = data.get("images") if isinstance(data, dict) else None
    if not isinstance(entries, list):
        return []
    images: list[MagicImage] = []
    for raw in entries:
        if not isinstance(raw, dict):
            continue
        image_id = _safe_name(raw.get("id"))
        relative_path = _text(raw.get("clonezilla_path") or raw.get("path"))
        candidate = root / relative_path
        try:
            minimum = int(raw.get("minimum_target_bytes") or raw.get("minimum_target_size_bytes") or 0)
        except (TypeError, ValueError):
            minimum = 0
        if not image_id or not relative_path or not _inside(root, candidate) or not looks_like_clonezilla_image(candidate):
            continue
        images.append(
            MagicImage(
                image_id=image_id,
                display_name=_text(raw.get("display_name")) or image_id,
                version=_text(raw.get("version")),
                image_path=str(candidate),
                minimum_target_bytes=max(0, minimum),
                description=_text(raw.get("description")),
                managed=True,
            )
        )
    return images


def looks_like_clonezilla_image(path: pathlib.Path) -> bool:
    """Recognise Clonezilla's file structure, never merely a folder name."""

    try:
        if not path.is_dir():
            return False
        return (path / "parts").is_file() and (path / "disk").is_file()
    except OSError:
        return False


def discover_images(repository_roots: Iterable[str]) -> list[MagicImage]:
    images: list[MagicImage] = []
    seen_paths: set[str] = set()
    for root_text in repository_roots:
        root = pathlib.Path(root_text)
        managed = _manifest_images(root)
        for image in managed:
            if image.image_path not in seen_paths:
                images.append(image)
                seen_paths.add(image.image_path)
        # The first proof-of-concept already has a real image but no manifest.
        # It remains visibly labelled TEST-Fund and must be selected manually.
        if managed:
            continue
        try:
            children = list(root.iterdir())
        except OSError:
            continue
        for child in sorted(children, key=lambda item: item.name.lower()):
            if not looks_like_clonezilla_image(child):
                continue
            path = str(child)
            if path in seen_paths:
                continue
            images.append(
                MagicImage(
                    image_id=f"detected-{child.name}",
                    display_name=child.name,
                    version="",
                    image_path=path,
                    minimum_target_bytes=0,
                    description="Automatisch über Clonezilla-Dateistruktur erkannt; vor Produktion in ein Manifest übernehmen.",
                    managed=False,
                )
            )
            seen_paths.add(path)
    return images


def safe_restore_targets(devices: Iterable[BlockDevice], protected_disks: Iterable[str]) -> list[BlockDevice]:
    """Return only internal physical disks that cannot host a known role."""

    protected = {path for path in protected_disks if path}
    targets: list[BlockDevice] = []
    for device in devices:
        if not device.is_disk or not device.path:
            continue
        if device.path in protected or device.parent_disk in protected:
            continue
        if device.is_usb:
            continue
        if device.size_bytes <= 0:
            continue
        targets.append(device)
    return targets


def validate_config(
    config: object,
    models: Iterable[dict[str, object]],
    snapshot: dict[str, object],
    scorer: Callable[..., object],
    available_configs: Iterable[str] | None = None,
) -> ConfigValidation:
    """Validate an explicitly entered config against model.json and ``#configs``.

    ``available_configs`` is optional for backwards compatible, model-only
    validation.  When media has been inspected, HardwareCheck supplies the
    detected ``#configs`` folders so an operator learns about a missing payload
    *before* a destructive restore is made available.  A hardware mismatch is
    deliberately returned as an explicit warning, not a block: the production
    post-installation script performs its established final check again.
    """

    value = _text(config)
    if not re.fullmatch(r"\d{4}", value):
        return ConfigValidation(value, False, 0, "Config muss genau vier Ziffern enthalten.")
    model = next((item for item in models if _text(item.get("model_id")) == value), None)
    if model is None:
        return ConfigValidation(value, False, 0, "Config ist nicht in model.json vorhanden.")
    if available_configs is not None:
        config_folders = {_text(item) for item in available_configs}
        if value not in config_folders:
            if config_folders:
                message = f"Config {value} ist in model.json vorhanden, aber #configs\\{value} wurde auf dem Image-Medium nicht gefunden."
            else:
                message = "Kein lesbarer #configs-Ordner auf dem Image-Medium erkannt."
            return ConfigValidation(value, False, 0, message, model)
    try:
        raw_result = scorer(snapshot, model, include_exclusion_reason=True)
    except Exception as exc:
        return ConfigValidation(value, False, 0, f"Hardware-Abgleich fehlgeschlagen: {exc}", model)
    result = raw_result if isinstance(raw_result, dict) else {}
    details = tuple(
        _text(reason)
        for reason in result.get("reasons", [])
        if _text(reason)
    ) if isinstance(result.get("reasons"), list) else ()
    score = int(result.get("score") or 0)
    exclusion = _text(result.get("excluded"))
    if exclusion:
        return ConfigValidation(value, True, score, f"Warnung: Config passt möglicherweise nicht zum Gerät. {exclusion}", model, details)
    if score < 60:
        return ConfigValidation(
            value,
            True,
            score,
            "Warnung: Modellabgleich für diese bewusst gewählte Config ist schwach. Bitte Hardwaredaten prüfen.",
            model,
            details,
        )
    return ConfigValidation(value, True, score, f"Config passt plausibel zur erkannten Hardware ({score} %).", model, details)


def discover_config_ids(repository_roots: Iterable[str]) -> set[str]:
    """Return four-digit configuration folders from verified repositories."""

    configs: set[str] = set()
    for root_text in repository_roots:
        root = pathlib.Path(root_text)
        config_root = root / "#configs"
        try:
            for candidate in config_root.iterdir():
                if candidate.is_dir() and re.fullmatch(r"\d{4}", candidate.name):
                    configs.add(candidate.name)
        except OSError:
            continue
    return configs


def clonezilla_squashfs_source(roles: Iterable[MediaRole]) -> pathlib.Path | None:
    """Find the Clonezilla root filesystem through its verified media role."""

    for role in roles:
        if role.role != "clonezilla":
            continue
        candidate = pathlib.Path(role.mountpoint) / CLONEZILLA_SQUASHFS_RELATIVE_PATH
        try:
            if candidate.is_file():
                return candidate
        except OSError:
            continue
    return None


def probe_clonezilla(roles: Iterable[MediaRole] = ()) -> ClonezillaProbe:
    """Report a local engine or the verified external Clonezilla runtime source."""

    executable = shutil.which("ocs-sr") or ""
    if executable:
        return ClonezillaProbe(
            True,
            executable,
            f"ocs-sr gefunden: {executable}. CLI-Optionen werden vor einem Restore separat verifiziert.",
            source_path=executable,
        )
    source = clonezilla_squashfs_source(roles)
    if source:
        return ClonezillaProbe(
            False,
            "",
            "Clonezilla-Engine auf geschütztem Medium erkannt. Bitte die Backend-Diagnose ausführen.",
            source_path=str(source),
        )
    return ClonezillaProbe(False, "", "ocs-sr ist im laufenden HardwareCheck-Debian nicht verfügbar.")


def _run_command(command: list[str], runner: Callable[..., object], timeout: int = 45) -> tuple[int, str]:
    try:
        completed = runner(command, check=False, capture_output=True, text=True, timeout=timeout)
    except (FileNotFoundError, OSError, subprocess.SubprocessError) as exc:
        return 127, str(exc)
    output = "\n".join(
        value for value in (_text(getattr(completed, "stdout", "")), _text(getattr(completed, "stderr", ""))) if value
    )
    return int(getattr(completed, "returncode", 1)), output


def diagnose_clonezilla_runtime(
    inspection: MediaInspection, runner: Callable[..., object] = subprocess.run
) -> ClonezillaProbe:
    """Run a non-destructive ``ocs-sr`` usage check from the Clonezilla medium.

    The checked Clonezilla filesystem is loop-mounted read-only below ``/run``
    only for this diagnostic, then unmounted again.  The command is strictly
    ``ocs-sr --help``: no image, target device or restore subcommand can reach
    this function.
    """

    local = shutil.which("ocs-sr") or ""
    if local:
        exit_code, output = _run_command([local, "--help"], runner)
        verified = "Usage:" in output or "savedisk|saveparts|restoredisk" in output
        return ClonezillaProbe(
            verified,
            local,
            "Lokale Clonezilla-CLI wurde ohne Restore-Befehl geprüft."
            if verified
            else f"Lokale Clonezilla-CLI-Diagnose fehlgeschlagen (Exit-Code {exit_code}).",
            source_path=local,
            usage_verified=verified,
            log_excerpt=output[-2000:],
        )

    source = clonezilla_squashfs_source(inspection.roles)
    if not source:
        return ClonezillaProbe(False, "", "Kein geprüftes Clonezilla-Live-System mit filesystem.squashfs gefunden.")
    if not sys.platform.startswith("linux"):
        return ClonezillaProbe(False, "", "Die Clonezilla-Backend-Diagnose kann nur im HardwareCheck-Debian laufen.", str(source))
    if getattr(os, "geteuid", lambda: 1)() != 0:
        return ClonezillaProbe(False, "", "Die Clonezilla-Backend-Diagnose benötigt Root-Rechte im Live-System.", str(source))

    runtime_root = CLONEZILLA_RUNTIME_ROOT / f"clonezilla-{os.getpid()}"
    try:
        runtime_root.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return ClonezillaProbe(False, "", f"Clonezilla-Laufzeitordner kann nicht angelegt werden: {exc}", str(source))

    mounted = False
    mount_exit, mount_output = _run_command(
        ["mount", "-o", "ro,loop,nosuid,nodev", str(source), str(runtime_root)], runner
    )
    if mount_exit != 0:
        try:
            runtime_root.rmdir()
        except OSError:
            pass
        return ClonezillaProbe(
            False,
            "",
            f"Clonezilla-Dateisystem konnte nicht schreibgeschützt vorbereitet werden (Exit-Code {mount_exit}).",
            str(source),
            log_excerpt=mount_output[-2000:],
        )
    mounted = True
    try:
        exit_code, output = _run_command(
            ["chroot", str(runtime_root), "/usr/sbin/ocs-sr", "--help"], runner
        )
        verified = "Usage:" in output or "savedisk|saveparts|restoredisk" in output
        message = (
            "Clonezilla-Engine vom geschützten Medium erfolgreich geprüft; kein Restore wurde ausgeführt."
            if verified
            else f"Clonezilla-Engine-Diagnose fehlgeschlagen (Exit-Code {exit_code}); kein Restore wurde ausgeführt."
        )
        return ClonezillaProbe(
            verified,
            "chroot:/usr/sbin/ocs-sr",
            message,
            str(source),
            usage_verified=verified,
            log_excerpt=output[-2000:],
        )
    finally:
        if mounted:
            _run_command(["umount", str(runtime_root)], runner)
        try:
            runtime_root.rmdir()
        except OSError:
            pass


def build_restore_proof_plan(
    config: ConfigValidation, image: MagicImage, target: BlockDevice, inspection: MediaInspection
) -> RestoreProofPlan:
    """Create the exact restore command after all non-destructive gates pass.

    The plan is bound to the drive serial number.  Clonezilla itself expects a
    current Linux device path, which is resolved from that serial immediately
    before execution, after the final safety revalidation.  This function
    returns data only; it cannot start a restore.
    """

    if not config.valid:
        return RestoreProofPlan(False, "Config ist nicht gültig geprüft.")
    if not inspection.clonezilla.usage_verified:
        return RestoreProofPlan(False, "Clonezilla-Engine wurde noch nicht erfolgreich geprüft.")
    if not target.is_disk or target.is_usb or target.path in inspection.protected_disks:
        return RestoreProofPlan(False, "Ziel ist kein zulässiger interner, ungeschützter Datenträger.")
    serial = re.sub(r"\s+", "_", target.serial.strip())
    if not serial or not re.fullmatch(r"[A-Za-z0-9._+-]+", serial):
        return RestoreProofPlan(False, "Ziel-SSD hat keine für Clonezilla nutzbare Seriennummer.")

    image_path = pathlib.Path(image.image_path)
    repository_roots = [pathlib.Path(role.mountpoint) for role in inspection.roles if role.role == "repository"]
    repository: pathlib.Path | None = None
    image_name = _safe_name(image_path.name)
    if not image_name or image_name != image_path.name:
        return RestoreProofPlan(False, "Image-Ordnername ist für Clonezilla nicht zulässig.")
    for candidate in repository_roots:
        try:
            relative = image_path.resolve().relative_to(candidate.resolve())
        except (OSError, ValueError):
            continue
        if relative.parts == (image_name,):
            repository = candidate
            break
    if repository is None:
        return RestoreProofPlan(False, "Image liegt nicht unmittelbar im geprüften Magic-Image-Repository.")
    try:
        if not (image_path / "parts").is_file() or not (image_path / "disk").is_file():
            return RestoreProofPlan(False, "Image hat keine vollständige Clonezilla-Disk-Struktur.")
    except OSError:
        return RestoreProofPlan(False, "Image-Struktur konnte nicht erneut geprüft werden.")

    selector = f"SERIALNO={serial}"
    command = (
        "/usr/sbin/ocs-sr",
        "--batch",
        "-nogui",
        "-g",
        "auto",
        "-e1",
        "auto",
        "-e2",
        "-r",
        "-j2",
        "-p",
        "true",
        "restoredisk",
        image_name,
        selector,
    )
    confirmation = f"RESTORE {serial}"
    return RestoreProofPlan(
        True,
        "Restore ist vorbereitet. Die Ziel-SSD wird erst nach der expliziten Bestätigung gelöscht.",
        config=config.config,
        image_name=image_name,
        image_path=str(image_path),
        repository_path=str(repository),
        target_path=target.path,
        target_selector=selector,
        target_model=target.model,
        target_size_bytes=target.size_bytes,
        confirmation_text=confirmation,
        command=command,
    )


def find_windows_partition(target_path: str, devices: Iterable[BlockDevice]) -> BlockDevice | None:
    """Choose the restored Windows volume by filesystem, label and size."""

    candidates = [
        device
        for device in devices
        if device.type == "part"
        and device.parent_disk == target_path
        and device.filesystem in {"ntfs", "ntfs3"}
        and device.size_bytes >= 10 * 1024**3
    ]
    if not candidates:
        return None
    return max(
        candidates,
        key=lambda device: (
            int("windows" in device.label.lower()),
            device.size_bytes,
        ),
    )


def _restore_log_path(roles: Iterable[MediaRole]) -> pathlib.Path:
    """Prefer the HardwareCheck medium for durable local restore logs."""

    stamp = time.strftime("%Y%m%d-%H%M%S")
    candidates: list[pathlib.Path] = []
    for role in roles:
        if role.role != "hardwarecheck":
            continue
        root = pathlib.Path(role.mountpoint)
        candidates.extend((root / "HardwareCheck" / "hardwarecheck-debug" / "magic-image", root / "hardwarecheck-debug" / "magic-image"))
    candidates.append(pathlib.Path("/run") / "hardwarecheck-magic-logs")
    for directory in candidates:
        try:
            directory.mkdir(parents=True, exist_ok=True)
            return directory / f"restore-proof-{stamp}.log"
        except OSError:
            continue
    return pathlib.Path("/tmp") / f"hardwarecheck-restore-proof-{stamp}.log"


def _write_log(log_path: pathlib.Path, lines: Iterable[str]) -> None:
    try:
        log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError:
        pass


def execute_restore_proof(
    plan: RestoreProofPlan,
    inspection: MediaInspection,
    runner: Callable[..., object] = subprocess.run,
    device_reader: Callable[[Callable[..., object]], list[BlockDevice]] = collect_lsblk,
    progress_callback: Callable[[int, str], object] | None = None,
) -> RestoreProofResult:
    """Run the explicitly confirmed restore and offline Handoff transaction.

    This function is intentionally reachable only after HardwareCheck's final
    confirmation dialog.  It rechecks the target serial immediately before
    executing Clonezilla, runs no reboot action, and leaves a local log for
    every outcome.
    """

    if not plan.ready:
        return RestoreProofResult(False, "preflight", plan.message)
    if not sys.platform.startswith("linux"):
        return RestoreProofResult(False, "preflight", "Restore-Proof kann nur im HardwareCheck-Debian laufen.")
    if getattr(os, "geteuid", lambda: 1)() != 0:
        return RestoreProofResult(False, "preflight", "Restore-Proof benötigt Root-Rechte im Live-System.")

    log_path = _restore_log_path(inspection.roles)
    log_lines = [
        f"HardwareCheck Magic Image restore started: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"Target path at planning time: {plan.target_path}",
        f"Target selector: {plan.target_selector}",
        f"Image: {plan.image_name}",
        f"Repository: {plan.repository_path}",
        "The requested completion action is executed only after restore and handoff validation.",
    ]
    _write_log(log_path, log_lines)

    def report_progress(percent: int, message: str) -> None:
        if progress_callback is None:
            return
        try:
            progress_callback(max(0, min(100, int(percent))), message)
        except Exception:
            pass

    def record(name: str, command: list[str], timeout: int = 60) -> tuple[int, str]:
        exit_code, output = _run_command(command, runner, timeout)
        log_lines.extend((f"[{name}] command: {' '.join(command)}", f"[{name}] exit-code: {exit_code}"))
        if output:
            log_lines.append(f"[{name}] output:\n{output}")
        _write_log(log_path, log_lines)
        return exit_code, output

    def record_restore(command: list[str], timeout: int) -> tuple[int, str]:
        """Run Clonezilla while forwarding its Partclone percentage to the GUI.

        Test doubles retain the previous ``runner`` contract.  The live GTK
        path uses ``Popen`` so the operator sees actual Clonezilla progress
        instead of a frozen window until the process exits.
        """

        if progress_callback is None or runner is not subprocess.run:
            return record("clonezilla-restoredisk", command, timeout)
        report_progress(1, "Clonezilla startet …")
        output_parts: list[str] = []
        try:
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
            if process.stdout is not None:
                for line in process.stdout:
                    output_parts.append(line)
                    match = re.search(r"Comple(?:te|ted):\s*([0-9]+(?:\.[0-9]+)?)%", line, re.IGNORECASE)
                    if match:
                        report_progress(int(float(match.group(1))), "Clonezilla schreibt das Image …")
            exit_code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            output_parts.append("\nTimeout: Clonezilla-Restore überschritt die erlaubte Laufzeit.\n")
            exit_code = 124
        except OSError as exc:
            output_parts.append(f"\nClonezilla konnte nicht gestartet werden: {exc}\n")
            exit_code = 127
        output = "".join(output_parts)
        log_lines.extend((f"[clonezilla-restoredisk] command: {' '.join(command)}", f"[clonezilla-restoredisk] exit-code: {exit_code}"))
        if output:
            log_lines.append(f"[clonezilla-restoredisk] output:\n{output}")
        _write_log(log_path, log_lines)
        return exit_code, output

    devices = device_reader(runner)
    planned_serial = plan.target_selector.removeprefix("SERIALNO=")
    matching_targets = [
        device
        for device in devices
        if device.is_disk and re.sub(r"\s+", "_", device.serial.strip()) == planned_serial
    ]
    current_target = matching_targets[0] if len(matching_targets) == 1 else None
    current_serial = re.sub(r"\s+", "_", current_target.serial.strip()) if current_target else ""
    expected_model = re.sub(r"\s+", " ", plan.target_model.strip())
    current_model = re.sub(r"\s+", " ", current_target.model.strip()) if current_target else ""
    if (
        current_target is None
        or current_target.is_usb
        or current_target.path in inspection.protected_disks
        or current_serial != planned_serial
        or (expected_model and current_model != expected_model)
        or (plan.target_size_bytes and current_target.size_bytes != plan.target_size_bytes)
    ):
        message = "Ziel-SSD hat sich seit der Bestätigung geändert, ist mehrdeutig oder nicht mehr zulässig; Restore abgebrochen."
        log_lines.append(message)
        _write_log(log_path, log_lines)
        return RestoreProofResult(False, "preflight", message, log_path=str(log_path))
    log_lines.append(f"Validated current Clonezilla target: {current_target.path} ({current_target.serial})")

    source = pathlib.Path(inspection.clonezilla.source_path)
    repository = pathlib.Path(plan.repository_path)
    image_path = pathlib.Path(plan.image_path)
    try:
        source_ok = source.is_file()
        image_ok = image_path.is_dir() and (image_path / "parts").is_file() and (image_path / "disk").is_file()
        repository_ok = image_path.resolve().parent == repository.resolve()
    except OSError:
        source_ok = image_ok = repository_ok = False
    if not source_ok or not image_ok or not repository_ok:
        message = "Clonezilla-Quelle oder geprüftes Image ist vor Restore nicht mehr unverändert verfügbar; Restore abgebrochen."
        log_lines.append(message)
        _write_log(log_path, log_lines)
        return RestoreProofResult(False, "preflight", message, log_path=str(log_path))

    nonce = uuid.uuid4().hex
    runtime_root = CLONEZILLA_RUNTIME_ROOT / f"restore-engine-{nonce}"
    workspace = CLONEZILLA_RUNTIME_ROOT / f"restore-work-{nonce}"
    mounted_engine = mounted_home = mounted_repository = mounted_workspace = mounted_windows = False
    mounted_tmp = mounted_run = mounted_var_log = mounted_var_lib = False
    mounted_dev = mounted_proc = mounted_sys = False
    clonezilla_exit: int | None = None
    output_excerpt = ""
    handoff_path = ""
    try:
        runtime_root.mkdir(parents=True, exist_ok=False)
        (workspace / "windows").mkdir(parents=True, exist_ok=False)
        (workspace / "home" / "partimag").mkdir(parents=True, exist_ok=False)
        (workspace / "tmp").mkdir(parents=True, exist_ok=False)
        (workspace / "run").mkdir(parents=True, exist_ok=False)
        (workspace / "var" / "log" / "clonezilla").mkdir(parents=True, exist_ok=False)
        (workspace / "var" / "lib" / "clonezilla").mkdir(parents=True, exist_ok=False)
    except OSError as exc:
        message = f"Laufzeitordner für Restore-Proof kann nicht angelegt werden: {exc}"
        log_lines.append(message)
        _write_log(log_path, log_lines)
        return RestoreProofResult(False, "preflight", message, log_path=str(log_path))

    try:
        exit_code, output = record("mount-clonezilla-readonly", ["mount", "-o", "ro,loop,nosuid,nodev", str(source), str(runtime_root)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-mount", "Clonezilla-Engine konnte nicht schreibgeschützt vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_engine = True
        home_target = runtime_root / "home"
        mnt_target = runtime_root / "mnt"
        tmp_target = runtime_root / "tmp"
        run_target = runtime_root / "run"
        log_target = runtime_root / "var" / "log"
        lib_target = runtime_root / "var" / "lib"
        dev_target = runtime_root / "dev"
        proc_target = runtime_root / "proc"
        sys_target = runtime_root / "sys"
        runtime_targets = (home_target, mnt_target, tmp_target, run_target, log_target, lib_target, dev_target, proc_target, sys_target)
        if not all(target.is_dir() for target in runtime_targets):
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Laufzeitumgebung hat keinen erwarteten Mountpunkt.", log_path=str(log_path))
        # Clonezilla Live normally runs on a writable overlay filesystem.  The
        # TEST backend deliberately mounts its squashfs read-only, therefore
        # the mutable areas have to be supplied from an isolated RAM workspace.
        exit_code, output = record("bind-clonezilla-tmp", ["mount", "--bind", str(workspace / "tmp"), str(tmp_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Temp-Verzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_tmp = True
        exit_code, output = record("bind-clonezilla-run", ["mount", "--bind", str(workspace / "run"), str(run_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Run-Verzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_run = True
        exit_code, output = record("bind-clonezilla-var-log", ["mount", "--bind", str(workspace / "var" / "log"), str(log_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Log-Verzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_var_log = True
        exit_code, output = record("bind-clonezilla-var-lib", ["mount", "--bind", str(workspace / "var" / "lib"), str(lib_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Statusverzeichnis konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_var_lib = True

        # A chroot into the read-only Clonezilla squashfs needs the live
        # kernel interfaces as well.  rbind preserves devpts and the other
        # nested mounts; rslave prevents cleanup from propagating to the host.
        for name, source_path, target_path in (
            ("dev", "/dev", dev_target),
            ("proc", "/proc", proc_target),
            ("sys", "/sys", sys_target),
        ):
            exit_code, output = record(f"bind-clonezilla-{name}", ["mount", "--rbind", source_path, str(target_path)])
            if exit_code != 0:
                return RestoreProofResult(False, "engine-layout", f"Clonezilla-Systempfad /{name} konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
            if name == "dev":
                mounted_dev = True
            elif name == "proc":
                mounted_proc = True
            else:
                mounted_sys = True
            exit_code, output = record(f"isolate-clonezilla-{name}", ["mount", "--make-rslave", str(target_path)])
            if exit_code != 0:
                return RestoreProofResult(False, "engine-layout", f"Clonezilla-Systempfad /{name} konnte nicht isoliert werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        exit_code, output = record("bind-clonezilla-home", ["mount", "--bind", str(workspace / "home"), str(home_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "engine-layout", "Clonezilla-Home konnte nicht für das Image-Repository vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_home = True
        partimag_target = home_target / "partimag"
        exit_code, output = record("bind-image-repository", ["mount", "--bind", str(repository), str(partimag_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "repository-mount", "Image-Repository konnte nicht an Clonezilla übergeben werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_repository = True
        exit_code, output = record("remount-image-repository-readonly", ["mount", "-o", "remount,bind,ro", str(partimag_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "repository-mount", "Image-Repository konnte nicht schreibgeschützt an Clonezilla gebunden werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        exit_code, output = record("bind-handoff-workspace", ["mount", "--bind", str(workspace), str(mnt_target)])
        if exit_code != 0:
            return RestoreProofResult(False, "workspace-mount", "Handoff-Arbeitsbereich konnte nicht vorbereitet werden.", log_path=str(log_path), output_excerpt=output[-2000:])
        mounted_workspace = True

        if not plan.command or plan.command[-1] != plan.target_selector:
            return RestoreProofResult(False, "preflight", "Clonezilla-Plan ist nicht konsistent; Restore abgebrochen.", log_path=str(log_path))
        runtime_restore_command = [*plan.command[:-1], current_target.path]
        clonezilla_command = [
            "chroot",
            str(runtime_root),
            "/usr/bin/env",
            "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "TERM=linux",
            "HOME=/root",
            "TMPDIR=/tmp",
            *runtime_restore_command,
        ]
        report_progress(1, "Clonezilla-Umgebung wird vorbereitet …")
        clonezilla_exit, output = record_restore(clonezilla_command, timeout=6 * 60 * 60)
        output_excerpt = output[-2000:]
        if clonezilla_exit != 0:
            return RestoreProofResult(
                False,
                "clonezilla",
                f"Clonezilla-Restore fehlgeschlagen (Exit-Code {clonezilla_exit}). Windows wird nicht gestartet.",
                clonezilla_exit,
                str(log_path),
                output_excerpt=output_excerpt,
            )

        record("settle-restored-disk", ["sync"])
        refreshed = device_reader(runner)
        windows_partition = find_windows_partition(current_target.path, refreshed)
        if windows_partition is None:
            return RestoreProofResult(
                False,
                "handoff-detect",
                "Clonezilla war erfolgreich, aber keine große Windows-NTFS-Partition wurde gefunden. Windows wird nicht gestartet.",
                clonezilla_exit,
                str(log_path),
                output_excerpt=output_excerpt,
            )
        exit_code, output = record(
            "mount-restored-windows",
            ["chroot", str(runtime_root), "/usr/bin/ntfs-3g", windows_partition.path, "/mnt/windows", "-o", "rw,uid=0,gid=0,umask=022"],
        )
        if exit_code != 0:
            return RestoreProofResult(
                False,
                "handoff-mount",
                "Clonezilla war erfolgreich, aber die Windows-Partition konnte für den Handoff nicht eingebunden werden. Windows wird nicht gestartet.",
                clonezilla_exit,
                str(log_path),
                output_excerpt=output[-2000:],
            )
        mounted_windows = True
        report_progress(100, "Windows-Handoff wird geschrieben …")
        handoff_file = workspace / "windows" / "MagicImage" / "hardwarecheck-config.txt"
        handoff_file.parent.mkdir(parents=True, exist_ok=True)
        with handoff_file.open("w", encoding="ascii", newline="\n") as handle:
            handle.write(config_value := plan.config + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        if handoff_file.read_text(encoding="ascii") != config_value:
            return RestoreProofResult(
                False,
                "handoff-verify",
                "Handoff-Datei konnte nicht erneut validiert werden. Windows wird nicht gestartet.",
                clonezilla_exit,
                str(log_path),
            )
        handoff_path = HANDOFF_WINDOWS_PATH
        log_lines.append(f"Handoff written and validated: {handoff_path} -> {config_value.strip()}")
        _write_log(log_path, log_lines)
        record("sync-handoff", ["sync"])
        return RestoreProofResult(
            True,
            "complete",
            "Restore und Windows-Handoff erfolgreich. Der gewählte Abschluss wird jetzt ausgeführt.",
            clonezilla_exit,
            str(log_path),
            handoff_path,
            output_excerpt,
        )
    finally:
        if mounted_windows:
            record("unmount-restored-windows", ["umount", str(workspace / "windows")])
        if mounted_workspace:
            record("unmount-handoff-workspace", ["umount", str(runtime_root / "mnt")])
        if mounted_repository:
            record("unmount-image-repository", ["umount", str(runtime_root / "home" / "partimag")])
        if mounted_home:
            record("unmount-clonezilla-home", ["umount", str(runtime_root / "home")])
        if mounted_var_log:
            record("unmount-clonezilla-var-log", ["umount", str(runtime_root / "var" / "log")])
        if mounted_var_lib:
            record("unmount-clonezilla-var-lib", ["umount", str(runtime_root / "var" / "lib")])
        if mounted_tmp:
            record("unmount-clonezilla-tmp", ["umount", str(runtime_root / "tmp")])
        if mounted_run:
            record("unmount-clonezilla-run", ["umount", str(runtime_root / "run")])
        if mounted_sys:
            record("unmount-clonezilla-sys", ["umount", "--recursive", str(runtime_root / "sys")])
        if mounted_proc:
            record("unmount-clonezilla-proc", ["umount", "--recursive", str(runtime_root / "proc")])
        if mounted_dev:
            record("unmount-clonezilla-dev", ["umount", "--recursive", str(runtime_root / "dev")])
        if mounted_engine:
            record("unmount-clonezilla-engine", ["umount", str(runtime_root)])
        for path in (
            workspace / "windows",
            workspace / "home" / "partimag",
            workspace / "home",
            workspace / "tmp",
            workspace / "run",
            workspace / "var" / "log" / "clonezilla",
            workspace / "var" / "log",
            workspace / "var" / "lib" / "clonezilla",
            workspace / "var" / "lib",
            workspace / "var",
            workspace,
            runtime_root,
        ):
            try:
                path.rmdir()
            except OSError:
                pass


def inspect_media(runner: Callable[..., object] = subprocess.run) -> MediaInspection:
    devices = collect_lsblk(runner)
    inspection = MediaInspection(devices=devices)
    if not devices:
        inspection.warnings.append("Datenträger konnten nicht über lsblk gelesen werden.")
        return inspection
    # The Clonezilla and image partitions may not be mounted when the
    # HardwareCheck live system starts.  Inspect only external partitions and
    # mount those read-only before looking for our marker files.  A fresh
    # lsblk pass is required because udisksctl can choose its own mount path.
    mounted, mount_warnings = mount_external_partitions_read_only(devices, runner)
    inspection.mounted_read_only = mounted
    inspection.warnings.extend(mount_warnings)
    if mounted:
        devices = collect_lsblk(runner)
        inspection.devices = devices
    inspection.roles = discover_media_roles(devices, pathlib.Path(__file__).resolve().parent)
    inspection.protected_disks = {role.parent_disk for role in inspection.roles}
    repositories = [role.mountpoint for role in inspection.roles if role.role == "repository"]
    inspection.config_repository_paths = tuple(repositories)
    inspection.available_configs = discover_config_ids(repositories)
    inspection.images = discover_images(repositories)
    inspection.safe_targets = safe_restore_targets(devices, inspection.protected_disks)
    inspection.clonezilla = probe_clonezilla(inspection.roles)
    if mounted:
        inspection.warnings.insert(0, f"Schreibgeschützt eingehängt: {', '.join(mounted)}.")
    if not repositories:
        inspection.warnings.append("Kein Magic-Image-Repository erkannt.")
    elif not inspection.available_configs:
        inspection.warnings.append("Im Image-Repository wurde kein lesbarer #configs-Ordner erkannt.")
    if not inspection.safe_targets:
        inspection.warnings.append("Kein zulässiger interner Zieldatenträger erkannt.")
    return inspection


def build_simulation_summary(config: ConfigValidation, image: MagicImage, target: BlockDevice, inspection: MediaInspection) -> str:
    """Build an auditable job preview without creating or running a command."""

    roles = ", ".join(f"{role.role}: {role.parent_disk}" for role in inspection.roles) or "keine Rollen erkannt"
    return "\n".join(
        (
            "SIMULATION – kein Clonezilla- oder Schreibvorgang wurde gestartet.",
            f"Config: {config.config} ({config.score} % Hardware-Match)",
            f"Image: {image.display_name}",
            f"Image-Pfad: {image.image_path}",
            f"Ziel: {target.description}",
            f"Zielkennung: {target.stable_identity}",
            f"Geschützte Medien: {roles}",
            f"Clonezilla-Backend: {inspection.clonezilla.message}",
            f"Geplanter Windows-Handoff: {HANDOFF_WINDOWS_PATH} mit Config {config.config}",
            "Vor echtem Restore: Ziel erneut über Seriennummer/WWN, Modell und Größe validieren.",
        )
    )
